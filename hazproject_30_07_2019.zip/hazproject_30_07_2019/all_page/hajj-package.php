<?php
/**
 * The hajj package template file
 *
 * This is the most generic template file in a WordPress theme
 * and one of the two required files for a theme (the other being style.css).
 * It is used to display a page when nothing more specific matches a query.
 * E.g., it puts together the home page when no home.php file exists.
 *
 * @link https://developer.wordpress.org/themes/basics/template-hierarchy/
 *
 * @package aynix
 */
 /*
  Template Name: hajj-package
*/
get_header(); ?>
      
         <!-- mobile-menu-area start -->
        <div class="mobile-menu-area">
          <div class="container">
            <div class="row">
              <div class="col-md-12">
                <div class="mobile-menu">
                  <nav id="dropdown">
                    <ul>
                        <li class="active"><a href="#">Home</a>
                            <ul>
                                <li><a href="#">Sub Item</a></li>
                                <li><a href="#">Sub Item</a></li>
                                <li><a href="#">Sub Item</a></li>
                                <li><a href="#">Sub Item</a></li>
                                <li><a href="#">Sub Item</a></li>
                                <li><a href="#">Sub Item</a></li>
                                <li><a href="#">Sub Item</a></li>
                            </ul>
                        </li>
                        <li><a href="#">Projects</a></li>
                        <li><a href="#">Activities</a></li>
                        <li><a href="#">Total Jobs</a></li>
                        <li><a href="#">Flights</a></li>
                        <li><a href="#">Hotels</a></li>
                    </ul>
                  </nav>
                </div>
              </div>
            </div>
          </div>
        </div>
        <!-- mobile-menu-area end -->



        <div class="hajj-pack has-border has-border">
            <div class="container">
                <div class="row">
                    <div class="col-lg-10">
                        <div class="pk-title">
                            <h1>Hajj Packages</h1>
                        </div>

                        <ul class="hajj-pk-item">

                            <li>
                                <h3>21-23 Days Hajj Package</h3>
                                <p>21-23 Days Tentative Hajj Package with Fairmont Clock Tower hotel accommodation (Half Board) in Makkah. Hotel Dar Al Hijra Intercon will be the hotel in Madinah. In Azizia Markaz 2 building with sharing four to six people and 3-time dish meal will be provided as well. Air Ticket is not included in the package.</p>
                                <figure>
                                    <a href="<?php echo esc_url(get_template_directory_uri());?>/img/1494489629-hajjpackages-image.jpg">
                                        <img src="<?php echo esc_url(get_template_directory_uri());?>/img/1494489629-hajjpackages-image.jpg">
                                    </a>
                                </figure>
                            </li>

                            <li>
                                <h3>21-23 Days Hajj Package</h3>
                                <p>21-23 Days Tentative Hajj Package with Fairmont Clock Tower hotel accommodation (Half Board) in Makkah. Hotel Dar Al Hijra Intercon will be the hotel in Madinah. In Azizia Markaz 2 building with sharing four to six people and 3-time dish meal will be provided as well. Air Ticket is not included in the package.</p>
                                <figure>
                                    <a href="<?php echo esc_url(get_template_directory_uri());?>/img/1494489629-hajjpackages-image.jpg">
                                        <img src="<?php echo esc_url(get_template_directory_uri());?>/img/1494489629-hajjpackages-image.jpg">
                                    </a>
                                </figure>
                            </li>

                            
                            <li>
                                <h3>21-23 Days Hajj Package</h3>
                                <p>21-23 Days Tentative Hajj Package with Fairmont Clock Tower hotel accommodation (Half Board) in Makkah. Hotel Dar Al Hijra Intercon will be the hotel in Madinah. In Azizia Markaz 2 building with sharing four to six people and 3-time dish meal will be provided as well. Air Ticket is not included in the package.</p>
                                <figure>
                                    <a href="<?php echo esc_url(get_template_directory_uri());?>/img/1494489629-hajjpackages-image.jpg">
                                        <img src="<?php echo esc_url(get_template_directory_uri());?>/img/1494489629-hajjpackages-image.jpg">
                                    </a>
                                </figure>
                            </li>

                        </ul> 

                    </div>
                </div>
            </div>
        </div>
<?php get_footer();?>