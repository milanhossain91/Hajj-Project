<?php
function newdesign(){

  add_theme_support('title_tag');
  add_theme_support('custom-header');
  add_theme_support('custom-background');
  add_theme_support('post-thumbnails');
  add_theme_support( 'post-formats', array( 'aside', 'gallery','audio','video' ) );
  add_theme_support( 'html5', array( 'comment-list', 'comment-form', 'search-form', 'gallery', 'caption' ) );
    add_theme_support('slide-image',1024,500,true);
    add_theme_support('serviceimg',90,90,true);

  load_theme_textdomain('newdesign',get_template_directory_uri().'/language');
/*registration menus*/
 register_nav_menus(array(



    'main_menu' =>__('Main menu','newdesign'),
    'footer_menu' =>__('Footer menu','newdesign')

    ));
 /*registration gallerypages
   register_post_type('sliders',array(

  'labels' => array(
         'name' => 'sliders',
         'add_new_item' => 'add new sliders'

    ),
  'public' => true,
  'menu_icon'       => 'dashicons-slides',
  'supports' => array('title','editor','thumbnail','excerpt','custom-fields')



  ));




*/

    $labelsumra = array(
      
        'name'                => _x( 'Umrah', 'Post Type General Name', 'twentythirteen' ),
        'singular_name'       => _x( 'Umrah', 'Post Type Singular Name', 'twentythirteen' ),
        'menu_name'           => __( 'Umrah', 'twentythirteen' ),
        'parent_item_colon'   => __( 'Parent Umrah', 'twentythirteen' ),
        'all_items'           => __( 'All Umrah', 'twentythirteen' ),
        'view_item'           => __( 'View Umrah', 'twentythirteen' ),
        'add_new_item'        => __( 'Add New', 'twentythirteen' ),
        'add_new'             => __( 'Add New', 'twentythirteen' ),
        'edit_item'           => __( 'Edit Umrah', 'twentythirteen' ),
        'update_item'         => __( 'Update Umrah', 'twentythirteen' ),
        'search_items'        => __( 'Search Umrah', 'twentythirteen' ),
        'not_found'           => __( 'Not Found', 'twentythirteen' ),
        'not_found_in_trash'  => __( 'Not found in Trash', 'twentythirteen' ),

    );

   $argsumrah = array(
        'label'               => __( 'Umrah', 'twentythirteen' ),
        'description'         => __( 'Umrah news and reviews', 'twentythirteen' ),
        'labels'              => $labelsumra,
       
        'hierarchical'        => true,
        'public'              => true,
        'show_ui'             => true,
        'show_in_menu'        => true,
        'show_in_nav_menus'   => true,
        'show_in_admin_bar'   => true,
        'menu_position'       => 5,
        'can_export'          => true,
        'has_archive'         => true,
        'exclude_from_search' => false,
        'publicly_queryable'  => true,
        'capability_type'     => 'post',
         
        // This is where we add taxonomies to our CPT
        
        'taxonomies' => array('Location','promotions'),
          
          'menu_icon'       => 'dashicons-palmtree',
          'supports' => array( 'title', 'editor', 'author', 'thumbnail', 'excerpt', 'comments'  )



  );

   register_post_type( 'umrah', $argsumrah );

      register_taxonomy( 'no_of_days', 'umrah', array(

        'labels' => array(

          'name' => 'No of Days'


        ),

        'rewrite' => array( 'slug' => 'genre' ),
      

    'hierarchical' => true,

      )

      
    );

      register_taxonomy( 'package_city', 'umrah', array(

        'labels' => array(

          'name' => 'Package City'


        ),
      
    'rewrite' => array( 'slug' => 'genre' ),
    'hierarchical' => true,

      )

      
    );

    register_taxonomy( 'hotel_name', 'umrah', array(

        'labels' => array(

          'name' => 'Hotel Name'


        ),
      
    'rewrite' => array( 'slug' => 'genre' ),
    'hierarchical' => true,

      ));

    register_taxonomy( 'price_range', 'umrah', array(

        'labels' => array(

          'name' => 'Price Range'


        ),
      
    'rewrite' => array( 'slug' => 'genre' ),
    'hierarchical' => true,

      ));

    register_taxonomy( 'package_class', 'umrah', array(

        'labels' => array(

          'name' => 'Package Class'


        ),
      
    'rewrite' => array( 'slug' => 'genre' ),
    'hierarchical' => true,

      ));
  }
add_action('init','newdesign');
 /* register Hotel Post type
     $labelargsrestaurant = array(
      
        'name'                => _x( 'Restaurant', 'Post Type General Name', 'twentythirteen' ),
        'singular_name'       => _x( 'Restaurant', 'Post Type Singular Name', 'twentythirteen' ),
        'menu_name'           => __( 'Restaurant', 'twentythirteen' ),
        'parent_item_colon'   => __( 'Parent Restaurant', 'twentythirteen' ),
        'all_items'           => __( 'All Restaurant', 'twentythirteen' ),
        'view_item'           => __( 'View Restaurant', 'twentythirteen' ),
        'add_new_item'        => __( 'Add New', 'twentythirteen' ),
        'add_new'             => __( 'Add New', 'twentythirteen' ),
        'edit_item'           => __( 'Edit Restaurant', 'twentythirteen' ),
        'update_item'         => __( 'Update Restaurant', 'twentythirteen' ),
        'search_items'        => __( 'Search Restaurant', 'twentythirteen' ),
        'not_found'           => __( 'Not Found', 'twentythirteen' ),
        'not_found_in_trash'  => __( 'Not found in Trash', 'twentythirteen' ),

    );

   $argsrestaurant = array(
        'label'               => __( 'Restaurant', 'twentythirteen' ),
        'description'         => __( 'Restaurant news and reviews', 'twentythirteen' ),
        'labels'              => $labelargsrestaurant,
       
        'hierarchical'        => true,
        'public'              => true,
        'show_ui'             => true,
        'show_in_menu'        => true,
        'show_in_nav_menus'   => true,
        'show_in_admin_bar'   => true,
        'menu_position'       => 5,
        'can_export'          => true,
        'has_archive'         => true,
        'exclude_from_search' => false,
        'publicly_queryable'  => true,
        'capability_type'     => 'post',
         
        // This is where we add taxonomies to our CPT
        
        'taxonomies' => array('Location','promotions'),
          
          'menu_icon'       => 'dashicons-cart',
          'supports' => array( 'title', 'editor', 'thumbnail', )



  );

   register_post_type( 'restaurant', $argsrestaurant );




   $labeltransport = array(
      
        'name'                => _x( 'Transport', 'Post Type General Name', 'twentythirteen' ),
        'singular_name'       => _x( 'Transport', 'Post Type Singular Name', 'twentythirteen' ),
        'menu_name'           => __( 'Transport', 'twentythirteen' ),
        'parent_item_colon'   => __( 'Parent Transport', 'twentythirteen' ),
        'all_items'           => __( 'All Transport', 'twentythirteen' ),
        'view_item'           => __( 'View Transport', 'twentythirteen' ),
        'add_new_item'        => __( 'Add New', 'twentythirteen' ),
        'add_new'             => __( 'Add New', 'twentythirteen' ),
        'edit_item'           => __( 'Edit Transport', 'twentythirteen' ),
        'update_item'         => __( 'Update Transport', 'twentythirteen' ),
        'search_items'        => __( 'Search Transport', 'twentythirteen' ),
        'not_found'           => __( 'Not Found', 'twentythirteen' ),
        'not_found_in_trash'  => __( 'Not found in Trash', 'twentythirteen' ),

    );

   $argstransport = array(
        'label'               => __( 'Transport', 'twentythirteen' ),
        'description'         => __( 'Transport news and reviews', 'twentythirteen' ),
        'labels'              => $labeltransport,
       
        'hierarchical'        => true,
        'public'              => true,
        'show_ui'             => true,
        'show_in_menu'        => true,
        'show_in_nav_menus'   => true,
        'show_in_admin_bar'   => true,
        'menu_position'       => 5,
        'can_export'          => true,
        'has_archive'         => true,
        'exclude_from_search' => false,
        'publicly_queryable'  => true,
        'capability_type'     => 'post',
         
        // This is where we add taxonomies to our CPT
        
        'taxonomies' => array('Location','promotions'),
          
          'menu_icon'       => 'dashicons-flag',
          'supports' => array( 'title', 'editor', 'author', 'thumbnail', 'excerpt', 'comments'  )



  );

   register_post_type( 'transport', $argstransport );

      register_taxonomy( 'transportno_of_days', 'transport', array(

        'labels' => array(

          'name' => 'No of Days'


        ),

        'rewrite' => array( 'slug' => 'genre' ),
      

    'hierarchical' => true,

      )

      
    );

      register_taxonomy( 'transportpackage_city', 'transport', array(

        'labels' => array(

          'name' => 'Package City'


        ),
      
    'rewrite' => array( 'slug' => 'genre' ),
    'hierarchical' => true,

      )

      
    );

    register_taxonomy( 'transporthotel_name', 'transport', array(

        'labels' => array(

          'name' => 'Hotel Name'


        ),
      
    'rewrite' => array( 'slug' => 'genre' ),
    'hierarchical' => true,

      ));

    register_taxonomy( 'transportprice_range', 'transport', array(

        'labels' => array(

          'name' => 'Price Range'


        ),
      
    'rewrite' => array( 'slug' => 'genre' ),
    'hierarchical' => true,

      ));

    register_taxonomy( 'transportpackage_class', 'transport', array(

        'labels' => array(

          'name' => 'Package Class'


        ),
      
    'rewrite' => array( 'slug' => 'genre' ),
    'hierarchical' => true,

      ));









  $labelsumra = array(
      
        'name'                => _x( 'Tours', 'Post Type General Name', 'twentythirteen' ),
        'singular_name'       => _x( 'Tours', 'Post Type Singular Name', 'twentythirteen' ),
        'menu_name'           => __( 'Tours', 'twentythirteen' ),
        'parent_item_colon'   => __( 'Parent Tours', 'twentythirteen' ),
        'all_items'           => __( 'All Tours', 'twentythirteen' ),
        'view_item'           => __( 'View Tours', 'twentythirteen' ),
        'add_new_item'        => __( 'Add New', 'twentythirteen' ),
        'add_new'             => __( 'Add New', 'twentythirteen' ),
        'edit_item'           => __( 'Edit Tours', 'twentythirteen' ),
        'update_item'         => __( 'Update Tours', 'twentythirteen' ),
        'search_items'        => __( 'Search Tours', 'twentythirteen' ),
        'not_found'           => __( 'Not Found', 'twentythirteen' ),
        'not_found_in_trash'  => __( 'Not found in Trash', 'twentythirteen' ),

    );

   $argsumrah = array(
        'label'               => __( 'Tours', 'twentythirteen' ),
        'description'         => __( 'Tours news and reviews', 'twentythirteen' ),
        'labels'              => $labelsumra,
       
        'hierarchical'        => true,
        'public'              => true,
        'show_ui'             => true,
        'show_in_menu'        => true,
        'show_in_nav_menus'   => true,
        'show_in_admin_bar'   => true,
        'menu_position'       => 5,
        'can_export'          => true,
        'has_archive'         => true,
        'exclude_from_search' => false,
        'publicly_queryable'  => true,
        'capability_type'     => 'post',
         
        // This is where we add taxonomies to our CPT
        
        'taxonomies' => array('Location','promotions'),
          
          'menu_icon'       => 'dashicons-palmtree',
          'supports' => array( 'title', 'editor', 'author', 'thumbnail', 'excerpt', 'comments'  )



  );

   register_post_type( 'tours', $argsumrah );

      register_taxonomy( 'Tourlocation', 'tours', array(

        'labels' => array(

          'name' => 'Location'


        ),

        'rewrite' => array( 'slug' => 'genre' ),
      

    'hierarchical' => true,

      )

      
    );

      register_taxonomy( 'Tourhotelname', 'tours', array(

        'labels' => array(

          'name' => 'Hotel Name'


        ),
      
    'rewrite' => array( 'slug' => 'genre' ),
    'hierarchical' => true,

      )

      
    );

    register_taxonomy( 'Tourprice', 'tours', array(

        'labels' => array(

          'name' => 'Price'


        ),
      
    'rewrite' => array( 'slug' => 'genre' ),
    'hierarchical' => true,

      ));

    register_taxonomy( 'facilities', 'tours', array(

        'labels' => array(

          'name' => 'Facilities'


        ),
      
    'rewrite' => array( 'slug' => 'genre' ),
    'hierarchical' => true,

      ));

    register_taxonomy( 'departuretime', 'tours', array(

        'labels' => array(

          'name' => 'Departure Time'


        ),
      
    'rewrite' => array( 'slug' => 'genre' ),
    'hierarchical' => true,

      ));

      
    





  

       
register_post_type('cars',array(

    'labels' => array(
         'name' => 'Cars',
         'add_new_item' => 'add new'

        ),
    'public' => true,
  'menu_icon'        => 'dashicons-dashboard',
    'supports' => array('title','editor','thumbnail','excerpt','custom-fields')



    ));

   register_taxonomy( 'CarsName', 'cars', array(

        'labels' => array(

          'name' => 'Cars Name'


        ),
      

    'hierarchical' => true,

      )

      
    );

     register_taxonomy( 'CarsFeatures', 'cars', array(

        'labels' => array(

          'name' => 'Cars Features'


        ),
      

    'hierarchical' => true,

      )

      
    );
 
   register_taxonomy( 'CarsLocation', 'cars', array(

        'labels' => array(

          'name' => 'Cars Location'


        ),
      

    'hierarchical' => true,

      )

      
    );
 

   register_taxonomy( 'DefaultEquipment', 'cars', array(

        'labels' => array(

          'name' => 'Default Equipment'


        ),
      

    'hierarchical' => true,

      )

      
    );
 
 }
 add_action('init','newdesign');
  




 function tours_hajj_metaboxes() {

    $umrah = new_cmb2_box( array(
    'id'            => 'tours',
    'title'         => __( 'Tours Package', 'cmb2' ),
    'object_types'  => array( 'tours', ), // Post type
    'context'       => 'normal',
    'priority'      => 'high',
    'show_names'    => true, 

  ) );

  $umrah->add_field( array(
    'name' => esc_html__( 'Departure date', 'cmb2' ),
    'desc' => esc_html__( 'Tours Departure date', 'cmb2' ),
    'id' => $prefix . 'toursdeparturedate',
    'type' => 'text_date',
  ) );

  $umrah->add_field( array(
    'name' => esc_html__( 'Arrive date', 'cmb2' ),
    'desc' => esc_html__( 'Tours Arrive date', 'cmb2' ),
    'id' => $prefix . 'toursarrivedate',
    'type' => 'text_date',
  ) );



  $umrah->add_field( array(
    'name' => esc_html__( 'Tours Name', 'cmb2' ),
    'desc' => esc_html__( 'Tours Package Name', 'cmb2' ),
    'id'   => 'toursname',
    
    'type' => 'text',
  ) );

  $umrah->add_field( array(
    'name' => esc_html__( 'Email', 'cmb2' ),
    'desc' => esc_html__( 'Tour Email', 'cmb2' ),
    'id'   => 'toursemail',
    
    'type' => 'text_email',
  ) );

  $umrah->add_field( array(
    'name' => esc_html__( 'Location', 'cmb2' ),
    'desc' => esc_html__( 'Tours Location', 'cmb2' ),
    'id'   => 'tourlocation',
    
    'type' => 'text',
  ) );

    $umrah->add_field( array(
    'name' => esc_html__( 'Price', 'cmb2' ),
    'desc' => esc_html__( 'Price', 'cmb2' ),
    'id'   => 'toursprice',
    
    'type' => 'text_money',
  ) );

  $umrah->add_field( array(
    'name' => esc_html__( 'Tours Type', 'cmb2' ),
    'desc' => esc_html__( 'Tours Type', 'cmb2' ),
    'id'   => 'tourstype',
    
    'type' => 'text',
  ) );

  $umrah->add_field( array(
    'name' => esc_html__( 'Maximum Number of People', 'cmb2' ),
    'desc' => esc_html__( 'Maximum Number of People', 'cmb2' ),
    'id'   => 'maximumnumberof',
    
    'type' => 'text',
  ) );

    $umrah->add_field( array(
    'name' => esc_html__( 'Overview', 'cmb2' ),
    'desc' => esc_html__( 'Tours Overview', 'cmb2' ),
    'id'   => 'toursoverview',
    
    'type' => 'textarea',
  ) );

    $umrah->add_field( array(
    'name' => esc_html__( 'Tours Map', 'cmb2' ),
    'desc' => esc_html__( 'Tours Map', 'cmb2' ),
    'id' => $prefix . 'toursmap',
    'type' => 'textarea_small',
  ) );

  $umrah->add_field( array(
    'name' => esc_html__( 'Day 1', 'cmb2' ),
    'desc' => esc_html__( 'Tours Day 1', 'cmb2' ),
    'id' => $prefix . 'toursdayone',
    'type' => 'wysiwyg',
  ) );


  $umrah->add_field( array(
    'name' => esc_html__( 'Day 2', 'cmb2' ),
    'desc' => esc_html__( 'Tours Day 2', 'cmb2' ),
    'id' => $prefix . 'toursdaytwo',
    'type' => 'wysiwyg',
  ) );

  $umrah->add_field( array(
    'name' => esc_html__( 'Day 3', 'cmb2' ),
    'desc' => esc_html__( 'Tours Day 3', 'cmb2' ),
    'id' => $prefix . 'toursdaythress',
    'type' => 'wysiwyg',
  ) );

    $umrah->add_field( array(
    'name' => esc_html__( 'Day 4', 'cmb2' ),
    'desc' => esc_html__( 'Tours Day 4', 'cmb2' ),
    'id' => $prefix . 'toursdayfour',
    'type' => 'wysiwyg',
  ) );





  }
  add_action( 'cmb2_admin_init', 'tours_hajj_metaboxes' );


 

   $labelsumra = array(
      
        'name'                => _x( 'Hotel', 'Post Type General Name', 'twentythirteen' ),
        'singular_name'       => _x( 'Hotel', 'Post Type Singular Name', 'twentythirteen' ),
        'menu_name'           => __( 'Hotel', 'twentythirteen' ),
        'parent_item_colon'   => __( 'Parent Hotel', 'twentythirteen' ),
        'all_items'           => __( 'All Hotel', 'twentythirteen' ),
        'view_item'           => __( 'View Hotel', 'twentythirteen' ),
        'add_new_item'        => __( 'Add New', 'twentythirteen' ),
        'add_new'             => __( 'Add New', 'twentythirteen' ),
        'edit_item'           => __( 'Edit Hotel', 'twentythirteen' ),
        'update_item'         => __( 'Update Hotel', 'twentythirteen' ),
        'search_items'        => __( 'Search Hotel', 'twentythirteen' ),
        'not_found'           => __( 'Not Found', 'twentythirteen' ),
        'not_found_in_trash'  => __( 'Not found in Trash', 'twentythirteen' ),

    );

   $argshotel = array(
        'label'               => __( 'Hotel', 'twentythirteen' ),
        'description'         => __( 'Hotel news and reviews', 'twentythirteen' ),
        'labels'              => $labelsumra,
       
        'hierarchical'        => true,
        'public'              => true,
        'show_ui'             => true,
        'show_in_menu'        => true,
        'show_in_nav_menus'   => true,
        'show_in_admin_bar'   => true,
        'menu_position'       => 5,
        'can_export'          => true,
        'has_archive'         => true,
        'exclude_from_search' => false,
        'publicly_queryable'  => true,
        'capability_type'     => 'post',
         
        // This is where we add taxonomies to our CPT
        
        'taxonomies' => array('Location','promotions'),
          
          'menu_icon'       => 'dashicons-admin-home',
          'supports' => array( 'title', 'editor', 'author', 'thumbnail', 'excerpt', 'comments'  )



  );

   register_post_type( 'hotelhajj', $argshotel );

      register_taxonomy( 'Hotellocation', 'hotelhajj', array(

        'labels' => array(

          'name' => 'Hotel Location'


        ),

        'rewrite' => array( 'slug' => 'genre' ),
      

    'hierarchical' => true,

      )

      
    );



     register_taxonomy( 'Hotelrating', 'hotelhajj', array(

        'labels' => array(

          'name' => 'Hotel Rating'


        ),

        'rewrite' => array( 'slug' => 'genre' ),
      

    'hierarchical' => true,

      )

      
    );

    register_taxonomy( 'Hotelprice', 'hotelhajj', array(

        'labels' => array(

          'name' => 'Hotel Price'


        ),

        'rewrite' => array( 'slug' => 'genre' ),
      

    'hierarchical' => true,

      )

      
    );


  

      register_taxonomy( 'hotelfacilities', 'hotelhajj', array(

        'labels' => array(

          'name' => 'Hotel Facilities'


        ),

        'rewrite' => array( 'slug' => 'genre' ),
      

    'hierarchical' => true,

      )

      
    );

   function hotel_hajj_metaboxes() {

    $umrah = new_cmb2_box( array(
    'id'            => 'hotelhajj',
    'title'         => __( 'Hotel Package', 'cmb2' ),
    'object_types'  => array( 'hotelhajj', ), // Post type
    'context'       => 'normal',
    'priority'      => 'high',
    'show_names'    => true, 

  ) );

  $umrah->add_field( array(
    'name' => esc_html__( 'Check - in', 'cmb2' ),
    'desc' => esc_html__( 'Check - in ', 'cmb2' ),
    'id' => $prefix . 'hotelcheckin',
    'type' => 'text_date',
  ) );

  $umrah->add_field( array(
    'name' => esc_html__( 'Check - out ', 'cmb2' ),
    'desc' => esc_html__( 'Check - out ', 'cmb2' ),
    'id' => $prefix . 'hotelcheckout ',
    'type' => 'text_date',
  ) );



  $umrah->add_field( array(
    'name' => esc_html__( 'Hotel Location', 'cmb2' ),
    'desc' => esc_html__( 'Hotel Location Name', 'cmb2' ),
    'id'   => 'hotellocation',
    
    'type' => 'text',
  ) );

  $umrah->add_field( array(
    'name' => esc_html__( 'Email', 'cmb2' ),
    'desc' => esc_html__( 'Hotel Email', 'cmb2' ),
    'id'   => 'hotelemail',
    
    'type' => 'text_email',
  ) );

  $umrah->add_field( array(
    'name' => esc_html__( 'Hotel Phone No', 'cmb2' ),
    'desc' => esc_html__( 'Hotel Phone', 'cmb2' ),
    'id'   => 'hotelphone',
    
    'type' => 'text',
  ) );

    $umrah->add_field( array(
    'name' => esc_html__( 'Price', 'cmb2' ),
    'desc' => esc_html__( 'Price', 'cmb2' ),
    'id'   => 'hotelprice',
    
    'type' => 'text_money',
  ) );

  $umrah->add_field( array(
    'name' => esc_html__( 'Hotel Website', 'cmb2' ),
    'desc' => esc_html__( 'Hotel Website', 'cmb2' ),
    'id'   => 'hotelwebsite',
    
    'type' => 'text',
  ) );

  $umrah->add_field( array(
    'name' => esc_html__( 'Cancelled/ Prepayment ', 'cmb2' ),
    'desc' => esc_html__( 'Cancelled/ Prepayment ', 'cmb2' ),
    'id'   => 'hotelprepayment',
    
    'type' => 'textarea',
  ) );

    $umrah->add_field( array(
    'name' => esc_html__( 'Children and extrabed ', 'cmb2' ),
    'desc' => esc_html__( 'Children and extrabed ', 'cmb2' ),
    'id'   => 'hotelchildren',
    
    'type' => 'textarea',
  ) );

    $umrah->add_field( array(
    'name' => esc_html__( 'Pets', 'cmb2' ),
    'desc' => esc_html__( 'Pets', 'cmb2' ),
    'id' => $prefix . 'hotelpets',
    'type' => 'textarea_small',
  ) );



    $umrah->add_field( array(
    'name' => esc_html__( 'Hotel Description', 'cmb2' ),
    'desc' => esc_html__( 'Hotel Description', 'cmb2' ),
    'id' => $prefix . 'hoteldescription',
    'type' => 'wysiwyg',
  ) );





  }
  add_action( 'cmb2_admin_init', 'hotel_hajj_metaboxes' );

 

   register_post_type('flights',array(

  'labels' => array(
         'name' => 'Flights',
         'add_new_item' => 'add new'

    ),
  'public' => true,
  'menu_icon'       => 'dashicons-flag',
  'supports' => array('title','editor','thumbnail','excerpt','custom-fields')



  ));

    register_taxonomy( 'Airports', 'flights', array(

        'labels' => array(

          'name' => 'Airports'


        ),
      

    'hierarchical' => true,

      )

      
    );

       register_taxonomy( 'Airline company', 'flights', array(

        'labels' => array(

          'name' => 'Airline company'


        ),
      

    'hierarchical' => true,

      )

      
    );
  
  








$labelsflights = array(
      
        'name'                => _x( 'Flights', 'Post Type General Name', 'twentythirteen' ),
        'singular_name'       => _x( 'Flights', 'Post Type Singular Name', 'twentythirteen' ),
        'menu_name'           => __( 'Flights', 'twentythirteen' ),
        'parent_item_colon'   => __( 'Parent Flights', 'twentythirteen' ),
        'all_items'           => __( 'All Flights', 'twentythirteen' ),
        'view_item'           => __( 'View Flights', 'twentythirteen' ),
        'add_new_item'        => __( 'Add New', 'twentythirteen' ),
        'add_new'             => __( 'Add New', 'twentythirteen' ),
        'edit_item'           => __( 'Edit Flights', 'twentythirteen' ),
        'update_item'         => __( 'Update Flights', 'twentythirteen' ),
        'search_items'        => __( 'Search Flights', 'twentythirteen' ),
        'not_found'           => __( 'Not Found', 'twentythirteen' ),
        'not_found_in_trash'  => __( 'Not found in Trash', 'twentythirteen' ),

    );

   $argsflights = array(
        'label'               => __( 'Flights', 'twentythirteen' ),
        'description'         => __( 'Flights news and reviews', 'twentythirteen' ),
        'labels'              => $labelsflights,
       
        'hierarchical'        => true,
        'public'              => true,
        'show_ui'             => true,
        'show_in_menu'        => true,
        'show_in_nav_menus'   => true,
        'show_in_admin_bar'   => true,
        'menu_position'       => 5,
        'can_export'          => true,
        'has_archive'         => true,
        'exclude_from_search' => false,
        'publicly_queryable'  => true,
        'capability_type'     => 'post',
         
        // This is where we add taxonomies to our CPT
        
        'taxonomies' => array('Location','promotions'),
          
          'menu_icon'       => 'dashicons-admin-home',
          'supports' => array( 'title', 'editor', 'author', 'thumbnail', 'excerpt', 'comments'  )



  );

   register_post_type( 'flights', $argsflights );

      register_taxonomy( 'locationto', 'flights', array(

        'labels' => array(

          'name' => 'Location To'


        ),

        'rewrite' => array( 'slug' => 'genre' ),
      

    'hierarchical' => true,

      )

      
    );


    register_taxonomy( 'locationform', 'flights', array(

        'labels' => array(

          'name' => 'Location From'


        ),

        'rewrite' => array( 'slug' => 'genre' ),
      

    'hierarchical' => true,

      )

      
    );




     register_taxonomy( 'passenger', 'flights', array(

        'labels' => array(

          'name' => 'Passenger'


        ),

        'rewrite' => array( 'slug' => 'genre' ),
      

    'hierarchical' => true,

      )

      
    );

    register_taxonomy( 'departuredate', 'flights', array(

        'labels' => array(

          'name' => 'Departure Date'


        ),

        'rewrite' => array( 'slug' => 'genre' ),
      

    

      )

      
    );


    register_taxonomy( 'roundtrip', 'flights', array(

        'labels' => array(

          'name' => 'Round Trip'


        ),

        'rewrite' => array( 'slug' => 'genre' ),

         'hierarchical' => true,
      

    

      )

      
    );



  

      register_taxonomy( 'stops', 'flights', array(

        'labels' => array(

          'name' => 'Stops'


        ),

        'rewrite' => array( 'slug' => 'genre' ),
      

    'hierarchical' => true,

      )

      
    );


      register_taxonomy( 'airlines', 'flights', array(

        'labels' => array(

          'name' => 'Airlines'


        ),

        'rewrite' => array( 'slug' => 'genre' ),
      

    'hierarchical' => true,

      )

      
    );

      register_taxonomy( 'price', 'flights', array(

        'labels' => array(

          'name' => 'Price'


        ),

        'rewrite' => array( 'slug' => 'genre' ),
      

    'hierarchical' => true,

      )

      
    );


   function flights_hajj_metaboxes() {

    $flights_hajj = new_cmb2_box( array(
    'id'            => 'flights',
    'title'         => __( 'Hotel Package', 'cmb2' ),
    'object_types'  => array( 'flights', ), // Post type
    'context'       => 'normal',
    'priority'      => 'high',
    'show_names'    => true, 

  ) );






  $flights_hajj->add_field( array(

    'name'    => 'Logo',
  'desc'    => 'Upload an image or enter an URL.',
  'id'      => 'flogo',
  'type'    => 'file',
  // Optional:
  'options' => array(
    'url' => false, // Hide the text input for the url
  ),
  'text'    => array(
    'add_upload_file_text' => 'Add File' // Change upload button text. Default: "Add or Upload File"
  ),
 
  'query_args' => array(
    'type' => 'application/pdf', // Make library only display PDFs.
 
  ),
  'preview_size' => 'large', 


  ) );

   $flights_hajj->add_field( array(
    'name' => esc_html__( 'Price', 'cmb2' ),
    'desc' => esc_html__( 'Price', 'cmb2' ),
    'id'   => 'fprice',
    'type' => 'text_money',

      ) );

     $flights_hajj->add_field( array(
    'name' => esc_html__( 'Tax', 'cmb2' ),
    'desc' => esc_html__( 'Tax', 'cmb2' ),
    'id'   => 'ftax',
    'type' => 'text_money',
  ) );
  
       $flights_hajj->add_field( array(
    'name' => esc_html__( 'Business Class', 'cmb2' ),
    'desc' => esc_html__( 'Business Class', 'cmb2' ),
    'id'   => 'businessclass',
    'type' => 'text_money',
  ) );

         $flights_hajj->add_field( array(
    'name' => esc_html__( 'Economy Class', 'cmb2' ),
    'desc' => esc_html__( 'Economy Class', 'cmb2' ),
    'id'   => 'economyclass',
    'type' => 'text_money',
  ) );

  $flights_hajj->add_field( array(
    'name' => esc_html__( 'Business Class Date', 'cmb2' ),
    'desc' => esc_html__( 'Business Class Date', 'cmb2' ),
    'id'   => 'businessclassdate',
    'type' => 'text_date',
  ) );

  $flights_hajj->add_field( array(
    'name' => esc_html__( 'Business Class Time', 'cmb2' ),
    'desc' => esc_html__( 'Business Class Time', 'cmb2' ),
    'id'   => 'businessclasstime',
    'type' => 'text_time',
  ) );

    $flights_hajj->add_field( array(
    'name' => esc_html__( 'Economy Class Date', 'cmb2' ),
    'desc' => esc_html__( 'Economy Class Date', 'cmb2' ),
    'id'   => 'economyclassdate',
    'type' => 'text_date',
  ) );

  $flights_hajj->add_field( array(
    'name' => esc_html__( 'Economy Class Time', 'cmb2' ),
    'desc' => esc_html__( 'Economy Class Time', 'cmb2' ),
    'id'   => 'economyclasstime',
    'type' => 'text_time',
  ) );
 


  }
  add_action( 'cmb2_admin_init', 'flights_hajj_metaboxes' );

  $labelshajj = array(
      
        'name'                => _x( 'Hajj', 'Post Type General Name', 'twentythirteen' ),
        'singular_name'       => _x( 'Hajj', 'Post Type Singular Name', 'twentythirteen' ),
        'menu_name'           => __( 'Hajj', 'twentythirteen' ),
        'parent_item_colon'   => __( 'Parent Hajj', 'twentythirteen' ),
        'all_items'           => __( 'All Hajj', 'twentythirteen' ),
        'view_item'           => __( 'View Hajj', 'twentythirteen' ),
        'add_new_item'        => __( 'Add New', 'twentythirteen' ),
        'add_new'             => __( 'Add New', 'twentythirteen' ),
        'edit_item'           => __( 'Edit Hajj', 'twentythirteen' ),
        'update_item'         => __( 'Update Hajj', 'twentythirteen' ),
        'search_items'        => __( 'Search Hajj', 'twentythirteen' ),
        'not_found'           => __( 'Not Found', 'twentythirteen' ),
        'not_found_in_trash'  => __( 'Not found in Trash', 'twentythirteen' ),

    );

   $argshajj = array(
        'label'               => __( 'Hajj', 'twentythirteen' ),
        'description'         => __( 'Hajj news and reviews', 'twentythirteen' ),
        'labels'              => $labelshajj,
       
        'hierarchical'        => true,
        'public'              => true,
        'show_ui'             => true,
        'show_in_menu'        => true,
        'show_in_nav_menus'   => true,
        'show_in_admin_bar'   => true,
        'menu_position'       => 5,
        'can_export'          => true,
        'has_archive'         => true,
        'exclude_from_search' => false,
        'publicly_queryable'  => true,
        'capability_type'     => 'post',
         
        // This is where we add taxonomies to our CPT
        
        'taxonomies' => array('Location','promotions'),
          
          'menu_icon'       => 'dashicons-schedule',
          'supports' => array( 'title', 'editor', 'author', 'thumbnail', 'excerpt', 'comments'  )



  );

   register_post_type( 'hajj', $argshajj );


*/
