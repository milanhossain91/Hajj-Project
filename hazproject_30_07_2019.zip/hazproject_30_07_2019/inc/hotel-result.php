<?php
/**
 * The rental search result template file
 *
 * This is the most generic template file in a WordPress theme
 * and one of the two required files for a theme (the other being style.css).
 * It is used to display a page when nothing more specific matches a query.
 * E.g., it puts together the home page when no home.php file exists.
 *
 * @link https://developer.wordpress.org/themes/basics/template-hierarchy/
 *
 * @package aynix
 */
 /*
  Template Name: hotel-result
*/
get_header(); ?>
   
     <!-- mobile-menu-area start -->
        <div class="mobile-menu-area">
          <div class="container">
            <div class="row">
              <div class="col-md-12">
                <div class="mobile-menu">
                  <nav id="dropdown">
                    <ul>
                        <li class="active"><a href="#">Home</a>
                            <ul>
                                <li><a href="#">Sub Item</a></li>
                                <li><a href="#">Sub Item</a></li>
                                <li><a href="#">Sub Item</a></li>
                                <li><a href="#">Sub Item</a></li>
                                <li><a href="#">Sub Item</a></li>
                                <li><a href="#">Sub Item</a></li>
                                <li><a href="#">Sub Item</a></li>
                            </ul>
                        </li>
                        <li><a href="#">Projects</a></li>
                        <li><a href="#">Activities</a></li>
                        <li><a href="#">Total Jobs</a></li>
                        <li><a href="#">Flights</a></li>
                        <li><a href="#">Hotels</a></li>
                    </ul>
                  </nav>
                </div>
              </div>
            </div>
          </div>
        </div>
        <!-- mobile-menu-area end -->



        <div class="search-res flight has-border">
            <div class="container">
                <div class="top-title">
                    <h3>Find Your Perfect Hotels</h3>
                </div>

                    <div class="row">

                      <?php

                                  if($_GET['Hotellocation'] && !empty($_GET['Hotellocation']))
                                    {
                                        $Hotellocationlast = $_GET['Hotellocation'];
                                    }

                                    if($_GET['Hotelprice'] && !empty($_GET['Hotelprice']))
                                    {
                                        $Hotelpricelast = $_GET['Hotelprice'];
                                    }
                                    if($_GET['Hotelrating'] && !empty($_GET['Hotelrating']))
                                    {
                                        $Hotelratinglast = $_GET['Hotelrating'];
                                    }



                      ?>
                    <div class="col-sm-12">
                        <form  method="get">
                            
                            <div class="tf-row row">
                                <div class="tf-col col-lg-3">
                                    <label for="desti">Hotel Location</label>
                                        <div class="map mb-2">
                                   
                                        <select class="form-control" name="Hotellocation">
                                        <option>Select Hotel Location</option>
                                       <?php
                                        $Hotellocation = get_terms([
                                        'taxonomy' => 'Hotellocation',
                                        'hide_empty' => false,
                                        ]);

                                       foreach($Hotellocation as $package_city_rows){  

                                        ?>
                                          <option value="<?php echo $package_city_rows->slug; ?>"><?php echo $package_city_rows->name; ?></option>
                                      <?php } ?>
                                        </select>
                                        </div>
                                </div>
        
    
                                
                                <div class="tf-col tf-slect col-lg-3">
                                    <label>Hotel Price</label>
                                    <select class="form-control" name="Hotelprice">
                                        <option>Select Price</option>
                                           <?php
                                        $Hotelprice = get_terms([
                                        'taxonomy' => 'Hotelprice',
                                        'hide_empty' => false,
                                        ]);

                                       foreach($Hotelprice as $package_city_rows){  

                                        ?>
                                          <option value="<?php echo $package_city_rows->slug; ?>"><?php echo $package_city_rows->name; ?></option>
                                      <?php } ?>
                                </select>
                                </div>



                                <div class="tf-col tf-slect col-lg-3">
                                    <label>Hotel Rating</label>
                                    <select class="form-control" name="Hotelrating">
                                        <option>Select Hotel Rating</option>
                                           <?php
                                        $Hotelrating = get_terms([
                                        'taxonomy' => 'Hotelrating',
                                        'hide_empty' => false,
                                        ]);

                                       foreach($Hotelrating as $package_city_rows){  

                                        ?>
                                          <option value="<?php echo $package_city_rows->slug; ?>"><?php echo $package_city_rows->name; ?></option>
                                      <?php } ?>
                                </select>
                                </div>

                                   <div class="col-lg-3">
                                    <div class="btn-area">
                                     <input class="btn btn-primary btn-md" name="toursubmit" type="submit" value="Search">
                                    </div>
                                </div>

                            </div>
                        </form>
                    </div>
                  
                </div>

                 <div class="top-title">
                    <h3></h3>

                  </div>


                <div class="row">
                    <div class="col-sm-3">
                        <div class="left-sidebar">
                            
                           

                            <div class="bar-item">
                                <div class="wrap">

                                      <a class="ac-title"  data-toggle="collapse" href="#ac2" role="button" aria-expanded="false" aria-controls="ac2">Hotel Rating</a>
                                 
                                    <div class="collapse show" id="ac1">
                                  <div class="inner">
                                     <?php
                                        $search = new WP_Advanced_Search('tourhotelrating');
                                        ?>
                                    <div class="custom-control custom-checkbox">
                                            <div class="row search-section">
                                           <div id="sidebar" class="large-3 columns">
                                              <?php $search->the_form(); ?>
                                           </div>
                        
                                    </div>
                                    </div>
                                  
                                </div>
                              </div>
                            </div>
                            </div>


                            <div class="bar-item">
                                <div class="wrap">
                                    <a class="ac-title"  data-toggle="collapse" href="#ac2" role="button" aria-expanded="false" aria-controls="ac2">Facilities</a>
                                    <div class="collapse show" id="ac2">
                                  <div class="inner">

                                        <?php
                                        $search = new WP_Advanced_Search('hotelfacilitiesall');
                                        ?>
                                    <div class="custom-control custom-checkbox">
                                            <div class="row search-section">
                                           <div id="sidebar" class="large-3 columns">
                                              <?php $search->the_form(); ?>
                                           </div>
                        
                                    </div>
                                    </div>
                                   
                                </div>
                              </div>
                            </div>
                            </div>


                            <div class="bar-item">
                                <div class="wrap">
                                    <a class="ac-title"  data-toggle="collapse" href="#ac3" role="button" aria-expanded="false" aria-controls="ac3">Departure Time</a>
                                    <div class="collapse show" id="ac3">
                                  <div class="inner">
                                        <?php
                                        $search = new WP_Advanced_Search('hoteldeparturetime');
                                        ?>
                                    <div class="custom-control custom-checkbox">
                                            <div class="row search-section">
                                           <div id="sidebar" class="large-3 columns">
                                              <?php $search->the_form(); ?>
                                           </div>
                        
                                    </div>
                                    </div>
                                </div>
                              </div>
                            </div>
                            </div>

                        </div>
                    </div> <!-- col- end -->
                     <?php

                          $args = array(
                                      'order' => 'asc',
                                      'order_by' => 'title',
                                      'post_type' => 'hotelhajj', 
                                      'posts_per_page' => 0,
                                          'tax_query' => array(

                                            'relation' => 'AND',

                                            array(
                                                
                                                'taxonomy' => 'Hotellocation', 
                                                'field' => 'slug',
                                                'terms' => $Hotellocationlast,
                                                
                                                
                                            ),


                                            array(
                                                
                                                'taxonomy' => 'Hotelprice', 
                                                'field' => 'slug',
                                                'terms' => $Hotelpricelast,
                                                
                                                
                                            ),

                               

                                            array(
                                                
                                                'taxonomy' => 'Hotelrating',
                                                'field' => 'slug',
                                                'terms' => $Hotelratinglast,
                                                'operator' => 'AND'
                                                
                                                
                                            ),



                                      
                                        )
                                      );
                        $query = new WP_Query($args);
                     if ($query -> have_posts()):
               while($query -> have_posts()) : $query -> the_post();
                   ?>


                     <div class="col-sm-9">
                                  <div class="row hotels-res">

                            <div class="col-sm-4">
                                <div class="top-deal-item">
                                    <a href="<?php the_permalink(); ?>" class="fig">

                                          <?php 
                                                 $title=get_the_title();
                                                 the_post_thumbnail( array(251, 188),array( 'alt' =>$title) );

                                                 ?>
                                        


                                        <span>Book Now</span>
                                    </a>
                                           
                                    <div class="content">
                                        <div class="icons">
                                            <i class="fa fa-star"></i>         
                                            <i class="fa fa-star"></i>         
                                            <i class="fa fa-star"></i>         
                                            <i class="fa fa-star"></i>         
                                            <i class="fa fa-star"></i>         
                                        </div>
                                        <h5><a href="<?php the_permalink(); ?>">I<?php the_title()?></a></h5>
                                        <div class="location">
                                            <i class="fa fa-map-marker"></i>
                                            <span><?php echo get_post_meta( get_the_ID(), 'hotellocation', true );?></span>
                                        </div>
                                        <p class="mb0">from <?php echo get_post_meta( get_the_ID(), 'hotelprice', true );?> <small>/night</small></p>
                                    </div>
                               
                                </div>
                            </div>

                                 </div>
                            </div>
                    





                                  <?php 

                   endwhile; 
                

                 elseif ( have_posts() ) :  
               
                           ?>

                                <div class="col-sm-9">
                                  

                         

                               <div id="wpas-results">

                                    
                            
                         </div>
                         </div>


                            <?php

                             else :
                  $ourteams = new WP_Query(array(
                  'post_type' => 'hotelhajj', 
                  'posts_per_page' => 0 
                  ));

                  
                    while ($ourteams->have_posts() ) : 
                 $ourteams->the_post();?>

                        <div class="col-sm-9">
                                  <div class="row hotels-res">

                            <div class="col-sm-4">
                                <div class="top-deal-item">
                                    <a href="<?php the_permalink(); ?>" class="fig">

                                          <?php 
                                                 $title=get_the_title();
                                                 the_post_thumbnail( array(251, 188),array( 'alt' =>$title) );

                                                 ?>
                                        


                                        <span>Book Now</span>
                                    </a>
                                           
                                    <div class="content">
                                        <div class="icons">
                                            <i class="fa fa-star"></i>         
                                            <i class="fa fa-star"></i>         
                                            <i class="fa fa-star"></i>         
                                            <i class="fa fa-star"></i>         
                                            <i class="fa fa-star"></i>         
                                        </div>
                                        <h5><a href="<?php the_permalink(); ?>">I<?php the_title()?></a></h5>
                                        <div class="location">
                                            <i class="fa fa-map-marker"></i>
                                            <span><?php echo get_post_meta( get_the_ID(), 'hotellocation', true );?></span>
                                        </div>
                                        <p class="mb0">from <?php echo get_post_meta( get_the_ID(), 'hotelprice', true );?> <small>/night</small></p>
                                    </div>
                               
                                </div>
                            </div>

                                 </div>
                            </div>






                              <?php 

                         endwhile;  


                         endif; ?>  






                     
                        </div>

                         
                    </div> <!--  col end-->
                </div>
            </div>
        </div>


<?php get_footer();?>