<?php
/**
 * Template Name: Hotel Details Template
 *  
 */

get_header();
require_once('functions/hotel_functions.php');

include('rating/rating.php');


   $service_type = 'hotels';  

 if(isset($_GET['id'])){
     $hid = $_GET['id'];
 }

    global $wpdb;
    $wp_post_db = "hotel_details";
    $show_vendor_posts = $wpdb->get_results("SELECT * FROM $wp_post_db WHERE id='$hid' ORDER BY id DESC"); 
    $i=0;
    foreach( $show_vendor_posts as $show_vendor_post) 
    {  
     
        $hotel_title =  $show_vendor_post->hotel_title;  
        $hotel_description =  $show_vendor_post->hotel_description; 
        $hotel_check_in =  $show_vendor_post->hotel_check_in;  
        $hotel_check_out =  $show_vendor_post->hotel_check_out;  
        $hotel_location =  $show_vendor_post->hotel_location;  
        $hotel_email =  $show_vendor_post->hotel_email;  
        $hotel_phone_no =  $show_vendor_post->hotel_phone_no;  
        $hotel_price =  $show_vendor_post->hotel_price;  
        $hotel_website =  $show_vendor_post->hotel_website;  
        $hotel_cancelled_repayment =  $show_vendor_post->hotel_cancelled_repayment;  
        $hotel_children_and_extrabed =  $show_vendor_post->hotel_children_and_extrabed;    
    }

?>




<div class="det-area car-det has-border u-padding-t-60 u-padding-b-60">
        <div class="container">
            <div class="det-top">
                <div class="left">
                    <h3><?php echo  $hotel_title; ?></h3>
                    <p><i class="fa fa-map-marker"></i> <?php echo $hotel_location; ?></p>
                    <ul>
                        <li><i class="fa fa-envelope"></i><?php echo $hotel_email; ?></li>
                        <li><i class="fa fa-home"></i> <?php echo $hotel_website; ?></li>
                        <li><i class="fa fa-phone"></i><?php echo $hotel_phone_no; ?></li>
                    </ul>
                </div>
                <div class="right">
                    <div class="prices">
                        <div class="old">
                            price from 
                        </div>
                        <div class="cr-price">
                             <?php echo $hotel_price; ?> <small>/night</small>
                        </div>
                    </div>
                </div>
            </div>

            <div class="row">

                <div class="col-lg-8">
                    <div class="det-tab u-padding-t-10">
                                <!-- Nav tabs -->
                                <ul class="nav nav-tabs" role="tablist">
                                  <li class="nav-item">
                                    <a class="nav-link active" href="#photos" role="tab" data-toggle="tab"><i class="fa fa-camera"></i>Photos </a>
                                  </li>
                                  <li class="nav-item">
                                    <a class="nav-link" href="#map" role="tab" data-toggle="tab">
                                        <i class="fa fa-map-marker"></i>On the map</a>
                                  </li>
                                  <li class="nav-item">
                                    <a class="nav-link" href="#rating" role="tab" data-toggle="tab"><i class="fa fa-signal"></i>Rating</a>
                                  </li>
                                  <li class="nav-item">
                                    <a class="nav-link" href="#Facilities" role="tab" data-toggle="tab"><i class="fa fa-asterisk"></i>Facilities</a>
                                  </li>
                  
                                </ul>

                                <!-- Tab panes -->
                                <div class="tab-content u-padding-t-20">
                                  <div role="tabpanel" class="tab-pane fade in active show" id="photos">
                                      <div class="fotorama" data-nav="thumbs">
                                         
                                         <?php   
                                          echo getGallaeryImageSrcById($hid, $service_type);

                                          ?>
                                          
                                        </div>
                                  </div>

                                <!-- map tab content -->
                                  <div role="tabpanel" class="tab-pane fade" id="map">
                                        <div class="map-frame">
                                            <iframe src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d387193.30594184523!2d-74.25986594809962!3d40.69714941820045!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x89c24fa5d33f083b%3A0xc80b8f06e177fe62!2sNew+York%2C+NY%2C+USA!5e0!3m2!1sen!2sbd!4v1540485618034"  frameborder="0" style="border:0" allowfullscreen></iframe>
                                        </div>
                                  </div>



                                
                                <!-- about tab content -->
                                  <div role="tabpanel" class="tab-pane fade" id="rating">
                                    <div class="row">
                                        <div class="col-lg-7">
                                            <div class="rat-summary">
                                              <h3>Traveler rating</h3>
                                              <ul>
                                                  <li>
                                                    <span class="left">Exellent</span>
                                                    <span class="right"></span>
                                                </li>
                                                  <li>
                                                    <span class="left">Vey Good</span>
                                                    <span class="right"></span>
                                                </li>
                                                  <li>
                                                    <span class="left">Average</span>
                                                    <span class="right"></span>
                                                </li>
                                                  <li>
                                                    <span class="left">Poor</span>
                                                    <span class="right"></span>
                                                </li>
                                                  <li>
                                                    <span class="left">Terrible</span>
                                                    <span class="right"></span>
                                                </li>
                                              </ul>
                                              <a class="btn btn-primary" href="#">Write a review</a>
                                          </div>
                                        </div>
                                                <div class="col-lg-5">
                                                    <div class="rat-summary">
                                                        <h3>Give Me Ratings</h3>
                                                    </div>
                                                    <ul class="list booking-item-raiting-summary-list stats-list-select"> 
                                                      <?php echo ratingsFunctions($hid, $service_type); ?>
                                                   </ul>
                                                
                                                    
                                               
                                                
                                                   </div>
                                    </div>
                                  </div>

                                <!-- Facilities tab content-->
                                  <div role="tabpanel" class="tab-pane fade" id="Facilities">
                                       <div class="hotel-facilities col2">
                                            <h4>Hotel Facilities</h4>
                                            <ul>
                                            <?php   
                                               $wp_post_db = "hotel_offers_relation";  
                                               $show_vendor_posts = $wpdb->get_results("SELECT * FROM $wp_post_db where service_type='$service_type' and hotel_id='$hid'  ORDER BY id DESC"); 
                                                $num_rows = $wpdb->num_rows;
                                                 
                                                if($num_rows  > 0){

                                                $i=0;
                                                foreach( $show_vendor_posts as $show_vendor_post)  
                                                {   
                                                //print_r($show_vendor_post);
                                              
                                                $service_id =  $show_vendor_post->service_id; 
                                                                                              
                                                ?>   
                                                <li>
                                                    <i class="fa fa-glass"></i>
                                                    <span><?php echo getServiceNameById($service_id); ?></span>
                                                </li>

                                                   <?php } }else{ ?>

                                                <h4>No data found.</h4>

                                              <?php } ?>

                                            </ul>
                                        </div>
                                  </div>



                                </div>
                            </div>
                </div> <!-- col-5 end -->

                <div class="col-lg-4">
                    <div class="hotel-info-wrap">
                        <div class="int">
                            <h1>Very Good</h1>
                            <p>80% <small>of guests recommend</small></p>
                            <div class="rev">
                                <div class="stars">
                                 <?php echo ratingsFunctions($hid, $service_type); ?>
                                   
                                </div>
                                <h6><?php echo ratingsRatio($hid, $service_type); ?> <small>of 5 rating</small></h6>
                            </div>
                            <span>based on 5 reviews</span>
                        </div> <!-- int -->

                        <div class="share clear">
                            <span>Share<i class="fa fa-share fa-lg"></i></span>
                            
                                <ul class="clear">
                                <li>
                                    <a class="facebook" href="#">
                                        <i class="fa fa-facebook fa-lg"></i>
                                    </a>
                                </li>

                                <li><a class="twitter" href="#"><i class="fa fa-twitter fa-lg"></i></a></li>

                                <li><a class="google" href="#"><i class="fa fa-google-plus fa-lg"></i></a></li>
                                <li><a class="no-open pinterest" href="#">
                                    <i class="fa fa-pinterest fa-lg"></i></a></li>

                                <li><a class="linkedin" href="#"><i class="fa fa-linkedin fa-lg"></i></a></li>
                                
                            </ul>
                        </div> <!-- share -->

                        <div class="ab-text">
                            <h3>About Hotel</h3>
                            <p> <?php echo $hotel_description; ?></p>
                        </div>

                        <div class="ht-logo">
                            <img src="<?php echo get_template_directory_uri(); ?>/img/New_York_Hilton_Midown_Logo.jpg" alt="">
                        </div>
                    </div> <!-- hotel-info-wrap -->
                </div>
            </div> <!-- row --> 

           
            <div class="sec-bar3 u-padding-t-40 row">
                <div class="col-lg-8">
                    <div class="from-wrap">
                        <h3>Available Rooms</h3>
                        <form class="tf-row row" id="formData_id">

                            <div class="tf-col  col-lg-3">
                                <label>Check in</label>
                                <input type="text" name="check_in" class="datepicker form-control" placeholder="dd/mm/yy">
                            </div>
                            <div class="tf-col col-lg-3">
                                <label>Check out</label>
                                <input type="text" name="check_out"  class="datepicker form-control" placeholder="dd/mm/yy">
                                
                            </div>

                            <div class="tf-col col-lg-3">
                                <label>Rooms</label>
                                <div class="inp-more">
                                    <div class="radio-wrap">
                                        <label><input type="radio" name="room">1</label>
                                        <label><input type="radio" name="room">2</label>
                                    </div>
                                    <span class="more-sl">2+</span>
                                </div>
                                
                            </div>

                            <div class="tf-col col-lg-3">
                                <label>Adult</label>
                                <div class="inp-more">
                                    <div class="radio-wrap">
                                        <label><input type="radio" name="room">1</label>
                                        <label><input type="radio" name="room">2</label>

                                    </div>
                                    <span class="more-sl">2+</span>
                                </div>
                                
                            </div>
                            <div class="col-sm-12">
                                <div class="btn-area">
                                     <input type="hidden" name="hotel_id" value="<?php echo $hid;?>">
                                    <button class="btn btn-primary btn-md" type="submit">Search For Room</button>
                                </div>
                            </div>
                        </form> <!-- row end -->
                    </div> <!--from-wrap --> 
 <div class="ajax_result">

                
                <?php 
                 
                    $service_type = 'rooms';                         
                               
                    $wp_post_db = "available_rooms";
                      //echo "SELECT * FROM $wp_post_db WHERE hotel_id='$hid' ORDER BY id DESC";        
                    $show_vendor_posts = $wpdb->get_results("SELECT * FROM $wp_post_db WHERE hotel_id='$hid' ORDER BY id DESC"); 
                    $i=0;
                    foreach( $show_vendor_posts as $show_vendor_post) 
                    {  
                       // print_r($show_vendor_post);
                       $rid =  $show_vendor_post->id;   
                       $room_id =  $show_vendor_post->hotel_id;   
                       $room_title =  $show_vendor_post->room_title;  
                       $room_description =  $show_vendor_post->room_description;    
                       $room_price =  $show_vendor_post->room_price;    
                       $date_added =  $show_vendor_post->date_added;                                                               
                    ?>     


                    
                    <div class="row hotels">
                        <div class="col-12">
                            <div class="item-hotel-price">
                                <div class="figr">
                                    <a href="<?php echo site_url(); ?>/room-details?id=<?php echo $rid;?>" target="_blank">
                                        <img src="<?php echo getImageSrcById($rid, $service_type); ?>">
                                    </a>
                                </div>
                                
                                <div class="bd-icons">
                                    <h5><a href="<?php echo site_url(); ?>/room-details?id=<?php echo $rid;?>" target="_blank"><?php echo $room_title; ?></a></h5>
                                    <ul class="ico-set">
                                            
                                            <?php echo serviceList($rid, $service_type);   ?>
                                        </ul>
                                </div>

                                <div class="action">
                                    <p><h2>$<?php echo $room_price; ?> <span style="font-size:11px;">/ 1 night(s)</span></h2></p>
                                    <a class="btn btn-primary" href="<?php echo site_url(); ?>/room-details?id=<?php echo $rid;?>" target="_blank">Room Details</a>
                                </div>
                            </div>
                        </div>
                    </div><!-- item -->

 <?php 
                                          }

    ?>

    </div>

                    
                     
                </div> <!-- col-9 end -->

                <div class="col-lg-4">
                    <div class="hotel-sidebar">
        
                    <div class="rel-hotel">
                        <h3 class="title u-margin-b-20">Near by <strong>InterContinental New York Barclay</strong></h3>
                        <ul>

                         <?php     
                      $service_type = 'hotels';  

                      $wp_post_db = "hotel_details";  
                      $show_vendor_posts = $wpdb->get_results("SELECT * FROM $wp_post_db ORDER BY id DESC LIMIT 10"); 
                      $num_rows = $wpdb->num_rows;
                     
                  if($num_rows  > 0){

                      $i=0;
                      foreach( $show_vendor_posts as $show_vendor_post)  
                      {   
                      //print_r($show_vendor_post);
                      $vhid =  $show_vendor_post->id; 
                      $hotel_title =  $show_vendor_post->hotel_title; 
                      $hotel_description =  $show_vendor_post->hotel_description;   
                      $hotel_location =  $show_vendor_post->hotel_location;    
                      $hotel_price =  $show_vendor_post->hotel_price;                                                
                      ?>   

                            <li>
                               <a href="<?php echo site_url().'/hotel-details/?id='.$vhid; ?>">
                                   <figure>
                                       <img src="<?php echo getImageSrcById($vhid, $service_type); ?>">
                                   </figure>
                                   <div class="title-star">
                                       <h4><?php echo $hotel_title; ?></h4>
                                       <span class="stars">
                                           <i class="fa fa-star"></i>
                                           <i class="fa fa-star"></i>
                                           <i class="fa fa-star"></i>
                                           <i class="fa fa-star"></i>
                                           <i class="fa fa-star-o"></i>
                                       </span>
                                   </div>

                                   <span class="price">
                                       <span>Price from</span>
                                       <p>$<?php echo $hotel_price; ?></p>
                                   </span>

                               </a>
                            </li> <!-- item -->

                            <?php }}else{ ?>

                    <h4>No data found.</h4>

                  <?php }  ?>
                            

                        </ul>
                    </div>
                    </div>
                </div> <!-- col-3 sidebar col -->
            </div>

            <div class="sec-rev-relhot row">
                <div class="col-lg-8">
                    <div class="hotel-rev">
                        <div class="rev-title">
                            <h3>Hotel Reviews </h3>
                        </div>
                        <ul class="booking-item-reviews list"> 

                            <?php echo reviewlists($hid, $service_type); ?> 

                        </ul>
                    </div>

                    
                    <div id="respond" class="comment-respond">
                    <h3 id="reply-title" class="comment-reply-title">Write a review </h3>    
                    <div class="col-lg-12"> 
                       <?php echo writeReviewForm($hid, $service_type); ?>  
                    </div><!--End Row-->     
                    </div><!-- #respond -->
                    
                </div> <!-- col-8 -->

            </div>
                

        </div>
    </div>




<?php

get_footer();

?>
<script>
 jQuery('.datepicker').datepicker();
</script>   



<script type="text/javascript">
         

         jQuery("form#formData_id").submit(function(e) { 
            e.preventDefault();

         var formData = new FormData(jQuery(this)[0]); 
       
          var tem_url = "<?php echo get_template_directory_uri(); ?>";
           var user_id = "<?php echo get_current_user_id(); ?>"; 
           
          

            var tem_uri = tem_url+'/ajax/available_room_ajax.php';
              // alert(tem_uri); 
            jQuery.ajax({
            url: tem_uri,
             type: "POST",
            data: formData,
            contentType: false,       
            cache: false,              
            processData:false,  
            success: function(response) { 
             //alert(response);  
             jQuery('.ajax_result').html(response); 
            }
            
            });

           setTimeout(function(){

                jQuery('#myModal').modal('toggle');

             }, 800);

         });




</script>


