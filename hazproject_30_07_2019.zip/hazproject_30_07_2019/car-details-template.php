<?php
/**
 * Template Name: Car Details Template
 */

get_header();

require_once('functions/car_functions.php');
include('rating/rating.php');
$service_type = "cars";

if(isset($_GET['car_id'])){
    $car_id = $_GET['car_id'];
}

 global $wpdb;
    $wp_post_db = "car_details";
    //echo "SELECT * FROM $wp_post_db WHERE id='$car_id' ORDER BY id DESC";
    $show_vendor_posts = $wpdb->get_results("SELECT * FROM $wp_post_db WHERE id='$car_id' ORDER BY id DESC"); 
    $i=0;
    foreach( $show_vendor_posts as $show_vendor_post) 
    {  
     
        $car_title =  $show_vendor_post->car_title;  
        $car_description =  $show_vendor_post->car_description; 
        $car_check_in =  $show_vendor_post->car_check_in;  
        $car_check_out =  $show_vendor_post->car_check_out;  
        $car_location =  $show_vendor_post->car_location;  
        $car_email =  $show_vendor_post->car_email;  
        $car_phone_no =  $show_vendor_post->car_phone_no;  
        $car_price =  $show_vendor_post->car_price;  
        $car_website =  $show_vendor_post->car_website;  
        $car_cancelled_repayment =  $show_vendor_post->car_cancelled_repayment;  
        $car_children_and_extrabed =  $show_vendor_post->car_children_and_extrabed;    
    }

?>
  
    <div class="det-area car-det has-border u-padding-t-60 u-padding-b-60">
        <div class="container">
            <div class="det-top">
                <div class="left">
                    <h3><?php echo $car_title; ?></h3>
                    <ul>
                        <li><i class="fa fa-envelope"></i>Agent E-mail <?php echo $car_email; ?></li>
                        <li><i class="fa fa-phone"></i> <?php echo $car_phone_no; ?></li>
                    </ul>
                </div>
                <div class="right">
                    <div class="prices">
                        <div class="old">
                            Price <span>$<?php echo $car_price; ?></span>
                        </div>
                        <i class="fa fa-long-arrow-right"></i>
                        <div class="cr-price">
                            $<?php echo $car_price; ?> <small>/day</small>
                        </div>
                    </div>
                </div>
            </div>

            <div class="row">

                <div class="col-lg-6 col-12">
                        <div class="det-tab u-padding-t-10">
                                <!-- Nav tabs -->
                                <ul class="nav nav-tabs" role="tablist">
                                  <li class="nav-item">
                                    <a class="nav-link active" href="#photos" role="tab" data-toggle="tab"><i class="fa fa-camera"></i>Photos </a>
                                  </li>
                                  <li class="nav-item">
                                    <a class="nav-link" href="#map" role="tab" data-toggle="tab">
                                        <i class="fa fa-map-marker"></i>On the map</a>
                                  </li>
                                  <li class="nav-item">
                                    <a class="nav-link" href="#rating" role="tab" data-toggle="tab"><i class="fa fa-signal"></i>Rating</a>
                                  </li>
                                  <li class="nav-item">
                                    <a class="nav-link" href="#video" role="tab" data-toggle="tab"><i class="fa fa-youtube-play"></i>Video</a>
                                  </li>
                  
                                </ul>

                                <!-- Tab panes -->
                                <div class="tab-content u-padding-t-20">
                                  <div role="tabpanel" class="tab-pane fade in active show" id="photos">
                                      <div class="fotorama" data-nav="thumbs">
                                         <?php   
                                          echo getGallaeryImageSrcById($car_id, $service_type); 
                                          ?>
                                        </div>
                                  </div>

                                <!-- map tab content -->
                                  <div role="tabpanel" class="tab-pane fade" id="map">
                                        <div class="map-frame">
                                            <iframe src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d387193.30594184523!2d-74.25986594809962!3d40.69714941820045!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x89c24fa5d33f083b%3A0xc80b8f06e177fe62!2sNew+York%2C+NY%2C+USA!5e0!3m2!1sen!2sbd!4v1540485618034"  frameborder="0" style="border:0" allowfullscreen></iframe>
                                        </div>
                                  </div>

                                
                                <!-- about tab content -->
                                  <div role="tabpanel" class="tab-pane fade" id="rating">
                                    <div class="row">
                                        <div class="col-lg-7">
                                            <div class="rat-summary">
                                              <h3>Traveler rating</h3>
                                              <ul>
                                                  <li>
                                                    <span class="left">Exellent</span>
                                                    <span class="right"></span>
                                                </li>
                                                  <li>
                                                    <span class="left">Vey Good</span>
                                                    <span class="right"></span>
                                                </li>
                                                  <li>
                                                    <span class="left">Average</span>
                                                    <span class="right"></span>
                                                </li>
                                                  <li>
                                                    <span class="left">Poor</span>
                                                    <span class="right"></span>
                                                </li>
                                                  <li>
                                                    <span class="left">Terrible</span>
                                                    <span class="right"></span>
                                                </li>
                                              </ul>
                                              <a class="btn btn-primary" href="#">Write a review</a>
                                          </div>
                                        </div>
                                                <div class="col-lg-5">
                                                    <div class="rat-summary">
                                                        <h3>Give Me Ratings</h3>
                                                    </div>
                                                    <ul class="list booking-item-raiting-summary-list stats-list-select"> 

                                                     <?php echo ratingsFunctions($car_id, $service_type); ?>
                                                     </ul></div>
                                    </div>
                                  </div>

                                <!-- Facilities tab content-->
                                  <div role="tabpanel" class="tab-pane fade" id="video">
                                       <div class="tab-video">
                                           <iframe src="https://www.youtube.com/embed/6lt2JfJdGSY" frameborder="0" allow="accelerometer; autoplay; encrypted-media; gyroscope; picture-in-picture" allowfullscreen></iframe>
                                       </div>
                                  </div>



                                </div>
                            </div>
                </div> <!-- col-6 end -->


                <div class="col-lg-3 col-12">
                        <form method="post">
                            <div class="car-info alt">
                                <div class="sec-calc">
                                    <div class="calc-left"> 
                                    

                                    <?php  
                                      $wp_post_db = "car_packages";  
                                      $show_vendor_posts = $wpdb->get_results("SELECT * FROM $wp_post_db ORDER BY id DESC"); 
                                      $i=0;
                                      foreach( $show_vendor_posts as $show_vendor_post)  
                                      {   

                                      //print_r($show_vendor_post);
                                      $pid =  $show_vendor_post->id; 
                                      $package_name =  $show_vendor_post->package_name; 
                                      $package_price =  $show_vendor_post->package_price;   
                                      ?>   
                                        <div class="custom-control custom-checkbox">
                                            <input type="radio" class="custom-control-input" id="<?php echo $pid; ?>" name="package_id" value="<?php echo $pid; ?>">
                                            <label class="custom-control-label" for="<?php echo $pid; ?>"><?php echo $package_name; ?><span>$<?php echo $package_price; ?></span></label>
                                        </div>
                                        <?php } ?>

                                    </form>
                                        
 
                                    </div> <!-- calc-left -->
                                    <div class="res-right">
                                        <ul>
                                            <li>Price Per Day <span>$66,55</span></li>
                                            <li>Equipment <span>Free</span></li>
                                        </ul>
                                        <input type="hidden" name="car_id" value="<?php echo $car_id; ?>">
                                       <button style="width: 150px" class="btn btn-primary" name="car_book_now">Book Now</button>
                                    </div>
                                    
                                </div>

                            </div>
                    </form>

                </div> <!-- col-3 end -->

                <div class="col-lg-3 col-12">
                    <div class="info-car-brand">
                        <ul> 

                            <li>
                                <h5>Phone:</h5>
                                <p><i class="fa fa-phone box-icon-inline box-icon-gray"></i>+<?php echo $car_phone_no; ?></p>
                            </li>
                             <li>
                                <h5>Email:</h5>
                                <p><i class="fa fa-envelope-o box-icon-inline box-icon-gray"></i><?php echo $car_email; ?></p>
                            </li>

                            <li><h5>Pick Up:</h5>
                                <p><i class="fa fa-map-marker box-icon-inline box-icon-gray"></i>none</p>
                                <p><i class="fa fa-calendar box-icon-inline box-icon-gray"></i><?php echo $car_check_in; ?></p>
                                <p><i class="fa fa-clock-o box-icon-inline box-icon-gray"></i>12:00 AM</p>
                            </li>
                            <li>   
                                <h5>Drop Off:</h5>
                                <p><i class="fa fa-map-marker box-icon-inline box-icon-gray"></i>none</p>
                                <p><i class="fa fa-calendar box-icon-inline box-icon-gray"></i><?php echo $car_check_out; ?></p>
                                <p><i class="fa fa-clock-o box-icon-inline box-icon-gray"></i>12:00 AM</p>
                            </li>
                        </ul>
                        <a data-toggle="modal" data-target="#booknowmodal" class="btn btn-primary btn-sm" href="#">Change Location & Date</a>
                    </div>
                </div>
            </div>
        </div>
    </div>





<div class="car-det-des">
    <div class="container">
        <div class="car-des u-padding-b-20">
            <h4>Overview</h4>
            <p> <?php echo $car_description; ?></p>
        </div>

                        <div class="car-feat">
                            <div class="feat-bl">
                                <h4>Car Features</h4>
                                <ul>
                                    <li>
                                       <i class="fa fa-briefcase"></i>
                                       <span>2 Pieces of Luggage</span>
                                    </li>
                                    <li>
                                       <i class="fa fa-briefcase"></i>
                                       <span>3 Doors</span>
                                    </li>
                                    <li>
                                       <i class="fa fa-briefcase"></i>
                                       <span>Automatic Transmission</span>
                                    </li>
                                    <li>
                                       <i class="fa fa-briefcase"></i>
                                       <span>Up to 4 Passengers</span>
                                    </li>
                                    <li>
                                       <i class="fa fa-briefcase"></i>
                                       <span>Gas Vehicle</span>
                                    </li>
                                </ul>
                            </div>
                            <div class="feat-bl">
                                <h4>Default Equipment</h4>
                                <ul>
                                    <li>
                                       <i class="fa fa-briefcase"></i>
                                       <span>Climate Control</span>
                                    </li>
                                    <li>
                                       <i class="fa fa-briefcase"></i>
                                       <span>FM Radio</span>
                                    </li>
                                    <li>
                                       <i class="fa fa-briefcase"></i>
                                       <span>Power Door Locks</span>
                                    </li>
                                    <li>
                                       <i class="fa fa-briefcase"></i>
                                       <span>Power Windows</span>
                                    </li>
                                    <li>
                                       <i class="fa fa-briefcase"></i>
                                       <span>Stereo CD/MP3</span>
                                    </li>
                                </ul>
                            </div>
                            <div class="feat-bl">
                                <h4>Pickup Features</h4>
                                <ul>
                                    <li>
                                       <i class="fa fa-briefcase"></i>
                                       <span>2 Pieces of Luggage</span>
                                    </li>
                                </ul>
                            </div>
                        </div>




            <div class="sec-rev-relhot">
                <div class="cm-full">
                    <div class="hotel-rev">
                        <div class="rev-title">
                            <h3>Car Reviews</h3>
                        </div>
                        <ul class="booking-item-reviews list">
                         <?php echo reviewlists($tour_id, $service_type); ?>  
                        </ul>
                    </div>

              
                     

              <div class="box bg-gray   u-margin-t-40">   
              <div id="respond" class="comment-respond">
              <h3 id="reply-title" class="comment-reply-title">Write a review </h3>          
              <div class="row"> 
              <?php echo writeReviewForm($tour_id, $service_type); ?>  
              </div><!--End Row-->   
              </div><!-- #respond -->


              </div>

                </div> <!-- col-8 -->

            </div>
                





    </div>
</div>




  

<?php

get_footer();

?>

<script>
 jQuery('.datepicker').datepicker();
</script>   