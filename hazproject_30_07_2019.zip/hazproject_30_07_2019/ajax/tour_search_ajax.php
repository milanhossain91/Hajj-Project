<?php  

include '../../../../wp-load.php'; 
global $wpdb;  
 
   $tour_location = $_POST['tour_location'];  
   $category_id = $_POST['category_id'];  
   $service_type = 'tours';

        
                      $wp_post_db = "tour_details";  
                      $show_vendor_posts = $wpdb->get_results("SELECT * FROM $wp_post_db WHERE tour_location LIKE '%$tour_location%' OR category_id ='$category_id' ORDER BY id DESC"); 
                      $num_rows = $wpdb->num_rows; 

                      ?>

                   <div class="sec-ti u-padding-b-20">
                        <h3 class="font-weight300">Advanced Search (<?php echo $num_rows; ?>)</h3>
                    </div>
                    <div class="row " >
                      <?php
                       if($num_rows  > 0){
                      $i=0;
                      foreach( $show_vendor_posts as $show_vendor_post)  
                      {   
                      //print_r($show_vendor_post);
                       $tid =  $show_vendor_post->id; 
                      $tour_title =  $show_vendor_post->tour_title; 
                      $tour_description =  $show_vendor_post->tour_description; 
                      $tour_location =  $show_vendor_post->tour_location;       
                      $tour_price =  $show_vendor_post->tour_price;                                                
                      ?>    
                       
                        <div class="col-sm-6 col-lg-6">
                            <div class="tour-item">
                              


                      <a href="<?php echo site_url().'/tour-details/?tour_id='.$tid;?>" class="fig">
                      <img style="height:190px;" src="<?php echo getImageSrcById($tid, $service_type); ?>">
                                        <h4><?php echo $tour_title; ?></h4>
                                    </a>

                                    <div class="content">

                                        <div class="left">
                                            <div class="location">
                                                <i class="fa fa-map-marker"></i>
                                                <span><?php echo $tour_location; ?></span>
                                            </div>
                                            <div class="price">
                                                <i class="fa fa-money"></i>
                                                <span>$<?php echo $tour_price; ?></span>
                                            </div>
                                        </div>
                                        <div class="right">
                                            <div class="cal">
                                                <i class="fa fa-calendar"></i>
                                                <span>3</span>
                                            </div>
                                             <div class="stars">
                                                <i class="fa fa-star"></i>         
                                                <i class="fa fa-star"></i>         
                                                <i class="fa fa-star"></i>         
                                                <i class="fa fa-star"></i>         
                                                <i class="fa fa-star"></i>         
                                            </div>
                                        </div>
                                    </div>
                            </div>
                        </div> <!-- col -6 --> 


                        <?php } }else{ ?>

                <h4>No data found.</h4>

              <?php } ?>
                        </div><!-- row-->
 