<?php  

include '../../../../wp-load.php'; 
global $wpdb;  

 
  $Hotellocation = $_POST['Hotellocation']; 
  $check_in = date("Y-m-d", strtotime($_POST['check_in'])); 
  $check_out = date("Y-m-d", strtotime($_POST['check_out']));   

  $service_type = 'hotels';
 
 
 

/*=================Search Function ====================*/
  $wp_post_db = "main_booking_details as mb INNER JOIN available_rooms as ar ON mb.post_id = ar.id";

  $show_vendor_posts = $wpdb->get_results("SELECT  ar.*, mb.booking_total as BookingTotal, room_title FROM $wp_post_db  WHERE mb.check_in >= '$check_in' AND mb.check_out <= '$check_out'");      

    $ArrayAvailableHotelId = array();
    $ArrayUnavialableHotelIds = "";
    $counter = 0;
    foreach( $show_vendor_posts as $show_vendor_post )  //print_r($show_vendor_post);  
    {  
 
     $BookingTotal = $show_vendor_post->BookingTotal;
     $available_room =  $show_vendor_post->total_room;    

     if($BookingTotal < $available_room ){
           $ArrayAvailableHotelId[] = $show_vendor_post->hotel_id; //available
     }     
     if($BookingTotal >= $available_room ){        
 
     $ArrayUnavialableHotelIds .= $show_vendor_post->hotel_id.','; //unavailable         

      }
    } 
   $ArrayUnavialableHotelId =  rtrim($ArrayUnavialableHotelIds,',');


/*=================Search Function ====================*/

        
                      $wp_post_db = "hotel_details";  
                      $show_vendor_posts = $wpdb->get_results("SELECT * FROM $wp_post_db WHERE id NOT IN ('$ArrayUnavialableHotelId') AND hotel_location LIKE '%$Hotellocation%' ORDER BY id DESC"); 
                       $num_rows = $wpdb->num_rows;
                      ?>

                       <div class="sec-ti u-padding-b-20 ajax_result">
                        <h3 class="font-weight300">Advanced Search (<?php echo $num_rows; ?>)</h3>
                    </div>
                    <div class="row ">      
                    <?php
                  if($num_rows  > 0){
                      $i=0;
                      foreach( $show_vendor_posts as $show_vendor_post)  
                      {   
                      //print_r($show_vendor_post);
                      $hid =  $show_vendor_post->id; 
                      $hotel_title =  $show_vendor_post->hotel_title; 
                      $hotel_description =  $show_vendor_post->hotel_description;    
                      $hotel_price =  $show_vendor_post->hotel_price;                                                
                      ?>   
 
                        <div class="col-lg-6">
                            <div class="top-deal-item">
                                <a href="<?php echo site_url().'/hotel-details/?id='.$hid; ?>" class="fig">
                                    <img src="<?php echo getImageSrcById($hid, $service_type); ?>">
                                    <span>Book Now</span>
                                </a>
                                       
                                <div class="content">
                                    <div class="icons">
                                        <i class="fa fa-star"></i>         
                                        <i class="fa fa-star"></i>         
                                        <i class="fa fa-star"></i>         
                                        <i class="fa fa-star"></i>         
                                        <i class="fa fa-star"></i>         
                                    </div>
                                    <h5><a href="#"><?php echo $hotel_title; ?></a></h5>
                                    <div class="location">
                                        <i class="fa fa-map-marker"></i>
                                        <span> <?php echo $hotel_description; ?></span>
                                    </div>
                                    <p class="mb0">from $<?php echo $hotel_price; ?> <small>/night</small></p>
                                </div>
                           
                            </div>
                        </div>
  <?php } }else{ ?>

    <h4>No data found.</h4>

  <?php } ?>
  </div><!-- row-->
 