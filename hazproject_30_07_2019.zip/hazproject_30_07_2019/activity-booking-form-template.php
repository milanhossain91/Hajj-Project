<?php
/**
 * Template Name: Activity Booking Form 
 */

get_header();
require_once('functions/activity_functions.php'); 
?>

   
       

    
    <div class="booking-page has-border-top">
        <div class="container">
            <div class="row">

                <div class="col-lg-8">
                <form method="post">
                    <div class="booking_s_form">
                        <h3>Booking Submission</h3>
                        <div class="row">

                            <div class="col-lg-6">
                                <div class="form-group form-group-icon-left">
                                    <label for="">Name <sup>*</sup></label>
                                    <input placeholder="First Name" name="u_name" class="form-control"  type="text"required>
                                    <i class="fa fa-user input-icon "></i>
                                </div>
                            </div> 

                            <div class="col-lg-6">
                                <div class="form-group form-group-icon-left">
                                    <label for="">Email <sup>*</sup></label>
                                    <input placeholder="Email" name="u_email" class="form-control" type="text"required>
                                    <i class="fa fa-envelope  input-icon "></i>
                                </div>
                            </div>


                            <div class="col-lg-6">
                                <div class="form-group form-group-icon-left">
                                    <label for="">Phone  <sup>*</sup></label>
                                    <input placeholder="Phone" name="u_cell" class="form-control" type="text"required>
                                    <i class="fa fa-phone  input-icon "></i>
                                </div>
                            </div>

                            <div class="col-lg-6">
                                <div class="form-group form-group-icon-left">
                                    <label for="">Address Line 1<sup>*</sup></label>
                                    <input placeholder="Your Address " name="u_address" class="form-control" type="text"required>
                                    <i class="fa fa-map-marker  input-icon "></i>
                                </div>
                            </div>

                            <div class="col-lg-6">
                                <div class="form-group form-group-icon-left">
                                    <label for="">Address Line 2<sup>*</sup></label>
                                    <input placeholder="Your Address " name="u_address2" class="form-control" type="text">
                                    <i class="fa fa-map-marker  input-icon "></i>
                                </div>
                            </div>

                            <div class="col-lg-6">
                                <div class="form-group form-group-icon-left">
                                    <label for="">City<sup>*</sup></label>
                                    <input placeholder="Your City " name="u_city" class="form-control" type="text" required>
                                    <i class="fa fa-map-marker  input-icon "></i>
                                </div>
                            </div>

                            <div class="col-lg-6">
                                <div class="form-group form-group-icon-left">
                                    <label for="">State/Province/Region<sup>*</sup></label>
                                    <input placeholder="State/Province/Region" name="u_state" class="form-control" type="text">
                                    <i class="fa fa-map-marker  input-icon "></i>
                                </div>
                            </div>

                            <div class="col-lg-6">
                                <div class="form-group form-group-icon-left">
                                    <label for="">ZIP code/Postal code<sup>*</sup></label>
                                    <input placeholder="ZIP code/Postal code" name="u_zip" class="form-control" type="text" required>
                                    <i class="fa fa-map-marker  input-icon "></i>
                                </div>
                            </div>


                            <div class="col-lg-6">
                                <div class="form-group form-group-icon-left">
                                    <label for="">Country<sup>*</sup></label>
                                    <input placeholder="Country" class="form-control"  name="u_country" type="text" required>
                                    <i class="fa fa-map-marker  input-icon "></i>
                                </div>
                            </div>


                            <div class="col-lg-12">
                                <div class="form-group form-group-icon-left">
                                    <label for="">Special Requirements</label>
                                    <textarea class="form-control" rows="6" aname="u_comments" placeholder="Special Requirements"></textarea>
                                </div>
                            </div>

                        </div>
                    </div>


                    <div class="meta-bottom">
                        <div class="custom-control custom-checkbox u-margin-b-30">
                            <input type="checkbox" class="custom-control-input" id="ec1" required>
                            <label class="custom-control-label" for="ec1">
                                
                                I have read and accept the<a target="_blank" href="#"> terms and conditions</a> and <a href="#" target="_blank">Privacy Policy</a>        
                            </label>
                        </div>
                    </div>

                    <div class="form-submit row">
                       <?php      if(empty($_GET['order_id'])){?><button style="width: 150px" class="btn btn-primary" name="activity_booking_submit">Submit</button>
                        <?php } ?>
                     
                    </div>
                        <input type="hidden" name="booking_total" value="<?php echo $activity_price; ?>"> 

                </form>
   <div class="row">
                     <?php 

                        if(isset($_GET['order_id'])){?>
                             <div class="col-lg-3"> 
                           <label>Paypal</label>
                           <input type="radio" name="payment_options">

                          <?php include('paypal/paypal-form-activity.php');  ?>
                          </div>
                            <div class="col-lg-5"> 
                           <label>Stripe</label></br>
                           <input type="radio" name="payment_options"></br>
                          
                             <input type="text" name="customer_name" placeholder="Customer Name">
                              <input type="text" name="customer_name" placeholder="Customer Address">
                               <input type="text" name="customer_name" placeholder="Customer ID"></br>
                                <input type="submit" name="customer_name" value="Submit">
                            
                        </div> 
                       
                        <?php } ?>
                        </div>


                </div>





                <div class="col-md-4">
                    <h4>Your Booking:</h4>

                    <div class="booking-item-payment">
                    <header class="clearfix">
                        <a class="booking-item-payment-img" href="#">
                        <img width="98" height="74" src="<?php echo getImageSrcById($activity_id, 'activities');?>">            </a>
                        <h5 class="booking-item-payment-title"><a href="https://travelerwp.com/hotel/intercontinental-new-york-barclay/"><?php echo $activity_title; ?></a></h5>
                        <ul class="icon-group booking-item-rating-stars hotel-star">
                            <li><i class="fa  fa-star"></i></li>
                            <li><i class="fa  fa-star-o"></i></li>
                            <li><i class="fa  fa-star-o"></i></li>
                            <li><i class="fa  fa-star-o"></i></li>
                            <li><i class="fa  fa-star-o"></i></li>            
                        </ul> 
                     
                    </header>
                    <ul class="booking-item-payment-details">
                    

                <li>
                    <p class="booking-item-payment-price-title">
                        Maximum number of people:                  </p>
                    <p class="booking-item-payment-price-amount">
                              <?php echo $u_rooms; //get data from url ?>            </p>
                </li>

                  <li>
                    <p class="booking-item-payment-price-title">
                       Specific Date:                  </p>
                    <p class="booking-item-payment-price-amount">
                              <?php echo $specific_date; //get data from url ?>            </p>
                </li>
               
                </ul>
        </li>
    </ul>

                    
                        
                        <div class="booking-item-payment-total text-right">
                       



                                <table border="0" class="table_checkout">
                                <tbody><tr>
                                    <td class="text-left title">Subtotal</td>
                                    <td class="text-right "><strong>$<?php echo $activity_price; ?></strong></td>
                                </tr>
                                            <tr>
                                        <td class="text-left title">Extra Price</td>
                                        <td class="text-right "><strong>$0,00</strong></td>
                                    </tr>
                                        <tr>
                                    <td class="text-left title">
                                        Tax            </td>
                                    <td class="text-right "><strong>0 %</strong></td>
                                </tr>
                                <tr style="border-top: 1px solid #CCC; font-size: 20px; text-transform: uppercase; margin-top: 20px;">
                                        <td class="text-left title">Pay Amount</td>
                                        <td class="text-right "><strong>$<?php echo $activity_price; ?></strong></td>
                                    </tr>
                                    </tbody>
                                </table>
                        </div>
                    </div>               
                </div>
            </div>
        </div>
    </div>

 
 
  

<?php

get_footer();