<?php
/**
 * The template for displaying archive pages
 *
 * @link https://developer.wordpress.org/themes/basics/template-hierarchy/
 *
 * @package venox
 */

get_header();
?>

<div class="det-area car-det has-border u-padding-t-60 u-padding-b-60">
        <div class="container">
        <?php while (have_posts() ) : the_post(); ?>

        <section class="error-404 not-found">
				<header class="page-header">
					<h1 class="page-title">jhgjhgjhg<?php the_title(); ?></h1>
				</header><!-- .page-header -->

				<div class="page-content">

				   <?php the_content(); ?>
				</div>


		</section>

       <?php endwhile; wp_reset_postdata(); ?>

  </div>
</div>
	

<?php

get_footer();
