<?php

/**
 * venox functions and definitions
 *
 * @link https://developer.wordpress.org/themes/basics/theme-functions/
 *
 * @package venox
 */

if ( ! function_exists( 'venox_setup' ) ) :
  /**
   * Sets up theme defaults and registers support for various WordPress features.
   *
   * Note that this function is hooked into the after_setup_theme hook, which
   * runs before the init hook. The init hook is too late for some features, such
   * as indicating support for post thumbnails.
   */
  function venox_setup() {
    /*
     * Make theme available for translation.
     * Translations can be filed in the /languages/ directory.
     * If you're building a theme based on venox, use a find and replace
     * to change 'venox' to the name of your theme in all the template files.
     */
    load_theme_textdomain( 'venox', get_template_directory() . '/languages' );

    // Add default posts and comments RSS feed links to head.
    add_theme_support( 'automatic-feed-links' );

    /*
     * Let WordPress manage the document title.
     * By adding theme support, we declare that this theme does not use a
     * hard-coded <title> tag in the document head, and expect WordPress to
     * provide it for us.
     */
    add_theme_support( 'title-tag' );

    /*
     * Enable support for Post Thumbnails on posts and pages.
     *
     * @link https://developer.wordpress.org/themes/functionality/featured-images-post-thumbnails/
     */
    add_theme_support( 'post-thumbnails' );

    // This theme uses wp_nav_menu() in one location.
    register_nav_menus( array(
      'menu-1' => esc_html__( 'Primary', 'venox' ),
    ) );

    /*
     * Switch default core markup for search form, comment form, and comments
     * to output valid HTML5.
     */
    add_theme_support( 'html5', array(
      'search-form',
      'comment-form',
      'comment-list',
      'gallery',
      'caption',
    ) );

    // Set up the WordPress core custom background feature.
    add_theme_support( 'custom-background', apply_filters( 'venox_custom_background_args', array(
      'default-color' => 'ffffff',
      'default-image' => '',
    ) ) );

    // Add theme support for selective refresh for widgets.
    add_theme_support( 'customize-selective-refresh-widgets' );

    /**
     * Add support for core custom logo.
     *
     * @link https://codex.wordpress.org/Theme_Logo
     */
    add_theme_support( 'custom-logo', array(
      'height'      => 250,
      'width'       => 250,
      'flex-width'  => true,
      'flex-height' => true,
    ) );

    require_once('wp-advanced-search/wpas.php');
  }
endif;


add_action( 'after_setup_theme', 'venox_setup' );

/**
 * Set the content width in pixels, based on the theme's design and stylesheet.
 *
 * Priority 0 to make it available to lower priority callbacks.
 *
 * @global int $content_width
 */
function venox_content_width() {
  // This variable is intended to be overruled from themes.
  // Open WPCS issue: {@link https://github.com/WordPress-Coding-Standards/WordPress-Coding-Standards/issues/1043}.
  // phpcs:ignore WordPress.NamingConventions.PrefixAllGlobals.NonPrefixedVariableFound
  $GLOBALS['content_width'] = apply_filters( 'venox_content_width', 640 );
}
add_action( 'after_setup_theme', 'venox_content_width', 0 );

/**
 * Register widget area.
 *
 * @link https://developer.wordpress.org/themes/functionality/sidebars/#registering-a-sidebar
 */
function venox_widgets_init() {
  register_sidebar( array(
    'name'          => esc_html__( 'Sidebar', 'venox' ),
    'id'            => 'sidebar-1',
    'description'   => esc_html__( 'Add widgets here.', 'venox' ),
    'before_widget' => '<section id="%1$s" class="widget %2$s">',
    'after_widget'  => '</section>',
    'before_title'  => '<h2 class="widget-title">',
    'after_title'   => '</h2>',
  ) );
}
add_action( 'widgets_init', 'venox_widgets_init' );

/**
 * Enqueue scripts and styles.
 */
function venox_scripts() {
  wp_enqueue_style( 'venox-style', get_stylesheet_uri() );

  wp_enqueue_script( 'venox-navigation', get_template_directory_uri() . '/js/navigation.js', array(), '20151215', true );

  wp_enqueue_script( 'venox-skip-link-focus-fix', get_template_directory_uri() . '/js/skip-link-focus-fix.js', array(), '20151215', true );

  if ( is_singular() && comments_open() && get_option( 'thread_comments' ) ) {
    wp_enqueue_script( 'comment-reply' );
  }
}
add_action( 'wp_enqueue_scripts', 'venox_scripts' );

/**
 * Implement the Custom Header feature.
 */
//require get_template_directory() . '/inc/custom-header.php';

/**
 * Custom template tags for this theme.
 */
//require get_template_directory() . '/inc/template-tags.php';

/**
 * Functions which enhance the theme by hooking into WordPress.
 */
//require get_template_directory() . '/inc/template-functions.php';

/**
 * Customizer additions.
 */
//require get_template_directory() . '/inc/customizer.php';

require get_template_directory() . '/cmb/init.php';

 function cmb2_sample_metaboxes() {


      $umrah = new_cmb2_box( array(
    'id'            => 'umrah',
    'title'         => __( 'Umrah Package', 'cmb2' ),
    'object_types'  => array( 'umrah', ), // Post type
    'context'       => 'normal',
    'priority'      => 'high',
    'show_names'    => true, 

  ) );



  $umrah->add_field( array(
    'name' => esc_html__( 'Agent Name', 'cmb2' ),
    'desc' => esc_html__( 'Agent Name', 'cmb2' ),
    'id'   => 'agentname',
    
    'type' => 'text',
  ) );

  $umrah->add_field( array(
    'name' => esc_html__( 'Makkah Stay', 'cmb2' ),
    'desc' => esc_html__( 'Makkah Stay', 'cmb2' ),
    'id'   => 'makkahstay',
    
    'type' => 'text',
  ) );

  $umrah->add_field( array(
    'name' => esc_html__( 'Madinah Stay', 'cmb2' ),
    'desc' => esc_html__( 'Madinah Stay', 'cmb2' ),
    'id'   => 'madinahstay',
    
    'type' => 'text',
  ) );

    $umrah->add_field( array(
    'name' => esc_html__( 'Makkah Hotel Name', 'cmb2' ),
    'desc' => esc_html__( 'Makkah Hotel Name', 'cmb2' ),
    'id'   => 'makkahhotelhame',
    
    'type' => 'text',
  ) );

  $umrah->add_field( array(
    'name' => esc_html__( 'Makkah Hotel Distance', 'cmb2' ),
    'desc' => esc_html__( 'Makkah Hotel Distance', 'cmb2' ),
    'id'   => 'Makkahoteldistance',
    
    'type' => 'text',
  ) );

  $umrah->add_field( array(
    'name' => esc_html__( 'Madinah Hotel Name', 'cmb2' ),
    'desc' => esc_html__( 'Madinah Hotel Name', 'cmb2' ),
    'id'   => 'madinahhotelname',
    
    'type' => 'text',
  ) );

    $umrah->add_field( array(
    'name' => esc_html__( 'Madinah Hotel Distance', 'cmb2' ),
    'desc' => esc_html__( 'Madinah Hotel Distance', 'cmb2' ),
    'id'   => 'madinahhoteldistance',
    
    'type' => 'text',
  ) );

    $umrah->add_field( array(
    'name' => esc_html__( 'location Map', 'cmb2' ),
    'desc' => esc_html__( 'Input map location', 'cmb2' ),
    'id' => $prefix . 'locationmap',
    'type' => 'pw_map',
  ) );

  $umrah->add_field( array(
    'name' => esc_html__( 'Check in', 'cmb2' ),
    'desc' => esc_html__( 'Check in', 'cmb2' ),
    'id' => $prefix . 'locationcheckins',
    'type' => 'text_date',
  ) );


  $umrah->add_field( array(
    'name' => esc_html__( 'Check out', 'cmb2' ),
    'desc' => esc_html__( 'Check out', 'cmb2' ),
    'id' => $prefix . 'locationcheckout',
    'type' => 'text_date',
  ) );

  $umrah->add_field( array(
    'name' => esc_html__( 'Total Room', 'cmb2' ),
    'desc' => esc_html__( 'Total Room Booking', 'cmb2' ),
    'id' => $prefix . 'umrahroom',
    'type' => 'text_small',
  ) );

    $umrah->add_field( array(
    'name' => esc_html__( 'Total Parson', 'cmb2' ),
    'desc' => esc_html__( 'Total Parson Set Par Room', 'cmb2' ),
    'id' => $prefix . 'umrahparson',
    'type' => 'text_small',
  ) );



  $umrah->add_field( array(
    'name' => esc_html__( 'Double Bed', 'cmb2' ),
    'desc' => esc_html__( 'Price Range Double Bed', 'cmb2' ),
    'id' => $prefix . 'umrahdouble',
    'type' => 'text_money',
  ) );

  $umrah->add_field( array(
    'name' => esc_html__( 'Triple Bed', 'cmb2' ),
    'desc' => esc_html__( 'Price Range Triple Bed', 'cmb2' ),
    'id' => $prefix . 'umrahtriplebed',
    'type' => 'text_money',
  ) );

  $umrah->add_field( array(
    'name' => esc_html__( 'Quad(4 Bed)', 'cmb2' ),
    'desc' => esc_html__( 'Price Range Quad(4 Bed)', 'cmb2' ),
    'id' => $prefix . 'umrahfourbed',
    'type' => 'text_money',
  ) );

    $umrah->add_field( array(
    'name' => esc_html__( 'Sharing ', 'cmb2' ),
    'desc' => esc_html__( 'Price Range Sharing ', 'cmb2' ),
    'id' => $prefix . 'umrahsharing',
    'type' => 'text_money',
  ) );


   $umrah->add_field( array(
    'name' => esc_html__( 'Policies', 'cmb2' ),
    'desc' => esc_html__( 'Policies', 'cmb2' ),
    'id' => $prefix . 'umrahpolicies',
    'type' => 'wysiwyg',
  ) );

   $umrah->add_field( array(
    'name' => esc_html__( 'Facilites', 'cmb2' ),
    'desc' => esc_html__( 'Facilites', 'cmb2' ),
    'id' => $prefix . 'umrahfacilites',
    'type' => 'wysiwyg',
  ) );





    $restaurant = new_cmb2_box( array(
    'id'            => 'restaurant',
    'title'         => __( 'Restaurant Information', 'cmb2' ),
    'object_types'  => array( 'restaurant', ), // Post type
    'context'       => 'normal',
    'priority'      => 'high',
    'show_names'    => true, 

  ) );


  $restaurant->add_field( array(
    'name' => esc_html__( 'Phone', 'cmb2' ),
    'desc' => esc_html__( 'Phone', 'cmb2' ),
    'id'   => 'restaurantphone',
    
    'type' => 'text',
  ) );

    $restaurant->add_field( array(
      'name' => 'Email',
      'id'   => 'restaurantemail',
      'type' => 'text_email',
       ) );

    $restaurant->add_field( array(
      'name' => 'Restaurant Address',
      'desc' => 'Restaurant Address',
      
      'id' => 'restaurantaddress',
      'type' => 'textarea_small'
    ) );




 

  $restaurant->add_field( array(
    'name' => esc_html__( 'Open Time', 'cmb2' ),
    'desc' => esc_html__( 'Open Time', 'cmb2' ),
    'id' => $prefix . 'restaurantopentime',
    'type' => 'text_datetime_timestamp',
  ) );


  $restaurant->add_field( array(
    'name' => esc_html__( 'Close Time', 'cmb2' ),
    'desc' => esc_html__( 'Close Time', 'cmb2' ),
    'id' => $prefix . 'restaurantclosetime',
    'type' => 'text_datetime_timestamp',
  ) );




    $cars = new_cmb2_box( array(
    'id'            => 'cars',
    'title'         => __( 'Umrah Package', 'cmb2' ),
    'object_types'  => array( 'cars', ), // Post type
    'context'       => 'normal',
    'priority'      => 'high',
    'show_names'    => true, 

  ) );

  $cars->add_field( array(
    'name' => esc_html__( 'Agent Name', 'cmb2' ),
    'desc' => esc_html__( 'Agent Name', 'cmb2' ),
    'id'   => 'agentname',
    
    'type' => 'text',
  ) );

  $cars->add_field( array(
    'name' => esc_html__( 'Agent Location', 'cmb2' ),
    'desc' => esc_html__( 'Agent Location', 'cmb2' ),
    'id'   => 'agentlocation',
    
    'type' => 'text',
  ) );



  $cars->add_field( array(
    'name' => esc_html__( 'Agent Email', 'cmb2' ),
    'desc' => esc_html__( 'Agent Email', 'cmb2' ),
    'id'   => 'agentemail',
    
    'type' => 'text_email',
  ) );

  $cars->add_field( array(
    'name' => esc_html__( 'Agent Phone', 'cmb2' ),
    'desc' => esc_html__( 'Agent Phone', 'cmb2' ),
    'id'   => 'agentphone',
    
    'type' => 'text',
  ) );

  $cars->add_field( array(
  'name'    => 'Agent Logo',
  'desc'    => 'Upload an agent logo or enter an URL.',
  'id'      => 'agentlogo',
  'type'    => 'file',
  // Optional:
  'options' => array(
    'url' => false, // Hide the text input for the url
  ),
  'text'    => array(
    'add_upload_file_text' => 'Add File' // Change upload button text. Default: "Add or Upload File"
  ),
  // query_args are passed to wp.media's library query.
  'query_args' => array(
    'type' => 'application/pdf', // Make library only display PDFs.
    // Or only allow gif, jpg, or png images
    // 'type' => array(
    //  'image/gif',
    //  'image/jpeg',
    //  'image/png',
    // ),
  ),
  'preview_size' => 'small', // Image size to use when previewing in the admin.
) );

  $cars->add_field( array(
    'name' => esc_html__( 'Old Price', 'cmb2' ),
    'desc' => esc_html__( 'Old Price', 'cmb2' ),
    'id'   => 'oldprice',
    
    'type' => 'text_money',
  ) );

    $cars->add_field( array(
    'name' => esc_html__( 'Present Price', 'cmb2' ),
    'desc' => esc_html__( 'Present Price', 'cmb2' ),
    'id'   => 'presentprice',
    
    'type' => 'text_money',
  ) );

  $cars->add_field( array(
    'name' => esc_html__( 'Child Toddler Seat', 'cmb2' ),
    'desc' => esc_html__( 'Child Toddler Seat', 'cmb2' ),
    'id'   => 'Makkahoteldistance',
    
    'type' => 'text_money',
  ) );

  $cars->add_field( array(
    'name' => esc_html__( 'Ski Rack', 'cmb2' ),
    'desc' => esc_html__( 'Ski Rack', 'cmb2' ),
    'id'   => 'madinahhotelname',
    
    'type' => 'text_money',
  ) );

    $cars->add_field( array(
    'name' => esc_html__( 'Infant Child Seat', 'cmb2' ),
    'desc' => esc_html__( 'Infant Child Seat', 'cmb2' ),
    'id'   => 'madinahhoteldistance',
    
    'type' => 'text_money',
  ) );

    $cars->add_field( array(
    'name' => esc_html__( 'GPS Satellite', 'cmb2' ),
    'desc' => esc_html__( 'GPS Satellite', 'cmb2' ),
    'id' => $prefix . 'locationmap',
    'type' => 'text_money',
  ) );

  $cars->add_field( array(
    'name' => esc_html__( 'Equipment', 'cmb2' ),
    'desc' => esc_html__( 'Equipment', 'cmb2' ),
    'id' => $prefix . 'carequipment',
    'type'    => 'wysiwyg',
     'options' => array(
      'wpautop' => true, // use wpautop?
      'media_buttons' => true, // show insert/upload button(s)
      'textarea_name' => $editor_id, // set the textarea name to something different, square brackets [] can be used here
      'textarea_rows' => get_option('default_post_edit_rows', 10), // rows="..."
      'tabindex' => '',
      'editor_css' => '', // intended for extra styles for both visual and HTML editors buttons, needs to include the `<style>` tags, can use "scoped".
      'editor_class' => '', // add extra class(es) to the editor textarea
      'teeny' => false, // output the minimal editor config used in Press This
      'dfw' => false, // replace the default fullscreen with DFW (needs specific css)
      'tinymce' => true, // load TinyMCE, can be used to pass settings directly to TinyMCE using an array()
      'quicktags' => true // load Quicktags, can be used to pass settings directly to Quicktags using an array()
  ),
  ) );


   





  }
  add_action( 'cmb2_admin_init', 'cmb2_sample_metaboxes' );



/**
 * Load Jetpack compatibility file.
 */
if ( defined( 'JETPACK__VERSION' ) ) {
  require get_template_directory() . '/inc/jetpack.php';
}

include_once('inc/pages_link.php');

/*register sidebar*/
function new_project(){

    
	register_sidebar(array(
       'name'=>'footer1',
       'description'=>'add footer1 this project',
       'id'=>'footer1',

       'before_title'=>'<h3>',
       'after_title'=>'</h3>',
       
        'before_widget'=>'<div class="column1 animate" data-anim-type="fadeIn" data-anim-delay="100">',
       'after_widget'=>'</div>',





		));
	register_sidebar(array(
       'name'=>'footer2',
       'description'=>'add footer2 this project',
       'id'=>'footer2',

       'before_title'=>'<h3>',
       'after_title'=>'</h3>',
       'before_widget'=>'<div class="column2 animate" data-anim-type="fadeIn" data-anim-delay="150">',
       'after_widget'=>'</div>'
       




		));
    register_sidebar(array(
       'name'=>'footer3',
       'description'=>'add footer3 this project',
       'id'=>'footer3',

        'before_title'=>'<h3>',
       'after_title'=>'</h3>',
       'before_widget'=>'<div class="column1 animate" data-anim-type="fadeIn" data-anim-delay="200">',
       'after_widget'=>'</div>'
       





    ));
        register_sidebar(array(
       'name'=>'footer4',
       'description'=>'add footer4 this project',
       'id'=>'footer4',

        'before_title'=>'<h3>',
       'after_title'=>'</h3>',
       'before_widget'=>'<div class="column1 last animate" data-anim-type="fadeIn" data-anim-delay="250">',
       'after_widget'=>'</div>'
       





    ));
          register_sidebar(array(
       'name'=>'footerbottom-right',
       'description'=>'add footerbottom-right this project',
       'id'=>'footerbottom-right',

        'before_title'=>'<h6 class="pi-margin-bottom-25 pi-weight-700 pi-uppercase pi-letter-spacing">',
       'after_title'=>'</h6>',
       'before_widget'=>'<div class="pi-header-block pi-pull-right pi-hidden-2xs">',
       'after_widget'=>'</div>'
       





    ));

     
    register_sidebar(array(
       'name'=>'pagesidebar ',
       'description'=>'add pagesidebar this project',
       'id'=>'page_sidebar',

        'before_title'=>'<h6 class="footer-title">',
       'after_title'=>'</h6>',
       'before_widget'=>'<div class="right_sidebar">
',
       'after_widget'=>'</div>',





    ));
	
}
add_action('widgets_init','new_project');



function read_more(){

  $post_content = explode(" ", get_the_content());
  $less_content = array_slice($post_content, 0, $limit);
  echo implode(" ",$less_content);

}
add_action('after_setup_theme','read_more');

function more_link_design($link){
  $link = preg_replace('|#more-[0-9]+|','', $link);
  return $link;

}
add_filter('the_content_more_link','more_link_design');


/*CSS And JS File Register*/
include_once('inc/css_and_js.php');
//include_once('inc/acf/acf.php');
/* Redux Framework registration*/
include_once('includes/ReduxCore/framework.php');

include_once('includes/sample/Rsnetwork-config.php');



function mytheme_add_woocommerce_support() {
    add_theme_support( 'woocommerce', array(
        'thumbnail_image_width' => 450,
        'single_image_width'    => 300,

        'product_grid'          => array(
            'default_rows'    => 3,
            'min_rows'        => 2,
            'max_rows'        => 8,
            'default_columns' => 4,
            'min_columns'     => 2,
            'max_columns'     => 5,
        ),
    ) );
}

add_action( 'after_setup_theme', 'mytheme_add_woocommerce_support' );

add_action( 'woocommerce_before_calculate_totals', 'add_custom_price' );

function add_custom_price( $cart_object ) {
    foreach ( $cart_object->cart_contents as $key => $value ) {
        $custom_price = 5;
        $value['data']->set_price($custom_price); 
    }
}

/**
 * Add another product depending on the cart total
 */
add_action( 'template_redirect', 'add_product_to_cart' );
function add_product_to_cart() {
  if ( ! is_admin() ) {
    global $woocommerce;
    $product_id = 2831; //replace with your product id
    $found = false;
    $cart_total = 30; //replace with your cart total needed to add above item

    if( $woocommerce->cart->total >= $cart_total ) {
      //check if product already in cart
      if ( sizeof( $woocommerce->cart->get_cart() ) > 0 ) {
        foreach ( $woocommerce->cart->get_cart() as $cart_item_key => $values ) {
          $_product = $values['data'];
          if ( $_product->get_id() == $product_id )
            $found = true;
        }
        // if product not found, add it
        if ( ! $found )
          $woocommerce->cart->add_to_cart( $product_id );
      } else {
        // if no products in cart, add it
        $woocommerce->cart->add_to_cart( $product_id );
      }
    }
  }
}

// Hook in



add_filter('woocommerce_admin_billing_fields', 'wdm_add_extra_customer_field');
add_filter('woocommerce_admin_shipping_fields', 'wdm_add_extra_customer_field');









function wdm_add_extra_customer_field( $fields ){
    
    //take back up of email and phone fields as they will be lost after repositioning
    $email = $fields['email']; 
    $phone = $fields['phone'];

    $fields = wdm_override_default_address_fields( $fields );
    
    //reassign email and phone fields
    $fields['email'] = $email;
    $fields['phone'] = $phone;
    
    global $wdm_ext_fields;
    
    if(is_array($wdm_ext_fields)){
        
        foreach($wdm_ext_fields as $wef){
            $fields[$wef]['show'] = false; //hide the way they are display by default as we have now merged them within the address field
        }
    }
    
    return $fields;
}
function umrah_advance_search() {
   

    $args = array();
    //$custom_terms = get_terms('CarsName');
    $args['wp_query'] = array( 'post_type' => array('umrah'), 
                               'orderby' => 'title', 
                               'order' => 'ASC' );

    $args['form'] = array( 'auto_submit' => true );

    $args['form']['ajax'] = array( 'enabled' => true,
                                   'show_default_results' => true,
                                   'results_template' => 'template-ajax-results.php', // This file must exist in your theme root
                                   'button_text' => 'Load More Results');

 
    $args['fields'][] = array( 

                          'type' => 'taxonomy',
                          
                          'format' => 'checkbox',
                          'taxonomy' => 'package_class',
                          
                        
                          
                        
                       
                 



      );




   
    register_wpas_form('myform', $args);
}
add_action('init', 'umrah_advance_search');


function umrah_advancenofotheday_search() {
   

    $args = array();
    //$custom_terms = get_terms('CarsName');
    $args['wp_query'] = array( 'post_type' => array('umrah'), 
                               'orderby' => 'title', 
                               'order' => 'ASC' );

    $args['form'] = array( 'auto_submit' => true );

    $args['form']['ajax'] = array( 'enabled' => true,
                                   'show_default_results' => true,
                                   'results_template' => 'template-ajax-results.php', // This file must exist in your theme root
                                   'button_text' => 'Load More Results');

 
    $args['fields'][] = array( 

                          'type' => 'taxonomy',
                          
                          'format' => 'checkbox',
                          'taxonomy' => 'no_of_days',
                          
                        
                          
                        
                       
                 



      );




   
    register_wpas_form('myonoftheform', $args);
}
add_action('init', 'umrah_advancenofotheday_search');

function umrah_pricerange_search() {
   

    $args = array();
    //$custom_terms = get_terms('CarsName');
    $args['wp_query'] = array( 'post_type' => array('umrah'), 
                               'orderby' => 'title', 
                               'order' => 'ASC' );

    $args['form'] = array( 'auto_submit' => true );

    $args['form']['ajax'] = array( 'enabled' => true,
                                   'show_default_results' => true,
                                   'results_template' => 'template-ajax-results.php', // This file must exist in your theme root
                                   'button_text' => 'Load More Results');

 
    $args['fields'][] = array( 

                          'type' => 'taxonomy',
                          
                          'format' => 'checkbox',
                          'taxonomy' => 'price_range',
                          
                        
                          
                        
                       
                 



      );




   
    register_wpas_form('pricerangeform', $args);
}

add_action('init', 'umrah_pricerange_search');

 

 



function pmrahagencylistallpost(){
    
    //add_menu_page('My Page Title', 'My Menu Title', 'manage_options', 'my-menu', 'my_menu_output' );
     
     //add_menu_page('header footer script', 'Very Basic plugin', 'manage_options', 'idia_for_admin_menu','pluginadminmenu','',200);
     //add_submenu_page('header1 footer1 script', 'Very Basic1 plugin', 'manage_options', 'idia_for_admin1_menu','pluginadminmenu1');
     add_menu_page('header footer script', 'Umrah Booking List', 'manage_options', 'agency_for_admin_menu', 'pmrahpmrahagencylistallpostdouwn','',100);

     
   }
   add_action( 'admin_menu', 'pmrahagencylistallpost' );
   
   function pmrahpmrahagencylistallpostdouwn(){

     
      include_once('admin-page/form_ahagencyleads.php'); 

      
        
   }


add_action( 'admin_menu', 'books_register_ref_page' );
function books_register_ref_page() {
    $role = 'taibur';
    add_submenu_page(
        'edit.php?post_type=umrah',
        __( 'Booking', 'textdomain' ),
        __( 'Booking', 'textdomain' ),
         $role, 
      
        'books-shortcode-ref',
        'books_ref_page_callback'
    );
}

/**
* Display callback for the submenu page.
*/
function books_ref_page_callback() { 
    ?>
       <?php include_once('admin-page/form_ahagencyleads.php');?>   
    <?php
}









function pmrahpackageslistallpost(){
    
    //add_menu_page('My Page Title', 'My Menu Title', 'manage_options', 'my-menu', 'my_menu_output' );
     
     //add_menu_page('header footer script', 'Very Basic plugin', 'manage_options', 'idia_for_admin_menu','pluginadminmenu','',200);
     //add_submenu_page('header1 footer1 script', 'Very Basic1 plugin', 'manage_options', 'idia_for_admin1_menu','pluginadminmenu1');
     add_menu_page('header footer script', 'Umrah Packages','manage_options', 'idia_for_admin_menu','pmrahpackageslistallpostdouwn','',100);
     
   }
   add_action( 'admin_menu', 'pmrahpackageslistallpost' );
   
   function pmrahpackageslistallpostdouwn(){

     
      include_once('admin-page/form_leads.php');

    

      
        
   }

   function xiong_theme_scripts() {

        //Ajax filter scripts     
        wp_register_script( 'ajax', get_template_directory_uri() . '/js/ajax.js', array( 'jquery' ), '1.0.0', true );
        wp_enqueue_script( 'ajax' );


        }
      add_action( 'wp_enqueue_scripts', 'xiong_theme_scripts' );



/* rabi custom code*/


//hook into the init action and call create_book_taxonomies when it fires
add_action( 'init', 'create_Hotels_hierarchical_taxonomy', 0 );
 
//create a custom taxonomy name it topics for your posts
  

/*===========Rabi custom code===============*/




function hotelMenu(){
    
   
  add_object_page( 'Hotels','Hotels','Hotels', 'Hotels', get_bloginfo('template_url').'/images/registry.png');
  add_submenu_page('Hotels', "Add Hotels", "Add Hotels", 8, 'add_hotels', 'addHotelsFunctions');   
  add_submenu_page('Hotels', "Add rooms", "Add Rooms", 8, 'add_rooms', 'addRoomFunctions'); 
        
   }

   add_action( 'admin_menu', 'hotelMenu' );
   
   function addRoomFunctions(){     
      include_once('admin-page/add_rooms.php');            
   }


   function addHotelsFunctions(){     
      include_once('admin-page/add_hotel.php');            
   }

   //car menu

   function carMenu(){
    
   
  add_object_page( 'Cars','Cars','Cars', 'Cars', get_bloginfo('template_url').'/images/registry.png');
  add_submenu_page('Cars', "Add Cars", "Add Cars", 8, 'add_cars', 'addCarsFunctions');   
  add_submenu_page('Cars', "Add Packages", "Add Packages", 8, 'add_packages', 'addPackageFunctions'); 
        
   }

   add_action( 'admin_menu', 'carMenu' );
   
   function addPackageFunctions(){     
      include_once('admin-page/add_cars_packages.php');            
   }

   function addCarsFunctions(){     
      include_once('admin-page/add_cars.php');            
   }




   //tour menu
  function tourMenu(){   
   
  add_object_page( 'Tours','Tours','Tours', 'Tours', get_bloginfo('template_url').'/images/registry.png');
  add_submenu_page('Tours', "Add Tours", "Add Tours", 8, 'add_tours', 'addToursFunctions');   
  add_submenu_page('Tours', "Add Category", "Add Category", 8, 'add_category', 'addCategoryFunctions'); 
        
   }

   add_action( 'admin_menu', 'tourMenu' );
   
   function addCategoryFunctions(){     
      include_once('admin-page/add_tour_category.php');            
   }

   function addToursFunctions(){     
      include_once('admin-page/add_tours.php');            
   }

     //activity menu
  function activityMenu(){      
    add_object_page( 'Activity','Activity','Activity', 'Activity', get_bloginfo('template_url').'/images/registry.png');
    add_submenu_page('Activity', "Add Activity", "Add Activity", 8, 'add_activities', 'addActivityFunctions');   
    add_submenu_page('Activity', "Add Category", "Add Category", 8, 'add_activity_category', 'addActivityCategoryFunctions');         
   }

   add_action( 'admin_menu', 'activityMenu' );
   
   function addActivityCategoryFunctions(){     
      include_once('admin-page/add_activity_category.php');            
   }

   function addActivityFunctions(){     
      include_once('admin-page/add_activities.php');            
   }




   //guide menu
  function guideMenu(){   
   
  add_object_page( 'Guide','Guide','Guide', 'Guide', get_bloginfo('template_url').'/images/registry.png');
  add_submenu_page('Guide', "Add Guide", "Add Guide", 8, 'add_guides', 'addGuideFunctions');   
  add_submenu_page('Guide', "Add Guide Category", "Add Guide Category", 8, 'add_Guide_category', 'addGuideCategoryFunctions'); 
        
   }

   add_action( 'admin_menu', 'guideMenu' );
   
   function addGuideCategoryFunctions(){     
      include_once('admin-page/add_guide_category.php');            
   }

   function addGuideFunctions(){     
      include_once('admin-page/add_guide.php');            
   }




/*==============functions=========================*/
function getVideoSrcById($service_id, $service_type){ 
global $wpdb;
$service_type  = substr($service_type, 0, -1); 
$wp_post_db = $service_type."_details";
//hotel_id= room_id
$show_vendor_posts = $wpdb->get_results("SELECT * FROM $wp_post_db WHERE service_type='$service_type' AND service_id='$service_id'  ORDER BY id DESC LIMIT 1");  
foreach( $show_vendor_posts as $show_vendor_post) 
{  
   echo "https://www.youtube.com/embed/".$show_vendor_post->video;   
}
}


function getServiceNameById($service_id){ 
global $wpdb;
$wp_post_db = "hotel_offers"; 
 
$show_vendor_posts = $wpdb->get_results("SELECT * FROM $wp_post_db WHERE  id='$service_id'  ORDER BY id DESC");  
foreach( $show_vendor_posts as $show_vendor_post) 
{  
   echo $show_vendor_post->service_name;   
}
}



function getImageSrcById($service_id, $service_type){ 
global $wpdb;
$wp_post_db = "new_order_img";
//hotel_id= room_id
 //echo "SELECT * FROM $wp_post_db WHERE service_type='$service_type' AND service_id='$service_id'  ORDER BY id DESC LIMIT 1"; 
$show_vendor_posts = $wpdb->get_results("SELECT * FROM $wp_post_db WHERE service_type='$service_type' AND service_id='$service_id'  ORDER BY id DESC LIMIT 1");  
foreach( $show_vendor_posts as $show_vendor_post) 
{  
   echo get_template_directory_uri().$show_vendor_post->img_url;   
}
}
 

function getGallaeryImageSrcById($service_id, $service_type){ 
global $wpdb;
  $wp_post_db = "new_order_img";
  //echo "SELECT * FROM $wp_post_db WHERE service_id='$service_id' And service_type='hotels' ORDER BY id DESC";
  $show_vendor_posts = $wpdb->get_results("SELECT * FROM $wp_post_db WHERE service_id='$service_id' And service_type='$service_type' ORDER BY id DESC"); 
  $i=0;
  foreach( $show_vendor_posts as $show_vendor_post) 
  {  
  //print_r($show_vendor_post);
    $img_url =  $show_vendor_post->img_url;                                              
  ?> 

   <img src="<?php echo get_template_directory_uri().$img_url; ?>">

  <?php 
  }

}
 
function ratingsRatio($service_id, $service_type){

 global $wpdb;
      //ratting rate 
      $sql ="SELECT * FROM ratings WHERE service_id='$service_id' AND service_type='$service_type'";
      $results = $wpdb->get_results($sql); 
      $num_rows = $wpdb->num_rows; 
      $count = count($results); 
      foreach($results as $row){
          $id = $row->id; 
          $ratings_val += $row->ratings_val; 
      }

     
      if($num_rows >0){
  $ratings_float =  $ratings_val  / $count;
  $ratings_rate =  number_format($ratings_float, 2);
    }else{
     $ratings_rate = 0; 
    }

     return $ratings_rate;
    }



function writeReviewForm($service_id, $service_type){

 global $wpdb;
 

  if(isset($_POST['submit_comment'])){
     // Create rooms object
    $data10 = array(  
      'user_id'           => get_current_user_id(), 
      'comment_post_ID'       => $service_id, 
      'comment_author_email' => $_POST['comment_author_email'],  
      'comment_content' => $_POST['comment_content'],   
      'comment_type' => $service_type,   
      'comment_title' => $_POST['comment_title'],   
      
    );  
     $wpdb->insert('wp_comments', $data10 );   
     $lastId = $wpdb->insert_id;

  }
 
  ?>
  <form   method="post" id="" class="comment-form" novalidate="">
  <div class="form-group">
  <label>Review Title</label>
  <input class="form-control" type="text" name="comment_title">
  </div><div class="form-group">
  <label>Review Text</label>
  <textarea name="comment_content" id="comment_content" class="form-control" rows="6"></textarea>
  </div>

  <div class="row">

  <div class="col-md-6">
  <div class="form-group">
  <label for="author">Name*</label>
  <input id="comment_title" name="comment_title" type="text" value="" size="30" aria-required="true" class="form-control">
  </div>
  </div>   
  <div class="col-md-6"><div class="form-group">

  <label for="email">Your email address *</label>
  <input class="form-control" id="comment_author_email" name="comment_author_email"  type="text"></div>
  </div>
  </div><!--End row-->

  <p class="form-submit">
  <input name="submit_comment" type="submit" id="submit" class="submit btn btn-primary" value="Leave a Review"> 
  </p>           

  </form>
<?php } ?>

    <?php 
    function serviceList($service_id, $service_type){  
      global $wpdb;
     $wp_post_db = "hotel_offers_relation";  
    // echo "SELECT * FROM $wp_post_db where hotel_id='$service_id' and service_type='$service_type'  ORDER BY id DESC";
     $show_vendor_posts = $wpdb->get_results("SELECT * FROM $wp_post_db where hotel_id='$service_id' and service_type='$service_type'  ORDER BY id DESC"); 
      $num_rows = $wpdb->num_rows;
       
      if($num_rows  > 0){

      $i=0;
      foreach( $show_vendor_posts as $show_vendor_post)  
      {   
      //print_r($show_vendor_post);

      $service_id =  $show_vendor_post->service_id; 
                                                    
      ?>    
      <li data-toggle="tooltip" data-placement="top" title="Data on top">
           <i class="fa fa-briefcase"></i>
            <span><?php echo getServiceNameById($service_id); ?></span>
      </li>

         <?php } }else{ ?>

      <h4>No data found.</h4>

    <?php } ?>

    <?php } ?>


  <?php 
    function reviewlists($service_id, $service_type){  
      global $wpdb;
     $wp_post_db = "wp_comments";  
   //echo "SELECT * FROM $wp_post_db where comment_post_ID='$service_id' and comment_type='$service_type'";
    
     $show_vendor_posts = $wpdb->get_results("SELECT * FROM $wp_post_db where comment_post_ID='$service_id' and comment_type='$service_type'"); 
      $num_rows = $wpdb->num_rows;
       
      if($num_rows  > 0){

      $i=0;
      foreach( $show_vendor_posts as $show_vendor_post)  
      {   
      //print_r($show_vendor_post);

        $comment_post_ID =  $show_vendor_post->comment_post_ID; 
        $comment_title =  $show_vendor_post->comment_title; 
        $comment_author =  $show_vendor_post->comment_author; 
        $comment_author_url =  $show_vendor_post->comment_author_url; 
        $comment_content =  $show_vendor_post->comment_content; 
        $comment_title =  $show_vendor_post->comment_title; 
        $comment_type =  $show_vendor_post->comment_type; 
        $user_id =  $show_vendor_post->user_id;  
                                                    
      ?>    
     <!--comment repeted item start -->
                            <li  class="st_reviews byuser comment-author-admin bypostauthor even thread-even depth-1">
                                <div class="row">
                                    <div class="col-md-2">
                                        <div class="booking-item-review-person">
                                            <a class="booking-item-review-person-avatar round" href="#">
                                                <img alt="avatar" width=70 height=70 src="<?php echo get_template_directory_uri(); ?>/img/avater.jpg" class="avatar avatar-96 photo origin round" >                </a>
                                            <p class="booking-item-review-person-name">
                                                <cite class="fn"><?php echo $comment_author; ?></cite>                </p>
                                            <p class="booking-item-review-person-loc">                </p>
                                           <!--  <small>
                                                <a href="#"> 73 reviews </a>
                                            </small> -->
                                        </div>
                                    </div>

                                    <div class="col-md-10">
                                        <div class="booking-item-review-content">
                                            <h5>"<?php echo $comment_title; ?>"</h5>
                                            <ul class="icon-group booking-item-rating-stars" data-rate="4.2">
                                                 <?php echo  ratingsViewFunctions($service_id, $service_type); ?>
                                            </ul>
                                            
                                            <div class="comment-content">
                                               <?php echo $comment_content; ?>          
                                            </div> 
                                                
                                           <!--  <p class="booking-item-review-rate">Was this review helpful?<b class="text-color"> <span class="number">56</span> like this</b>
                                            <a data-id="196" class="st-like-review fa fa-thumbs-o-up box-icon-inline round" href="#"></a>
                                                             -->        
                                            </p>
                           
                                        </div>
                                    </div><!-- col-10 -->
                                </div><!-- row -->
                            </li>
                            <!--comment repeted item end -->


 <?php } }else{ ?>

      <h4>No data found.</h4>

    <?php } ?>

    <?php } ?>

