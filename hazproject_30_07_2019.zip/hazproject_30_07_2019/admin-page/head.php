<?php 
  include('admin_function.php');  
  //=================Delete parent details with related gallery===========================
if(isset($_GET['delete'])){

    global $wpdb; 
    
    $id = $_GET['id']; 
    $service_type = $_GET['delete'];  
    $page = $_GET['page']; 

    if($service_type == 'cars'){
      $service_db = 'car_details';
    }
    else if($service_type == 'hotels'){
       $service_db = 'hotel_details';
     }
     else if($service_type == 'rooms'){
       $service_db = 'available_rooms';
     }
    else if($service_type == 'tours'){
       $service_db = 'tour_details';
     } 


    $wp_post_db = "new_order_img";  
    $show_vendor_posts = $wpdb->get_results("SELECT * FROM $wp_post_db WHERE service_id='$id' AND service_type='$service_type'");  
    foreach( $show_vendor_posts as $show_vendor_posts) 
    {   
       $img_id = $show_vendor_posts->id; 
       $delete_src =  get_theme_root().'/hazproject'.$show_vendor_posts->img_url;    

        if (file_exists($delete_src)) 
         {
            unlink($delete_src);
            echo "File Successfully Delete."; 
            $wpdb->delete( 'new_order_img', array( 'id' => $img_id ) );  
        }
        else
        {
            echo "File does not exists"; 
        } 
    }
 

    $wpdb->delete( $service_db, array( 'id' => $id ) );   

    $location = '?page='.$page;
    echo '<script type="text/javascript">window.location.href = "'.$location.'"</script>'; 
}
//=================Delete parent details with related gallery===========================

?>
	<!-- Bootstrap Styles-->

    <link href="<?php echo get_template_directory_uri(); ?>/admin-page/css/bootstrap.css" rel="stylesheet" />

     <!-- FontAwesome Styles-->

    <link href="<?php echo get_template_directory_uri(); ?>/admin-page/css/font-awesome.css" rel="stylesheet" />

     <!-- Morris Chart Styles-->
 
   

     <!-- Google Fonts-->

   <link href='http://fonts.googleapis.com/css?family=Open+Sans' rel='stylesheet' type='text/css' />

     <!-- TABLE STYLES-->

    <link href="<?php echo get_template_directory_uri(); ?>/admin-page/css/datatables.min.css" rel="stylesheet" />

	<style>

	button, html input[type="button"], input[type="reset"], input[type="submit"]{ background:none; border:0; color:blue; }

	input[type="submit"]:hover{text-decoration:underline;}

	
#dataTables-example {
	width: 100%;
	text-align: left;
}


	.page-title-action{

	background: hsl(0, 0%, 97%) none repeat scroll 0 0;

    border: 1px solid hsl(0, 0%, 80%);

    border-radius: 2px;

    color: hsl(199, 100%, 33%);

    cursor: pointer;

    font-size: 13px;

    font-weight: 600;

    line-height: normal;

    margin-left: 4px;

    outline: 0 none;

    padding: 4px 8px;

    position: relative;

    text-decoration: none;

    text-shadow: none;

    top: -3px;}

	input[type="submit"]{

	background: hsl(0, 0%, 97%) none repeat scroll 0 0;

    border: 1px solid hsl(0, 0%, 80%);

    border-radius: 2px;

    color: hsl(199, 100%, 33%);

    cursor: pointer;

    font-size: 13px;

    font-weight: 600;

    line-height: normal;

    margin-left: 4px;

    outline: 0 none;

    padding: 4px 8px;

    position: relative;

    text-decoration: none;

    text-shadow: none;

    top: -3px;

	

	

	}

  .dropzone .dz-default.dz-message {
    opacity: 1;
    -ms-filter: none;
    filter: none;
    -webkit-transition: opacity 0.3s ease-in-out;
    -moz-transition: opacity 0.3s ease-in-out;
    -o-transition: opacity 0.3s ease-in-out;
    -ms-transition: opacity 0.3s ease-in-out;
    transition: opacity 0.3s ease-in-out; 
    background-repeat: no-repeat;
    background-position: 0 0;
    position: inherit; 
    width: 250px;
    height: 123px;
    margin-left: 0px; 
    margin-top: 0px; 
    top: 50%;
    left: 50%;
}


	input[type="text"],input[type="password"]{

	height:35px; padding:5px; width:250px;}

	.wp-admin select{ height:35px!important; width:250px;}
	</style>

<script type="text/javascript">

var requrl = '<?php echo get_template_directory_uri(); ?>';

</script>



<script>

jQuery('document').ready(function(){ 
	

	jQuery('#location').change(function(){

									   

			//alert('1st step');

	

		 	var c_id = jQuery('#location').val();

			//alert(c_id);

			var ajaxhandler = requrl+'/ajaxhandler.php';

			

			//alert(ajaxhandler );

		

			jQuery.ajax({

				url:ajaxhandler,

				type:"post",

				data:{type:'location',c_id:c_id},

				success:function(data){

				//alert(data);

					jQuery("#shops_name").html(data);



					  

				}

				});

			

			

			});

			

			

			

			

			});

</script>


      
        <!--dreopzinw-->
     <!-- <link rel="stylesheet" href="<?php echo get_template_directory_uri();?>/admin-page/dropzone/css/runnable.css" />
    <link rel="stylesheet" href="<?php echo get_template_directory_uri();?>/admin-page/dropzone/css/dropzone.css" />
    <script src="<?php echo get_template_directory_uri();?>/admin-page/dropzone/js/jquery-1.11.2.min.js"></script>
    <script src="<?php echo get_template_directory_uri();?>/admin-page/dropzone/js/dropzone.js"></script> -->   
    
    
    
    <style>
    .dropzone .dz-default.dz-message {
    opacity: 1;
    -ms-filter: none;
    filter: none;
    -webkit-transition: opacity 0.3s ease-in-out;
    -moz-transition: opacity 0.3s ease-in-out;
    -o-transition: opacity 0.3s ease-in-out;
    -ms-transition: opacity 0.3s ease-in-out;
    transition: opacity 0.3s ease-in-out; 
    background-repeat: no-repeat;
    background-position: 0 0;
    position: inherit; 
    width: 250px;
    height: 123px;
    margin-left: 0px; 
    margin-top: 0px; 
    top: 50%;
    left: 50%;
}
</style>   

    

	

	

	

	

	

	

	

	

	

	

	

	

	

	

	

	<script src="<?php echo get_template_directory_uri(); ?>/admin-page/assets/js/jquery-1.10.2.js"></script>

      <!-- Bootstrap Js -->

    <script src="<?php echo get_template_directory_uri(); ?>/admin-page/assets/js/bootstrap.min.js"></script>

    <!-- Metis Menu Js -->

    <script src="<?php echo get_template_directory_uri(); ?>/admin-page/assets/js/jquery.metisMenu.js"></script>

     <!-- DATA TABLE SCRIPTS -->

    <script src="<?php echo get_template_directory_uri(); ?>/admin-page/assets/js/dataTables/jquery.dataTables.js"></script>

    <script src="<?php echo get_template_directory_uri(); ?>/admin-page/assets/js/dataTables/dataTables.bootstrap.js"></script>

        <script>

            $(document).ready(function () {

                $('#dataTables-example').dataTable();

            });

    </script>

         <!-- Custom Js -->

    <script src="<?php echo get_template_directory_uri(); ?>/admin-page/assets/js/custom-scripts.js"></script>