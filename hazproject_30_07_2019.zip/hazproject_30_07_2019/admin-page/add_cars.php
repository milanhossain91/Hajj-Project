<?php include('head.php');  
?>  

 
<div class="admin_form">
	<div class="crow">
		<div class="col-md-12">
<h2><?php if(isset($_POST['add_cars_submit_btn'])){ echo $msg;  } ?><h2>
<h4>Added Cars</h4> </br> </br>
		</div>
	</div>
	
	
 <form action="<?php echo get_stylesheet_directory_uri();?>/admin-page/upload.php" method="post" class="dropzone" id="my-awesome-dropzone" enctype="multipart/form-data">
   
  <div class="form-group crow">
    <label for="colFormLabel" class="col-sm-2 col-form-label">Car Title</label>
    <div class="col-sm-10">
      <input type="text" class="form-control" id="colFormLabel" name="car_title">
    </div>
  </div> 


  <div class="form-group crow">
    <label for="colFormLabelLg" class="col-sm-2 col-form-label col-form-label-lg">Car Description</label>
    <div class="col-sm-10">
       <textarea name="car_description"  class="form-control"  style="resize:none;height:300px;width:40%;float:left"></textarea>
    </div>
  </div>


   
  </br> </br>

  


      <div class="form-group crow">
    <label for="colFormLabel" class="col-sm-2 col-form-label">Car Location</label>
    <div class="col-sm-10">
      <input type="text" class="form-control" id="colFormLabel" name="car_location">
    </div>
  </div>


    <div class="form-group crow">
    <label for="colFormLabel" class="col-sm-2 col-form-label">Car Email</label>
    <div class="col-sm-10">
      <input type="text" class="form-control" id="colFormLabel" name="car_email">
    </div>
  </div>


    <div class="form-group crow">
    <label for="colFormLabel" class="col-sm-2 col-form-label">Car Phone No</label>
    <div class="col-sm-10">
      <input type="text" class="form-control" id="colFormLabel" name="car_phone_no">
    </div>
  </div>


   <div class="form-group crow">
    <label for="colFormLabel" class="col-sm-2 col-form-label">Car Price</label>
    <div class="col-sm-10">
      <input type="text" class="form-control" id="colFormLabel" name="car_price">
    </div>
  </div>


   <div class="form-group crow">
    <label for="colFormLabel" class="col-sm-2 col-form-label">Total Car</label>
    <div class="col-sm-10">
      <input type="text" class="form-control" id="colFormLabel" name="total_car">
    </div>
  </div>



 

 


<div class="form-group crow">
    <label for="colFormLabel" class="col-sm-2 col-form-label">Car Packages</label>
    <div class="col-sm-10">
      <?php 

      global $wpdb;
        $wp_post_db = "car_packages";
        $show_vendor_posts = $wpdb->get_results("SELECT * FROM $wp_post_db ORDER BY id DESC"); 
        $i=0;
        foreach( $show_vendor_posts as $show_vendor_post) 
        {  
         ?> 
       
            <label for="choice_<?php echo $show_vendor_post->id; ?>">
            <input name="package_id" id="choice_<?php echo $show_vendor_post->id; ?>" type="radio" value="<?php echo $show_vendor_post->id; ?>" <?php if($i==0){ ?> checked="checked" <?php } ?> tabindex="28">
                <?php echo $show_vendor_post->package_name; ?>
              </label>
           

            <?php $i++; } ?>
       
    </div>
  </div> 





<div class="form-group crow">
    <label for="colFormLabel" class="col-sm-2 col-form-label">Car Gallery</label>
    <div class="col-sm-10">
 
<input type="file" class="form-control"  name="files[]" multiple="multiple" accept="image/*" /> 
</div>
</div>


  <div class="form-group crow"> 
    <div class="col-sm-10">
		<div class="admin_form_submit"> 
     <input type="hidden" name="service_type" value="cars">
      <input type="submit" id="submit-all" class="btn-primary"   name="add_cars_submit_btn">
    </div>
  </div> 
</div>
</form>
</div>


<?php include('footer.php'); ?>


 



  <div class="crow"> 
    <div class="col-sm-12">
  <h1>List of Cars</h1>
  <table class="table table-striped table-bordered table-hover" id="dataTables-example">
     
      <thead>
          <tr>   
               <th>Car ID</th>
               <th>Car Image</th>
              <th>Car Title</th>
               <th>Car Description</th>
               <th>Car Price</th>  
               <th>Added Date</th>
               <th>Action</th>
             </tr>
      </thead>

      <tbody>
      <?php     
        $service_type = 'cars';           
        $wp_post_db = "car_details";  


        $show_vendor_posts = $wpdb->get_results("SELECT * FROM $wp_post_db ORDER BY id DESC"); 
        $i=0;
        foreach( $show_vendor_posts as $show_vendor_post)  
        {   
          //print_r($show_vendor_post);
          $cid             =  $show_vendor_post->id; 
          $car_title       =  $show_vendor_post->car_title; 
          $car_description =  $show_vendor_post->car_description;    
          $car_price       =  $show_vendor_post->car_price;  
          $added_date      =  $show_vendor_post->added_date;
                                                          
        ?>   

         <tr class="odd gradeA">   
            <td><?php echo $cid;?></td>
            <th> <img src="<?php echo getImageSrcById($cid, $service_type); ?>" width="60" height="60"></th>
            <td><?php echo $car_title;?></td>
            <td><?php echo substr($car_description, '0', '20');?></td>
            <td><?php echo $car_price;?></td>  
            <td><?php echo $added_date; ?></td>
            <td class="center"> <a class="btn btn-danger" href="?page=add_cars&id=<?php echo $cid;?>&delete=cars&page=add_cars">Delete</a></td> 
         </tr>

<?php } ?>  
                
    </tbody>

      <tr>   
        <th>car ID</th>
        <th>car Image</th>
        <th>car Title</th>
        <th>car Description</th>
        <th>car Price</th> 
        <th>Added Date</th>
        <th>Action</th>
      </tr>
</table>
	  </div>
</div>