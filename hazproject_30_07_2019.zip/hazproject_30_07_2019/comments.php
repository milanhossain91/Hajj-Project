<?php
/**
 * The template for displaying comments
 *
 * This is the template that displays the area of the page that contains both the current comments
 * and the comment form.
 *
 * @link https://developer.wordpress.org/themes/basics/template-hierarchy/
 *
 * @package venox
 */

/*
 * If the current post is protected by a password and
 * the visitor has not yet entered the password we will
 * return early without loading the comments.
 */
if ( post_password_required() ) {
	return;
}
?>



<div class="det-area car-det has-border u-padding-t-60 u-padding-b-60">
        <div class="container">
        <?php while (have_posts() ) : the_post(); ?>

        <section class="error-404 not-found">
				<header class="page-header">
					<h1 class="page-title"><?php the_title(); ?></h1>
				</header><!-- .page-header -->

				<div class="page-content">

				   <?php the_content(); ?>
				</div>


		</section>

       <?php endwhile; wp_reset_postdata(); ?>

  </div>
</div>
	

