<?php
//for booking page
   if(isset($_GET['activity_id'])){
     $activity_id = $_GET['activity_id'];   
     }
    
    if(isset($_GET['u_rooms'])){
     $u_rooms = $_GET['u_rooms'];   
     }   

     if(isset($_GET['specific_date'])){
     $specific_date = $_GET['specific_date'];   
     }   
    
    
    //search page 
    if(isset($_GET['activity_location'])){ 
    $activity_location = $_GET['activity_location']; 
    $category_id = $_GET['category_id'];  
    }



//activity details page
if(isset($_POST['activity_book_now'])){

  if(isset($_POST['activity_id'])){
     $activity_id = $_POST['activity_id'];   
     }

    if(isset($_POST['specific_date'])){
     $specific_date = $_POST['specific_date'];   
     $specific_date = date("Y-m-d", strtotime($specific_date));   
     }
  
    if(isset($_POST['u_rooms'])){
     $u_rooms = $_POST['u_rooms'];   
     } 
     
    $location =  site_url().'/activity-booking/?activity_id='.$activity_id.'&u_rooms='.$u_rooms.'&specific_date='.$specific_date;  
    echo '<script type="text/javascript">window.location.href = "'.$location.'"</script>';


}

$wp_post_db = "activity_details"; 
$show_vendor_posts = $wpdb->get_results("SELECT * FROM $wp_post_db WHERE id='$activity_id' ORDER BY id DESC"); 
$i=0;
foreach( $show_vendor_posts as $show_vendor_post) 
{  //print_r($show_vendor_post);
   $aid =  $show_vendor_post->id;    
   $category_id =  $show_vendor_post->category_id;  
   $activity_title =  $show_vendor_post->activity_title;  
   $activity_description =  $show_vendor_post->activity_description;    
   $activity_price =  $show_vendor_post->activity_price;    
   $date_added =  $show_vendor_post->date_added;     
   }                                                          
           



 //booking form submit
if(isset($_POST['activity_booking_submit'])){ 
  
// Create rooms object
$bookingData = array(   

  'user_id'           => get_current_user_id(),   
  'post_parent_id'   => $activity_id,
  'post_id'       => $category_id, //available room
  'booking_total'       => $activity_price, 
  'check_in'       => $specific_date, //specific_date 
  'u_name'        => $_POST['u_name'], 
  'u_cell'       => $_POST['u_cell'], 
  'u_email'       => $_POST['u_email'],  
  'service_type'       => 'activities',    
  
);  
//print_r($bookingData);

$order_id =  $wpdb->insert('main_booking_details', $bookingData );    
if($order_id){
  $msg = '<p style="color:green;text-align:center;font-size:19px">Successfully Inserted...</p>';

  $location =  site_url().'/activity-booking/?order_id='.$order_id.'&activity_id='.$activity_id.'&u_rooms='.$u_rooms.'&specific_date='.$specific_date;  
    echo '<script type="text/javascript">window.location.href = "'.$location.'"</script>';
}


}

//functions
function getActivityNameById($activity_id){ 
global $wpdb;
 $wp_post_db = "activity_activities";
  $show_vendor_posts = $wpdb->get_results("SELECT DISTINCT * FROM $wp_post_db WHERE activity_id='$activity_id'");   
   return $show_vendor_posts;   
 
} 


function getPackagePriceById($package_id){ 
global $wpdb;
$wp_post_db = "activity_packages"; 
$show_vendor_posts = $wpdb->get_results("SELECT package_price FROM $wp_post_db WHERE id='$package_id'  ORDER BY id DESC");  
foreach( $show_vendor_posts as $show_vendor_post) 
{  
   return $show_vendor_post->package_price;   
}
} 

 
 


?>

 