<?php
//for booking page
   if(isset($_GET['guide_id'])){
     $guide_id = $_GET['guide_id'];   
     }
    
    if(isset($_GET['u_rooms'])){
     $u_rooms = $_GET['u_rooms'];   
     }   

     if(isset($_GET['specific_date'])){
     $specific_date = $_GET['specific_date'];   
     }   
    
    
    //search page 
    if(isset($_GET['guide_location'])){ 
    $guide_location = $_GET['guide_location']; 
    $category_id = $_GET['category_id'];  
    }



//guide details page
if(isset($_POST['guide_book_now'])){

  if(isset($_POST['guide_id'])){
     $guide_id = $_POST['guide_id'];   
     }

    if(isset($_POST['specific_date'])){
     $specific_date = $_POST['specific_date'];   
     $specific_date = date("Y-m-d", strtotime($specific_date));   
     }
  
    if(isset($_POST['u_rooms'])){
     $u_rooms = $_POST['u_rooms'];   
     } 
     
    $location =  site_url().'/guide-booking/?guide_id='.$guide_id.'&u_rooms='.$u_rooms.'&specific_date='.$specific_date;  
    echo '<script type="text/javascript">window.location.href = "'.$location.'"</script>';


}

$wp_post_db = "guide_details"; 
$show_vendor_posts = $wpdb->get_results("SELECT * FROM $wp_post_db WHERE id='$guide_id' ORDER BY id DESC"); 
$i=0;
foreach( $show_vendor_posts as $show_vendor_post) 
{  //print_r($show_vendor_post);
   $aid =  $show_vendor_post->id;    
   $category_id =  $show_vendor_post->category_id;  
   $guide_title =  $show_vendor_post->guide_title;  
   $guide_description =  $show_vendor_post->guide_description;    
   $guide_price =  $show_vendor_post->guide_price;    
   $date_added =  $show_vendor_post->date_added;     
   }                                                          
           



 //booking form submit
if(isset($_POST['guide_booking_submit'])){ 
  
// Create rooms object
$bookingData = array(   

  'user_id'           => get_current_user_id(),   
  'post_parent_id'   => $guide_id,
  'post_id'       => $category_id, //available room
  'booking_total'       => $guide_price, 
  'check_in'       => $specific_date, //specific_date 
  'u_name'        => $_POST['u_name'], 
  'u_cell'       => $_POST['u_cell'], 
  'u_email'       => $_POST['u_email'],  
  'service_type'       => 'guides',    
  
);  
//print_r($bookingData);

$order_id =  $wpdb->insert('main_booking_details', $bookingData );    
if($order_id){
  $msg = '<p style="color:green;text-align:center;font-size:19px">Successfully Inserted...</p>';

  $location =  site_url().'/guide-booking/?order_id='.$order_id.'&guide_id='.$guide_id.'&u_rooms='.$u_rooms.'&specific_date='.$specific_date;  
    echo '<script type="text/javascript">window.location.href = "'.$location.'"</script>';
}


}

//functions
function getguideNameById($guide_id){ 
global $wpdb;
 $wp_post_db = "guide_packages";
  $show_vendor_posts = $wpdb->get_results("SELECT DISTINCT * FROM $wp_post_db WHERE guide_id='$guide_id'");   
   return $show_vendor_posts;   
 
} 


function getPackagePriceById($package_id){ 
global $wpdb;
$wp_post_db = "guide_packages"; 
$show_vendor_posts = $wpdb->get_results("SELECT package_price FROM $wp_post_db WHERE id='$package_id'  ORDER BY id DESC");  
foreach( $show_vendor_posts as $show_vendor_post) 
{  
   return $show_vendor_post->package_price;   
}
} 

 
 


?>

 