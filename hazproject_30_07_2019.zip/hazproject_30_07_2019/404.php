<?php
/**
 * The template for displaying 404 pages (not found)
 *
 * @link https://codex.wordpress.org/Creating_an_Error_404_Page
 *
 * @package venox
 */

get_header();
?>

<div class="det-area car-det has-border u-padding-t-60 u-padding-b-60">
        <div class="container">

			<section class="error-404 not-found">
				<header class="page-header">
					<h1 class="page-title"><?php esc_html_e( 'Oops! That page can&rsquo;t be found.', 'venox' ); ?></h1>
				</header><!-- .page-header -->

				<div class="page-content">
					<p><?php esc_html_e( 'It looks like nothing was found at this location. Maybe try one of the links below or a search?', 'venox' ); ?></p>

					<?php
					get_search_form();

					the_widget( 'WP_Widget_Recent_Posts' );
					?>

					<div class="widget widget_categories">
						<h2 class="widget-title"><?php esc_html_e( 'Most Used Categories', 'venox' ); ?></h2>
						<ul>
							<?php

							$args = array(
							  'orderby' => 'count',
								'order' => 'desc',
								'show_count' => 1,
								'taxonomy' => 'price_range',
								'title_li' => '<h4><span>' . __('Filter results', 'pdw-bijma') . '</span></h4>',
								
								
							);
							wp_list_categories( $args );
							wp_list_categories( array(
								'orderby'    => 'count',
								'order'      => 'DESC',
								'show_count' => 1,
								'title_li'   => '',
								'number'     => 10,
							) );

							$terms = get_the_term_list( $post->ID, 'price_range' );
							//$terms = strip_tags( $terms );
							echo $terms;

							$termid = get_queried_object()->term_id;
							$term = get_term( $termid, 'price_range' );
							echo $term->name.'<br>';
							echo $term->description;
							?>

							<?php echo get_the_term_list( $post->ID, 'Location', '<li class="jobs_item">', ', ', '</li>' ) ?>
						</ul>
					</div><!-- .widget -->

					<?php
					/* translators: %1$s: smiley */
					$venox_archive_content = '<p>' . sprintf( esc_html__( 'Try looking in the monthly archives. %1$s', 'venox' ), convert_smilies( ':)' ) ) . '</p>';
					the_widget( 'WP_Widget_Archives', 'dropdown=1', "after_title=</h2>$venox_archive_content" );

					the_widget( 'WP_Widget_Tag_Cloud' );
					?>

					<?php 

					   global $taxonomy,$term;

						$terms = get_the_term_list( $post->ID, 'price_range' );
							//$terms = strip_tags( $terms );
							echo $terms;

							$termid = get_queried_object()->term_id;
							$term = get_term( $termid, 'price_range' );
							echo $term->name.'<br>';
							echo $term->description;



					echo get_the_term_list( $post->ID, 'Location', '<li class="jobs_item">', ', ', '</li>' ) ?>

				</div><!-- .page-content -->
			</section><!-- .error-404 -->

		</div><!-- #main -->
	</div><!-- #primary -->

<?php
get_footer();
