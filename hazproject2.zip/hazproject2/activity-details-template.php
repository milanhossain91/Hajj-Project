<?php
/**
 * Template Name: Activity Details Template
 *  
 */

get_header();
require_once('functions/activity_functions.php');
include('rating/rating.php');
$service_type = "activities";

 if(isset($_GET['activity_id'])){
       $activity_id = $_GET['activity_id'];
 }



    global $wpdb;
    $wp_post_db = "activity_details";
    $show_vendor_posts = $wpdb->get_results("SELECT * FROM $wp_post_db WHERE id='$activity_id' ORDER BY id DESC"); 
    $i=0;
    foreach( $show_vendor_posts as $show_vendor_post) 
    {   
      //print_r($show_vendor_post);
  
              $activity_title =  $show_vendor_post->activity_title;  
            $activity_description =  $show_vendor_post->activity_description; 
            $activity_check_in =  $show_vendor_post->activity_check_in;  
            $activity_check_out =  $show_vendor_post->activity_check_out;  
            $activity_location =  $show_vendor_post->activity_location;  

            $activity_email =  $show_vendor_post->activity_email;  
            $activity_phone_no =  $show_vendor_post->activity_phone_no;  


            $activity_price =  $show_vendor_post->activity_price;  
            $total_activity =  $show_vendor_post->total_activity;  
          
 } 

?>



 

    <div class="det-area car-det has-border u-padding-t-60 u-padding-b-60">
        <div class="container">
            <div class="det-top">
                <div class="left">
                    <h3><?php echo $activity_title; ?>
</h3>
                    <p><i class="fa fa-map-marker"></i> <?php echo $activity_location; ?></p>
                    <ul>
                        <li><i class="fa fa-envelope"></i><?php echo $activity_email; ?></li>
                    </ul>
                </div>
                <div class="right">
                    <div class="prices">
                        <div class="cr-price">
                             <small style="text-decoration: line-through;">$<?php echo $activity_price; ?></small> 
                        </div>
                    </div>
                </div>
            </div>  

   
            <div class="row">
                <div class="col-sm-4">
                    <div class="activity-aside">
                        <div class="block">
                            <h3 class="title">Similar activitys</h3>
                            <ul>
<?php

    $wp_post_db = "activity_details";
    $show_vendor_posts = $wpdb->get_results("SELECT * FROM $wp_post_db ORDER BY id DESC"); 
    $i=0;
    foreach( $show_vendor_posts as $show_vendor_post) 
    {   
  
            $aid =  $show_vendor_post->id;   
            $activity_title =  $show_vendor_post->activity_title;   
            $activity_price =  $show_vendor_post->activity_price;  
            $total_activity =  $show_vendor_post->total_activity;  
          
       ?>
                                
                                <li>
                                   <a href="<?php echo site_url(); ?>/activity-details/?activity_id=<?php echo $aid; ?>">
                                       <figure>
                                            <img src="<?php echo getImageSrcById($aid, $service_type); ?>"> 
                                       </figure>
                                       <div class="title-star">
                                           <h4><?php echo $activity_title; ?></h4>
                                           <span class="stars">
                                               <i class="fa fa-star"></i>
                                               <i class="fa fa-star"></i>
                                               <i class="fa fa-star"></i>
                                               <i class="fa fa-star"></i>
                                               <i class="fa fa-star-o"></i>
                                           </span>
                                       </div>

                                       <span class="price">
                                           <span>Price from</span>
                                           <p>$<?php echo number_format($activity_price, 2); ?></p>
                                       </span>

                                   </a>
                                </li> <!-- item -->

                                <?php } ?>
                                 

                            </ul>
                        </div>
                    </div>
                </div> <!--  -->

                <div class="col-sm-8">
                    <div class="main-content">
                        <div class="slider-wrap">
                            
                         

                             <div role="tabpanel" class="tab-pane fade in active show" id="photos">
                                      <div class="fotorama" data-nav="thumbs">
                                             <?php echo getGallaeryImageSrcById($activity_id, $service_type); ?> 
                                        </div>
                                  </div>


                        </div>

                        <form id="form-booking-inpage" class="form-has-guest-name" method="post"  >
                            <!-- activity Package -->
                                    <!-- End activity Package -->
                            <div class="package-info-wrapper" style="width: 100%">
                                <div class="overlay-form" style="display: none;"><i class="fa fa-refresh text-color"></i></div>
                                <div class="row">

                                    <div class="col-md-6">
                                        <div class="package-info clearfix">
                                            <i class="fa fa-info"></i>
                                            <span class="head">activity type: </span>
                                            <span>Specific Date</span>
                                        </div>
                                        <div class="package-info clearfix">
                                            <i class="fa fa-user"></i>
                                            <span class="head">Maximum number of people: </span>
                                            <?php echo $total_activity; ?>                      
                                        </div>

                                        <div class="package-info clearfix">
                                            <i class="fa fa-location-arrow"></i>
                                            <span class="head">Location: </span>
                                            <?php echo $activity_location; ?>              
                                        </div>
                                        <div class="package-info clearfix">
                                            <i class="fa fa-star"></i>
                                            <span class="head">Rate:</span>
                                            <ul class="icon-group booking-item-rating-stars">
                                                <li><i class="fa  fa-star"></i></li><li><i class="fa  fa-star"></i></li><li><i class="fa  fa-star-half-o"></i></li><li><i class="fa  fa-star-o"></i></li><li><i class="fa  fa-star-o"></i></li>                        
                                            </ul>
                                        </div>
                                    </div>
                                    <div class="col-md-6">
                                                            
                                        <div class="package-book-now-button">
                                            <input type="hidden" name="action" value="activitys_add_to_cart">
                                            <input type="hidden" name="item_id" value="1030">
                                            
                                            <div class="div_book">
                                                <div class="row">
                                                          <input type="text" class="datepicker" name="specific_date" required> 
                                                            
                                                        </div>
     

                                                <div class="row u-margin-t-20 u-margin-b-20">
                                                    <div class="col-xs-12 col-sm-12">
                                                            <label for="label_adult_number"><strong>Maximum number of people: </strong></label>
                                                            <select class="form-control" name="u_rooms"  required >
                                                                <option>5</option>
                                                                <option>10</option>
                                                                <option>20</option>
                                                                <option>30</option>
                                                                <option>40</option>
                                                            </select>
                                                        </div>
                                                         
                                                    </div>
                  


                                                <div class="div_btn_book_activity">
                                                <a href="#" class="btn btn-default btn-send-message-login" data-id="1030">Send message</a>       
                                                 <input type="submit" class=" btn btn-primary " name="activity_book_now" value="Book Now">
                                             </div>
                                                                                                                        </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </form>



                        <div class="hotel-des">
                            <h3>Overview</h3>
                            <p><?php echo $activity_description; ?>      </p>
                            
                        </div>


                        <div class="tour-location">
                            <h3>Tour’s Location</h3>

                            <iframe src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d387193.30594184523!2d-74.25986594809962!3d40.69714941820045!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x89c24fa5d33f083b%3A0xc80b8f06e177fe62!2sNew+York%2C+NY%2C+USA!5e0!3m2!1sen!2sbd!4v1540485618034" frameborder="0" style="border:0" allowfullscreen=""></iframe>
                        </div>


                    <div class="panel-group ac-tour">
                    <?php $activitiesArray = getActivityNameById($activity_id);
                    
                    
 
                    foreach($activitiesArray as $row){  ?>
                        <div class="panel panel-default">
                                <div class="panel-heading">
                                    <h4 class="panel-title">
                                        <a href="#collapse-<?php echo $row->id; ?>" data-parent="#accordion_tours" data-toggle="collapse" class="title_program collapsed">
                                            <?php echo $row->activity_name; ?>                     
                                        </a>
                                    </h4>
                                </div>
                            <div id="collapse-<?php echo $row->id; ?>" class="panel-collapse collapse" aria-expanded="false">
                                <div class="panel-body">
                                 <?php echo $row->activity_description; ?>                    
                                </div>
                            </div>
                        </div>

                        <?php } ?> 



                        <div class="hotel-rev u-padding-t-50">
                        <div class="rev-title u-margin-b-30">
                            <h3>Write a review</h3>
                        </div>
                        <ul class="booking-item-reviews list">

                             <?php echo reviewlists($activity_id, $service_type); ?> 

                        </ul>

                      
                    </div>






<div class="box bg-gray   u-margin-t-40">   
                        <div id="respond" class="comment-respond">
        <h3 id="reply-title" class="comment-reply-title">Write a review </h3>          
           <ul class="booking-item-reviews list"> 

                            <?php echo reviewlists($activity_id, $service_type); ?> 

                        </ul>
 
                    <div class="row"> 
                       <?php echo writeReviewForm($activity_id, $service_type); ?>  
                    </div><!--End Row-->     
                    
            </div><!-- #respond -->
    </div>


                    </div>
                </div>
            </div>        

        </div>
    </div>







<?php

get_footer();

?>
<script>
 jQuery('.datepicker').datepicker();
</script>   



<script type="text/javascript">
         

         jQuery("form#formData_id").submit(function(e) { 
            e.preventDefault();

         var formData = new FormData(jQuery(this)[0]); 
       
          var tem_url = "<?php echo get_template_directory_uri(); ?>";
           var user_id = "<?php echo get_current_user_id(); ?>"; 
           
          

            var tem_uri = tem_url+'/ajax/available_room_ajax.php';
              // alert(tem_uri); 
            jQuery.ajax({
            url: tem_uri,
             type: "POST",
            data: formData,
            contentType: false,       
            cache: false,              
            processData:false,  
            success: function(response) { 
             //alert(response);  
             jQuery('.ajax_result').html(response); 
            }
            
            });

           setTimeout(function(){

                jQuery('#myModal').modal('toggle');

             }, 800);

         });




</script>



<script>
 jQuery('.datepicker').datepicker();
</script>   