<?php  

include '../../../../wp-load.php'; 
include('../rating/rating.php');
global $wpdb;  
 
   $guide_location = $_POST['guide_location'];  
   $category_id = $_POST['category_id'];  
   $service_type = 'guides';

        
                      $wp_post_db = "guide_details";  
                      $show_vendor_posts = $wpdb->get_results("SELECT * FROM $wp_post_db WHERE guide_location LIKE '%$guide_location%' OR category_id ='$category_id' ORDER BY id DESC"); 
                      $num_rows = $wpdb->num_rows; 

                      ?>

                   <div class="sec-ti u-padding-b-20">
                        <h3 class="font-weight300">Advanced Search (<?php echo $num_rows; ?>)</h3>
                    </div>
                    <div class="row " >
                      <?php
                       if($num_rows  > 0){
                      $i=0;
                      foreach( $show_vendor_posts as $show_vendor_post)  
                      {   
                      //print_r($show_vendor_post);
                       $gid =  $show_vendor_post->id; 
                      $guide_title =  $show_vendor_post->guide_title; 
                      $guide_description =  $show_vendor_post->guide_description; 
                      $guide_location =  $show_vendor_post->guide_location;       
                      $guide_price =  $show_vendor_post->guide_price;                                                
                      ?>    
                       
                        <div class="col-sm-6 col-lg-6">
                            <div class="guide-item">
                              


                      <a href="<?php echo site_url().'/guide-details/?guide_id='.$gid;?>" class="fig">
                      <img style="height:190px;" src="<?php echo getImageSrcById($gid, $service_type); ?>">
                                        <h4><?php echo $guide_title; ?></h4>
                                    </a>

                                    <div class="content">

                                        <div class="left">
                                            <div class="location">
                                                <i class="fa fa-map-marker"></i>
                                                <span><?php echo $guide_location; ?></span>
                                            </div>
                                            <div class="price">
                                                <i class="fa fa-money"></i>
                                                <span>$<?php echo $guide_price; ?></span>
                                            </div>
                                        </div>
                                        <div class="right">
                                            <div class="cal">
                                                <i class="fa fa-calendar"></i>
                                                <span>3</span>
                                            </div>
                                             <div class="stars">
                                              <?php echo ratingsViewFunctions($gid, $service_type); ?>     
                                            </div>
                                        </div>
                                    </div>
                            </div>
                        </div> <!-- col -6 --> 


                        <?php } }else{ ?>

                <h4>No data found.</h4>

              <?php } ?>
                        </div><!-- row-->
 