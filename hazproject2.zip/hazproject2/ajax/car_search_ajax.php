<?php  

include '../../../../wp-load.php'; 
include('../rating/rating.php');
global $wpdb;  
 
 
   $car_location = $_POST['car_location'];  
   $package_id = $_POST['package_id'];  
   $service_type = 'cars'; 
     

                      $wp_post_db = "car_details";  
                      $show_vendor_posts = $wpdb->get_results("SELECT * FROM $wp_post_db WHERE car_location LIKE '%$car_location%' OR package_id ='$package_id' ORDER BY id DESC"); 
                      $num_rows = $wpdb->num_rows;
                      ?>

                    <div class="sec-ti u-padding-b-20">
                        <h3 class="font-weight300">Advanced Search (<?php echo $num_rows; ?>)</h3>
                    </div>
                    <div class="row">

                     <?php   
                      if($num_rows  > 0){   
                      $i=0;
                      foreach( $show_vendor_posts as $show_vendor_post)  
                      {   
                      //print_r($show_vendor_post);
                       $cid =  $show_vendor_post->id; 
                      $car_title =  $show_vendor_post->car_title; 
                      $car_description =  $show_vendor_post->car_description;    
                      $car_price =  $show_vendor_post->car_price;                                                
                      ?>   



                        <div class="col-12 col-sm-6">
                            <div class="car-item-g">
                                <a href="<?php echo site_url().'/car-details/?car_id='.$cid;?>" class="fig">
                                    <img src="<?php echo getImageSrcById($cid, $service_type); ?>">
                                    <span class="reb">50%</span>
                                </a>
                                       
                                <div class="content">
                                    <h5><a href="<?php echo site_url().'/car-details/?car_id='.$cid;?>"><?php echo $car_title; ?></a></h5>
                                    <div class="sub">Premium ,Standard</div>
                                    <ul class="ico-set">
                                        <li>
                                            <i class="fa fa-briefcase"></i>
                                            <span>x3</span>
                                        </li>
                                        <li>
                                            <i class="fa fa-male"></i>
                                            <span>Auto</span>
                                        </li>
                                        <li>
                                            <i class="fa fa-briefcase"></i>
                                            <span>x3</span>
                                        </li>
                                        <li>
                                            <i class="fa fa-briefcase"></i>
                                            <span>x4</span>
                                        </li>
                                        <li>
                                            <i class="fa fa-briefcase"></i>
                                            <span>x3</span>
                                        </li>
                                    </ul>
                                </div>

                                <div class="price">
                                    <span class="old">$70,00</span>
                                    <i class="fa fa-long-arrow-right"></i>
                                    <span class="current">$<?php echo $car_price; ?> /day</span>
                                </div>
                            </div>
                        </div><!-- car item col --> 

                        <?php } }else{ ?>

                        <h4>No data found.</h4>

                      <?php } ?>
                        
                    </div>