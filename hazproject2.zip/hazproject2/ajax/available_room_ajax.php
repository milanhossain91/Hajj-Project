<?php  

 include '../../../../wp-load.php'; 
 include('../rating/rating.php');
 global $wpdb; 

 require_once('hotels/hotel_functions.php');

if (isset($_POST['check_in'])) {
     $hotel_id = $_POST['hotel_id'];
  $check_in = date("Y-m-d", strtotime($_POST['check_in']));
  $check_out = date("Y-m-d", strtotime($_POST['check_out']));   
  
}
 
/*=================Search Function ====================*/
  $wp_post_db = "main_booking_details as mb INNER JOIN available_rooms as ar ON mb.post_id = ar.id";

  $show_vendor_posts = $wpdb->get_results("SELECT  ar.*, mb.booking_total as BookingTotal, room_title FROM $wp_post_db  WHERE mb.check_in >= '$check_in' AND mb.check_out <= '$check_out'");      

    $ArrayAvailableHotelId = array();
    $ArrayUnavialableHotelIds = "";
    $counter = 0;
    foreach( $show_vendor_posts as $show_vendor_post )  //print_r($show_vendor_post);  
    {  
 
     $BookingTotal = $show_vendor_post->BookingTotal;
     $available_room =  $show_vendor_post->total_room;    

     if($BookingTotal < $available_room ){
           $ArrayAvailableHotelId[] = $show_vendor_post->hotel_id; //available
     }     
     if($BookingTotal >= $available_room ){        
 
     $ArrayUnavialableHotelIds .= $show_vendor_post->id.','; //unavailable   room       

      }
    } 
   $ArrayUnavialableHotelId =  rtrim($ArrayUnavialableHotelIds,',');


/*=================Search Function ====================*/

      $service_type = 'rooms';
      $wp_post_db = "available_rooms";  
      //echo "SELECT * FROM $wp_post_db WHERE id NOT IN ('$ArrayUnavialableHotelId') AND hotel_id='$hotel_id' ORDER BY id DESC";
       $show_vendor_posts = $wpdb->get_results("SELECT * FROM $wp_post_db WHERE id NOT IN ('$

       ') AND hotel_id='$hotel_id' ORDER BY id DESC"); 
       

              $i=0;
              foreach( $show_vendor_posts as $show_vendor_post) 
              {  

              //print_r($show_vendor_post);

              $rid =  $show_vendor_post->id; 
              $room_title =  $show_vendor_post->room_title;    
              $room_description =  $show_vendor_post->room_description;    
              $room_price =  $show_vendor_post->room_price;    
              $date_added =  $show_vendor_post->date_added;                                              
                    ?>       
                    
                    <div class="row hotels">
                        <div class="col-12">
                            <div class="item-hotel-price">
                                <div class="figr">
                                    <a href="<?php echo site_url(); ?>/room-details?id=<?php echo $rid;?>" target="_blank">
                                        <img src="<?php echo getImageSrcById($imgid, $service_type); ?>">
                                    </a>
                                </div>
                                
                                <div class="bd-icons">
                                    <h5><a href="<?php echo site_url(); ?>/room-details?id=<?php echo $rid;?>" target="_blank"><?php echo $room_title; ?></a></h5>
                                    <ul class="ico-set">
                                            <?php echo serviceList($rid, $service_type);   ?>
                                        </ul>
                                </div>

                                <div class="action">
                                    <p><h2>$<?php echo $room_price; ?> <span style="font-size:11px;">/ 1 night(s)</span></h2></p>
                                    <a class="btn btn-primary" href="<?php echo site_url(); ?>/room-details?id=<?php echo $rid;?>">Room Details</a>
                                </div>
                            </div>
                        </div>
                    </div><!-- item -->

 <?php 
  
  }
    ?>


 