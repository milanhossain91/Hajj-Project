<?php

function Rsnetwork_css_and_js(){
  wp_register_style('bootstrap.min',get_template_directory_uri().'/css/bootstrap.min.css');
  wp_enqueue_style('bootstrap.min');

  wp_register_style('framework.min',get_template_directory_uri().'/css/font-awesome.min.css');
  wp_enqueue_style('framework.min');

   wp_register_style('slider.min',get_template_directory_uri().'/css/jquery-ui.css');
  wp_enqueue_style('slider.min');

  wp_register_style('font-awesome.min',get_template_directory_uri().'/css/meanmenu.min.css');
  wp_enqueue_style('font-awesome.min');
  wp_register_style('font-awesome',get_template_directory_uri().'/css/style.css');
  wp_enqueue_style('font-awesome');
  
   wp_register_style('grid',get_template_directory_uri().'/css/grid.css');
  wp_enqueue_style('grid');


  

  /*JS File Register*/




   
  
   wp_enqueue_script('jquery');
 








}
add_action('wp_enqueue_scripts','Rsnetwork_css_and_js');





