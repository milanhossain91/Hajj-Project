
    

  
<?php
function newdesign(){

  add_theme_support('title_tag');
  add_theme_support('custom-header');
  add_theme_support('custom-background');
  add_theme_support('post-thumbnails');
  add_theme_support( 'post-formats', array( 'aside', 'gallery','audio','video' ) );
  add_theme_support( 'html5', array( 'comment-list', 'comment-form', 'search-form', 'gallery', 'caption' ) );
    add_theme_support('slide-image',1024,500,true);
    add_theme_support('serviceimg',90,90,true);

  load_theme_textdomain('newdesign',get_template_directory_uri().'/language');
/*registration menus*/
 register_nav_menus(array(



 	'main_menu' =>__('Main menu','newdesign'),
 	'footer_menu' =>__('Footer menu','newdesign')

 	));
 /*registration gallerypages
   register_post_type('sliders',array(

  'labels' => array(
         'name' => 'sliders',
         'add_new_item' => 'add new sliders'

    ),
  'public' => true,
  'menu_icon'       => 'dashicons-slides',
  'supports' => array('title','editor','thumbnail','excerpt','custom-fields')



  ));




*/

    $labelsumra = array(
      
        'name'                => _x( 'Umrah', 'Post Type General Name', 'twentythirteen' ),
        'singular_name'       => _x( 'Umrah', 'Post Type Singular Name', 'twentythirteen' ),
        'menu_name'           => __( 'Umrah', 'twentythirteen' ),
        'parent_item_colon'   => __( 'Parent Umrah', 'twentythirteen' ),
        'all_items'           => __( 'All Umrah', 'twentythirteen' ),
        'view_item'           => __( 'View Umrah', 'twentythirteen' ),
        'add_new_item'        => __( 'Add New', 'twentythirteen' ),
        'add_new'             => __( 'Add New', 'twentythirteen' ),
        'edit_item'           => __( 'Edit Umrah', 'twentythirteen' ),
        'update_item'         => __( 'Update Umrah', 'twentythirteen' ),
        'search_items'        => __( 'Search Umrah', 'twentythirteen' ),
        'not_found'           => __( 'Not Found', 'twentythirteen' ),
        'not_found_in_trash'  => __( 'Not found in Trash', 'twentythirteen' ),

    );

   $argsumrah = array(
        'label'               => __( 'Umrah', 'twentythirteen' ),
        'description'         => __( 'Umrah news and reviews', 'twentythirteen' ),
        'labels'              => $labelsumra,
       
        'hierarchical'        => true,
        'public'              => true,
        'show_ui'             => true,
        'show_in_menu'        => true,
        'show_in_nav_menus'   => true,
        'show_in_admin_bar'   => true,
        'menu_position'       => 5,
        'can_export'          => true,
        'has_archive'         => true,
        'exclude_from_search' => false,
        'publicly_queryable'  => true,
        'capability_type'     => 'post',
         
        // This is where we add taxonomies to our CPT
        
        'taxonomies' => array('Location','promotions'),
          
          'menu_icon'       => 'dashicons-palmtree',
          'supports' => array( 'title', 'editor', 'author', 'thumbnail', 'excerpt', 'comments'  )



  );

   register_post_type( 'umrah', $argsumrah );

      register_taxonomy( 'no_of_days', 'umrah', array(

        'labels' => array(

          'name' => 'No of Days'


        ),

        'rewrite' => array( 'slug' => 'genre' ),
      

    'hierarchical' => true,

      )

      
    );

      register_taxonomy( 'package_city', 'umrah', array(

        'labels' => array(

          'name' => 'Package City'


        ),
      
    'rewrite' => array( 'slug' => 'genre' ),
    'hierarchical' => true,

      )

      
    );

    register_taxonomy( 'hotel_name', 'umrah', array(

        'labels' => array(

          'name' => 'Hotel Name'


        ),
      
    'rewrite' => array( 'slug' => 'genre' ),
    'hierarchical' => true,

      ));

    register_taxonomy( 'price_range', 'umrah', array(

        'labels' => array(

          'name' => 'Price Range'


        ),
      
    'rewrite' => array( 'slug' => 'genre' ),
    'hierarchical' => true,

      ));

    register_taxonomy( 'package_class', 'umrah', array(

        'labels' => array(

          'name' => 'Package Class'


        ),
      
    'rewrite' => array( 'slug' => 'genre' ),
    'hierarchical' => true,

      ));


  
   




 

/*registration leftservice*/
  

       


 
 }
 add_action('init','newdesign');
  
/*registration leftservice*/



 function tours_hajj_metaboxes() {

    $umrah = new_cmb2_box( array(
    'id'            => 'tours',
    'title'         => __( 'Tours Package', 'cmb2' ),
    'object_types'  => array( 'tours', ), // Post type
    'context'       => 'normal',
    'priority'      => 'high',
    'show_names'    => true, 

  ) );

  $umrah->add_field( array(
    'name' => esc_html__( 'Departure date', 'cmb2' ),
    'desc' => esc_html__( 'Tours Departure date', 'cmb2' ),
    'id' => $prefix . 'toursdeparturedate',
    'type' => 'text_date',
  ) );

  $umrah->add_field( array(
    'name' => esc_html__( 'Arrive date', 'cmb2' ),
    'desc' => esc_html__( 'Tours Arrive date', 'cmb2' ),
    'id' => $prefix . 'toursarrivedate',
    'type' => 'text_date',
  ) );



  $umrah->add_field( array(
    'name' => esc_html__( 'Tours Name', 'cmb2' ),
    'desc' => esc_html__( 'Tours Package Name', 'cmb2' ),
    'id'   => 'toursname',
    
    'type' => 'text',
  ) );

  $umrah->add_field( array(
    'name' => esc_html__( 'Email', 'cmb2' ),
    'desc' => esc_html__( 'Tour Email', 'cmb2' ),
    'id'   => 'toursemail',
    
    'type' => 'text_email',
  ) );

  $umrah->add_field( array(
    'name' => esc_html__( 'Location', 'cmb2' ),
    'desc' => esc_html__( 'Tours Location', 'cmb2' ),
    'id'   => 'tourlocation',
    
    'type' => 'text',
  ) );

    $umrah->add_field( array(
    'name' => esc_html__( 'Price', 'cmb2' ),
    'desc' => esc_html__( 'Price', 'cmb2' ),
    'id'   => 'toursprice',
    
    'type' => 'text_money',
  ) );

  $umrah->add_field( array(
    'name' => esc_html__( 'Tours Type', 'cmb2' ),
    'desc' => esc_html__( 'Tours Type', 'cmb2' ),
    'id'   => 'tourstype',
    
    'type' => 'text',
  ) );

  $umrah->add_field( array(
    'name' => esc_html__( 'Maximum Number of People', 'cmb2' ),
    'desc' => esc_html__( 'Maximum Number of People', 'cmb2' ),
    'id'   => 'maximumnumberof',
    
    'type' => 'text',
  ) );

    $umrah->add_field( array(
    'name' => esc_html__( 'Overview', 'cmb2' ),
    'desc' => esc_html__( 'Tours Overview', 'cmb2' ),
    'id'   => 'toursoverview',
    
    'type' => 'textarea',
  ) );

    $umrah->add_field( array(
    'name' => esc_html__( 'Tours Map', 'cmb2' ),
    'desc' => esc_html__( 'Tours Map', 'cmb2' ),
    'id' => $prefix . 'toursmap',
    'type' => 'textarea_small',
  ) );

  $umrah->add_field( array(
    'name' => esc_html__( 'Day 1', 'cmb2' ),
    'desc' => esc_html__( 'Tours Day 1', 'cmb2' ),
    'id' => $prefix . 'toursdayone',
    'type' => 'wysiwyg',
  ) );


  $umrah->add_field( array(
    'name' => esc_html__( 'Day 2', 'cmb2' ),
    'desc' => esc_html__( 'Tours Day 2', 'cmb2' ),
    'id' => $prefix . 'toursdaytwo',
    'type' => 'wysiwyg',
  ) );

  $umrah->add_field( array(
    'name' => esc_html__( 'Day 3', 'cmb2' ),
    'desc' => esc_html__( 'Tours Day 3', 'cmb2' ),
    'id' => $prefix . 'toursdaythress',
    'type' => 'wysiwyg',
  ) );

    $umrah->add_field( array(
    'name' => esc_html__( 'Day 4', 'cmb2' ),
    'desc' => esc_html__( 'Tours Day 4', 'cmb2' ),
    'id' => $prefix . 'toursdayfour',
    'type' => 'wysiwyg',
  ) );





  }
  add_action( 'cmb2_admin_init', 'tours_hajj_metaboxes' );


  /* register Hotel Post type*/

  

  /*registration slider*/
