<?php
/**
 * The book now template file
 *
 * This is the most generic template file in a WordPress theme
 * and one of the two required files for a theme (the other being style.css).
 * It is used to display a page when nothing more specific matches a query.
 * E.g., it puts together the home page when no home.php file exists.
 *
 * @link https://developer.wordpress.org/themes/basics/template-hierarchy/
 *
 * @package aynix
 */
 /*
  Template Name: book-now
*/
get_header(); ?>

<?php 
 $user_id = get_current_user_id();

$post_id =  $_GET['post_id'];
 
?>


       <!-- mobile-menu-area start -->
        <div class="mobile-menu-area">
          <div class="container">
            <div class="row">
              <div class="col-md-12">
                <div class="mobile-menu">
                  <nav id="dropdown">
                    <ul>
                        <li class="active"><a href="#">Home</a>
                            <ul>
                                <li><a href="#">Sub Item</a></li>
                                <li><a href="#">Sub Item</a></li>
                                <li><a href="#">Sub Item</a></li>
                                <li><a href="#">Sub Item</a></li>
                                <li><a href="#">Sub Item</a></li>
                                <li><a href="#">Sub Item</a></li>
                                <li><a href="#">Sub Item</a></li>
                            </ul>
                        </li>
                        <li><a href="#">Projects</a></li>
                        <li><a href="#">Activities</a></li>
                        <li><a href="#">Total Jobs</a></li>
                        <li><a href="#">Flights</a></li>
                        <li><a href="#">Hotels</a></li>
                    </ul>
                  </nav>
                </div>
              </div>
            </div>
          </div>
        </div>
        <!-- mobile-menu-area end -->



        <div class="has-border book-now">
            <div class="container">
                <div class="row">
                <div class="col-lg-7 col-12">
                    <div class="bookn-con-left">


                        <?php 
                            //booking data insert
                        
                       if (!empty($_POST)) {


                                
                                
                                //$post_id = $_GETT['post'];
                                global $wpdb;
                               // $user_id = $_GETT['user'];
                                $data = array(
                                    'user_id' => $user_id,
                                    'post_id' => $post_id,
                                    'u_city'    => $_POST['u_city'],
                                    'u_bed' => $_POST['u_bed'],
                                   'u_adults'    => $_POST['u_adults'],  
                                    'u_name'    => $_POST['u_name'],
                                    'u_children'    => $_POST['u_children'],  
                                    'u_infants'    => $_POST['u_infants'],
                                    'u_lname'    => $_POST['u_lname'],
                                    'u_cell' => $_POST['u_cell'],
                                   'u_email'    => $_POST['u_email'],  
                                    'u_address'    => $_POST['u_address'],
                                    'u_ucity'    => $_POST['u_ucity'],  
                                    'u_comments'    => $_POST['u_comments']
                                );
           
                                $success = $wpdb->insert('booking_info',$data);
                                if($success){
                                echo 'data has been saved' ; 
                           
                             }
                               
                           }     
                             ?>

                         <form action="" method="post" >
                        <h2 class="top-text"><?php the_title();?></h2>

                        <div class="book-box package-details">
                            <div class="book-box__title">
                                <span>Step 1</span>
                                <p>Package Details</p>
                            </div>
                            <div class="book-box__body">
                                <ul class="item-det">

                                    <li>
                                        <label>Name:</label>
                                        <div><?php echo get_the_title( $post_id, 'title'); ?></div>
                                        <span class="ico" data-toggle="tooltip" data-placement="top" title="Data on top">
                                            <i class="fa fa-info-circle"></i>
                                        </span>
                                    </li>
                                    <li>
                                        <label>Agent:</label>
                                        <div><?php echo get_post_meta( $post_id, 'agentname', true );?></div>
                                        <span class="ico" data-toggle="tooltip" data-placement="top" title="Data on top">
                                            <i class="fa fa-info-circle"></i>
                                        </span>
                                    </li>
                                    <li>
                                        <label>City:</label>



                                         <select class="form-control u_city" name="u_city">
                                              <?php
                                        $Packagecity = get_terms([
                                        'taxonomy' => 'package_city',
                                        'hide_empty' => false,
                                        ]);
                                          foreach($Packagecity as $package_city_rows){  

                                        ?>
                                           <option value="<?php echo $package_city_rows->name; ?>"><?php echo $package_city_rows->name; ?></option>
                                      <?php } ?>
                                        </select>
                                        <span class="ico" data-toggle="tooltip" data-placement="top" title="Data on top">
                                            <i class="fa fa-info-circle"></i>
                                        </span>
                                    </li>
                                    <li>
                                        <label>Bed:</label>
                                        
                                       <select class="form-control u_bed" name="u_bed">
                                            <option value="Double Bed">Double Bed</option>
                                            <option value="Triple Bed">Triple Bed</option>
                                            <option value="Quad(4 Bed)">Quad(4 Bed)</option>
                                            <option value="DSharing">DSharing</option>

                                        </select>
                                        <span class="ico" data-toggle="tooltip" data-placement="top" title="Data on top">
                                            <i class="fa fa-info-circle"></i>
                                        </span>
                                    </li>
                                    <li>
                                        <label>Adults:</label>
                                        
                                        <select class="form-control u_adults" name="u_adults">
                                            <option  value="0">0</option>
                                            <option  value="1" selected="selected">1</option>
                                            <option  value="2">2</option>
                                            <option  value="3">3</option>
                                            <option  value="4">4</option>
                                        </select>
                                        <span class="ico" data-toggle="tooltip" data-placement="top" title="Data on top">
                                            <i class="fa fa-info-circle"></i>
                                        </span>
                                    </li>
                            
                                    <li>
                                        <label>Children:</label>
                                          <select class="form-control u_children" name="u_children">
                                            <option  value="0">0</option>
                                            <option  value="1" selected="selected">1</option>
                                            <option  value="2">2</option>
                                            <option  value="3">3</option>
                                            <option  value="4">4</option>
                                        </select>
                                        <span class="ico" data-toggle="tooltip" data-placement="top" title="Data on top">
                                            <i class="fa fa-info-circle"></i>
                                        </span>
                                    </li>
                                    <li>
                                        <label>Infants:</label>
                                           <select class="form-control u_infants" name="u_infants">
                                          <option  value="0">0</option>
                                         <option  value="1" selected="selected">1</option>
                                            <option  value="2">2</option>
                                            <option  value="3">3</option>
                                            <option  value="4">4</option>
                                        </select>
                                        <span class="ico" data-toggle="tooltip" data-placement="top" title="Data on top">
                                            <i class="fa fa-info-circle"></i>
                                        </span>
                                    </li>

                                </ul>
                            </div>
                        </div>
       


                        <div class="book-box package-details u-margin-t-30">
                            <div class="book-box__title">
                                <span>Step 3</span>
                                <p>Your Details</p>
                            </div>
                            <div class="book-box__body">

                         

                                <div class="user-det-item">

                                    <button class="ac-btn" type="button" data-toggle="collapse" data-target="#ac1">
                                        <i class="fa fa-caret-down"></i>

                                        Express Booking (By Signing in)

                                      </button>
                                     
                                      
                                      <div class="collapse show cl-b" id="ac1">
                                      <div class="error_msg"></div>
                                            <div class="f-row u-margin-b-15">
                                                <label>Email / Username:</label>
                                                <input class="form-control email_add"  name="email_add" type="text" placeholder="email@domain.com">
                                            </div> 
                                            <div class="f-row u-margin-b-15">
                                                <label>Password:</label>
                                                <input class="form-control pass_user"  type="password" name="pass_user" placeholder="Password">
                                            </div> 

                                            <div class="f-row">
                                                <label></label>
                                                <input type="hidden" class="post_id" name="post_id" value="<?php echo $post_id; ?>" />
                                                <button class="btn btn-primary signin_btn"   type="button">Sign in</button>
                                            </div> 


                                    </div>

                                   


                                </div>

                                 

                           








                                <div class="user-det-item u-margin-t-15">

                                    <button class="ac-btn" type="button" data-toggle="collapse" data-target="#ac2">
                                        <i class="fa fa-caret-down"></i>
                                        Detailed Booking
                                      </button>
                                      <div class="collapse cl-b" id="ac2">
                                            
                                            <div class="f-row u-margin-b-15">
                                                <label>First Name: *</label>
                                                <input class="form-control" type="text" name="u_name" placeholder="First name">
                                            </div> 
          
                                            <div class="f-row u-margin-b-15">
                                                <label>Last Name: *</label>
                                                <input class="form-control" type="text" name="u_lname"  placeholder="Last name">
                                            </div> 

                                            <div class="f-row u-margin-b-15">
                                                <label>CELL#: *</label>
                                                <input class="form-control" type="text" name="u_cell" placeholder="CELL">
                                            </div> 


                                            <div class="f-row u-margin-b-15">
                                                <label>Email: *</label>
                                                <input class="form-control" type="text" name="u_email" placeholder="Email">
                                            </div> 

                                            <div class="f-row u-margin-b-15">
                                                <label>Address: *</label>
                                                <input class="form-control" type="text" name="u_address" placeholder="Address">
                                            </div> 
                                            <div class="f-row u-margin-b-15">
                                                <label>City:</label>
                                                <input class="form-control" type="text" name="u_ucity" placeholder="City">
                                            </div> 
                                            <div class="f-row u-margin-b-15">
                                                <label>Comments:</label>
                                                <textarea class="form-control" name="u_comments"></textarea>
                                            </div> 

                                    </div>

                                </div>

                            </div>
                        </div> 



                        <div class="book-box package-details u-margin-t-30 u-margin-b-30">
                            <div class="book-box__title">
                                <span>Step 3</span>
                                <p>Booking Confirmation</p>
                            </div>
                            <div class="book-box__body">
                                <div class="custom-control custom-checkbox u-margin-b-30">
                                    <input type="checkbox" class="custom-control-input" id="ec1" required>
                                    <label class="custom-control-label" for="ec1">
                                        
                                        I have read and accept the<a target="_blank" href="#"> terms and conditions</a> and <a href="#" target="_blank">book Policy</a>        
                                    </label>
                                </div>

                                  <div class="booking_button">
                                 <?php
                                 if(!is_user_logged_in()){ 
                                  ?>
                                  <button class="btn btn-primary not_user_loggedin" type="button">Book Now</button>

                               <?php }else{ ?>
 
                                     <input class="btn btn-primary" type="submit" value="Book Now"/>

                              <?php } ?>

                              
                                 </div>
                                
                            </div>
                        </div>

                        </form> 

                    </div>
                </div><!-- col 7 -->
            

                <div class="offset-lg-1 col-12 col-lg-4">
                    <div class="booking-summary">
                        <div class="top-text">
                            <h3>Booking Summary</h3>
                        </div>
                        <div class="cont">
                            <h4><?php echo get_the_title( $post_id, 'title'); ?></h4>
                            <div class="cont-ch">
                                <img src="<?php echo esc_url(get_template_directory_uri());?>/img/company_name.png">
                                <p><?php echo get_post_meta( $post_id, 'agentname', true );?></p>
                            </div>

                            <div class="t-col">
                                <div class="fig">
                                    <?php 
                                                
                                                echo get_the_post_thumbnail($post_id, 'thumbnail'); 

                                                 ?>
                                </div>
                                <div class="exp-rat def-exp" data-toggle="tooltip" data-placement="top" title="" data-original-title="Data on top">
                                                <a href="#">

                                                    <div class="titl">Expert Rating</div>
                                             

                                                          <?php

                                                     $id = $post_id;
                                                       global $wpdb;
                                                    
                                                      $show_details = $wpdb->get_results("SELECT * FROM umratinguser WHERE upostid = '$id'"); 
                                                      ?>

                                                      <?php 

                                                     foreach ( $show_details as $show_detail) 
                                                     { 

                                                        ?>

                                                         <div class="bd">
                                                        <h4>

                                                             <?php



                                 $ratingPercentaa = $show_detail->rating; 

                                 $maxrating = ($ratingPercentaa * 5)/100;

                                 echo $maxrating;



                                                            ?>


                                                        </h4>
                                                        <img src="<?php echo esc_url(get_template_directory_uri());?>/img/user_icon.png">
                                                    </div>

                           <div class="stars">
                               
                                 <?php if( $show_detail->rating == '1'):?>★<?php endif; ?>
                                    <?php if( $show_detail->rating == '2'):?>★★<?php endif; ?>
                                    <?php if( $show_detail->rating == '3'):?>★★★<?php endif; ?>
                                    <?php if( $show_detail->rating == '4'):?>★★★★<?php endif; ?>
                                    <?php if( $show_detail->rating == '5'):?>★★★★★<?php endif; ?>

                                 
                               
                           </div>
                             <?php } ?>




                                                </a>
                                            </div>

                                            <div class="exp-rat def-exp" data-toggle="tooltip" data-placement="top" title="" data-original-title="Data on top">
                                                <a href="#">

                                                    <div class="titl">User Rating</div>
                                                    <div class="bd">
                                                        <h4><?php echo do_shortcode('[site_reviews_summary assigned_to="post_id" hide="bars,if_empty,stars,summary"]'); ?></h4>
                                                        <img src="<?php echo esc_url(get_template_directory_uri());?>/img/user_group_icon.png">
                                                    </div>
                                                    <div class="stars">
                                                        <?php echo do_shortcode('[site_reviews_summary assigned_to="post_id"  hide="bars,if_empty,rating,summary"]'); ?>
                                                    </div>
                                                </a>
                                            </div>
                            </div>

                            <div class="book-det">
                                <h4>Your Booking Details</h4>
                                <ul>
                                    <li>
                                        <div class="left">Package City:</div>
										    <?php
                                        $Tourprice = get_the_terms(  $post_id, 'package_city' );

                                       foreach($Tourprice as $package_city_rows){  

                                        ?>
                                        <div class="right package_city"><?php echo $package_city_rows->name; ?></div>
										<?php } ?>
                                    </li>
									 
									 <li>
                                        <div class="left ">Double Bed:</div>
                                        <div class="right">PKR <?php echo get_post_meta( $post_id, 'umrahdouble', true );?></div>
                                    </li>
									 <li>
                                        <div class="left ">Triple Bed:</div>
                                        <div class="right">PKR <?php echo get_post_meta( $post_id, 'umrahtriplebed', true );?></div>
                                    </li>
									 <li>
                                        <div class="left ">Quad(4 Bed):</div>
                                        <div class="right">PKR <?php echo get_post_meta( $post_id, 'umrahfourbed', true );?></div>
                                    </li>
									<li>
                                        <div class="left ">DSharing:</div>
                                        <div class="right">PKR <?php echo get_post_meta( $post_id, 'umrahsharing', true );?></div>
                                    </li>
                                    <li>
                                        <div class="left ">Package Bed Type:</div>
                                        <div class="right Package_Bed_Type">Single</div>
                                    </li>
                              
                                    <li>
                                        <div class="left">Number of Adults:</div>
                                        <div class="right Number_of_Adults">1</div>
                                    </li>
                              
                                    <li>
                                        <div class="left ">Number of Childrens:</div>
                                        <div class="right Number_of_Childrens">1</div>
                                    </li>
                                    <li>
                                        <div class="left ">Number of Infants:</div>
                                        <div class="right Number_of_Infants">1</div>
                                    </li>
                                </ul>
                            </div>

                           <!--  <div class="book-det  u-padding-t-10">
                                <h4>Your Payments Details</h4>
                                <ul>
                                    <li>
                                        <div class="left bld">Total Adult Price:</div>
                                        <div class="right bld">37,927 PKR</div>
                                    </li>
                                    <li>
                                        <div class="left bld">Total Children Price:</div>
                                        <div class="right bld">0 PKR</div>
                                    </li>
                              
                                    <li>
                                        <div class="left bld">Total Infant Price:</div>
                                        <div class="right bld">0 PKR</div>
                                    </li>
                              
                                    <li class="last u-margin-t-25">
                                        <div class="left">Total Discount:</div>
                                        <div class="right">0 PKR</div>
                                    </li>
                                </ul>

                                <div class="fot">
                                    <span>Total Price (Approx.) </span>
                                    37,927 PKR
                                </div>
                            </div> -->



                        </div>
                    </div>
                </div>



                </div> 
            </div>
        </div>


<?php get_footer();?>
<?php 
//booking data insert
if(isset($_GET['user'])){

     $user_id = $_GET['user'];
      $post_id = $_GET['post'];

     $table = 'booking_info'; 


 $arg =  array( 
    'user_id' => $user_id,
    'post_id' => $post_id, 
    );   
    $succs = $wpdb->insert($table, $arg);    
}
    
 ?>



<script>
  jQuery(".signin_btn").click(function(e) { 
            e.preventDefault();

            
       
           var tem_url = "<?php echo get_template_directory_uri(); ?>";
           var user_id = "<?php echo get_current_user_id(); ?>"; 
           var site_url = "<?php echo site_url(); ?>/book-now/";
            var email_add = jQuery('.email_add').val();
            var pass_user = jQuery('.pass_user').val();

            if(email_add ==""){
                alert('Please Email Input');
                return false;
            }

            if(pass_user ==""){
                alert('Please Password Input');
                return false;
            }


           
           
         // alert(user_id);
            var tem_uri = tem_url+'/ajax/login_authentication_ajax.php?email_add='+email_add+'&pass_user='+pass_user;
            //alert(tem_uri); 
            jQuery.ajax({
            url: tem_uri,
             type: "GET", 
            success: function(response) { 
          // alert(response);  
            jQuery('.error_msg').html('<p style="color:red;">'+response+'</p>'); 

/*            var str = response;
var res = str.split("_");

 alert(res[1]);*/
 

            if(response == 'mass'){
                //alert(22222222222);
                //jQuery('.booking_button').html('<a href="'+site_url+res[2]+'" class="btn btn-primary">Book Now</button>'); 

                 jQuery('.booking_button').html('<button class="btn btn-primary" type="submit">Book Now</button>');
            }
            }
            
            });         

         });



          jQuery(document).on('click', '.not_user_loggedin', function(e) { 

            alert("Please Login first"); 

        });

        jQuery(document).on('change', '.u_city', function(e) {  
             var u_city = jQuery('.u_city').val();
              jQuery('.package_city').html(u_city);
        });

        jQuery(document).on('change', '.u_bed', function(e) {  
             var u_bed = jQuery('.u_bed').val();
              jQuery('.Package_Bed_Type').html(u_bed);
        });


        jQuery(document).on('change', '.u_adults', function(e) {  
             var u_adults = jQuery('.u_adults').val();
              jQuery('.Number_of_Adults').html(u_adults);
        });


        jQuery(document).on('change', '.u_children', function(e) {  
             var u_children = jQuery('.u_children').val();
              jQuery('.Number_of_Childrens').html(u_children);
        });


        jQuery(document).on('change', '.u_infants', function(e) {  
             var u_infants = jQuery('.u_infants').val();
              jQuery('.Number_of_Infants').html(u_infants);
        });



</script>