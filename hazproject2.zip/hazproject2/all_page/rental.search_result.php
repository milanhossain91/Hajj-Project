<?php
/**
 * The rental search result template file
 *
 * This is the most generic template file in a WordPress theme
 * and one of the two required files for a theme (the other being style.css).
 * It is used to display a page when nothing more specific matches a query.
 * E.g., it puts together the home page when no home.php file exists.
 *
 * @link https://developer.wordpress.org/themes/basics/template-hierarchy/
 *
 * @package aynix
 */
 /*
  Template Name: rental.search_result
*/
get_header(); ?>
   
     <!-- mobile-menu-area start -->
        <div class="mobile-menu-area">
          <div class="container">
            <div class="row">
              <div class="col-md-12">
                <div class="mobile-menu">
                  <nav id="dropdown">
                    <ul>
                        <li class="active"><a href="#">Home</a>
                            <ul>
                                <li><a href="#">Sub Item</a></li>
                                <li><a href="#">Sub Item</a></li>
                                <li><a href="#">Sub Item</a></li>
                                <li><a href="#">Sub Item</a></li>
                                <li><a href="#">Sub Item</a></li>
                                <li><a href="#">Sub Item</a></li>
                                <li><a href="#">Sub Item</a></li>
                            </ul>
                        </li>
                        <li><a href="#">Projects</a></li>
                        <li><a href="#">Activities</a></li>
                        <li><a href="#">Total Jobs</a></li>
                        <li><a href="#">Flights</a></li>
                        <li><a href="#">Hotels</a></li>
                    </ul>
                  </nav>
                </div>
              </div>
            </div>
          </div>
        </div>
        <!-- mobile-menu-area end -->



        <div class="search-res flight has-border">
            <div class="container">
                <div class="top-title">
                    <h3>28 hotels test  <a href="#">Change search</a></h3>
                </div>
                <div class="row">
                    <div class="col-sm-3">
                        <div class="left-sidebar">
                            <div class="bar-title">
                                Filter By:
                            </div>

                            <div class="bar-item">
                                <div class="wrap">
                                    <a class="ac-title"  data-toggle="collapse" href="#ac1" role="button" aria-expanded="false" aria-controls="ac1">Review Score</a>
                                    <div class="collapse show" id="ac1">
                                  <div class="inner">
                                    <div class="custom-control custom-checkbox">
                                        <input type="checkbox" class="custom-control-input" id="a1">
                                        <label class="custom-control-label" for="a1">
                                            <i class="fa fa-star"></i>
                                            <i class="fa fa-star"></i>
                                            <i class="fa fa-star"></i>
                                            <i class="fa fa-star"></i>
                                            <i class="fa fa-star"></i>
                                        </label>
                                    </div>
                                    <div class="custom-control custom-checkbox">
                                        <input type="checkbox" class="custom-control-input" id="a2">
                                        <label class="custom-control-label" for="a2">
                                            <i class="fa fa-star"></i>
                                            <i class="fa fa-star"></i>
                                            <i class="fa fa-star"></i>
                                            <i class="fa fa-star"></i>
                                        </label>
                                    </div>
                                    <div class="custom-control custom-checkbox">
                                        <input type="checkbox" class="custom-control-input" id="a3">
                                        <label class="custom-control-label" for="a3">
                                            <i class="fa fa-star"></i>
                                            <i class="fa fa-star"></i>
                                            <i class="fa fa-star"></i>
                                        </label>
                                    </div>
                                    <div class="custom-control custom-checkbox">
                                        <input type="checkbox" class="custom-control-input" id="a4">
                                        <label class="custom-control-label" for="a4">
                                            <i class="fa fa-star"></i>
                                            <i class="fa fa-star"></i>
                                        </label>
                                    </div>
                                    <div class="custom-control custom-checkbox">
                                        <input type="checkbox" class="custom-control-input" id="a5">
                                        <label class="custom-control-label" for="a5">
                                            <i class="fa fa-star"></i>
                                        </label>
                                    </div>
                                </div>
                              </div>
                            </div>
                            </div>

                            <div class="bar-item">
                                <div class="wrap">
                                    <a class="ac-title"  data-toggle="collapse" href="#ac4" role="button" aria-expanded="false" aria-controls="ac4">Price</a>
                                    <div class="collapse show" id="ac4">
                                  <div class="inner">
                                    <div class="price-filter">
                                        <input type="text" id="price-filter" name="priceRange">
                                        <button class="btn btn-primary button-filter-price" type="submit">Filter</button>
                                    </div>
                                </div>
                              </div>
                            </div>
                            </div>

                            <div class="bar-item">
                                <div class="wrap">
                                    <a class="ac-title"  data-toggle="collapse" href="#ac2" role="button" aria-expanded="false" aria-controls="ac2">Facilities</a>
                                    <div class="collapse show" id="ac2">
                                  <div class="inner">
                                    <div class="custom-control custom-checkbox">
                                        <input type="checkbox" class="custom-control-input" id="b1">
                                        <label class="custom-control-label" for="b1">Non-stop</label>
                                    </div>
                                    <div class="custom-control custom-checkbox">
                                        <input type="checkbox" class="custom-control-input" id="b2">
                                        <label class="custom-control-label" for="b2">1 Stop</label>
                                    </div>
                                    <div class="custom-control custom-checkbox">
                                        <input type="checkbox" class="custom-control-input" id="b3">
                                        <label class="custom-control-label" for="b3">2 Stop</label>
                                    </div>
                                </div>
                              </div>
                            </div>
                            </div>


                            <div class="bar-item">
                                <div class="wrap">
                                    <a class="ac-title"  data-toggle="collapse" href="#ac3" role="button" aria-expanded="false" aria-controls="ac3">Departure Time</a>
                                    <div class="collapse show" id="ac3">
                                  <div class="inner">
                                    <div class="custom-control custom-checkbox">
                                        <input type="checkbox" class="custom-control-input" id="b10">
                                        <label class="custom-control-label" for="b10">Non-stop</label>
                                    </div>
                                    <div class="custom-control custom-checkbox">
                                        <input type="checkbox" class="custom-control-input" id="b20">
                                        <label class="custom-control-label" for="b20">1 Stop</label>
                                    </div>
                                    <div class="custom-control custom-checkbox">
                                        <input type="checkbox" class="custom-control-input" id="b30">
                                        <label class="custom-control-label" for="b30">2 Stop</label>
                                    </div>
                                </div>
                              </div>
                            </div>
                            </div>

                        </div>
                    </div> <!-- col- end -->

                    <div class="col-sm-9">
                        <div class="row hotels-res">

                            <div class="col-sm-4">
                                <div class="top-deal-item">
                                    <a href="#" class="fig">
                                        <img src="<?php echo esc_url(get_template_directory_uri());?>/img/Barclay-400x300.jpg">
                                        <span>Book Now</span>
                                    </a>
                                           
                                    <div class="content">
                                        <div class="icons">
                                            <i class="fa fa-star"></i>         
                                            <i class="fa fa-star"></i>         
                                            <i class="fa fa-star"></i>         
                                            <i class="fa fa-star"></i>         
                                            <i class="fa fa-star"></i>         
                                        </div>
                                        <h5><a href="#">InterContinental New</a></h5>
                                        <div class="location">
                                            <i class="fa fa-map-marker"></i>
                                            <span> Paris-Charles de Gaulle Airport, Roissy-en-France, France</span>
                                        </div>
                                        <p class="mb0">from $130,00 <small>/night</small></p>
                                    </div>
                               
                                </div>
                            </div>

                            <div class="col-sm-4">
                                <div class="top-deal-item">
                                    <a href="#" class="fig">
                                        <img src="<?php echo esc_url(get_template_directory_uri());?>/img/Barclay-400x300.jpg">
                                        <span>Book Now</span>
                                    </a>
                                           
                                    <div class="content">
                                        <div class="icons">
                                            <i class="fa fa-star"></i>         
                                            <i class="fa fa-star"></i>         
                                            <i class="fa fa-star"></i>         
                                            <i class="fa fa-star"></i>         
                                            <i class="fa fa-star"></i>         
                                        </div>
                                        <h5><a href="#">InterContinental New</a></h5>
                                        <div class="location">
                                            <i class="fa fa-map-marker"></i>
                                            <span> Paris-Charles de Gaulle Airport, Roissy-en-France, France</span>
                                        </div>
                                        <p class="mb0">from $130,00 <small>/night</small></p>
                                    </div>
                               
                                </div>
                            </div>

                            <div class="col-sm-4">
                                <div class="top-deal-item">
                                    <a href="#" class="fig">
                                        <img src="<?php echo esc_url(get_template_directory_uri());?>/img/Barclay-400x300.jpg">
                                        <span>Book Now</span>
                                    </a>
                                           
                                    <div class="content">
                                        <div class="icons">
                                            <i class="fa fa-star"></i>         
                                            <i class="fa fa-star"></i>         
                                            <i class="fa fa-star"></i>         
                                            <i class="fa fa-star"></i>         
                                            <i class="fa fa-star"></i>         
                                        </div>
                                        <h5><a href="#">InterContinental New</a></h5>
                                        <div class="location">
                                            <i class="fa fa-map-marker"></i>
                                            <span> Paris-Charles de Gaulle Airport, Roissy-en-France, France</span>
                                        </div>
                                        <p class="mb0">from $130,00 <small>/night</small></p>
                                    </div>
                               
                                </div>
                            </div>

                            <div class="col-sm-4">
                                <div class="top-deal-item">
                                    <a href="#" class="fig">
                                        <img src="<?php echo esc_url(get_template_directory_uri());?>/img/Barclay-400x300.jpg">
                                        <span>Book Now</span>
                                    </a>
                                           
                                    <div class="content">
                                        <div class="icons">
                                            <i class="fa fa-star"></i>         
                                            <i class="fa fa-star"></i>         
                                            <i class="fa fa-star"></i>         
                                            <i class="fa fa-star"></i>         
                                            <i class="fa fa-star"></i>         
                                        </div>
                                        <h5><a href="#">InterContinental New</a></h5>
                                        <div class="location">
                                            <i class="fa fa-map-marker"></i>
                                            <span> Paris-Charles de Gaulle Airport, Roissy-en-France, France</span>
                                        </div>
                                        <p class="mb0">from $130,00 <small>/night</small></p>
                                    </div>
                               
                                </div>
                            </div>

                            <div class="col-sm-4">
                                <div class="top-deal-item">
                                    <a href="#" class="fig">
                                        <img src="<?php echo esc_url(get_template_directory_uri());?>/img/Barclay-400x300.jpg">
                                        <span>Book Now</span>
                                    </a>
                                           
                                    <div class="content">
                                        <div class="icons">
                                            <i class="fa fa-star"></i>         
                                            <i class="fa fa-star"></i>         
                                            <i class="fa fa-star"></i>         
                                            <i class="fa fa-star"></i>         
                                            <i class="fa fa-star"></i>         
                                        </div>
                                        <h5><a href="#">InterContinental New</a></h5>
                                        <div class="location">
                                            <i class="fa fa-map-marker"></i>
                                            <span> Paris-Charles de Gaulle Airport, Roissy-en-France, France</span>
                                        </div>
                                        <p class="mb0">from $130,00 <small>/night</small></p>
                                    </div>
                               
                                </div>
                            </div>

                            <div class="col-sm-4">
                                <div class="top-deal-item">
                                    <a href="#" class="fig">
                                        <img src="<?php echo esc_url(get_template_directory_uri());?>/img/Barclay-400x300.jpg">
                                        <span>Book Now</span>
                                    </a>
                                           
                                    <div class="content">
                                        <div class="icons">
                                            <i class="fa fa-star"></i>         
                                            <i class="fa fa-star"></i>         
                                            <i class="fa fa-star"></i>         
                                            <i class="fa fa-star"></i>         
                                            <i class="fa fa-star"></i>         
                                        </div>
                                        <h5><a href="#">InterContinental New</a></h5>
                                        <div class="location">
                                            <i class="fa fa-map-marker"></i>
                                            <span> Paris-Charles de Gaulle Airport, Roissy-en-France, France</span>
                                        </div>
                                        <p class="mb0">from $130,00 <small>/night</small></p>
                                    </div>
                               
                                </div>
                            </div>

                            <div class="col-sm-4">
                                <div class="top-deal-item">
                                    <a href="#" class="fig">
                                        <img src="<?php echo esc_url(get_template_directory_uri());?>/img/Barclay-400x300.jpg">
                                        <span>Book Now</span>
                                    </a>
                                           
                                    <div class="content">
                                        <div class="icons">
                                            <i class="fa fa-star"></i>         
                                            <i class="fa fa-star"></i>         
                                            <i class="fa fa-star"></i>         
                                            <i class="fa fa-star"></i>         
                                            <i class="fa fa-star"></i>         
                                        </div>
                                        <h5><a href="#">InterContinental New</a></h5>
                                        <div class="location">
                                            <i class="fa fa-map-marker"></i>
                                            <span> Paris-Charles de Gaulle Airport, Roissy-en-France, France</span>
                                        </div>
                                        <p class="mb0">from $130,00 <small>/night</small></p>
                                    </div>
                               
                                </div>
                            </div>

                            <div class="col-sm-4">
                                <div class="top-deal-item">
                                    <a href="#" class="fig">
                                        <img src="<?php echo esc_url(get_template_directory_uri());?>/img/Barclay-400x300.jpg">
                                        <span>Book Now</span>
                                    </a>
                                           
                                    <div class="content">
                                        <div class="icons">
                                            <i class="fa fa-star"></i>         
                                            <i class="fa fa-star"></i>         
                                            <i class="fa fa-star"></i>         
                                            <i class="fa fa-star"></i>         
                                            <i class="fa fa-star"></i>         
                                        </div>
                                        <h5><a href="#">InterContinental New</a></h5>
                                        <div class="location">
                                            <i class="fa fa-map-marker"></i>
                                            <span> Paris-Charles de Gaulle Airport, Roissy-en-France, France</span>
                                        </div>
                                        <p class="mb0">from $130,00 <small>/night</small></p>
                                    </div>
                               
                                </div>
                            </div>

                            <div class="col-sm-4">
                                <div class="top-deal-item">
                                    <a href="#" class="fig">
                                        <img src="<?php echo esc_url(get_template_directory_uri());?>/img/Barclay-400x300.jpg">
                                        <span>Book Now</span>
                                    </a>
                                           
                                    <div class="content">
                                        <div class="icons">
                                            <i class="fa fa-star"></i>         
                                            <i class="fa fa-star"></i>         
                                            <i class="fa fa-star"></i>         
                                            <i class="fa fa-star"></i>         
                                            <i class="fa fa-star"></i>         
                                        </div>
                                        <h5><a href="#">InterContinental New</a></h5>
                                        <div class="location">
                                            <i class="fa fa-map-marker"></i>
                                            <span> Paris-Charles de Gaulle Airport, Roissy-en-France, France</span>
                                        </div>
                                        <p class="mb0">from $130,00 <small>/night</small></p>
                                    </div>
                               
                                </div>
                            </div>
                        </div>
                        
                        <div class="res-pagi c-pagi">
                            <nav aria-label="Page navigation example">
                                  <ul class="pagination">
                                    <li class="page-item"><a class="page-link" href="#"><i class="fa fa-angle-left"></i></a></li>
                                    <li class="page-item"><a class="page-link" href="#">1</a></li>
                                    <li class="page-item"><a class="page-link" href="#">2</a></li>
                                    <li class="page-item"><a class="page-link" href="#">3</a></li>
                                    <li class="page-item">
                                        <a class="page-link" href="#"><i class="fa fa-angle-right"></i></a>
                                    </li>
                                  </ul>
                            </nav>
                        </div>

                    </div> <!--  col end-->
                </div>
            </div>
        </div>


<?php get_footer();?>