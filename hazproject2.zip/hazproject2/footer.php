<?php
/**
 * The template for displaying the footer
 *
 * Contains the closing of the #content div and all content after.
 *
 * @link https://developer.wordpress.org/themes/basics/template-files/#template-partials
 *
 * @package venox
 */

?>


	<footer id="main-footer">
    <div class="wpb-row">
        <div class="container">
            <div class="row">
                <div class="col-md-3">
                    <div class="wpb-wrapper1 wpb-wrapper">
                        <div class="wpb-text">
                                <img src="<?php global $redux_demo; echo $redux_demo['logo'] ['url'];?>" alt="">
                            <p><?php global $redux_demo; echo $redux_demo['aboutus'];?></p>
                        </div>
                        <div class="wpb-social">
                            <ul>
                                <li>
                                    <a href="<?php global $redux_demo; echo $redux_demo['facebook'];?>"><i class="fa fa-facebook"></i></a>
                                </li>
                                <li>
                                    <a href="<?php global $redux_demo; echo $redux_demo['twitter'];?>"><i class="fa fa-twitter"></i></a>
                                </li>
                                <li>
                                    <a href="<?php global $redux_demo; echo $redux_demo['linkedin'];?>"><i class="fa fa-google-plus"></i></a>
                                </li>
                                <li>
                                    <a href="<?php global $redux_demo; echo $redux_demo['googleplus'];?>"><i class="fa fa-linkedin"></i></a>
                                </li>
                               
                            </ul>
                        </div> 
                    </div>
                </div>
                <div class="col-md-3">
                    <div class="wpb-wrapper2 wpb-wrapper">
                        <div class="wpb-wrapper2-title">
                            <h4>Newsletter</h4>
                        </div>
                        <form>
                            <label>Enter your E-mail Address</label>
                            <input type="email" name="Email">
                        </form>
                        <p class="mt5"><small>*We Never Send Spam</small></p>
                        <input type="submit" value="Subscribe" class="btn-subscribe">
                    </div>
                </div>
                <div class="col-md-2">
                    <div class="wpb-wrapper3 wpb-wrapper">
                        <div class="list-footer">

                                        <?php wp_nav_menu(array(


                                  'theme_location' => 'footer_menu',
                                  'container'  => false,
                                 
                                  





                                   ));?>
                      
                        </div>
                    </div>
                </div>
                <div class="col-md-4">
                    <div class="wpb-wrapper4 wpb-wrapper">

                        <?php global $redux_demo; echo $redux_demo['trust_have_questions'];?>
                        
                    </div> 
                </div>
            </div>
        </div>
    </div>
</footer><!--footer-->

    <script src="//code.jquery.com/jquery-1.12.4.min.js" integrity="sha256-ZosEbRLbNQzLpnKIkEdrPv7lOy9C27hHQ+Xp8a4MxAQ=" crossorigin="anonymous"></script>
	 <script src="//www.bookmyumrah.pk/addons/shared_addons/themes/bmu/js/minified/ionrangeslider.min.js" type="text/javascript"></script> 
    
    
     <script src="<?php echo get_template_directory_uri();?>/js/bootstrap.bundle.min.js"></script>
	 <script src="<?php echo get_template_directory_uri();?>/js/jquery.gridrotator.js"></script>
    <script src="<?php echo get_template_directory_uri();?>/js/jquery.meanmenu.js"></script>

     <script src="http://www.bookmyumrah.pk/addons/shared_addons/themes/bmu/js/minified/ionrangeslider.min.js" defer="defer" type="text/javascript"></script> 
     <script src="https://cdnjs.cloudflare.com/ajax/libs/fotorama/4.6.4/fotorama.js"></script>
     
	 <script src="<?php echo get_template_directory_uri();?>/js/bootstrap-timepicker.js"></script>
	
	 <script src="<?php echo get_template_directory_uri();?>/js/index.js"></script>



 


<?php wp_footer(); ?>

</body>
</html>
