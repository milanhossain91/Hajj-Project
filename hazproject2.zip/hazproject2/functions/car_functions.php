<?php
//for booking page
   if(isset($_GET['car_id'])){
     $car_id = $_GET['car_id'];   
     }
    
    if(isset($_GET['package_id'])){
     $package_id = $_GET['package_id'];   
     }   
      if(isset($_GET['booking_total'])){
     $booking_total = $_GET['booking_total'];   
     }   
//search page 
if(isset($_GET['car_location'])){ 
$car_location = $_GET['car_location'];
$car_title = $_GET['car_title']; 
$package_id = $_GET['package_id'];  
}



//car details page
if(isset($_POST['car_book_now'])){

  if(isset($_POST['package_id'])){
     $package_id = $_POST['package_id'];   
     }
  
    if(isset($_POST['car_id'])){
     $car_id = $_POST['car_id'];   
     } 
     
    $location =  site_url().'/car-booking/?car_id='.$car_id.'&package_id='.$package_id;  
    echo '<script type="text/javascript">window.location.href = "'.$location.'"</script>';


}


 


function getPackagePriceById($package_id){ 
global $wpdb;
$wp_post_db = "car_packages"; 
$show_vendor_posts = $wpdb->get_results("SELECT package_price FROM $wp_post_db WHERE id='$package_id'  ORDER BY id DESC");  
foreach( $show_vendor_posts as $show_vendor_post) 
{  
   return $show_vendor_post->package_price;   
}
} 

 
  
if(isset($_POST['car_booking_submit'])){ 


if(isset($_POST['is_different'])){
  $is_different = $_POST['is_different'];
}else{
  $is_different = 0;
}
// Create rooms object
$bookingData = array(   

  'user_id'           => get_current_user_id(),   
  'post_parent_id'   => $car_id,
  'post_id'       => $package_id, //available room
   'booking_total'       => getPackagePriceById($package_id),

  'is_different'       => $is_different,  
  'time_of_journey'       => $_POST['time_of_journey'],  
  'date_of_journey'       => $_POST['date_of_journey'],  
  'drop_off_location'       => $_POST['drop_off_location'],  
  'pickup_location'       => $_POST['pickup_location'],  

  'u_name' 				=> $_POST['u_name'], 
  'u_cell'       => $_POST['u_cell'], 
  'u_email'       => $_POST['u_email'],  
  'service_type'       => 'cars',    
  
);  
//print_r($bookingData);

$order_id =  $wpdb->insert('main_booking_details', $bookingData );    
if($order_id){
  $msg = '<p style="color:green;text-align:center;font-size:19px">Successfully Inserted...</p>';
};

}


?>

 