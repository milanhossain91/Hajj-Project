<?php
//for booking page
   if(isset($_GET['tour_id'])){
     $tour_id = $_GET['tour_id'];   
     }
    
    if(isset($_GET['u_rooms'])){
     $u_rooms = $_GET['u_rooms'];   
     }   

     if(isset($_GET['specific_date'])){
     $specific_date = $_GET['specific_date'];   
     }   
    
    
    //search page 
    if(isset($_GET['tour_location'])){ 
    $tour_location = $_GET['tour_location']; 
    $category_id = $_GET['category_id'];  
    }



//tour details page
if(isset($_POST['tour_book_now'])){

  if(isset($_POST['tour_id'])){
     $tour_id = $_POST['tour_id'];   
     }

    if(isset($_POST['specific_date'])){
     $specific_date = $_POST['specific_date'];   
     $specific_date = date("Y-m-d", strtotime($specific_date));   
     }
  
    if(isset($_POST['u_rooms'])){
     $u_rooms = $_POST['u_rooms'];   
     } 
     
    $location =  site_url().'/tour-booking/?tour_id='.$tour_id.'&u_rooms='.$u_rooms.'&specific_date='.$specific_date;  
    echo '<script type="text/javascript">window.location.href = "'.$location.'"</script>';


}

$wp_post_db = "tour_details"; 
$show_vendor_posts = $wpdb->get_results("SELECT * FROM $wp_post_db WHERE id='$tour_id' ORDER BY id DESC"); 
$i=0;
foreach( $show_vendor_posts as $show_vendor_post) 
{  //print_r($show_vendor_post);
   $tid =  $show_vendor_post->id;    
   $category_id =  $show_vendor_post->category_id;  
   $tour_title =  $show_vendor_post->tour_title;  
   $tour_description =  $show_vendor_post->tour_description;    
   $tour_price =  $show_vendor_post->tour_price;    
   $date_added =  $show_vendor_post->date_added;     
   }                                                          
           



 //booking form submit
if(isset($_POST['tour_booking_submit'])){ 
  
// Create rooms object
$bookingData = array(   

  'user_id'           => get_current_user_id(),   
  'post_parent_id'   => $tour_id,
  'post_id'       => $category_id, //available room
  'booking_total'       => $tour_price, 
  'check_in'       => $specific_date, //specific_date 
  'u_name'        => $_POST['u_name'], 
  'u_cell'       => $_POST['u_cell'], 
  'u_email'       => $_POST['u_email'],  
  'service_type'       => 'tours',    
  
);  
//print_r($bookingData);

$order_id =  $wpdb->insert('main_booking_details', $bookingData );    
if($order_id){
  $msg = '<p style="color:green;text-align:center;font-size:19px">Successfully Inserted...</p>';

  $location =  site_url().'/tour-booking/?order_id='.$order_id.'&tour_id='.$tour_id.'&u_rooms='.$u_rooms.'&specific_date='.$specific_date;  
    echo '<script type="text/javascript">window.location.href = "'.$location.'"</script>';
}


}

//functions
function getActivityNameById($tour_id){ 
global $wpdb;
 $wp_post_db = "tour_activities";
  $show_vendor_posts = $wpdb->get_results("SELECT DISTINCT * FROM $wp_post_db WHERE tour_id='$tour_id'");   
   return $show_vendor_posts;   
 
} 


function getPackagePriceById($package_id){ 
global $wpdb;
$wp_post_db = "tour_packages"; 
$show_vendor_posts = $wpdb->get_results("SELECT package_price FROM $wp_post_db WHERE id='$package_id'  ORDER BY id DESC");  
foreach( $show_vendor_posts as $show_vendor_post) 
{  
   return $show_vendor_post->package_price;   
}
} 

 
 


?>

 