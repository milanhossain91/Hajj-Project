<?php include('head.php');?>  

<?php 
 if(isset($_POST['add_activity_submit_btn'])){
  
   global $wpdb;
    // Create rooms object
    $data3 = array(  
      'category_name'       => $_POST['category_name'], 
      'category_description' => $_POST['category_description'],   
    );  
    $results = $wpdb->insert('activity_categories', $data3 ); 
    if($results){
    $msg = "Successfully Inserted..";
    }
}
?>



<div style="padding:50px;border:1px solid blue;">
  <h2 style="color:blue;"><?php if(isset($_POST['add_activity_submit_btn'])){ echo $msg;  } ?><h2>
  <h4>Added activitys</h4>  
   
   <form method="post" enctype="multipart/form-data">

     
    <div class="form-group row">
      <label for="colFormLabel" class="col-sm-2 col-form-label">Category Name</label>
      <div class="col-sm-10">
        <input type="text" class="form-control" id="colFormLabel" name="category_name">
      </div>
    </div> 

    <div class="form-group row">
      <label for="colFormLabelLg" class="col-sm-2 col-form-label col-form-label-lg">activity Description</label>
      <div class="col-sm-10">
         <textarea name="category_description" style="resize:none;height:300px;width:40%;float:left"></textarea>
      </div>
    </div>    
     
    <div class="form-group row"> 
      <div class="col-sm-10">
       <input type="hidden" name="service_type" value="cars">
        <input type="submit"  class="btn-primary"   name="add_activity_submit_btn" >
      </div>
    </div> 


</form>

</div>

<?php include('footer.php'); ?>


  

   