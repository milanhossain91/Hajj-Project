<?php include('head.php'); 
 
 global $wpdb;
?>  
 


<div style="padding:50px;border:1px solid blue;">
<h2><?php if(isset($_POST['add_Rooms_submit_btn'])){ echo $msg;  } ?><h2>
<h4>Added Available Rooms</h4> </br> </br>
 <form action="<?php echo get_stylesheet_directory_uri();?>/admin-page/upload.php" method="post" class="dropzone" id="my-awesome-dropzone" enctype="multipart/form-data">
   

    <div class="form-group row">
    <label for="colFormLabel" class="col-sm-2 col-form-label">room Title</label>
       <div class="col-sm-10">
        <select name="hotel_id">
<?php 


  $wp_post_db = "hotel_details";
  $show_vendor_posts = $wpdb->get_results("SELECT * FROM $wp_post_db ORDER BY id DESC"); 
  $i=0;
  foreach( $show_vendor_posts as $show_vendor_post) 
  {  
   ?>  
      <option value="<?php echo $show_vendor_post->id ?>"> <?php echo $show_vendor_post->hotel_title; ?> </option> 
  <?php } ?>
  </select>
   </div>
  </div> 



  <div class="form-group row">
    <label for="colFormLabel" class="col-sm-2 col-form-label">room Title</label>
    <div class="col-sm-10">
      <input type="text" class="form-control" id="colFormLabel" name="room_title">
    </div>
  </div> 


  <div class="form-group row">
    <label for="colFormLabelLg" class="col-sm-2 col-form-label col-form-label-lg">Room Description</label>
    <div class="col-sm-10">
       <textarea name="room_description"  style="resize:none;height:300px;width:40%;float:left"></textarea>
    </div>
  </div>


   
  </br> </br>


<div class="form-group row">
    <label for="colFormLabel" class="col-sm-2 col-form-label">Room Check In</label>
    <div class="col-sm-4">
      <input type="date" class="form-control" id="colFormLabel" name="room_check_in" >
    </div>
  </div> 


    <div class="form-group row">
    <label for="colFormLabel" class="col-sm-2 col-form-label">Room Check Out</label>
    <div class="col-sm-4">
      <input type="date" class="form-control" id="colFormLabel" name="room_check_out">
    </div>
  </div>

 

    <div class="form-group row">
    <label for="colFormLabel" class="col-sm-2 col-form-label">Room Email</label>
    <div class="col-sm-10">
      <input type="text" class="form-control" id="colFormLabel" name="room_email">
    </div>
  </div>


    <div class="form-group row">
    <label for="colFormLabel" class="col-sm-2 col-form-label">Room Phone No</label>
    <div class="col-sm-10">
      <input type="text" class="form-control" id="colFormLabel" name="room_phone_no">
    </div>
  </div>


   <div class="form-group row">
    <label for="colFormLabel" class="col-sm-2 col-form-label">Room Price</label>
    <div class="col-sm-10">
      <input type="text" class="form-control" id="colFormLabel" name="room_price">
    </div>
  </div> 


   <div class="form-group row">
    <label for="colFormLabel" class="col-sm-2 col-form-label">Room Total</label>
    <div class="col-sm-10">
      <input type="text" class="form-control" id="colFormLabel" name="total_room">
    </div>
  </div> 
  


   <div class="form-group row">
    <label for="colFormLabel" class="col-sm-2 col-form-label">Room Services</label>
    <div class="col-sm-10">
   <?php 

  
                                                    $wp_post_db = "hotel_offers";
                                                    $show_vendor_posts = $wpdb->get_results("SELECT * FROM $wp_post_db ORDER BY id DESC"); 
                                                    $i=0;
                                                    foreach( $show_vendor_posts as $show_vendor_post) 
                                                    {  
                                                     ?> 
                                                   
                                                        <label for="choice_<?php echo $show_vendor_post->ID; ?>">
                                                        <input  name="service_name_ids[]" id="choice_<?php echo $show_vendor_post->id; ?>" type="checkbox" value="<?php echo $show_vendor_post->id; ?>" <?php if($i==0){ ?> checked="checked" <?php } ?> tabindex="28">
                                                            <?php echo $show_vendor_post->service_name; ?>
                                                          </label>
                                                       

                     <?php $i++; } ?>
       
    </div>
  </div> 





  
 <div class="form-group row">
    <label for="colFormLabel" class="col-sm-2 col-form-label">Hotel Gallery</label>
    <div class="col-sm-10">
 
<input type="file"  name="files[]" multiple="multiple" accept="image/*" /> 
</div>
</div>

  <div class="form-group row"> 
    <div class="col-sm-10">
     <input type="hidden" name="service_type" value="rooms">
      <input type="submit" id="submit-all" class="btn-primary"   name="add_Rooms_submit_btn">
    </div>
  </div> 

</form>

</div>





<?php include('footer.php'); ?>
 




  <h1>List of Rooms</h1>
  <table class="table table-striped table-bordered table-hover" id="dataTables-example">
      <thead>
          <tr>   
               <th>Room ID</th>
               <th>Room Image</th>
                <th>Room Title</th>
               <th>Room Description</th>
               <th>Room Price</th>  
               <th>Added Date</th>
                <th>Action</th>
             </tr>
      </thead>
      <tbody>

      <?php  

      $service_type = 'rooms';                         
      //echo "SELECT * FROM $wp_post_db WHERE id='11' AND service_type='rooms' ORDER BY id DESC";                    
      $wp_post_db = "available_rooms";
      
      $show_vendor_posts = $wpdb->get_results("SELECT * FROM $wp_post_db ORDER BY id DESC"); 
      $i=0;
      foreach( $show_vendor_posts as $show_vendor_post) 
      {  
         $rid =  $show_vendor_post->id;   
         $room_id =  $show_vendor_post->room_title;   
         $room_title =  $show_vendor_post->room_title;  
         $room_description =  $show_vendor_post->room_description;    
         $room_price =  $show_vendor_post->room_price;    
         $date_added =  $show_vendor_post->date_added;                                                               
      ?>     

        <tr class="odd gradeA">    
                      
                      <td><?php echo $rid;?></td>
                      <th> <img src="<?php echo getImageSrcById($rid, $service_type); ?>" width="60" height="60"></th>
                      <td><?php echo $room_title;?></td>
                      <td><?php echo substr($room_description, '0', '20');?></td>
                      <td><?php echo $room_price;?></td>  
                      <td><?php echo $date_added; ?></td>
                       <td class="center"> <a class="btn btn-danger" href="?page=add_rooms&id=<?php echo $rid;?>&delete=rooms&page=add_rooms">Delete</a></td> 
                     </tr>
         <?php } ?>

         
      </tbody>
      <tr>   
               <th>Room ID</th>
                <th>Room Image</th>
                <th>Room Title</th>
               <th>Room Description</th>
               <th>Room Price</th> 
               <th>Added Date</th>
                <th>Action</th>
       </tr>
  </table>