 <?php
/*
  Template Name: Car Search Templates
*/
get_header(); 

require_once('functions/car_functions.php'); 
?>

 

    <div class="search-area has-border has-map">
        <div class="container-full">
            <div class="map-half">
                <iframe src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d387193.30594184523!2d-74.25986594809962!3d40.69714941820045!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x89c24fa5d33f083b%3A0xc80b8f06e177fe62!2sNew+York%2C+NY%2C+USA!5e0!3m2!1sen!2sbd!4v1540485618034"  frameborder="0" style="border:0" allowfullscreen></iframe>
            </div>
            <div class="scroll-content">

                <form class="searcg-form u-padding-t-20" id="formData_id">
                    <h1 class="title">Search for Cheap Rental Cars</h1>

                    <div class="tf-row row">
                        
                                <div class="tf-col col-12 col-sm-12 form-group">
                                    <label for="desti">Pick Up Location</label>
                                    <div class="map">
                                        <label for="desti"><i class="fa fa-map-marker"></i></label>
                                        <!-- <input id="desti" type="text" name="car_location" class="form-control" placeholder="City or Destination"> -->

                                         <select class="form-control" name="car_location">
                                       <option value="All">All</option>
                                        <?php  
                                         
                                            $wp_post_db = "car_details";
                                            $show_vendor_posts = $wpdb->get_results("SELECT * FROM $wp_post_db ORDER BY id DESC"); 
                                            $i=0;
                                            foreach( $show_vendor_posts as $show_vendor_post) 
                                            {                                     
                                            ?> 
  
                                          <option value="<?php echo $show_vendor_post->car_location; ?>"><?php echo $show_vendor_post->car_location; ?></option>

                                          <?php 
                                          } ?>
 
                                </select>

                                
                                    </div>
                                </div>




                             

                                <div class="tf-col  col-lg-12">
                                    <label>Car Packages </label>
                                     <select class="form-control" name="package_id">
                                       <option value="All">All</option>
                                        <?php  
                                         
                                            $wp_post_db = "car_packages";
                                            $show_vendor_posts = $wpdb->get_results("SELECT * FROM $wp_post_db ORDER BY id DESC"); 
                                            $i=0;
                                            foreach( $show_vendor_posts as $show_vendor_post) 
                                            {                                     
                                            ?> 
  
                                          <option value="<?php echo $show_vendor_post->id; ?>"><?php echo $show_vendor_post->package_name; ?></option>

                                          <?php 
                                          } ?>
 
                                </select>
                                </div>
                                

                                <div class="col-12 col-lg-12">
                                    <div class="btn-area">
                                        <button class="btn btn-primary btn-md" type="submit">Search for Car</button>
                                    </div>
                                </div>

                            </div>
                </form>




                <div class="content-search u-padding-t-30 ajax_result">

                  <?php     
                      $service_type = 'cars';  


                      $wp_post_db = "car_details";  
                      if($_GET['car_title'] == 'All'){
                         $show_vendor_posts = $wpdb->get_results("SELECT * FROM $wp_post_db ORDER BY id DESC"); 
                        
                      }else{
                      $show_vendor_posts = $wpdb->get_results("SELECT * FROM $wp_post_db WHERE car_location LIKE '%$car_location%' OR package_id ='$package_id' ORDER BY id DESC"); 
                      }
                      $num_rows = $wpdb->num_rows;
                      ?>

                    <div class="sec-ti u-padding-b-20">
                        <h3 class="font-weight300">Advanced Search (<?php echo $num_rows; ?>)</h3>
                    </div>
                    <div class="row">

                     <?php   
                      if($num_rows  > 0){   
                      $i=0;
                      foreach( $show_vendor_posts as $show_vendor_post)  
                      {   
                      //print_r($show_vendor_post);
                       $cid =  $show_vendor_post->id; 
                      $car_title =  $show_vendor_post->car_title; 
                      $car_description =  $show_vendor_post->car_description;    
                      $car_price =  $show_vendor_post->car_price;                                                
                      ?>   



                        <div class="col-12 col-sm-6">
                            <div class="car-item-g">
                                <a href="<?php echo site_url().'/car-details/?car_id='.$cid;?>" class="fig">
                                    <img src="<?php echo getImageSrcById($cid, $service_type); ?>">
                                    <span class="reb">50%</span>
                                </a>
                                       
                                <div class="content">
                                    <h5><a href="<?php echo site_url().'/car-details/?car_id='.$cid;?>"><?php echo $car_title; ?></a></h5>
                                    <div class="sub">Premium ,Standard</div>
                                    <ul class="ico-set">
                                        <li>
                                            <i class="fa fa-briefcase"></i>
                                            <span>x3</span>
                                        </li>
                                        <li>
                                            <i class="fa fa-male"></i>
                                            <span>Auto</span>
                                        </li>
                                        <li>
                                            <i class="fa fa-briefcase"></i>
                                            <span>x3</span>
                                        </li>
                                        <li>
                                            <i class="fa fa-briefcase"></i>
                                            <span>x4</span>
                                        </li>
                                        <li>
                                            <i class="fa fa-briefcase"></i>
                                            <span>x3</span>
                                        </li>
                                    </ul>
                                </div>

                                <div class="price">
                                    <span class="old">$70,00</span>
                                    <i class="fa fa-long-arrow-right"></i>
                                    <span class="current">$<?php echo $car_price; ?> /day</span>
                                </div>
                            </div>
                        </div><!-- car item col --> 

                        <?php } }else{ ?>

                        <h4>No data found.</h4>

                      <?php } ?>
                        
                    </div>
                </div>




            </div>
        </div>
    </div>



<?php get_footer();?>



<script>
 jQuery('.datepicker').datepicker();
</script>   


    <script type="text/javascript">       

    
    jQuery("form#formData_id").submit(function(e) { 
          
           e.preventDefault();
           var formData = new FormData(jQuery(this)[0]);         
           var tem_url = "<?php echo get_template_directory_uri(); ?>";
           var user_id = "<?php echo get_current_user_id(); ?>";  
           var tem_uri = tem_url+'/ajax/car_search_ajax.php';
            //alert(tem_uri); 

            jQuery.ajax({
            url: tem_uri,
            type: "POST",
            data: formData,
            contentType: false,       
            cache: false,              
            processData:false,  
            success: function(response) { 
                //alert(response);  
                jQuery('.ajax_result').html(response); 
            }

          });


          setTimeout(function(){
                jQuery('#myModal').modal('toggle');
             }, 800);

         });
    </script>