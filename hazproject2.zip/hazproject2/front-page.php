<?php
/**
 * The main template file
 *
 * This is the most generic template file in a WordPress theme
 * and one of the two required files for a theme (the other being style.css).
 * It is used to display a page when nothing more specific matches a query.
 * E.g., it puts together the home page when no home.php file exists.
 *
 * @link https://developer.wordpress.org/themes/basics/template-hierarchy/
 *
 * @package aynix
 */

get_header();
 




 ?> 

        <!-- mobile-menu-area start -->
        <div class="mobile-menu-area">
          <div class="container">
            <div class="row">
              <div class="col-md-12">
                <div class="mobile-menu">
                  <nav id="dropdown">
                    <ul>
                        <li class="active"><a href="#">Home</a>
                            <ul>
                                <li><a href="#">Sub Item</a></li>
                                <li><a href="#">Sub Item</a></li>
                                <li><a href="#">Sub Item</a></li>
                                <li><a href="#">Sub Item</a></li>
                                <li><a href="#">Sub Item</a></li>
                                <li><a href="#">Sub Item</a></li>
                                <li><a href="#">Sub Item</a></li>
                            </ul>
                        </li>
                        <li><a href="#">Projects</a></li>
                        <li><a href="#">Activities</a></li>
                        <li><a href="#">Total Jobs</a></li>
                        <li><a href="#">Flights</a></li>
                        <li><a href="#">Hotels</a></li>
                    </ul>
                  </nav>
                </div>
              </div>
            </div>
          </div>
        </div>
        <!-- mobile-menu-area end -->


<div class="image-grid">
    <div class="tab-area">
        <div class="container">
            <div class="tab-inner">
                <h1 class="top-title">Find Your Perfect Umrah Package</h1>

                <ul class="nav nav-tabs" role="tablist">
                   
                    <li class="nav-item">
                        <a class="nav-link active" data-toggle="tab" href="#tabs-2" role="tab">
                        <span><i class="fa fa-paper-plane"></i></span>Cars</a>
                    </li>

                    <li class="nav-item">
                        <a class="nav-link" data-toggle="tab" href="#tabs-3" role="tab">
                        <span><i class="fa fa-paper-plane"></i></span>Tours</a>
                    </li>

                    <li class="nav-item">
                        <a class="nav-link" data-toggle="tab" href="#tabs-4" role="tab">
                        <span><i class="fa fa-paper-plane"></i></span>Hotel</a>
                    </li>

                   
                    <li class="nav-item">
                        <a class="nav-link" data-toggle="tab" href="#tabs-5" role="tab">
                        <span><i class="fa fa-paper-plane"></i></span>Flight</a>
                    </li>

                      <li class="nav-item">
                        <a class="nav-link" data-toggle="tab" href="#tabs-6" role="tab">
                        <span><i class="fa fa-paper-plane"></i></span>Activity</a>
                    </li>


                     <li class="nav-item">
                        <a class="nav-link" data-toggle="tab" href="#tabs-7" role="tab">
                        <span><i class="fa fa-paper-plane"></i></span>Guide</a>
                    </li>

                       <li class="nav-item">
                        <a class="nav-link" data-toggle="tab" href="#tabs-1" role="tab"><span><i class="fa fa-paper-plane"></i></span>Umrah</a>
                    </li>



                      <li class="nav-item">
                        <a class="nav-link" data-toggle="tab" href="#tabs-8" role="tab">
                        <span><i class="fa fa-paper-plane"></i></span>Transport</a>
                    </li>


                     <li class="nav-item">
                        <a class="nav-link" data-toggle="tab" href="#tabs-9" role="tab">
                        <span><i class="fa fa-paper-plane"></i></span>Restaurant</a>
                    </li>

                  
                    

                </ul><!-- Tab panes -->


                <?php


                if($_POST['umrah_submit']){

                  if(isset($_POST['Noofdays'])){
                   $Noofdays = $_POST['Noofdays'];   
                   }

                  if(isset($_POST['Packageclass'])){
                   $Packageclass = $_POST['Packageclass']; 
                   } 
                   if(isset($_POST['Packagecity'])){
                     $Packagecity = $_POST['Packagecity']; 
                   } 
               
                  if(isset($_POST['Pricerange'])){
                     $Pricerange = $_POST['Pricerange']; 
                   } 


                  $location =  site_url().'/umrah-result/?Noofdays='.$Noofdays.'&Packageclass='.$Packageclass.'&Packagecity='.$Packagecity.'&Pricerange='.$Pricerange;  
                  echo '<script type="text/javascript">window.location.href = "'.$location.'"</script>';


              }






                ?>


     

                <div class="tab-content">
                    <div class="tab-pane" id="tabs-1" role="tabpanel">
                    <form method="POST">
                            <h2 class="title">Search Umrah Packages</h2>
                             <div class="tf-row row">
                                

                                <div class="tf-col col-lg-2">
                                <label for="desti">No of Days</label>
                                <div class="map mb-2">
                                    <select class="form-control" name="Noofdays">
                                        <option>Select Days</option>
                                         <?php
                                        $Noofdays = get_terms([
                                        'taxonomy' => 'no_of_days',
                                        'hide_empty' => false,
                                        ]);

                                       foreach($Noofdays as $no_of_days_rows){  

                                        ?>
                                          <option value="<?php echo $no_of_days_rows->slug; ?>"><?php echo $no_of_days_rows->name; ?></option>
                                      <?php } ?>
                                                                    </select>
                                </div>
                            </div> 


                            <div class="tf-col col-lg-2">
                                <label for="desti">package Class</label>
                                <div class="map mb-2">
                                    <select class="form-control" name="Packageclass">
                                        <option value="All">ALL</option>
                                         <?php
                                        $Packageclass = get_terms([
                                        'taxonomy' => 'package_class',
                                        'hide_empty' => false,
                                        ]);

                                       foreach($Packageclass as $package_class_rows){  

                                        ?>
                                          <option value="<?php echo $package_class_rows->slug; ?>"><?php echo $package_class_rows->name; ?></option>
                                      <?php } ?>
                                       </select>
                                </div>
                            </div> 


                            <div class="tf-col col-lg-3">
                                <label for="desti">Package City</label>
                                <div class="map mb-2">
                                    <select class="form-control" name="Packagecity">
                                         <option>ALL</option>
                                          <?php
                                        $Packagecity = get_terms([
                                        'taxonomy' => 'package_city',
                                        'hide_empty' => false,
                                        ]);

                                       foreach($Packagecity as $package_city_rows){  

                                        ?>
                                          <option value="<?php echo $package_city_rows->slug; ?>"><?php echo $package_city_rows->name; ?></option>
                                      <?php } ?>
                                                                    </select>
                                </div>
                            </div>
                                    

                                   
 


                                  <div class="tf-col col-lg-3">
                                <label for="desti">Price Range</label>
                                <div class="map mb-2">
                                    <select class="form-control" name="Pricerange">
                                        <option>ALL</option>
                                                           <?php
                                        $Pricerange = get_terms([
                                        'taxonomy' => 'price_range',
                                        'hide_empty' => false,
                                        ]);

                                       foreach($Pricerange as $price_range_rows){  

                                        ?>
                                          <option value="<?php echo $price_range_rows->slug; ?>"><?php echo $price_range_rows->name; ?></option>
                                      <?php } ?>
                                     </select>
                                </div>
                            </div>

 
                             </div>   

  <input class="btn btn-primary btn-md" name="umrah_submit" type="submit" value="Search">
                        </form>
                    </div>



                    <div class="tab-pane active" id="tabs-2" role="tabpanel">
                    <?php  
                    
                    
                        if($_POST['car_submit']){

                            if(isset($_POST['car_location'])){
                             $car_location = $_POST['car_location'];   
                             }

                            if(isset($_POST['car_title'])){
                             $car_title = $_POST['car_title']; 
                             } 

                             if(isset($_POST['package_id'])){
                             $package_id = $_POST['package_id']; 
                             }  

                            $location =  site_url().'/car-result/?car_location='.$car_location.'&car_title='.$car_title.'&package_id='.$package_id;  
                            echo '<script type="text/javascript">window.location.href = "'.$location.'"</script>'; 

                        } 
                    ?>
                        <form  method="post">
                            <h2 class="title">Search Cars</h2>
                            <div class="tf-row row">
                                <div class="tf-col col-lg-4">
                                    <label for="desti">Pick Up Location</label>
                                    <div class="map mb-2">
                                    <!--  <input type="text" name="car_location" class="form-control"> -->

                                      <select class="form-control" name="car_location">
                                       <option value="All">All</option>
                                        <?php  
                                         
                                            $wp_post_db = "car_details";
                                            $show_vendor_posts = $wpdb->get_results("SELECT * FROM $wp_post_db ORDER BY id DESC"); 
                                            $i=0;
                                            foreach( $show_vendor_posts as $show_vendor_post) 
                                            {                                     
                                            ?> 
  
                                          <option value="<?php echo $show_vendor_post->car_location; ?>"><?php echo $show_vendor_post->car_location; ?></option>

                                          <?php 
                                          } ?>
 
                                </select>


                                    </div>
                                </div>
        
    
                                
                                <div class="tf-col tf-slect col-lg-4">
                                    <label>Cars Name</label>
                                    <select class="form-control" name="car_title">
                                       <option>All</option>
                                        <?php  
                                         
                                            $wp_post_db = "car_details";
                                            $show_vendor_posts = $wpdb->get_results("SELECT * FROM $wp_post_db ORDER BY id DESC"); 
                                            $i=0;
                                            foreach( $show_vendor_posts as $show_vendor_post) 
                                            {                                     
                                            ?> 
  
                                          <option value="<?php echo $show_vendor_post->car_title; ?>"><?php echo $show_vendor_post->car_title; ?></option>

                                          <?php 
                                          } ?>
 
                                </select>
                                </div>

                                    <div class="tf-col tf-slect col-lg-4">
                                    <label>Cars Package</label>
                                     <select class="form-control" name="package_id">
                                      <option>All</option>
                                        <?php  
                                         
                                            $wp_post_db = "car_packages";
                                            $show_vendor_posts = $wpdb->get_results("SELECT * FROM $wp_post_db ORDER BY id DESC"); 
                                            $i=0;
                                            foreach( $show_vendor_posts as $show_vendor_post) 
                                            {                                     
                                            ?> 
  
                                          <option value="<?php echo $show_vendor_post->id; ?>"><?php echo $show_vendor_post->package_name; ?></option>

                                          <?php 
                                          } ?>
 
                                </select>
                                </div>

              

 
                                <div class="col-lg-12">
                                    <div class="btn-area">
                                     <input class="btn btn-primary btn-md" name="car_submit" type="submit" value="Search">
                                    </div>
                                </div>

                            </div>
                        </form>
                    </div>

                    <?php  
                    
                    
                        if($_POST['tour_submit']){

                            if(isset($_POST['tour_location'])){
                             $tour_location = $_POST['tour_location'];   
                             }
                             if(isset($_POST['category_id'])){
                             $category_id = $_POST['category_id']; 
                             }  

                            $location =  site_url().'/tour-result/?tour_location='.$tour_location.'&category_id='.$category_id;  
                            echo '<script type="text/javascript">window.location.href = "'.$location.'"</script>'; 

                        } 
                    ?>

                    


                    <div class="tab-pane" id="tabs-3" role="tabpanel">
                        <form  method="post">
                            <h2 class="title">Tours</h2>
                            <div class="tf-row row">
                                <div class="tf-col col-lg-4">
                                    <label for="desti">Tour Location</label>
                                        <div class="map mb-2"> 
                                        <!--  <input type="text" name="tour_location" class="form-control"> -->
                                        <select class="form-control" name="tour_location">
                                       <option value="All">All</option>
                                        <?php  
                                         
                                            $wp_post_db = "tour_details";
                                            $show_vendor_posts = $wpdb->get_results("SELECT * FROM $wp_post_db ORDER BY id DESC"); 
                                            $i=0;
                                            foreach( $show_vendor_posts as $show_vendor_post) 
                                            {                                     
                                            ?> 
  
                                          <option value="<?php echo $show_vendor_post->tour_location; ?>"><?php echo $show_vendor_post->tour_location; ?></option>

                                          <?php 
                                          } ?>
 
                                </select>
                                        </div>
                                </div>
        
    
                                
                                <div class="tf-col tf-slect col-lg-4">
                                    <label>Tour Category</label>
                                    <select class="form-control" name="category_id">
                                    <option>All</option>
                                        <?php  
                                         
                                            $wp_post_db = "tour_categories";
                                            $show_vendor_posts = $wpdb->get_results("SELECT * FROM $wp_post_db ORDER BY id DESC"); 
                                            $i=0;
                                            foreach( $show_vendor_posts as $show_vendor_post) 
                                            {                                     
                                            ?> 
  
                                          <option value="<?php echo $show_vendor_post->id; ?>"><?php echo $show_vendor_post->category_name; ?></option>

                                          <?php 
                                          } ?>
 
                                </select>
                                </div> 
 

                                   <div class="col-lg-12">
                                    <div class="btn-area">
                                     <input class="btn btn-primary btn-md" name="tour_submit" type="submit" value="Search">
                                    </div>
                                </div>

                            </div>
                        </form>
                    </div>
                
                     <?php 


                    if($_POST['hotelsubmit']){

                        if(isset($_POST['Hotellocation'])){
                         $Hotellocation = $_POST['Hotellocation'];   
                         }

                        if(isset($_POST['check_in'])){
                         $check_in = $_POST['check_in']; 
                          $check_in = date("Y-m-d", strtotime($check_in)); 
                         } 

                        if(isset($_POST['check_out'])){
                         $check_out = $_POST['check_out']; 

                          $check_out = date("Y-m-d", strtotime($check_out)); 



                         } 
                        
                        $hotellocationmain =  site_url().'/main-hotel-search//?Hotellocation='.$Hotellocation.'&check_in='.$check_in.'&check_out='.$check_out;  
                        echo '<script type="text/javascript">window.location.href = "'.$hotellocationmain.'"</script>';


                    }



                    ?>


                       <div class="tab-pane" id="tabs-4" role="tabpanel">
                        <form  method="post">
                            <h2 class="title">Hotel</h2>
                            <div class="tf-row row">
                                <div class="tf-col col-lg-4">
                                    <label for="desti">Hotel location</label>
                                        <div class="map mb-2">
                                   
                                        <select class="form-control" name="Hotellocation" required>
                                        <option>All</option>
                                         <?php  
                                         
                                            $wp_post_db = "hotel_details";
                                            $show_vendor_posts = $wpdb->get_results("SELECT * FROM $wp_post_db ORDER BY id DESC"); 
                                            $i=0;
                                            foreach( $show_vendor_posts as $show_vendor_post) 
                                            {  

                                            $img_url =  $show_vendor_post->img_url;                                              
                                            ?> 
  
                                          <option value="<?php echo $show_vendor_post->hotel_location; ?>"><?php echo $show_vendor_post->hotel_location; ?></option>

                                          <?php 
                                          } ?>
 
                                     
                                        </select>
                                        </div>
                                </div>
        
    
                                
                                <div class="tf-col tf-slect col-lg-4">
                                    <label>Check In </label>
                                     <input type="text" class="datepicker form-control" name="check_in" placeholder="dd/mm/yy">
                                </div>



                                <div class="tf-col tf-slect col-lg-4">
                                    <label>Check Out</label>
                                    <input type="text" class="datepicker form-control" name="check_out" placeholder="dd/mm/yy">
                                </div>

                                   <div class="col-lg-12">
                                    <div class="btn-area">
                                     <input class="btn btn-primary btn-md" name="hotelsubmit" type="submit" value="Search">
                                    </div>
                                </div>

                            </div>
                        </form>
                    </div>


                       <?php 


                    if($_POST['flightsubmit']){

                        if(isset($_POST['Locationform'])){
                         $locationform = $_POST['Locationform'];   
                         }

                        if(isset($_POST['Locationto'])){
                         $locationto = $_POST['Locationto']; 
                         } 

                        if(isset($_POST['Departuredate'])){
                         $departuredate = $_POST['Departuredate']; 
                         } 

                        if(isset($_POST['Passenger'])){
                         $passenger = $_POST['Passenger']; 
                         } 
                        
                        $flightlocationmain =  site_url().'/flight-search/?Locationform='.$locationform.'&Locationto='.$locationto.'&Departuredate='.$departuredate.'&Passenger='.$passenger;  
                        echo '<script type="text/javascript">window.location.href = "'.$flightlocationmain.'"</script>';


                    }



                    ?>


                    <div class="tab-pane" id="tabs-5" role="tabpanel">
                          <form method="post">
                            <h2 class="title">Search For Flights</h2>
                            <div class="flight-tab">
                      

                                <!-- Tab panes -->
                                <div class="tab-content">
                                  <div role="tabpanel" class="tab-pane fade in active show" id="flight-tab1">
                                      <form>
                            <div class="tf-row row">

                                
                                <div class="tf-col col-lg-3">
                                    <label for="desti">From</label>
                                      <select class="form-control" name="Locationform" required>
                                        <option><i class="fa fa-map-marker"></i>All</option>
                                           <?php
                                        $locationform = get_terms([
                                        'taxonomy' => 'locationform',
                                        'hide_empty' => false,
                                        ]);

                                       foreach($locationform as $package_city_rows){  

                                        ?>
                                          <option value="<?php echo $package_city_rows->slug; ?>"><?php echo $package_city_rows->name; ?></option>
                                      <?php } ?>
                                </select>
                                </div>


                                <div class="tf-col col-lg-3">
                                    <label for="desti">To</label>
                                      <select class="form-control" name="Locationto" required>
                                        <option><i class="fa fa-map-marker"></i>All</option>
                                           <?php
                                        $locationto = get_terms([
                                        'taxonomy' => 'locationto',
                                        'hide_empty' => false,
                                        ]);

                                       foreach($locationto as $package_city_rows){  

                                        ?>
                                          <option value="<?php echo $package_city_rows->slug; ?>"><?php echo $package_city_rows->name; ?></option>
                                      <?php } ?>
                                </select>
                                </div>



                                <div class="tf-col col-lg-2">
                                    <label>Date</label>
                                     <select class="form-control" name="Departuredate">
                                        <option><i class="fa fa-map-marker"></i>All</option>
                                           <?php
                                        $departuredate = get_terms([
                                        'taxonomy' => 'departuredate',
                                        'hide_empty' => false,
                                        ]);

                                       foreach($departuredate as $package_city_rows){  

                                        ?>
                                          <option value="<?php echo $package_city_rows->slug; ?>"><?php echo $package_city_rows->name; ?></option>
                                      <?php } ?>
                                </select>
                                    
                                </div>
                                <div class="tf-col col-lg-2">
                                    <label>Passenger</label>
                                      <select class="form-control" name="Passenger">
                                        <option><i class="fa fa-map-marker"></i>All</option>
                                           <?php
                                        $passenger = get_terms([
                                        'taxonomy' => 'passenger',
                                        'hide_empty' => false,
                                        ]);

                                       foreach($passenger as $package_city_rows){  

                                        ?>
                                          <option value="<?php echo $package_city_rows->slug; ?>"><?php echo $package_city_rows->name; ?></option>
                                      <?php } ?>
                                </select>
                                    
                                </div> 


                                
                                <div class="col-lg-2">
                                    <div class="btn-area">
                                        <input class="btn btn-primary btn-md" name="flightsubmit" type="submit" value="Search">
                                        
                                    </div>
                                </div>

                            </div> 
                                  </div>
                                </div>
                            </div>
                        </form>


                    </div>



                        <?php   
                    
                        if($_POST['activity_submit']){

                            if(isset($_POST['activity_location'])){
                             $activity_location = $_POST['activity_location'];   
                             }
                             if(isset($_POST['category_id'])){
                             $category_id = $_POST['category_id']; 
                             }  

                            $location =  site_url().'/activity-result/?activity_location='.$activity_location.'&category_id='.$category_id;  
                            echo '<script type="text/javascript">window.location.href = "'.$location.'"</script>'; 

                        } 
                        ?>

                    


                    <div class="tab-pane" id="tabs-6" role="tabpanel">
                        <form  method="post">
                            <h2 class="title">Activity</h2>
                               <div class="tf-row row">
                                <div class="tf-col col-lg-4">
                                    <label for="desti">Activity Location</label>
                                        <div class="map mb-2"> 
                                         <!-- <input type="text" name="activity_location" class="form-control"> -->
                                         <select class="form-control" name="activity_location">
                                       <option value="All">All</option>
                                        <?php  
                                         
                                            $wp_post_db = "activity_details";
                                            $show_vendor_posts = $wpdb->get_results("SELECT * FROM $wp_post_db ORDER BY id DESC"); 
                                            $i=0;
                                            foreach( $show_vendor_posts as $show_vendor_post) 
                                            {                                     
                                            ?> 
  
                                          <option value="<?php echo $show_vendor_post->activity_location; ?>"><?php echo $show_vendor_post->activity_location; ?></option>

                                          <?php 
                                          } ?>
 
                                </select>
                                        </div>
                                </div>
         
                                
                                <div class="tf-col tf-slect col-lg-4">
                                    <label>Activity Category</label>
                                    <select class="form-control" name="category_id">
                                    <option>All</option>
                                        <?php  

                                         
                                            $wp_post_db = "activity_categories";
                                            $show_vendor_posts = $wpdb->get_results("SELECT * FROM $wp_post_db ORDER BY id DESC"); 
                                            $i=0;
                                            foreach( $show_vendor_posts as $show_vendor_post) 
                                            {                                     
                                            ?> 
  
                                          <option value="<?php echo $show_vendor_post->id; ?>"><?php echo $show_vendor_post->category_name; ?></option>

                                          <?php 
                                          } ?>
 
                                </select>
                                </div> 
 

                                   <div class="col-lg-12">
                                    <div class="btn-area">
                                     <input class="btn btn-primary btn-md" name="activity_submit" type="submit" value="Search">
                                    </div>
                                </div>

                            </div>
                        </form>
                    </div><!--tabs-6- close-->


                     <?php   
                    
                        if($_POST['guide_submit']){

                            if(isset($_POST['guide_location'])){
                             $guide_location = $_POST['guide_location'];   
                             }
                             if(isset($_POST['category_id'])){
                             $category_id = $_POST['category_id']; 
                             }  

                            $location =  site_url().'/guide-result/?guide_location='.$guide_location.'&category_id='.$category_id;  
                            echo '<script type="text/javascript">window.location.href = "'.$location.'"</script>'; 

                        } 
                        ?>

                    


                    <div class="tab-pane" id="tabs-7" role="tabpanel">
                        <form  method="post">
                            <h2 class="title">Guide</h2>
                               <div class="tf-row row">
                                <div class="tf-col col-lg-4">
                                    <label for="desti">Guide Location</label>
                                        <div class="map mb-2"> 
                                        <!--  <input type="text" name="guide_location" class="form-control"> -->

                                          <select class="form-control" name="guide_location">
                                       <option value="All">All</option>
                                        <?php  
                                         
                                            $wp_post_db = "guide_details";
                                            $show_vendor_posts = $wpdb->get_results("SELECT * FROM $wp_post_db ORDER BY id DESC"); 
                                            $i=0;
                                            foreach( $show_vendor_posts as $show_vendor_post) 
                                            {                                     
                                            ?> 
  
                                          <option value="<?php echo $show_vendor_post->guide_location; ?>"><?php echo $show_vendor_post->guide_location; ?></option>

                                          <?php 
                                          } ?>
 
                                </select>

                                        </div>
                                </div>
         
                                
                                <div class="tf-col tf-slect col-lg-4">
                                    <label>Guide Category</label>
                                    <select class="form-control" name="category_id">
                                    <option>All</option>
                                        <?php  
                                         
                                            $wp_post_db = "guide_categories";
                                            $show_vendor_posts = $wpdb->get_results("SELECT * FROM $wp_post_db ORDER BY id DESC"); 
                                            $i=0;
                                            foreach( $show_vendor_posts as $show_vendor_post) 
                                            {                                     
                                            ?> 
  
                                          <option value="<?php echo $show_vendor_post->id; ?>"><?php echo $show_vendor_post->category_name; ?></option>

                                          <?php 
                                          } ?>
 
                                </select>
                                </div> 
 

                                   <div class="col-lg-12">
                                    <div class="btn-area">
                                     <input class="btn btn-primary btn-md" name="guide_submit" type="submit" value="Search">
                                    </div>
                                </div>

                            </div>
                        </form>
                    </div><!--tabs-8- close-->


                       <?php   
                    
                        if($_POST['transport_submit']){

                            if(isset($_POST['transport_location'])){
                              $transport_location = $_POST['transport_location'];   
                             }
                            if(isset($_POST['transport_time'])){
                              $transport_time = $_POST['transport_time']; 
                              $part = explode(' ', $transport_time); 
                             }  
 
                            $location =  site_url().'/transport-result/?transport_location='.$transport_location.'&transport_time='.$part[0].'&transport_am_pm='.$part[1];  
                           echo '<script type="text/javascript">window.location.href = "'.$location.'"</script>'; 

                        } 
                        ?>

                    


                    <div class="tab-pane" id="tabs-8" role="tabpanel">
                        <form  method="post">
                            <h2 class="title">transport</h2>
                               <div class="tf-row row">
                                <div class="tf-col col-lg-4">
                                    <label for="desti">transport Location</label>
                                        <div class="map mb-2"> 
                                        <!--  <input type="text" name="transport_location" class="form-control"> -->


                                         <select class="form-control" name="transport_location">
                                       <option value="All">All</option>
                                        <?php  
                                         
                                            $wp_post_db = "transport_details";
                                            $show_vendor_posts = $wpdb->get_results("SELECT * FROM $wp_post_db ORDER BY id DESC"); 
                                            $i=0;
                                            foreach( $show_vendor_posts as $show_vendor_post) 
                                            {                                     
                                            ?> 
  
                                          <option value="<?php echo $show_vendor_post->transport_location; ?>"><?php echo $show_vendor_post->transport_location; ?></option>

                                          <?php 
                                          } ?>
 
                                </select>


                                        </div>
                                </div>
         
                                
                                <div class="tf-col tf-slect col-lg-4">
                                    <label>transport Time</label>
                                    <input type="text" name="transport_time"  class="timepicker form-control" >
                                </div> 
 

                                   <div class="col-lg-12">
                                    <div class="btn-area">
                                     <input class="btn btn-primary btn-md" name="transport_submit" type="submit" value="Search">
                                    </div>
                                </div>

                            </div>
                        </form>
                    </div><!--tabs-8- close-->


                      <?php   
                    
                        if($_POST['restaurant_submit']){

                            if(isset($_POST['restaurant_location'])){

                              $restaurant_location = $_POST['restaurant_location'];   
                             }
                             
                            $location =  site_url().'/restaurant-result/?restaurant_location='.$restaurant_location;  
                           echo '<script type="text/javascript">window.location.href = "'.$location.'"</script>'; 

                        } 
                        ?>

                    


                    <div class="tab-pane" id="tabs-9" role="tabpanel">
                        <form  method="post">
                            <h2 class="title">restaurant</h2>
                               <div class="tf-row row">
                                <div class="tf-col col-lg-4">
                                    <label for="desti">restaurant Location</label>
                                        <div class="map mb-2"> 
                                         <!-- <input type="text" name="restaurant_location" class="form-control"> -->

                                          <select class="form-control" name="restaurant_location">
                                             <option value="All">All</option>
                                            <?php  
                                             
                                                $wp_post_db = "restaurant_details";
                                                $show_vendor_posts = $wpdb->get_results("SELECT * FROM $wp_post_db ORDER BY id DESC"); 
                                                $i=0;
                                                foreach( $show_vendor_posts as $show_vendor_post) 
                                                {                                     
                                                ?> 
      
                                              <option value="<?php echo $show_vendor_post->restaurant_location; ?>"><?php echo $show_vendor_post->restaurant_location; ?></option>

                                              <?php 
                                              } ?>
     
                                    </select> 
                                   </div>
                                </div> 
 

                                   <div class="col-lg-12">
                                    <div class="btn-area">
                                     <input class="btn btn-primary btn-md" name="restaurant_submit" type="submit" value="Search">
                                    </div>
                                </div>

                            </div>
                        </form>
                    </div><!--tabs-9- close-->



                </div>

            </div>
        </div>
    </div>
    <div id="rigrid" class="ri-grid ri-grid-size-2 ri-shadow">
        <img class="ri-loading-image" src="<?php echo esc_url(get_template_directory_uri());?>/img/loading.gif" alt=""/>
                    <ul>
                        <li><a href="#"><img src="<?php echo esc_url(get_template_directory_uri());?>/img/1.jpg"/></a></li>
                        <li><a href="#"><img src="<?php echo esc_url(get_template_directory_uri());?>/img/2.jpg"/></a></li>
                        <li><a href="#"><img src="<?php echo esc_url(get_template_directory_uri());?>/img/3.jpg"/></a></li>
                        <li><a href="#"><img src="<?php echo esc_url(get_template_directory_uri());?>/img/4.jpg"/></a></li>
                        <li><a href="#"><img src="<?php echo esc_url(get_template_directory_uri());?>/img/5.jpg"/></a></li>
                        <li><a href="#"><img src="<?php echo esc_url(get_template_directory_uri());?>/img/6.jpg"/></a></li>
                        <li><a href="#"><img src="<?php echo esc_url(get_template_directory_uri());?>/img/7.jpg"/></a></li>
                        <li><a href="#"><img src="<?php echo esc_url(get_template_directory_uri());?>/img/8.jpg"/></a></li>
                        <li><a href="#"><img src="<?php echo esc_url(get_template_directory_uri());?>/img/9.jpg"/></a></li>
                        <li><a href="#"><img src="<?php echo esc_url(get_template_directory_uri());?>/img/10.jpg"/></a></li>
                        <li><a href="#"><img src="<?php echo esc_url(get_template_directory_uri());?>/img/11.jpg"/></a></li>
                        <li><a href="#"><img src="<?php echo esc_url(get_template_directory_uri());?>/img/12.jpg"/></a></li>
                        <li><a href="#"><img src="<?php echo esc_url(get_template_directory_uri());?>/img/13.jpg"/></a></li>
                        <li><a href="#"><img src="<?php echo esc_url(get_template_directory_uri());?>/img/14.jpg"/></a></li>
                        <li><a href="#"><img src="<?php echo esc_url(get_template_directory_uri());?>/img/15.jpg"/></a></li>
                        <li><a href="#"><img src="<?php echo esc_url(get_template_directory_uri());?>/img/16.jpg"/></a></li>
                        <li><a href="#"><img src="<?php echo esc_url(get_template_directory_uri());?>/img/17.jpg"/></a></li>
                        <li><a href="#"><img src="<?php echo esc_url(get_template_directory_uri());?>/img/18.jpg"/></a></li>
                        <li><a href="#"><img src="<?php echo esc_url(get_template_directory_uri());?>/img/19.jpg"/></a></li>
                        <li><a href="#"><img src="<?php echo esc_url(get_template_directory_uri());?>/img/20.jpg"/></a></li>
                        <li><a href="#"><img src="<?php echo esc_url(get_template_directory_uri());?>/img/21.jpg"/></a></li>
                        <li><a href="#"><img src="<?php echo esc_url(get_template_directory_uri());?>/img/22.jpg"/></a></li>
                        <li><a href="#"><img src="<?php echo esc_url(get_template_directory_uri());?>/img/23.jpg"/></a></li>
                        <li><a href="#"><img src="<?php echo esc_url(get_template_directory_uri());?>/img/24.jpg"/></a></li>
                        <li><a href="#"><img src="<?php echo esc_url(get_template_directory_uri());?>/img/25.jpg"/></a></li>
                        <li><a href="#"><img src="<?php echo esc_url(get_template_directory_uri());?>/img/26.jpg"/></a></li>
                        <li><a href="#"><img src="<?php echo esc_url(get_template_directory_uri());?>/img/27.jpg"/></a></li>
                        <li><a href="#"><img src="<?php echo esc_url(get_template_directory_uri());?>/img/28.jpg"/></a></li>
                        <li><a href="#"><img src="<?php echo esc_url(get_template_directory_uri());?>/img/29.jpg"/></a></li>
                        <li><a href="#"><img src="<?php echo esc_url(get_template_directory_uri());?>/img/30.jpg"/></a></li>
                        <li><a href="#"><img src="<?php echo esc_url(get_template_directory_uri());?>/img/31.jpg"/></a></li>
                        <li><a href="#"><img src="<?php echo esc_url(get_template_directory_uri());?>/img/32.jpg"/></a></li>
                        <li><a href="#"><img src="<?php echo esc_url(get_template_directory_uri());?>/img/33.jpg"/></a></li>
                        <li><a href="#"><img src="<?php echo esc_url(get_template_directory_uri());?>/img/34.jpg"/></a></li>
                        <li><a href="#"><img src="<?php echo esc_url(get_template_directory_uri());?>/img/35.jpg"/></a></li>
                        <li><a href="#"><img src="<?php echo esc_url(get_template_directory_uri());?>/img/36.jpg"/></a></li>
                        <li><a href="#"><img src="<?php echo esc_url(get_template_directory_uri());?>/img/37.jpg"/></a></li>
                        <li><a href="#"><img src="<?php echo esc_url(get_template_directory_uri());?>/img/38.jpg"/></a></li>
                        <li><a href="#"><img src="<?php echo esc_url(get_template_directory_uri());?>/img/39.jpg"/></a></li>
                        <li><a href="#"><img src="<?php echo esc_url(get_template_directory_uri());?>/img/40.jpg"/></a></li>
                        <li><a href="#"><img src="<?php echo esc_url(get_template_directory_uri());?>/img/41.jpg"/></a></li>
                        <li><a href="#"><img src="<?php echo esc_url(get_template_directory_uri());?>/img/42.jpg"/></a></li>
                        <li><a href="#"><img src="<?php echo esc_url(get_template_directory_uri());?>/img/43.jpg"/></a></li>
                        <li><a href="#"><img src="<?php echo esc_url(get_template_directory_uri());?>/img/44.jpg"/></a></li>
                        <li><a href="#"><img src="<?php echo esc_url(get_template_directory_uri());?>/img/45.jpg"/></a></li>
                        <li><a href="#"><img src="<?php echo esc_url(get_template_directory_uri());?>/img/46.jpg"/></a></li>
                        <li><a href="#"><img src="<?php echo esc_url(get_template_directory_uri());?>/img/47.jpg"/></a></li>
                        <li><a href="#"><img src="<?php echo esc_url(get_template_directory_uri());?>/img/48.jpg"/></a></li>
                        <li><a href="#"><img src="<?php echo esc_url(get_template_directory_uri());?>/img/49.jpg"/></a></li>
                        <li><a href="#"><img src="<?php echo esc_url(get_template_directory_uri());?>/img/50.jpg"/></a></li>
                        <li><a href="#"><img src="<?php echo esc_url(get_template_directory_uri());?>/img/51.jpg"/></a></li>
                        <li><a href="#"><img src="<?php echo esc_url(get_template_directory_uri());?>/img/52.jpg"/></a></li>
                        <li><a href="#"><img src="<?php echo esc_url(get_template_directory_uri());?>/img/53.jpg"/></a></li>
                        <li><a href="#"><img src="<?php echo esc_url(get_template_directory_uri());?>/img/54.jpg"/></a></li>
                    </ul>
                </div>
</div>


<div class="our-features">
    <div class="container ">
        <div class="row">
            
    <div class="col-md-4 ">
        <div class="single-fetures">
              <div class="icon">
                  <i class="fa fa-thumbs-up"></i>
              </div>  
              <h3>Best Travel Agent</h3>
              <p>Morbi semper fames lobortis ac hac penatibus quisque massa scelerisque proin dignissim est</p>
<!--               <h3><?php global $redux_demo; echo $redux_demo['best_travel_agent_title'];?></h3>
              <p><?php global $redux_demo; echo $redux_demo['best_travel_agent_content'];?></p> -->
        </div>
    </div> 

            
    <div class="col-md-4 ">
        <div class="single-fetures">
              <div class="icon">
                  <i class="fa fa-lock"></i>
              </div> 

              <h3>Trust & Safety</h3> 
              <p>Viverra magna gravida accumsan enim integer faucibus velit leo laoreet platea senectus ullamcorper</p>
<!--               <h3><?php global $redux_demo; echo $redux_demo['trust_safety_title'];?></h3>
              <p><?php global $redux_demo; echo $redux_demo['trust_safety_content'];?></p> -->
        </div>
    </div> 

            
    <div class="col-md-4 ">
        <div class="single-fetures">
              <div class="icon">
                  <i class="fa fa-dollar"></i>
              </div>  
              <h3>Best Price Guarantee</h3>
              <p>At nec sit magnis enim nascetur platea molestie lobortis purus nunc tempor placerat</p>
              <!-- <h3><?php global $redux_demo; echo $redux_demo['best_price_guarantee_title'];?></h3>
              <p><?php global $redux_demo; echo $redux_demo['best_price_guarantee_content'];?></p> -->
        </div>
    </div> 

</div><!--End .row-->
</div>
</div>
<div class="Destinations-area">
    <div class="container">
        <div class="Destinations-title">
            <h2>Top Travel Destinations</h2>
        </div>   
            <div class="row t_top_location">
                 <?php
                  $ourteams = new WP_Query(array(
                  'post_type' => 'tours', 
                  'posts_per_page' => 4 
                  ));

                  
                    while ($ourteams->have_posts() ) : 
                 $ourteams->the_post();?>

                <div class="col-md-6 col-lg-3">
                    <div class="tumb">
                        <div class="tumb-header">

                             <a href="<?php the_permalink(); ?>" class="fig">
                                         <?php 
                                                 $title=get_the_title();
                                                 the_post_thumbnail( array(251, 188),array( 'alt' =>$title) );

                                                 ?>
                            <!-- <div class="feature_class st_featured">Featured</div> -->
                          
                                <span class="tumb-header-icon">
                                    <i class="fa fa-plus"></i>
                                </span>
                            </a>
                        </div>
                        <div class="tumb-caption">
                            <h4 class="tumb-title"><?php echo get_post_meta( get_the_ID(), 'tourlocation', true );?></h4>
                            <p class="tumb-desc"><?php the_title()?></p>
                        </div>  
                    </div> 
                </div>

                  <?php     endwhile;   ?>  
                
            </div>
        </div>
</div><!--Travel Destinations-->
<div class="deal-area">
    <div class="container-fluid">
        <div class="row">
            <div class="col-md-12">
                <div class="wbp-deal-content">
                    <h2>Last Minute Deal</h2>
                    <div class="deal-icon">
                        <ul>
                            <li><i class="fa fa-star"></i></li>
                            <li><i class="fa fa-star"></i></li>
                            <li><i class="fa fa-star"></i></li>
                            <li><i class="fa fa-star"></i></li>
                            <li><i class="fa fa-star"></i></li>
                        </ul>
                    </div>
                    <h5 class="deal-title">Life is beautiful</h5>
                    <p class="deal-date">12/10/2018</p>
                    <p class="mb4"><b>From $80,00</b></p>
                    <a href="<?php bloginfo(); ?>/book-now/" class="book-btn">
                    Book now 
                    <i class="fa fa-chevron-right"></i>
                    </a>
                </div>
            </div>
        </div>
    </div>
</div><!--deal area-->
<div class="Activity">
    <div class="container">
        <h3>Activity Related</h3>
           <div class="list-activities row">

            <?php
                  $ourteams = new WP_Query(array(
                  'post_type' => 'hotelhajj', 
                  'posts_per_page' => 10 
                  ));

                  
                    while ($ourteams->have_posts() ) : 
                 $ourteams->the_post();?>

                <div class="col-12 col-lg-6">
                    <div class="booking-item">

                            <div class="figure">
                                 <a href="<?php the_permalink(); ?>" class="fig">

                                          <?php 
                                                 $title=get_the_title();
                                                 the_post_thumbnail( array(251, 120),array( 'alt' =>$title) );

                                                 ?>
                                </a>
                            </div>
                            <div class="content">
                
                                    <div class="time-squre cl">
                                        <h5 class="booking-titlle">
                                            <a href="<?php the_permalink(); ?>">I<?php the_title()?></a>
                                        </h5>
                                        <ul class="group-icon">
                                            <li><i class="fa fa-star"></i></li>
                                            <li><i class="fa fa-star"></i></li>
                                            <li><i class="fa fa-star"></i></li>
                                            <li><i class="fa fa-star"></i></li>
                                            <li><i class="fa fa-star"></i></li>
                                        </ul>
                                    </div>
                                    <div class="booking-item-price cl">
                                        <span>from</span>
                                        <div class="item-price">
                                          <span> <?php echo get_post_meta( get_the_ID(), 'hotelprice', true );?></span>  
                                        </div>
                                        
                                    </div>
                            
                            </div>
                    </div>
                </div>
             <?php     endwhile;   ?>  




            </div> 
    </div>
</div><!--Activity-->

      

<?php get_footer();?>


<script>
 jQuery('.datepicker').datepicker();
   

   jQuery('.timepicker').timepicker({
             icons: {
                 up: 'fa fa-angle-up',
                 down: 'fa fa-angle-down'
             }
         });

 
</script>   
