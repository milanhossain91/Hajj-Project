<?php
/**
 * The template for displaying all single posts
 *
 * @link https://developer.wordpress.org/themes/basics/template-hierarchy/#single-post
 *
 * @package venox
 */
 /*
  Template Name: advanced search
*/
?>
<?php
get_header();

      
$search = new WP_Advanced_Search('myform');
?>
<div class="search-res umrah has-border">
            <div class="container">
                <div class="top-title">

                    <h3>Search for Umrah Cars</h3>

                     <div class="tf-col col-lg-12">
                                <label for="desti"><?php echo $custom_term->name; ?></h2></label>
                                <div class="map mb-4">

                              <?php $search->the_form(); ?>
             </div>
           </div>
       </div>
       </div>
	 <div class="popural u-padding-t-50">
	        <div class="container">
	          <div class="sec-ti">
	                <h2 class="font-weight300">Popular Destinations</h2>
	            </div>
	   <div class="row">
         <div id="wpas-results"></div> <!-- This is where our results will be loaded -->
       </div>
     </div>
    </div>
   </div>

<?php get_footer(); ?>
