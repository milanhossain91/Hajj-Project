<?php include('head.php');
?>  

 
<div class="admin_form">
	<div class="crow">
		<div class="col-md-12">
			<h2><?php if(isset($_POST['add_guide_submit_btn'])){ echo $msg;  } ?><h2>
			<h4>Added guide</h4> </br> </br>
		</div>
	</div>



 <form action="<?php echo get_stylesheet_directory_uri();?>/admin-page/upload.php" method="post" class="dropzone" id="my-awesome-dropzone" enctype="multipart/form-data">
   
  <div class="form-group crow">
    <label for="colFormLabel" class="col-sm-2 col-form-label">Guide Title</label>
    <div class="col-sm-10">
      <input type="text" class="form-control" id="colFormLabel" name="guide_title">
    </div>
  </div> 


  <div class="form-group crow">
    <label for="colFormLabelLg" class="col-sm-2 col-form-label col-form-label-lg">Guide Description</label>
    <div class="col-sm-10">
       <textarea name="guide_description" class="form-control" style="resize:none;height:300px;width:40%;float:left"></textarea>
    </div>
  </div>   
  </br> 
  </br>

    <div class="form-group crow">
    <label for="colFormLabel" class="col-sm-2 col-form-label">Guide Location</label>
    <div class="col-sm-10">
      <input type="text" class="form-control" id="colFormLabel" name="guide_location">
    </div>
  </div>


    <div class="form-group crow">
    <label for="colFormLabel" class="col-sm-2 col-form-label">Guide Email</label>
    <div class="col-sm-10">
      <input type="text" class="form-control" id="colFormLabel" name="guide_email">
    </div>
  </div>


    <div class="form-group crow">
    <label for="colFormLabel" class="col-sm-2 col-form-label">Guide Phone No</label>
    <div class="col-sm-10">
      <input type="text" class="form-control" id="colFormLabel" name="guide_phone_no">
    </div>
  </div>


   <div class="form-group crow">
    <label for="colFormLabel" class="col-sm-2 col-form-label">Guide Price</label>
    <div class="col-sm-10">
      <input type="text" class="form-control" id="colFormLabel" name="guide_price">
    </div>
  </div>


   <div class="form-group crow">
    <label for="colFormLabel" class="col-sm-2 col-form-label">Total guide</label>
    <div class="col-sm-10">
      <input type="text" class="form-control" id="colFormLabel" name="total_guide">
    </div>
  </div>


 <div class="form-group crow">
    <label for="colFormLabel" class="col-sm-2 col-form-label">Video</label>
    <div class="col-sm-10">
      <input type="text" class="form-control" id="colFormLabel" name="video">
    </div>
  </div>

  



   <div class="form-group crow">
    <label for="colFormLabel" class="col-sm-2 col-form-label">Package Name</label>
    <div class="col-sm-10">

    <div class="form-group">
                    <label for="">Package Name<sup>*</sup></label>
                    <input placeholder="Enter Package Name" class="form-control" type="text" name="package_name[]">
                </div>
                <div class="form-group">
                    <label for="">Package Description<sup>*</sup></label>
                    <textarea placeholder="Enter Package description" class="form-control" type="text" name="package_description[]"></textarea>
                </div>
     <div id="injectPkg"></div>
                            
            <div class="cr-pkg" style="margin-bottom: 15px;">
            <a href="#"><span> <i class="fa fa-plus"></i></span>+ Create Package</a>
        </div>
    </div>
  </div>


 

 


<div class="form-group crow">
    <label for="colFormLabel" class="col-sm-2 col-form-label">Guide Category</label>
    <div class="col-sm-10">
      <?php 

        global $wpdb;
        $wp_post_db = "guide_categories";
        $show_vendor_posts = $wpdb->get_results("SELECT * FROM $wp_post_db ORDER BY id DESC"); 
        $i=0;
        foreach( $show_vendor_posts as $show_vendor_post) 
        {  
         ?> 
       
            <label for="choice_<?php echo $show_vendor_post->id; ?>">
            <input name="category_id" id="choice_<?php echo $show_vendor_post->id; ?>" type="radio" value="<?php echo $show_vendor_post->id; ?>" <?php if($i==0){ ?> checked="checked" <?php } ?> tabindex="28">
                <?php echo $show_vendor_post->category_name; ?>
              </label> 

            <?php $i++; } ?>
       
    </div>
  </div> 





   <div class="form-group crow">
    <label for="colFormLabel" class="col-sm-2 col-form-label">Guide Gallery</label>
    <div class="col-sm-10">
 
<input type="file" class="form-control" name="files[]" multiple="multiple" accept="image/*" /> 
</div>
</div>



  <div class="form-group crow"> 
    <div class="col-sm-10">
		<div class="admin_form_submit"> 
     <input type="hidden" name="service_type" value="guides">
      <input type="submit" id="submit-all" class="btn-primary"   name="add_guide_submit_btn" >
    </div>
  </div> 
</div>

</form>
</div>


<?php include('footer.php'); ?>


 
  <div class="crow"> 
    <div class="col-sm-12">
  <h1>List of Guides</h1>
  <table class="table table-striped table-bordered table-hover" id="dataTables-example">
     
      <thead>
          <tr>   
               <th>guides ID</th>
               <th>guides Image</th>
              <th>guides Title</th>
               <th>guides Description</th>
               <th>guides Price</th>  
               <th>Added Date</th>
               <th>Action</th>
             </tr>
      </thead>

      <tbody>
      <?php     
        $service_type = 'guides';           
        $wp_post_db = "guide_details";  


        $show_vendor_posts = $wpdb->get_results("SELECT * FROM $wp_post_db ORDER BY id DESC"); 
        $i=0;
        foreach( $show_vendor_posts as $show_vendor_post)  
        {   
          //print_r($show_vendor_post);
          $tid             =  $show_vendor_post->id; 
          $guide_title       =  $show_vendor_post->guide_title; 
          $guide_description =  $show_vendor_post->guide_description;    
          $guide_price       =  $show_vendor_post->guide_price;  
          $added_date      =  $show_vendor_post->added_date;
                                                          
        ?>   

         <tr class="odd gradeA">   
            <td><?php echo $cid;?></td>
            <th> <img src="<?php echo getImageSrcById($cid, $service_type); ?>" width="60" height="60"></th>
            <td><?php echo $guide_title;?></td>
            <td><?php echo substr($guide_description, '0', '20');?></td>
            <td><?php echo $guide_price;?></td>  
            <td><?php echo $added_date; ?></td>
            <td class="center"> <a class="btn btn-danger" href="?page=add_guides&id=<?php echo $tid;?>&delete=guides&page=add_guides">Delete</a></td> 
         </tr>

<?php } ?>  
                
    </tbody>

      <tr>   
        <th>guide ID</th>
        <th>guide Image</th>
        <th>guide Title</th>
        <th>guide Description</th>
        <th>guide Price</th> 
        <th>Added Date</th>
        <th>Action</th>
      </tr>
</table>
	  </div>
</div>

<script>
         jQuery(".cr-pkg a").on("click", function(e){
            e.preventDefault();
            jQuery("#injectPkg").append(` 
                <div class="form-group">
                    <label for="">Package Name<sup>*</sup></label>
                    <input placeholder="Enter Package Name" class="form-control" type="text" name="package_name[]">
                </div>
                <div class="form-group">
                    <label for="">Package Description<sup>*</sup></label>
                    <textarea placeholder="Enter Package description" class="form-control" type="text" name="package_description[]"></textarea>
                </div>`);
         })
     </script>