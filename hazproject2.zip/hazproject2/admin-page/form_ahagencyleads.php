   <?php include('head.php'); ?> 

<script type="text/javascript" src="https://code.jquery.com/jquery-3.3.1.js"></script>
<script type="text/javascript" src="https://cdn.datatables.net/1.10.19/js/jquery.dataTables.min.js"></script>
<script type="text/javascript" src="https://cdn.datatables.net/1.10.19/js/dataTables.bootstrap.min.js"></script>



<link rel="stylesheet" type="text/css" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">
<link rel="stylesheet" type="text/css" href="https://cdn.datatables.net/1.10.19/css/dataTables.bootstrap.min.css">

<div id="page-wrapper" >
	<div id="page-inner">
		<div class="row">
			<div class="col-md-12">
				<h1 class="page-header">
					Umrah Booking List View
				</h1>
			</div>
		</div> 
		<!-- /. ROW  -->

		<div class="row">
			<div class="col-md-12">
				<!-- Advanced Tables -->
				<div class="panel">

					<div class="panel-body_old">



						<?php if(isset($_GET['details'])) { ?>
								<table class="table table-striped table-bordered table-hover" style="width: 60%">
									<?php	
									//  global $post;	
									  $id	= $_GET['id'];	
									// $upost = get_post(459);
									// print_r($upost);
									   global $wpdb;
							
							         $table = 'booking_info'; 
							        $show_update = $wpdb->get_results("SELECT * FROM `$table` WHERE id ='$id'"); 

									   foreach ( $show_update as $show_updatevalue) 
							       {

							?>



								<tr>  
								<th>Customer Name</th> 
								<td> <?php echo $show_updatevalue->u_name;?> <?php echo $show_updatevalue->u_lname;?></td>
								</tr>
								
								<tr> 

								<th>Customer Email</th>
								<td><?php echo $show_updatevalue->u_email;?></td>

								</tr>
								<tr> 

								<th>Address</th>

								<td><?php echo $show_updatevalue->u_address;?></td> 

								</tr>


								<tr> 

								<th>City</th>
								<td><?php echo $show_updatevalue->u_ucity;?></td> 
								</tr>
								<tr> 

								<th>CELL</th>
								<td><?php echo $show_updatevalue->u_cell;?></td>
								</tr>
								<tr> 
                            <?php }?>
							

                         
							
							 

							  </table> 


							    




				


						<?php } else{ ?>
          <div class="table-responsive">  
    
       <table class="table table-striped table-bordered table-hover" id="example">
       	<thead> 
            <tr>
               <th>Booking ID</th>
                <th>Photo</th>
                 <th>Title</th>
           <th>Packages City</th>
               
                 
                 <th>Bed</th>
                <th>Adults</th>
                 <th>Children</th>
                  <th>Infants</th>
                   <th>Booking Date</th>
                    <th>Comments</th>
                    
                 

                 
            
              
      
              
            </tr>
            </thead> 
            	<tbody>
         
						        <?php    

 
                             
							  global $wpdb;
							
							  $table = 'booking_info'; 
							  $show_update = $wpdb->get_results("SELECT * FROM `$table`"); 

						

                                







                    foreach ( $show_update as $show_updatevalue) 
							       {

		      	$user_info = get_userdata($show_updatevalue->user_id);
                $customaer_name = $user_info->user_nicename;
                $customaer_email = $user_info->user_email;
   




							       	?>
    
               <tr class="odd gradeA">

        
                    <td><?php echo $show_updatevalue->id;?></td> 
                    <td><?php  echo get_the_post_thumbnail($show_updatevalue->post_id, array(70,70)); ?></td>

                    
                    
                    <td><?php echo get_the_title( $show_updatevalue->post_id );?>
                    	



                    </td> 
                    <td><?php echo $show_updatevalue->u_city;?></td>
         
                     
                    
                    <td><?php echo $show_updatevalue->u_bed;?> </td>
                    <td><?php echo $show_updatevalue->u_adults;?> </td>
                    <td><?php echo $show_updatevalue->u_children;?> </td>
                    <td><?php echo $show_updatevalue->u_infants;?> </td>
                
                
                    
                         
                    <td><?php echo $show_updatevalue->date_added;?>

                    </td>
                    <td><?php echo $show_updatevalue->u_comments;?></td>
                 

                  <!---td>  
											
<a class="center btn btn-primary" href="?page=agency_for_admin_menu&id=<?php echo $show_updatevalue->id; ?>&details=yes">View</a>
										</td--->
                  
                 
                   
          
					                </tr>
					             <?php }?>


					       </tbody>

					               <tr>
					              <th>Booking ID</th>
					              <th>Photo</th>
                
                 <th>Title</th>
                 <th>Packages City</th>
           
                
              
                 <th>Bed</th>
                <th>Adults</th>
                 <th>Children</th>
                  <th>Infants</th>
                   <th>Booking Date</th>
                   <th>Comments</th>
                  
					              
					      
					              
					            </tr>
					      </table>

					  </div>  

					  <?php } ?>
					</div>
				</div>
				<!--End Advanced Tables -->
			</div>
		</div>
	</div>

</div>



<script type="text/javascript">
$(document).ready(function() {
    $('#example').DataTable( {
        "pagingType": "full_numbers"
    } );
} );

</script>




  <?php include('footer.php'); ?> 