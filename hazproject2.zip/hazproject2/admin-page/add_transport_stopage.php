<?php include('head.php');?>  

<?php 
 if(isset($_POST['add_stopage_submit_btn'])){
  
   global $wpdb;
    // Create rooms object
    $data3 = array(  
      'stopage_name'       => $_POST['stopage_name'], 
      'stopage_description' => $_POST['stopage_description'],   
    );  
    $results = $wpdb->insert('transport_stopage', $data3 ); 
   // print_r($data3);
    if($results){
    $msg = "Successfully Inserted..";
    }
}
?>



<div class="admin_form">
		<div class="crow">
		<div class="col-md-12">
  			<h2 style="color:blue;"><?php if(isset($_POST['add_stopage_submit_btn'])){ echo $msg;  } ?><h2>
  			<h4>Added stopage</h4>  
				<br>
				<br>
	</div>
</div>
   <form method="post" enctype="multipart/form-data">

     
    <div class="form-group crow">
      <label for="colFormLabel" class="col-sm-2 col-form-label">stopage Name</label>
      <div class="col-sm-10">
        <input type="text" class="form-control" id="colFormLabel" name="stopage_name">
      </div>
    </div> 

    <div class="form-group crow">
      <label for="colFormLabelLg" class="col-sm-2 col-form-label col-form-label-lg">stopage Description</label>
      <div class="col-sm-10">
         <textarea name="stopage_description" class="form-control" style="resize:none;height:300px;width:40%;"></textarea>
      </div>
    </div>    
     
    <div class="form-group crow"> 
      <div class="col-sm-10">
		  <div class="admin_form_submit"> 
       <input type="hidden" name="service_type" value="stopages">
        <input type="submit"  class="btn-primary"   name="add_stopage_submit_btn" >
      </div>
    </div> 
	   </div>

</form>

</div>

<?php include('footer.php'); ?>


  

   