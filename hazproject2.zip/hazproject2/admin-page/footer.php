 

	
 

	
 

      <!-- Bootstrap Js -->

      <!--  <script src="<?php echo get_template_directory_uri(); ?>/admin-page/js/bootstrap.min.js"></script>
 

   

    <script src="<?php echo get_template_directory_uri(); ?>/admin-page/js/datatables.min.js"></script>

    <script src="<?php echo get_template_directory_uri(); ?>/admin-page/js/dataTables.bootstrap.js"></script>

        <script>

            $(document).ready(function () {

                $('#dataTables-example').dataTable();

            });

    </script>-->

      