<?php
/**
 * The template for displaying all single posts
 *
 * @link https://developer.wordpress.org/themes/basics/template-hierarchy/#single-post
 *
 * @package venox
 */
 /*
  Template Name: car-result
*/

get_header();
?>



        <div class="search-res umrah has-border">
            <div class="container">
                <div class="top-title">
                    <h3>Search for Umrah Cars</h3>


                                <?php 

                          

                                    $args = array(
                                       
                                        'depth'               => 0,
                                        'echo'                => 1,
                                        'exclude'             => '',
                                        'exclude_tree'        => '',
                                        'feed'                => '',
                                        'feed_image'          => '',
                                        'feed_type'           => '',
                                        'hide_empty'          => 0,
                                        'hide_title_if_empty' => false,
                                        'hierarchical'        => true,
                                        'order'               => 'ASC',
                                        'orderby'             => 'name',
                                        'separator'           => '',
                                        'show_count'          => 1,
                                        'show_option_all'     => '',
                                        'show_option_none'    => __( 'No categories' ),
                                        'style'               => 'list',
                                        'taxonomy'            => 'CarsName',
                                        'title_li'            => __( $current_category_name ),
                                        'use_desc_for_title'  => 0,
                                    );

                                      $categories = get_categories($args);  
                                        $CarsName = array();  
                                        foreach ($categories as $category_list ) 
                                        {  
                                              $CarsName[$category_list->cat_ID] = $category_list->cat_name;  
                                        } 

                                   

                                    $args = array(
                                        
                                        'depth'               => 0,
                                        'echo'                => 1,
                                        'exclude'             => '',
                                        'exclude_tree'        => '',
                                        'feed'                => '',
                                        'feed_image'          => '',
                                        'feed_type'           => '',
                                        'hide_empty'          => 0,
                                        'hide_title_if_empty' => false,
                                        'hierarchical'        => true,
                                        'order'               => 'ASC',
                                        'orderby'             => 'name',
                                        'separator'           => '',
                                        'show_count'          => 1,
                                        'show_option_all'     => '',
                                        'show_option_none'    => __( 'No categories' ),
                                        'style'               => 'list',
                                        'taxonomy'            => 'CarsFeatures',
                                        'title_li'            => __( $current_category_name ),
                                        'use_desc_for_title'  => 0,
                                    );

                                      $categories = get_categories($args);  
                                        $CarsFeatures = array();  
                                        foreach ($categories as $category_list ) 
                                        {  
                                              $CarsFeatures[$category_list->cat_ID] = $category_list->cat_name;  
                                        } 


                                    $category_object           = get_queried_object();
                                 

                                    $args = array(
                                        'child_of'            => $current_category_term_id,
                                        'current_category'    => $current_category_term_id,
                                        'depth'               => 0,
                                        'echo'                => 1,
                                        'exclude'             => '',
                                        'exclude_tree'        => '',
                                        'feed'                => '',
                                        'feed_image'          => '',
                                        'feed_type'           => '',
                                        'hide_empty'          => 0,
                                        'hide_title_if_empty' => false,
                                        'hierarchical'        => true,
                                        'order'               => 'ASC',
                                        'orderby'             => 'name',
                                        'separator'           => '',
                                        'show_count'          => 1,
                                        'show_option_all'     => '',
                                        'show_option_none'    => __( 'No categories' ),
                                        'style'               => 'list',
                                        'taxonomy'            => 'CarsLocation',
                                        'title_li'            => __( $current_category_name ),
                                        'use_desc_for_title'  => 0,
                                    );

                                      $categories = get_categories($args);  
                                        $CarsLocation = array();  
                                        foreach ($categories as $category_list ) 
                                        {  
                                              $CarsLocation[$category_list->cat_ID] = $category_list->cat_name;  
                                        } 





                             
                                    if($_GET['CarsName'] && !empty($_GET['CarsName']))
                                    {
                                        $NoofDays = $_GET['CarsName'];
                                    }

                                    if($_GET['CarsLocation'] && !empty($_GET['CarsLocation']))
                                    {
                                        $PackageClass = $_GET['CarsLocation'];
                                    }
                                    if($_GET['CarsFeatures'] && !empty($_GET['CarsFeatures']))
                                    {
                                        $Location = $_GET['CarsFeatures'];
                                    }
                                

                                ?>
                    <form action="<?php the_permalink(); ?>" method="get">
                        <div class="tf-row row">
                            
                            <div class="tf-col col-lg-4">
                                <label for="desti">Cars Name</label>
                                <div class="map mb-4">
                                    <select class="form-control" name="CarsName">
                                        <option>Select Cars Name</option>
                                    <?php foreach ($CarsName as $v) { ;?>
                                     <option value="<?php echo $v;?>"><?php echo $v;?></option>
                                    <?php } ; ?>
                                </select>
                                </div>
                            </div>

                            
                            <div class="tf-col col-lg-4">
                                <label for="desti">Package Cars Location</label>
                                <div class="map mb-4">
                                    <select class="form-control" name="CarsLocation">
                                        <option>Select Cars Location</option>
                                       <?php foreach ($CarsLocation as $v) { ;?>
                                     <option value="<?php echo $v;?>"><?php echo $v;?></option>
                                    <?php } ; ?>
                                </select>
                                </div>
                            </div>


                            <div class="tf-col col-lg-4">
                                <label for="desti">Cars Features</label>
                                <div class="map mb-4">
                                    <select class="form-control" name="CarsFeatures">
                                        <option>Select Cars Features</option>
                                       <?php foreach ($CarsFeatures as $v) { ;?>
                                     <option value="<?php echo $v;?>"><?php echo $v;?></option>
                                    <?php } ; ?>
                                </select>
                                </div>
                            </div>

                  

                            <div class="col-lg-12">
                                <div class="btn-area">
                                    <button class="btn btn-primary btn-md" type="submit">Search</button>
                                </div>
                            </div>

                         </div>
                    </form>
                </div>

     

    <div class="popural u-padding-t-50">
        <div class="container">
            <div class="sec-ti">
                <h2 class="font-weight300">Popular Destinations</h2>
            </div>
            <div class="row">

                       
       <?php

                              $args = array(
                                      'order' => 'asc',
                                      'order_by' => 'title',
                                      'post_type' => 'cars', 
                                      'posts_per_page' => 0,
                                          'tax_query' => array(

                                            'relation' => 'AND',

                                            array(
                                                
                                                'taxonomy' => 'CarsName', 
                                                'field' => 'slug',
                                                'terms' => $NoofDays,
                                                
                                                
                                            ),


                                            array(
                                                
                                                'taxonomy' => 'CarsLocation', 
                                                'field' => 'slug',
                                                'terms' => $PackageClass,
                                                
                                                
                                            ),

                                             array(
                                                
                                                'taxonomy' => 'CarsFeatures', 
                                                'field' => 'slug',
                                                'terms' => $Location,
                                                
                                                
                                            ),


                                      
                                        )
                                      );

          
                             

               $query = new WP_Query($args);
             
               if ($query -> have_posts()):
               while($query -> have_posts()) : $query -> the_post();?>

           

         

                <div class="col-sm-3">
                    <div class="pop-item">
                        <a href="<?php the_permalink(); ?>">
                            <?php the_post_thumbnail();?>
                            <div class="content">
                                <h5><?php the_title();?></h5>
                                <p><?php echo get_post_meta( get_the_ID(), 'agentname', true );?></p>
                                <p class="mb0">3 offers price from $<?php echo get_post_meta( get_the_ID(), 'presentprice', true );?></p>
                            </div>
                        </a>
                    </div>
                </div>

               
               

                    <?php 

                   endwhile; 
                

                 else: 
               

                    $ourteams = new WP_Query(array(
                  'post_type' => 'cars', 
                  'posts_per_page' => 0 
                  ));

                    while ($ourteams->have_posts() ) : 
                 $ourteams->the_post();


                    ?>



                <div class="col-sm-3">
                    <div class="pop-item">
                        <a href="<?php the_permalink(); ?>">
                            <?php the_post_thumbnail();?>
                            <div class="content">
                                <h5><?php the_title();?></h5>
                                <p><?php echo get_post_meta( get_the_ID(), 'agentname', true );?></p>
                                <p class="mb0">3 offers price from $<?php echo get_post_meta( get_the_ID(), 'presentprice', true ); ?></p>
                            </div>
                        </a>
                    </div>
                </div>

               
               


                               <?php
              endwhile; 
                 wp_reset_postdata();
                endif;
            ?>

             </div>
        </div>
    </div>
  </div>
</div>         




<?php
get_footer();
?>