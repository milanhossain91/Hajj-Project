<?php 
/*
 * template-ajax-results.php
 * This file should be created in the root of your theme directory
 */

if ( have_posts() ) :             
   while ( have_posts() ) : the_post(); 
   $post_type = get_post_type_object($post->post_type);
   ?>

      <div class="flight-block">
                                <div class="title">
                                    <h4>Departure Berlin (BER) to Paris (CDG)</h4>
                                </div>
                                <div class="f-item">
                                    <div class="f-logo">
                                        <?php 
                                                 $title=get_the_title();
                                                 the_post_thumbnail( array(251, 188),array( 'alt' =>$title) );

                                                 ?>
                                    </div>
                                    <div class="f-inf">
                                        <div class="cl left">
                                            <p><?php echo get_post_meta( get_the_ID(), 'umrahpakegeclass', true );?></p>
                                            <span><?php echo get_post_meta( get_the_ID(), 'umrahpakegeclass', true );?></span>
                                        </div>
                                        <div class="cl mid">
                                            <div class="top">4H 0M</div>
                                            <div class="bottom">Direct Flight</div>
                                            <div class="hand-l">
                                                <span>CDG</span>
                                            </div>
                                            <div class="hand-r">
                                                <span>BER</span>
                                            </div>
                                        </div>
                                        <div class="cl right">
                                            <p><?php echo get_post_meta( get_the_ID(), 'umrahpakegeclass', true );?></p>
                                            <span><?php echo get_post_meta( get_the_ID(), 'umrahpakegeclass', true );?></span>
                                        </div>
                                    </div>
                                    <div class="f-end">
                                        <div class="item-price">
                                            <p>$<?php echo get_post_meta( get_the_ID(), 'umrahpakegeclass', true );?><small>/person</small></p>
                                            <span>Class Economy</span>
                                            <div class="btn-rdo">
                                                <div class="custom-control custom-radio">
                                                    <input type="radio" id="customRadio1" name="customRadio" class="custom-control-input">
                                                    <label class="custom-control-label" for="customRadio1"></label>
                                                </div>
                                            </div>
                                        </div>
                                        <div class="item-price">
                                            <p>$<?php echo get_post_meta( get_the_ID(), 'umrahpakegeclass', true );?> <small>/person</small></p>
                                            <span>Class Economy</span>
                                            <div class="btn-rdo">
                                                <div class="custom-control custom-radio">
                                                    <input type="radio" id="customRadio2" name="customRadio" class="custom-control-input">
                                                    <label class="custom-control-label" for="customRadio2"></label>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>



                            </div>
   


   <?php 
   endwhile; 

else :
   echo '<p>Sorry, no results matched your search.</p>';
endif; 
wp_reset_query();
?>