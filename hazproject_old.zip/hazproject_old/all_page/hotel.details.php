<?php
/**
 * The hotel details template file
 *
 * This is the most generic template file in a WordPress theme
 * and one of the two required files for a theme (the other being style.css).
 * It is used to display a page when nothing more specific matches a query.
 * E.g., it puts together the home page when no home.php file exists.
 *
 * @link https://developer.wordpress.org/themes/basics/template-hierarchy/
 *
 * @package aynix
 */
 /*
  Template Name: hotel.details
*/
get_header(); ?>
    
           <!-- mobile-menu-area start -->
        <div class="mobile-menu-area">
          <div class="container">
            <div class="row">
              <div class="col-md-12">
                <div class="mobile-menu">
                  <nav id="dropdown">
                    <ul>
                        <li class="active"><a href="#">Home</a>
                            <ul>
                                <li><a href="#">Sub Item</a></li>
                                <li><a href="#">Sub Item</a></li>
                                <li><a href="#">Sub Item</a></li>
                                <li><a href="#">Sub Item</a></li>
                                <li><a href="#">Sub Item</a></li>
                                <li><a href="#">Sub Item</a></li>
                                <li><a href="#">Sub Item</a></li>
                            </ul>
                        </li>
                        <li><a href="#">Projects</a></li>
                        <li><a href="#">Activities</a></li>
                        <li><a href="#">Total Jobs</a></li>
                        <li><a href="#">Flights</a></li>
                        <li><a href="#">Hotels</a></li>
                    </ul>
                  </nav>
                </div>
              </div>
            </div>
          </div>
        </div>
        <!-- mobile-menu-area end -->



    <div class="det-area car-det has-border u-padding-t-60 u-padding-b-60">
        <div class="container">
            <div class="det-top">
                <div class="left">
                    <h3>Shangri-La International Hotel</h3>
                    <p><i class="fa fa-map-marker"></i> Pierpoint Road Cairns , QLD 4870 Australia</p>
                    <ul>
                        <li><i class="fa fa-envelope"></i>Hotel E-mail</li>
                        <li><i class="fa fa-home"></i> Hotel Website</li>
                        <li><i class="fa fa-phone"></i> +123456789</li>
                    </ul>
                </div>
                <div class="right">
                    <div class="prices">
                        <div class="old">
                            price from 
                        </div>
                        <div class="cr-price">
                             $273,00 <small>/night</small>
                        </div>
                    </div>
                </div>
            </div>

            <div class="row">

                <div class="col-sm-5">
                    <div class="hotel-fig">
                        <div class="slider-hotel">
                            <img src="<?php echo esc_url(get_template_directory_uri());?>/img/_2.JPG">
                        </div>
                    </div>
                </div> <!-- col-5 end -->

                <div class="col-sm-7">
                    <div class="hotel-info-wrap">
                        <div class="int">
                            <h2>Good</h2>
                            <p>80% <small>of guests recommend</small></p>
                            <div class="rev">
                                <div class="stars">
                                    <i class="fa fa-star"></i>
                                    <i class="fa fa-star"></i>
                                    <i class="fa fa-star"></i>
                                    <i class="fa fa-star"></i>
                                    <i class="fa fa-star-o"></i>
                                </div>

                                <h6>3.5 <small>of 5 rating</small></h6>
                            </div>
                        </div>

                        <div class="share clear">
                            <span>Share<i class="fa fa-share fa-lg"></i></span>
                            
                                <ul class="clear">
                                <li>
                                    <a class="facebook" href="#">
                                        <i class="fa fa-facebook fa-lg"></i>
                                    </a>
                                </li>

                                <li><a class="twitter" href="#"><i class="fa fa-twitter fa-lg"></i></a></li>

                                <li><a class="google" href="#"><i class="fa fa-google-plus fa-lg"></i></a></li>
                                <li><a class="no-open pinterest" href="#">
                                    <i class="fa fa-pinterest fa-lg"></i></a></li>

                                <li><a class="linkedin" href="#"><i class="fa fa-linkedin fa-lg"></i></a></li>
                                
                            </ul>
                        </div>


                        <div class="row">
                    <div class="col-md-8">
                                    <h4 class="lh1em">Traveler rating</h4>
                        <ul class="list booking-item-raiting-list">

                                            <li>
                                <div class="booking-item-raiting-list-title">Excellent</div>
                                <div class="booking-item-raiting-list-bar">
                                    <div style="width:20%;"></div>
                                </div>
                                <div class="booking-item-raiting-list-number">1</div>
                            </li>

                                            <li>
                                <div class="booking-item-raiting-list-title">Very Good</div>
                                <div class="booking-item-raiting-list-bar">
                                    <div style="width:20%;"></div>
                                </div>
                                <div class="booking-item-raiting-list-number">1</div>
                            </li>

                                            <li>
                                <div class="booking-item-raiting-list-title">Average</div>
                                <div class="booking-item-raiting-list-bar">
                                    <div style="width:40%;"></div>
                                </div>
                                <div class="booking-item-raiting-list-number">2</div>
                            </li>
                                            <li>
                                <div class="booking-item-raiting-list-title">Poor</div>
                                <div class="booking-item-raiting-list-bar">
                                    <div style="width:20%;"></div>
                                </div>
                                <div class="booking-item-raiting-list-number">1</div>
                            </li>

                                            <li>
                                <div class="booking-item-raiting-list-title">Terrible</div>
                                <div class="booking-item-raiting-list-bar">
                                    <div style="width:0%;"></div>
                                </div>
                                <div class="booking-item-raiting-list-number">0</div>
                            </li>
                        </ul>
                        <a href="#" class="btn btn-primary mb10">Write a review</a>
                    </div>

                    <div class="col-md-4">
                <h4 class="lhem">Summary</h4>
                <ul class="list booking-item-raiting-summary-list">
                                            <li>
                            <div class="booking-item-raiting-list-title">Sleep</div>
                            <ul class="icon-group booking-item-rating-stars">
                                <li><i class="fa fa-smile-o "></i></li><li><i class="fa fa-smile-o "></i></li><li><i class="fa fa-smile-o "></i></li><li><i class="fa fa-smile-o text-gray"></i></li><li><i class="fa fa-smile-o text-gray"></i>                            </li></ul>
                        </li>
                                                <li>
                            <div class="booking-item-raiting-list-title">Location</div>
                            <ul class="icon-group booking-item-rating-stars">
                                <li><i class="fa fa-smile-o "></i></li><li><i class="fa fa-smile-o "></i></li><li><i class="fa fa-smile-o "></i></li><li><i class="fa fa-smile-o text-gray"></i></li><li><i class="fa fa-smile-o text-gray"></i>                            </li></ul>
                        </li>
                                                <li>
                            <div class="booking-item-raiting-list-title">Service</div>
                            <ul class="icon-group booking-item-rating-stars">
                                <li><i class="fa fa-smile-o "></i></li><li><i class="fa fa-smile-o "></i></li><li><i class="fa fa-smile-o "></i></li><li><i class="fa fa-smile-o text-gray"></i></li><li><i class="fa fa-smile-o text-gray"></i>                            </li></ul>
                        </li>
                                                <li>
                            <div class="booking-item-raiting-list-title">Clearness</div>
                            <ul class="icon-group booking-item-rating-stars">
                               
                                <li><i class="fa fa-smile-o "></i></li>

                                <li><i class="fa fa-smile-o "></i></li>

                                <li><i class="fa fa-smile-o "></i></li>

                                <li><i class="fa fa-smile-o "></i></li>

                                <li><i class="fa fa-smile-o text-gray"></i>                            </li>
                            </ul>
                        </li>
                            <li>
                            <div class="booking-item-raiting-list-title">Rooms</div>
                            <ul class="icon-group booking-item-rating-stars">
                                <li><i class="fa fa-smile-o "></i></li><li><i class="fa fa-smile-o "></i></li><li><i class="fa fa-smile-o "></i></li><li><i class="fa fa-smile-o text-gray"></i></li><li><i class="fa fa-smile-o text-gray"></i>                            </li></ul>
                        </li>
                        
                </ul>
            </div>
            </div>
                    </div>
                </div>

            
            <div class="col-sm-12">
                <div class="hotel-des">
                    <h3>Hotel Description</h3>
                    <p>This boutique hotel in the Manhattan neighborhood of Nolita features a private rooftop and rooms with free WiFi. The Bowery subway station is 1 block from this New York hotel.</p>
                    <p>Guest rooms at the Nolitan Hotel provide a 37-inch flat-screen cable TV and an iPod dock. The bathrooms provide bathrobes and slippers.</p>
                    <p>The hotel provides free bike rentals and a local gym membership for guests. There is also on-site dining at the French bistro Cantine Parisienne. A complimentary wine and cheese hour is served every Monday through Saturday.</p>
                    <p>Times Square, Rockefeller Center and Madison Square Garden are 4.8 km from The Nolitan Hotel. The hotel is bordered by SoHo, Little Italy and Chinatown.</p>
                    <p>NoLita is a great choice for travelers interested in nightlife, food and culture.</p>
                    <p>We speak your language! Pierpoint Road Cairns , QLD 4870 Australia</p>
                </div>
                <div class="payment-ac">
                    <ul>
                        <li><img src="<?php echo esc_url(get_template_directory_uri());?>/img/mastercard.png"></li>
                        <li><img src="<?php echo esc_url(get_template_directory_uri());?>/img/jcb.png"></li>
                        <li><img src="<?php echo esc_url(get_template_directory_uri());?>/img/unionpay.png"></li>
                        <li><img src="<?php echo esc_url(get_template_directory_uri());?>/img/visa (1).png"></li>
                    </ul>
                </div>
            </div> <!-- col-12 des -->

            </div> <!-- row --> 

            <div class="hotel_policy container-fluid">
    
                    <div class="row">
                    <div class="col-lg-3">
                        Check - in                 
                    </div>
                    <div class="col-lg-9">
                        12:00 AM  -  23:00 PM                 
                    </div>
                </div>
                                

                <div class="row">
                    <div class="col-lg-3">
                        Check - out                 
                    </div>
                    <div class="col-lg-9">
                        6:00 AM - 12:00 AM                  
                    </div>
                </div>
                                <div class="row">
                    <div class="col-lg-3">
                        Cancelled/ Prepayment                   
                    </div>
                    <div class="col-lg-9">
                        <b>Lorem Ipsum is simply dummy text of the printing and typesetting industry.</b> Lorem Ipsum has been the industry's standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book. It has survived not only five centuries, but also the leap into electronic typesetting, <a href="#">remaining essentially unchanged</a>. It was popularised in the 1960s with the release of Letraset sheets containing Lorem Ipsum passages, and more recently with desktop publishing software like Aldus PageMaker including versions of Lorem Ipsum.                   
                    </div>
                </div>
                <div class="row">
                    <div class="col-lg-3">
                        Children and extrabed                   
                    </div>
                    <div class="col-lg-9">
                        <p>All children are wellcome</p>
                    <p>Free ! Lorem Ipsum is simply dummy text of the printing and typesetting industry</p>
                    <p>Free ! Lorem Ipsum is simply dummy text of the printing and typesetting industry</p>
                    <p>Free ! Lorem Ipsum is simply dummy text of the printing and typesetting industry</p>                 
                </div>
                </div>
                <div class="row">
                    <div class="col-lg-3">
                        Pets                    
                    </div>
                    <div class="col-lg-9">
                        <b>Lorem Ipsum is simply dummy text of the printing and typesetting industry</b>                    
                    </div>
                </div>
                <div class="row">
                    <div class="col-lg-3">
                        Card eccepted at this property                  
                    </div>

                    <div class="col-lg-9">
                        
                        <ul class="list-card-accepted text-left">
                            <li><img src="<?php echo esc_url(get_template_directory_uri());?>/img/mastercard.png"></li>
                            <li><img src="<?php echo esc_url(get_template_directory_uri());?>/img/jcb.png"></li>
                            <li><img src="<?php echo esc_url(get_template_directory_uri());?>/img/unionpay.png"></li>
                            <li><img src="<?php echo esc_url(get_template_directory_uri());?>/img/visa.png"></li>    
                        </ul>
    
                    </div>
                </div>
                    
            </div> <!-- policy end -->
            
            <div class="sec-bar3 u-padding-t-40 row">
                <div class="col-sm-9">
                    <div class="from-wrap">
                        <h3>Available Rooms</h3>
                        <form class="tf-row row">

                            <div class="tf-col  col-lg-3">
                                <label>Check in</label>
                                <input type="text" class="datepicker form-control" placeholder="dd/mm/yy">
                            </div>
                            <div class="tf-col col-lg-3">
                                <label>Check out</label>
                                <input type="text" class="datepicker form-control" placeholder="dd/mm/yy">
                                
                            </div>

                            <div class="tf-col col-lg-3">
                                <label>Rooms</label>
                                <div class="inp-more">
                                    <div class="radio-wrap">
                                        <label><input type="radio" name="room">1</label>
                                        <label><input type="radio" name="room">2</label>
                                    </div>
                                    <span class="more-sl">2+</span>
                                </div>
                                
                            </div>

                            <div class="tf-col col-lg-3">
                                <label>Adult</label>
                                <div class="inp-more">
                                    <div class="radio-wrap">
                                        <label><input type="radio" name="room">1</label>
                                        <label><input type="radio" name="room">2</label>

                                    </div>
                                    <span class="more-sl">2+</span>
                                </div>
                                
                            </div>
                            <div class="col-sm-12">
                                <div class="btn-area">
                                    <button class="btn btn-primary btn-md" type="submit">Search For Room</button>
                                </div>
                            </div>
                        </form> <!-- row end -->
                    </div> <!--from-wrap --> 
                    
                    <div class="row hotels">
                        <div class="col-12">
                            <div class="item-hotel-price">
                                <div class="figr">
                                    <a href="#">
                                        <img src="<?php echo esc_url(get_template_directory_uri());?>/img/Barclay-400x300.jpg">
                                    </a>
                                </div>
                                
                                <div class="bd-icons">
                                    <h5><a href="#">Superior Penthouse</a></h5>
                                    <ul class="ico-set">
                                            <li data-toggle="tooltip" data-placement="top" title="Data on top">
                                                <i class="fa fa-briefcase"></i>
                                                <span>x3</span>
                                            </li>
                                            <li data-toggle="tooltip" data-placement="top" title="Data on top">
                                                <i class="fa fa-male"></i>
                                                <span>Auto</span>
                                            </li>
                                            <li data-toggle="tooltip" data-placement="top" title="Data on top">
                                                <i class="fa fa-briefcase"></i>
                                                <span>x3</span>
                                            </li>
                                            <li data-toggle="tooltip" data-placement="top" title="Data on top">
                                                <i class="fa fa-briefcase"></i>
                                                <span>x4</span>
                                            </li>
                                        </ul>
                                </div>

                                <div class="action">
                                    <a class="btn btn-primary" href="#">Show Price</a>
                                </div>
                            </div>
                        </div>
                    </div><!-- item -->
                    
                    <div class="row hotels">
                        <div class="col-12">
                            <div class="item-hotel-price">
                                <div class="figr">
                                    <a href="#">
                                        <img src="<?php echo esc_url(get_template_directory_uri());?>/img/Barclay-400x300.jpg">
                                    </a>
                                </div>
                                
                                <div class="bd-icons">
                                    <h5><a href="#">Superior Penthouse</a></h5>
                                    <ul class="ico-set">
                                            <li data-toggle="tooltip" data-placement="top" title="Data on top">
                                                <i class="fa fa-briefcase"></i>
                                                <span>x3</span>
                                            </li>
                                            <li data-toggle="tooltip" data-placement="top" title="Data on top">
                                                <i class="fa fa-male"></i>
                                                <span>Auto</span>
                                            </li>
                                            <li data-toggle="tooltip" data-placement="top" title="Data on top">
                                                <i class="fa fa-briefcase"></i>
                                                <span>x3</span>
                                            </li>
                                            <li data-toggle="tooltip" data-placement="top" title="Data on top">
                                                <i class="fa fa-briefcase"></i>
                                                <span>x4</span>
                                            </li>
                                        </ul>
                                </div>

                                <div class="action">
                                    <a class="btn btn-primary" href="#">Show Price</a>
                                </div>
                            </div>
                        </div>
                    </div><!-- item -->
                    
                    <div class="row hotels">
                        <div class="col-12">
                            <div class="item-hotel-price">
                                <div class="figr">
                                    <a href="#">
                                        <img src="<?php echo esc_url(get_template_directory_uri());?>/img/Barclay-400x300.jpg">
                                    </a>
                                </div>
                                
                                <div class="bd-icons">
                                    <h5><a href="#">Superior Penthouse</a></h5>
                                    <ul class="ico-set">
                                            <li data-toggle="tooltip" data-placement="top" title="Data on top">
                                                <i class="fa fa-briefcase"></i>
                                                <span>x3</span>
                                            </li>
                                            <li data-toggle="tooltip" data-placement="top" title="Data on top">
                                                <i class="fa fa-male"></i>
                                                <span>Auto</span>
                                            </li>
                                            <li data-toggle="tooltip" data-placement="top" title="Data on top">
                                                <i class="fa fa-briefcase"></i>
                                                <span>x3</span>
                                            </li>
                                            <li data-toggle="tooltip" data-placement="top" title="Data on top">
                                                <i class="fa fa-briefcase"></i>
                                                <span>x4</span>
                                            </li>
                                        </ul>
                                </div>

                                <div class="action">
                                    <a class="btn btn-primary" href="#">Show Price</a>
                                </div>
                            </div>
                        </div>
                    </div><!-- item -->
                    
                    <div class="row hotels">
                        <div class="col-12">
                            <div class="item-hotel-price">
                                <div class="figr">
                                    <a href="#">
                                        <img src="<?php echo esc_url(get_template_directory_uri());?>/img/Barclay-400x300.jpg">
                                    </a>
                                </div>
                                
                                <div class="bd-icons">
                                    <h5><a href="#">Superior Penthouse</a></h5>
                                    <ul class="ico-set">
                                            <li data-toggle="tooltip" data-placement="top" title="Data on top">
                                                <i class="fa fa-briefcase"></i>
                                                <span>x3</span>
                                            </li>
                                            <li data-toggle="tooltip" data-placement="top" title="Data on top">
                                                <i class="fa fa-male"></i>
                                                <span>Auto</span>
                                            </li>
                                            <li data-toggle="tooltip" data-placement="top" title="Data on top">
                                                <i class="fa fa-briefcase"></i>
                                                <span>x3</span>
                                            </li>
                                            <li data-toggle="tooltip" data-placement="top" title="Data on top">
                                                <i class="fa fa-briefcase"></i>
                                                <span>x4</span>
                                            </li>
                                        </ul>
                                </div>

                                <div class="action">
                                    <a class="btn btn-primary" href="#">Show Price</a>
                                </div>
                            </div>
                        </div>
                    </div><!-- item -->
                </div> <!-- col-9 end -->

                <div class="col-sm-3">
                    <div class="hotel-sidebar">
                        <div class="about-hotel">
                            <h3>About Hotel</h3>
                            <img src="<?php echo esc_url(get_template_directory_uri());?>/img/hotel-logo.jpg">
                        </div>

                        <div class="hotel-facilities">
                            <h4>Hotel Facilities</h4>
                            <ul>
                                <li>
                                    <i class="fa fa-glass"></i>
                                    <span>Airport Transport</span>
                                </li>
                                <li>
                                    <i class="fa fa-glass"></i>
                                    <span>Outdoor pool (all year)</span>
                                </li>
                                <li>
                                    <i class="fa fa-glass"></i>
                                    <span>Shuttle Bus Service</span>
                                </li>
                                <li>
                                    <i class="fa fa-glass"></i>
                                    <span>Bathrobe</span>
                                </li>
                                <li>
                                    <i class="fa fa-glass"></i>
                                    <span>Wi-Fi Internet</span>
                                </li>
                                <li>
                                    <i class="fa fa-glass"></i>
                                    <span>Bathrobe</span>
                                </li>
                                <li>
                                    <i class="fa fa-glass"></i>
                                    <span>Shuttle Bus Service</span>
                                </li>
                            </ul>
                        </div>
                    </div>
                </div> <!-- col-3 sidebar col -->
            </div>

            <div class="sec-rev-relhot row">
                <div class="col-sm-8">
                    <div class="hotel-rev">
                        <div class="rev-title">
                            <h3>Hotel Reviews</h3>
                        </div>
                        <ul class="booking-item-reviews list">

                            <!--comment repeted item start -->
                            <li  class="st_reviews byuser comment-author-admin bypostauthor even thread-even depth-1">
                                <div class="row">
                                    <div class="col-md-2">
                                        <div class="booking-item-review-person">
                                            <a class="booking-item-review-person-avatar round" href="#">
                                                <img alt="avatar" width=70 height=70 src="<?php echo esc_url(get_template_directory_uri());?>/img/avater.jpg" class="avatar avatar-96 photo origin round" >                </a>
                                            <p class="booking-item-review-person-name">
                                                <cite class="fn">admin</cite>                </p>
                                            <p class="booking-item-review-person-loc">                </p>
                                            <small>
                                                <a href="#">                        73 reviews
                                                </a>
                                            </small>
                                        </div>
                                    </div>

                                    <div class="col-md-10">
                                        <div class="booking-item-review-content">
                                            <h5>"Good"</h5>
                                            <ul class="icon-group booking-item-rating-stars" data-rate="4.2">
                                                <li><i class="fa  fa-star"></i></li><li><i class="fa  fa-star"></i></li><li><i class="fa  fa-star"></i></li><li><i class="fa  fa-star"></i></li><li><i class="fa  fa-star-half-o"></i></li>
                                            </ul>
                                            
                                            <div class="comment-content">
                                                Nam ullamcorper ornare auctor rhoncus nulla pellentesque tempus penatibus tristique lobortis dignissim sollicitudin Nam...              
                                            </div>

                                            <div class="booking-item-review-more-content">
                                                <ul class="list booking-item-raiting-summary-list mt20">
                                                <li>
                                                    <div class="booking-item-raiting-list-title">Sleep</div>
                                                    <ul class="icon-group booking-item-rating-stars">
                                                        <li><i class="fa fa-smile-o "></i>
                                                        <li><i class="fa fa-smile-o "></i>
                                                        <li><i class="fa fa-smile-o "></i>
                                                        <li><i class="fa fa-smile-o "></i>
                                                        <li><i class="fa fa-smile-o text-gray"></i>
                                                    </ul>
                                                </li>

                                                <li>
                                                    <div class="booking-item-raiting-list-title">Location</div>
                                                    <ul class="icon-group booking-item-rating-stars">
                                                        <li><i class="fa fa-smile-o "></i>
                                                        <li><i class="fa fa-smile-o "></i>
                                                        <li><i class="fa fa-smile-o "></i>
                                                        <li><i class="fa fa-smile-o "></i>
                                                        <li><i class="fa fa-smile-o text-gray"></i>
                                                    </ul>
                                                </li>

                                                <li>
                                                    <div class="booking-item-raiting-list-title">Service</div>
                                                    <ul class="icon-group booking-item-rating-stars">
                                                        <li><i class="fa fa-smile-o "></i>
                                                        <li><i class="fa fa-smile-o "></i>
                                                        <li><i class="fa fa-smile-o "></i>
                                                        <li><i class="fa fa-smile-o "></i>
                                                        <li><i class="fa fa-smile-o "></i>
                                                    </ul>
                                                </li>

                                                <li>
                                                    <div class="booking-item-raiting-list-title">Clearness</div>
                                                    <ul class="icon-group booking-item-rating-stars">
                                                        <li><i class="fa fa-smile-o "></i>
                                                        <li><i class="fa fa-smile-o "></i>
                                                        <li><i class="fa fa-smile-o "></i>
                                                        <li><i class="fa fa-smile-o "></i>
                                                        <li><i class="fa fa-smile-o "></i>
                                                    </ul>
                                                </li>

                                                <li>
                                                    <div class="booking-item-raiting-list-title">Rooms</div>
                                                    <ul class="icon-group booking-item-rating-stars">
                                                        <li><i class="fa fa-smile-o "></i>
                                                        <li><i class="fa fa-smile-o "></i>
                                                        <li><i class="fa fa-smile-o "></i>
                                                        <li><i class="fa fa-smile-o text-gray"></i>
                                                        <li><i class="fa fa-smile-o text-gray"></i>
                                                    </ul>
                                                </li>
                            
                                            </ul>                
                                        </div>
                                            <div class="booking-item-review-expand">
                                                <span class="booking-item-review-expand-more">More <i class="fa fa-angle-down"></i></span>
                                                <span class="booking-item-review-expand-less">Less <i class="fa fa-angle-up"></i></span>
                                            </div>
                                                
                                            <p class="booking-item-review-rate">Was this review helpful?<b class="text-color"> <span class="number">56</span> like this</b>
                                            <a data-id="196" class="st-like-review fa fa-thumbs-o-up box-icon-inline round" href="#"></a>
                                                                    
                                            </p>
                           
                                        </div>
                                    </div><!-- col-10 -->
                                </div><!-- row -->
                            </li>
                            <!--comment repeted item end -->
 <!--comment repeted item start -->
                            <li  class="st_reviews byuser comment-author-admin bypostauthor even thread-even depth-1">
                                <div class="row">
                                    <div class="col-md-2">
                                        <div class="booking-item-review-person">
                                            <a class="booking-item-review-person-avatar round" href="#">
                                                <img alt="avatar" width=70 height=70 src="<?php echo esc_url(get_template_directory_uri());?>/img/avater.jpg" class="avatar avatar-96 photo origin round" >                </a>
                                            <p class="booking-item-review-person-name">
                                                <cite class="fn">admin</cite>                </p>
                                            <p class="booking-item-review-person-loc">                </p>
                                            <small>
                                                <a href="#">                        73 reviews
                                                </a>
                                            </small>
                                        </div>
                                    </div>

                                    <div class="col-md-10">
                                        <div class="booking-item-review-content">
                                            <h5>"Good"</h5>
                                            <ul class="icon-group booking-item-rating-stars" data-rate="4.2">
                                                <li><i class="fa  fa-star"></i></li><li><i class="fa  fa-star"></i></li><li><i class="fa  fa-star"></i></li><li><i class="fa  fa-star"></i></li><li><i class="fa  fa-star-half-o"></i></li>
                                            </ul>
                                            
                                            <div class="comment-content">
                                                Nam ullamcorper ornare auctor rhoncus nulla pellentesque tempus penatibus tristique lobortis dignissim sollicitudin Nam...              
                                            </div>

                                            <div class="booking-item-review-more-content">
                                                <ul class="list booking-item-raiting-summary-list mt20">
                                                <li>
                                                    <div class="booking-item-raiting-list-title">Sleep</div>
                                                    <ul class="icon-group booking-item-rating-stars">
                                                        <li><i class="fa fa-smile-o "></i>
                                                        <li><i class="fa fa-smile-o "></i>
                                                        <li><i class="fa fa-smile-o "></i>
                                                        <li><i class="fa fa-smile-o "></i>
                                                        <li><i class="fa fa-smile-o text-gray"></i>
                                                    </ul>
                                                </li>

                                                <li>
                                                    <div class="booking-item-raiting-list-title">Location</div>
                                                    <ul class="icon-group booking-item-rating-stars">
                                                        <li><i class="fa fa-smile-o "></i>
                                                        <li><i class="fa fa-smile-o "></i>
                                                        <li><i class="fa fa-smile-o "></i>
                                                        <li><i class="fa fa-smile-o "></i>
                                                        <li><i class="fa fa-smile-o text-gray"></i>
                                                    </ul>
                                                </li>

                                                <li>
                                                    <div class="booking-item-raiting-list-title">Service</div>
                                                    <ul class="icon-group booking-item-rating-stars">
                                                        <li><i class="fa fa-smile-o "></i>
                                                        <li><i class="fa fa-smile-o "></i>
                                                        <li><i class="fa fa-smile-o "></i>
                                                        <li><i class="fa fa-smile-o "></i>
                                                        <li><i class="fa fa-smile-o "></i>
                                                    </ul>
                                                </li>

                                                <li>
                                                    <div class="booking-item-raiting-list-title">Clearness</div>
                                                    <ul class="icon-group booking-item-rating-stars">
                                                        <li><i class="fa fa-smile-o "></i>
                                                        <li><i class="fa fa-smile-o "></i>
                                                        <li><i class="fa fa-smile-o "></i>
                                                        <li><i class="fa fa-smile-o "></i>
                                                        <li><i class="fa fa-smile-o "></i>
                                                    </ul>
                                                </li>

                                                <li>
                                                    <div class="booking-item-raiting-list-title">Rooms</div>
                                                    <ul class="icon-group booking-item-rating-stars">
                                                        <li><i class="fa fa-smile-o "></i>
                                                        <li><i class="fa fa-smile-o "></i>
                                                        <li><i class="fa fa-smile-o "></i>
                                                        <li><i class="fa fa-smile-o text-gray"></i>
                                                        <li><i class="fa fa-smile-o text-gray"></i>
                                                    </ul>
                                                </li>
                            
                                            </ul>                
                                        </div>
                                            <div class="booking-item-review-expand">
                                                <span class="booking-item-review-expand-more">More <i class="fa fa-angle-down"></i></span>
                                                <span class="booking-item-review-expand-less">Less <i class="fa fa-angle-up"></i></span>
                                            </div>
                                                
                                            <p class="booking-item-review-rate">Was this review helpful?<b class="text-color"> <span class="number">56</span> like this</b>
                                            <a data-id="196" class="st-like-review fa fa-thumbs-o-up box-icon-inline round" href="#"></a>
                                                                    
                                            </p>
                           
                                        </div>
                                    </div><!-- col-10 -->
                                </div><!-- row -->
                            </li>
                            <!--comment repeted item end -->

                        </ul>

                      
                    </div>

                    <div class="box bg-gray">   
                        <div id="respond" class="comment-respond">
        <h3 id="reply-title" class="comment-reply-title">Write a review </h3>          
        <form action="#" method="post" id="commentform" class="comment-form" novalidate="">
                
                        <div class="row">
                            <div class="col-sm-8">
                    <div class="form-group">
                                            <label>Review Title</label>
                                            <input class="form-control" type="text" name="comment_title">
                                        </div><div class="form-group">
                                            <label>Review Text</label>
                                            <textarea name="comment" id="comment" class="form-control" rows="6"></textarea>
                                        </div>
                                        </div><!--End col-sm-8-->
                                        <div class="col-sm-4"><ul class="list booking-item-raiting-summary-list stats-list-select"><li class=""><div class="booking-item-raiting-list-title">Sleep</div>
                                                    <ul class="icon-group booking-item-rating-stars">
                                                    <li class=""><i class="fa fa-smile-o"></i>
                                                    </li>
                                                    <li class=""><i class="fa fa-smile-o"></i>
                                                    </li>
                                                    <li class=""><i class="fa fa-smile-o"></i>
                                                    </li>
                                                    <li class=""><i class="fa fa-smile-o"></i>
                                                    </li>
                                                    <li><i class="fa fa-smile-o"></i>
                                                    </li>
                                                </ul>
                                                <input type="hidden" class="st_review_stats" value="0" name="st_review_stats[Sleep]">
                                                    </li><li class=""><div class="booking-item-raiting-list-title">Location</div>
                                                    <ul class="icon-group booking-item-rating-stars">
                                                    <li class=""><i class="fa fa-smile-o"></i>
                                                    </li>
                                                    <li class=""><i class="fa fa-smile-o"></i>
                                                    </li>
                                                    <li class=""><i class="fa fa-smile-o"></i>
                                                    </li>
                                                    <li class=""><i class="fa fa-smile-o"></i>
                                                    </li>
                                                    <li><i class="fa fa-smile-o"></i>
                                                    </li>
                                                </ul>
                                                <input type="hidden" class="st_review_stats" value="0" name="st_review_stats[Location]">
                                                    </li><li class=""><div class="booking-item-raiting-list-title">Service</div>
                                                    <ul class="icon-group booking-item-rating-stars">
                                                    <li class=""><i class="fa fa-smile-o"></i>
                                                    </li>
                                                    <li class=""><i class="fa fa-smile-o"></i>
                                                    </li>
                                                    <li class=""><i class="fa fa-smile-o"></i>
                                                    </li>
                                                    <li class=""><i class="fa fa-smile-o"></i>
                                                    </li>
                                                    <li><i class="fa fa-smile-o"></i>
                                                    </li>
                                                </ul>
                                                <input type="hidden" class="st_review_stats" value="0" name="st_review_stats[Service]">
                                                    </li><li class=""><div class="booking-item-raiting-list-title">Clearness</div>
                                                    <ul class="icon-group booking-item-rating-stars">
                                                    <li class=""><i class="fa fa-smile-o"></i>
                                                    </li>
                                                    <li class=""><i class="fa fa-smile-o"></i>
                                                    </li>
                                                    <li class=""><i class="fa fa-smile-o"></i>
                                                    </li>
                                                    <li class=""><i class="fa fa-smile-o"></i>
                                                    </li>
                                                    <li><i class="fa fa-smile-o"></i>
                                                    </li>
                                                </ul>
                                                <input type="hidden" class="st_review_stats" value="0" name="st_review_stats[Clearness]">
                                                    </li><li class=""><div class="booking-item-raiting-list-title">Rooms</div>
                                                    <ul class="icon-group booking-item-rating-stars">
                                                    <li class=""><i class="fa fa-smile-o"></i>
                                                    </li>
                                                    <li class=""><i class="fa fa-smile-o"></i>
                                                    </li>
                                                    <li class=""><i class="fa fa-smile-o"></i>
                                                    </li>
                                                    <li class=""><i class="fa fa-smile-o"></i>
                                                    </li>
                                                    <li><i class="fa fa-smile-o"></i>
                                                    </li>
                                                </ul>
                                                <input type="hidden" class="st_review_stats" value="0" name="st_review_stats[Rooms]">
                                                    </li></ul></div></div><!--End Row--><input name="wpml_language_code" type="hidden" value="en"><div class="row">

                                        <div class="col-md-6"><div class="form-group">
                                            <label for="author">Name*</label>
                                            <input id="author" name="author" type="text" value="" size="30" aria-required="true" class="form-control">
                                         </div></div>   
                                    <div class="col-md-6"><div class="form-group">

                                    <label for="email">Your email address *</label>
                                    <input class="form-control" id="email"  type="text"></div>
                                    </div>
                                    </div><!--End row-->
                                <p class="form-submit"><input name="submit" type="submit" id="submit" class="submit btn btn-primary" value="Leave a Review"> <input type="hidden" name="comment_post_ID" value="980" id="comment_post_ID">
                                <input type="hidden" name="comment_parent" id="comment_parent" value="0"></p>            </form>
            </div><!-- #respond -->
    </div>
                </div> <!-- col-8 -->

                <div class="col-sm-4">
                    <div class="rel-hotel">
                        <h3 class="title">Related hotel</h3>
                        <ul>
                            <li>
                               <a href="#">
                                   <figure>
                                       <img src="<?php echo esc_url(get_template_directory_uri());?>/img/pexels-photo-227405-70x60.jpeg">
                                   </figure>
                                   <div class="title-star">
                                       <h4>Kerama Islands Hotel</h4>
                                       <span class="stars">
                                           <i class="fa fa-star"></i>
                                           <i class="fa fa-star"></i>
                                           <i class="fa fa-star"></i>
                                           <i class="fa fa-star"></i>
                                           <i class="fa fa-star-o"></i>
                                       </span>
                                   </div>

                                   <span class="price">
                                       <span>Price from</span>
                                       <p>$267,00</p>
                                   </span>

                               </a>
                            </li> <!-- item -->
                            <li>
                               <a href="#">
                                   <figure>
                                       <img src="<?php echo esc_url(get_template_directory_uri());?>/img/pexels-photo-227405-70x60.jpeg">
                                   </figure>
                                   <div class="title-star">
                                       <h4>Kerama Islands Hotel</h4>
                                       <span class="stars">
                                           <i class="fa fa-star"></i>
                                           <i class="fa fa-star"></i>
                                           <i class="fa fa-star"></i>
                                           <i class="fa fa-star"></i>
                                           <i class="fa fa-star-o"></i>
                                       </span>
                                   </div>

                                   <span class="price">
                                       <span>Price from</span>
                                       <p>$267,00</p>
                                   </span>

                               </a>
                            </li> <!-- item -->
                            <li>
                               <a href="#">
                                   <figure>
                                       <img src="<?php echo esc_url(get_template_directory_uri());?>/img/pexels-photo-227405-70x60.jpeg">
                                   </figure>
                                   <div class="title-star">
                                       <h4>Kerama Islands Hotel</h4>
                                       <span class="stars">
                                           <i class="fa fa-star"></i>
                                           <i class="fa fa-star"></i>
                                           <i class="fa fa-star"></i>
                                           <i class="fa fa-star"></i>
                                           <i class="fa fa-star-o"></i>
                                       </span>
                                   </div>

                                   <span class="price">
                                       <span>Price from</span>
                                       <p>$267,00</p>
                                   </span>

                               </a>
                            </li> <!-- item -->
                            <li>
                               <a href="#">
                                   <figure>
                                       <img src="<?php echo esc_url(get_template_directory_uri());?>/img/pexels-photo-227405-70x60.jpeg">
                                   </figure>
                                   <div class="title-star">
                                       <h4>Kerama Islands Hotel</h4>
                                       <span class="stars">
                                           <i class="fa fa-star"></i>
                                           <i class="fa fa-star"></i>
                                           <i class="fa fa-star"></i>
                                           <i class="fa fa-star"></i>
                                           <i class="fa fa-star-o"></i>
                                       </span>
                                   </div>

                                   <span class="price">
                                       <span>Price from</span>
                                       <p>$267,00</p>
                                   </span>

                               </a>
                            </li> <!-- item -->
                            <li>
                               <a href="#">
                                   <figure>
                                       <img src="<?php echo esc_url(get_template_directory_uri());?>/img/pexels-photo-227405-70x60.jpeg">
                                   </figure>
                                   <div class="title-star">
                                       <h4>Kerama Islands Hotel</h4>
                                       <span class="stars">
                                           <i class="fa fa-star"></i>
                                           <i class="fa fa-star"></i>
                                           <i class="fa fa-star"></i>
                                           <i class="fa fa-star"></i>
                                           <i class="fa fa-star-o"></i>
                                       </span>
                                   </div>

                                   <span class="price">
                                       <span>Price from</span>
                                       <p>$267,00</p>
                                   </span>

                               </a>
                            </li> <!-- item -->
                            <li>
                               <a href="#">
                                   <figure>
                                       <img src="<?php echo esc_url(get_template_directory_uri());?>/img/pexels-photo-227405-70x60.jpeg">
                                   </figure>
                                   <div class="title-star">
                                       <h4>Kerama Islands Hotel</h4>
                                       <span class="stars">
                                           <i class="fa fa-star"></i>
                                           <i class="fa fa-star"></i>
                                           <i class="fa fa-star"></i>
                                           <i class="fa fa-star"></i>
                                           <i class="fa fa-star-o"></i>
                                       </span>
                                   </div>

                                   <span class="price">
                                       <span>Price from</span>
                                       <p>$267,00</p>
                                   </span>

                               </a>
                            </li> <!-- item -->
                            <li>
                               <a href="#">
                                   <figure>
                                       <img src="<?php echo esc_url(get_template_directory_uri());?>/img/pexels-photo-227405-70x60.jpeg">
                                   </figure>
                                   <div class="title-star">
                                       <h4>Kerama Islands Hotel</h4>
                                       <span class="stars">
                                           <i class="fa fa-star"></i>
                                           <i class="fa fa-star"></i>
                                           <i class="fa fa-star"></i>
                                           <i class="fa fa-star"></i>
                                           <i class="fa fa-star-o"></i>
                                       </span>
                                   </div>

                                   <span class="price">
                                       <span>Price from</span>
                                       <p>$267,00</p>
                                   </span>

                               </a>
                            </li> <!-- item -->

                        </ul>
                    </div>
                </div> <!-- col-sm-4 -->
            </div>

                                

        </div>
    </div>





<?php get_footer();?>