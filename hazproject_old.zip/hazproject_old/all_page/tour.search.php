<?php
/**
 * The tour search template file
 *
 * This is the most generic template file in a WordPress theme
 * and one of the two required files for a theme (the other being style.css).
 * It is used to display a page when nothing more specific matches a query.
 * E.g., it puts together the home page when no home.php file exists.
 *
 * @link https://developer.wordpress.org/themes/basics/template-hierarchy/
 *
 * @package aynix
 */
 /*
  Template Name: tour.search
*/
get_header(); ?>
  
  
        <!-- mobile-menu-area start -->
        <div class="mobile-menu-area">
          <div class="container">
            <div class="row">
              <div class="col-md-12">
                <div class="mobile-menu">
                  <nav id="dropdown">
                    <ul>
                        <li class="active"><a href="#">Home</a>
                            <ul>
                                <li><a href="#">Sub Item</a></li>
                                <li><a href="#">Sub Item</a></li>
                                <li><a href="#">Sub Item</a></li>
                                <li><a href="#">Sub Item</a></li>
                                <li><a href="#">Sub Item</a></li>
                                <li><a href="#">Sub Item</a></li>
                                <li><a href="#">Sub Item</a></li>
                            </ul>
                        </li>
                        <li><a href="#">Projects</a></li>
                        <li><a href="#">Activities</a></li>
                        <li><a href="#">Total Jobs</a></li>
                        <li><a href="#">Flights</a></li>
                        <li><a href="#">Hotels</a></li>
                    </ul>
                  </nav>
                </div>
              </div>
            </div>
          </div>
        </div>
        <!-- mobile-menu-area end -->



    <div class="search-area has-border u-padding-t-60">
        <div class="container">
            <div class="top-title u-padding-b-80">
                <h1>Search for Tours</h1>
            </div>
            <div class="row">
                <div class="col-sm-3">
                    <div class="left-sidebar-w">
                        <form>
                                <div class="tf-row row">
                                    <div class="tf-col col-12">
                                        <label for="desti">Address</label>
                                        <div class="map mb-2">
                                            <label for="desti"><i class="fa fa-map-marker"></i></label>
                                            <input id="desti" type="text" class="form-control" placeholder="Destination: Zip Code">
                                        </div>
                                    </div>
                                    <div class="tf-col  col-12 u-margin-t-10">
                                        <label>Departure date</label>
                                        <input type="text" class="datepicker form-control" placeholder="dd/mm/yy">
                                    </div>
                                    <div class="tf-col col-12 u-margin-t-20">
                                        <label>Arrive date</label>
                                        <input type="text" class="datepicker form-control" placeholder="dd/mm/yy">
                                        </select>
                                    </div>

                                </div>


                           
                                <button class="opt-ctrl" type="button"><span>+</span>Advance Search</button>
                              
                                <div class="advance-opt">
                                    <div class="list-block">
                                        <h3>Car Features</h3>
                                        <div class="row">

                                            <div class="col-12">


                                                <div class="custom-control custom-checkbox">
                                                    <input type="checkbox" class="custom-control-input" id="c6">
                                                    <label class="custom-control-label" for="c6">Satellite Channels</label>
                                                </div>

                                                <div class="custom-control custom-checkbox">
                                                    <input type="checkbox" class="custom-control-input" id="c7">
                                                    <label class="custom-control-label" for="c7">Spa and wellness centre</label>
                                                </div>

                                                <div class="custom-control custom-checkbox">
                                                    <input type="checkbox" class="custom-control-input" id="c8">
                                                    <label class="custom-control-label" for="c8">Airport Transport</label>
                                                </div>

                                                <div class="custom-control custom-checkbox">
                                                    <input type="checkbox" class="custom-control-input" id="c9">
                                                    <label class="custom-control-label" for="c9">Fitness Center</label>
                                                </div>

                                                <div class="custom-control custom-checkbox">
                                                    <input type="checkbox" class="custom-control-input" id="c10">
                                                    <label class="custom-control-label" for="c10">Cable Channels</label>
                                                </div>

                                            </div>

                                        </div>
                                    </div>

                                    <div class="list-block">
                                        <h3>Room Facilitites</h3>
                                        <div class="row">

                                            <div class="col-12">

                                                <div class="custom-control custom-checkbox">
                                                    <input type="checkbox" class="custom-control-input" id="c6">
                                                    <label class="custom-control-label" for="c6">Satellite Channels</label>
                                                </div>

                                                <div class="custom-control custom-checkbox">
                                                    <input type="checkbox" class="custom-control-input" id="c7">
                                                    <label class="custom-control-label" for="c7">Spa and wellness centre</label>
                                                </div>

                                                <div class="custom-control custom-checkbox">
                                                    <input type="checkbox" class="custom-control-input" id="c8">
                                                    <label class="custom-control-label" for="c8">Airport Transport</label>
                                                </div>

                                                <div class="custom-control custom-checkbox">
                                                    <input type="checkbox" class="custom-control-input" id="c9">
                                                    <label class="custom-control-label" for="c9">Fitness Center</label>
                                                </div>

                                                <div class="custom-control custom-checkbox">
                                                    <input type="checkbox" class="custom-control-input" id="c10">
                                                    <label class="custom-control-label" for="c10">Cable Channels</label>
                                                </div>

                                            </div>

                                        </div>
                                    </div>

                                    <div class="bottom row">
                                        <div class="tf-col col-12">
                                            <label for="dest2">Tour Name</label>
                                            <div class="map mb-2">
                                                <label for="dest2">
                                                    <i class="fa fa-sort-amount-asc"></i>
                                                </label>
                                                <input id="dest2" type="text" class="form-control" placeholder="">
                                            </div>
                                        </div>

                                        <div class="tf-col tf-range col-12">
                                            <input type="text" id="car-ranger1" name="priceRange">
                                        </div>
                                    </div>
                                </div>
                                <div class="btn-area">
                                    <button class="btn btn-primary btn-md" type="submit">Search For Tour</button>
                                </div>
               

                                
                        </form>
                    </div>
                </div> <!-- col- end -->

                <div class="col-sm-9">
                    <div class="sec-ti">
                        <h2 class="font-weight300">Destinations</h2>
                    </div>
                    <div class="row">

                        <div class="col-sm-4">
                            <div class="pop-item">
                                <a href="#">
                                    <img src="<?php echo esc_url(get_template_directory_uri());?>/img/Barclay-400x300.jpg">
                                    <div class="content">
                                        <h5>InterContinental New York Barclay</h5>
                                        <p>5 reviews</p>
                                        <p class="mb0">3 offers price from $130,00</p>
                                    </div>
                                </a>
                            </div>
                        </div> <!-- col-4 -->

                        <div class="col-sm-4">
                            <div class="pop-item">
                                <a href="#">
                                    <img src="<?php echo esc_url(get_template_directory_uri());?>/img/Barclay-400x300.jpg">
                                    <div class="content">
                                        <h5>InterContinental New York Barclay</h5>
                                        <p>5 reviews</p>
                                        <p class="mb0">3 offers price from $130,00</p>
                                    </div>
                                </a>
                            </div>
                        </div> <!-- col-4 -->

                        <div class="col-sm-4">
                            <div class="pop-item">
                                <a href="#">
                                    <img src="<?php echo esc_url(get_template_directory_uri());?>/img/Barclay-400x300.jpg">
                                    <div class="content">
                                        <h5>InterContinental New York Barclay</h5>
                                        <p>5 reviews</p>
                                        <p class="mb0">3 offers price from $130,00</p>
                                    </div>
                                </a>
                            </div>
                        </div> <!-- col-4 -->

                        <div class="col-sm-4">
                            <div class="pop-item">
                                <a href="#">
                                    <img src="<?php echo esc_url(get_template_directory_uri());?>/img/Barclay-400x300.jpg">
                                    <div class="content">
                                        <h5>InterContinental New York Barclay</h5>
                                        <p>5 reviews</p>
                                        <p class="mb0">3 offers price from $130,00</p>
                                    </div>
                                </a>
                            </div>
                        </div> <!-- col-4 -->

                        <div class="col-sm-4">
                            <div class="pop-item">
                                <a href="#">
                                    <img src="<?php echo esc_url(get_template_directory_uri());?>/img/Barclay-400x300.jpg">
                                    <div class="content">
                                        <h5>InterContinental New York Barclay</h5>
                                        <p>5 reviews</p>
                                        <p class="mb0">3 offers price from $130,00</p>
                                    </div>
                                </a>
                            </div>
                        </div> <!-- col-4 -->

                        <div class="col-sm-4">
                            <div class="pop-item">
                                <a href="#">
                                    <img src="<?php echo esc_url(get_template_directory_uri());?>/img/Barclay-400x300.jpg">
                                    <div class="content">
                                        <h5>InterContinental New York Barclay</h5>
                                        <p>5 reviews</p>
                                        <p class="mb0">3 offers price from $130,00</p>
                                    </div>
                                </a>
                            </div>
                        </div> <!-- col-4 -->

                    </div> <!-- row -->

                    <div class="sec-ti">
                        <h2 class="font-weight300">Tour</h2>
                    </div>

                    <div class="row u-padding-b-40">
                        
                        <div class="col-12 col-sm-4">
                            <div class="tour-item">
                                    <a href="#" class="fig">
                                        <img src="<?php echo esc_url(get_template_directory_uri());?>/img/pexels-photo-338023-260x190.jpeg">
                                        <h4>Inter Continental New</h4>
                                    </a>
                                           
                                    <div class="content">

                                        <div class="left">
                                            <div class="location">
                                                <i class="fa fa-map-marker"></i>
                                                <span> Place Vendôme Paris</span>
                                            </div>
                                            <div class="price">
                                                <i class="fa fa-money"></i>
                                                <span>$1000,00</span>
                                            </div>
                                        </div>
                                        <div class="right">
                                            <div class="cal">
                                                <i class="fa fa-calendar"></i>
                                                <span>3</span>
                                            </div>
                                             <div class="stars">
                                                <i class="fa fa-star"></i>         
                                                <i class="fa fa-star"></i>         
                                                <i class="fa fa-star"></i>         
                                                <i class="fa fa-star"></i>         
                                                <i class="fa fa-star"></i>         
                                            </div>
                                        </div>

      

                                    </div>
                            </div>
                        </div> <!-- col -4 -->
                        
                        <div class="col-12 col-sm-4">
                            <div class="tour-item">
                                    <a href="#" class="fig">
                                        <img src="<?php echo esc_url(get_template_directory_uri());?>/img/pexels-photo-338023-260x190.jpeg">
                                        <h4>Inter Continental New</h4>
                                    </a>
                                           
                                    <div class="content">

                                        <div class="left">
                                            <div class="location">
                                                <i class="fa fa-map-marker"></i>
                                                <span> Place Vendôme Paris</span>
                                            </div>
                                            <div class="price">
                                                <i class="fa fa-money"></i>
                                                <span>$1000,00</span>
                                            </div>
                                        </div>
                                        <div class="right">
                                            <div class="cal">
                                                <i class="fa fa-calendar"></i>
                                                <span>3</span>
                                            </div>
                                             <div class="stars">
                                                <i class="fa fa-star"></i>         
                                                <i class="fa fa-star"></i>         
                                                <i class="fa fa-star"></i>         
                                                <i class="fa fa-star"></i>         
                                                <i class="fa fa-star"></i>         
                                            </div>
                                        </div>

      

                                    </div>
                            </div>
                        </div> <!-- col -4 -->
                        
                        <div class="col-12 col-sm-4">
                            <div class="tour-item">
                                    <a href="#" class="fig">
                                        <img src="<?php echo esc_url(get_template_directory_uri());?>/img/pexels-photo-338023-260x190.jpeg">
                                        <h4>Inter Continental New</h4>
                                    </a>
                                           
                                    <div class="content">

                                        <div class="left">
                                            <div class="location">
                                                <i class="fa fa-map-marker"></i>
                                                <span> Place Vendôme Paris</span>
                                            </div>
                                            <div class="price">
                                                <i class="fa fa-money"></i>
                                                <span>$1000,00</span>
                                            </div>
                                        </div>
                                        <div class="right">
                                            <div class="cal">
                                                <i class="fa fa-calendar"></i>
                                                <span>3</span>
                                            </div>
                                             <div class="stars">
                                                <i class="fa fa-star"></i>         
                                                <i class="fa fa-star"></i>         
                                                <i class="fa fa-star"></i>         
                                                <i class="fa fa-star"></i>         
                                                <i class="fa fa-star"></i>         
                                            </div>
                                        </div>

      

                                    </div>
                            </div>
                        </div> <!-- col -4 -->
                        
                        <div class="col-12 col-sm-4">
                            <div class="tour-item">
                                    <a href="#" class="fig">
                                        <img src="<?php echo esc_url(get_template_directory_uri());?>/img/pexels-photo-338023-260x190.jpeg">
                                        <h4>Inter Continental New</h4>
                                    </a>
                                           
                                    <div class="content">

                                        <div class="left">
                                            <div class="location">
                                                <i class="fa fa-map-marker"></i>
                                                <span> Place Vendôme Paris</span>
                                            </div>
                                            <div class="price">
                                                <i class="fa fa-money"></i>
                                                <span>$1000,00</span>
                                            </div>
                                        </div>
                                        <div class="right">
                                            <div class="cal">
                                                <i class="fa fa-calendar"></i>
                                                <span>3</span>
                                            </div>
                                             <div class="stars">
                                                <i class="fa fa-star"></i>         
                                                <i class="fa fa-star"></i>         
                                                <i class="fa fa-star"></i>         
                                                <i class="fa fa-star"></i>         
                                                <i class="fa fa-star"></i>         
                                            </div>
                                        </div>

      

                                    </div>
                            </div>
                        </div> <!-- col -4 -->
                        
                        <div class="col-12 col-sm-4">
                            <div class="tour-item">
                                    <a href="#" class="fig">
                                        <img src="<?php echo esc_url(get_template_directory_uri());?>/img/pexels-photo-338023-260x190.jpeg">
                                        <h4>Inter Continental New</h4>
                                    </a>
                                           
                                    <div class="content">

                                        <div class="left">
                                            <div class="location">
                                                <i class="fa fa-map-marker"></i>
                                                <span> Place Vendôme Paris</span>
                                            </div>
                                            <div class="price">
                                                <i class="fa fa-money"></i>
                                                <span>$1000,00</span>
                                            </div>
                                        </div>
                                        <div class="right">
                                            <div class="cal">
                                                <i class="fa fa-calendar"></i>
                                                <span>3</span>
                                            </div>
                                             <div class="stars">
                                                <i class="fa fa-star"></i>         
                                                <i class="fa fa-star"></i>         
                                                <i class="fa fa-star"></i>         
                                                <i class="fa fa-star"></i>         
                                                <i class="fa fa-star"></i>         
                                            </div>
                                        </div>

      

                                    </div>
                            </div>
                        </div> <!-- col -4 -->

                        <div class="col-12 col-sm-4">
                            <div class="tour-item">
                                    <a href="#" class="fig">
                                        <img src="<?php echo esc_url(get_template_directory_uri());?>/img/pexels-photo-338023-260x190.jpeg">
                                        <h4>Inter Continental New</h4>
                                    </a>
                                           
                                    <div class="content">

                                        <div class="left">
                                            <div class="location">
                                                <i class="fa fa-map-marker"></i>
                                                <span> Place Vendôme Paris</span>
                                            </div>
                                            <div class="price">
                                                <i class="fa fa-money"></i>
                                                <span>$1000,00</span>
                                            </div>
                                        </div>
                                        <div class="right">
                                            <div class="cal">
                                                <i class="fa fa-calendar"></i>
                                                <span>3</span>
                                            </div>
                                             <div class="stars">
                                                <i class="fa fa-star"></i>         
                                                <i class="fa fa-star"></i>         
                                                <i class="fa fa-star"></i>         
                                                <i class="fa fa-star"></i>         
                                                <i class="fa fa-star"></i>         
                                            </div>
                                        </div>

      

                                    </div>
                            </div>
                        </div> <!-- col -4 -->

                    </div>

                </div> <!-- col-9 end -->
            </div>


            
        </div>
    </div>

   

<?php get_footer();?>