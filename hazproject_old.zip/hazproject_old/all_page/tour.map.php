<?php
/**
 * The tour map template file
 *
 * This is the most generic template file in a WordPress theme
 * and one of the two required files for a theme (the other being style.css).
 * It is used to display a page when nothing more specific matches a query.
 * E.g., it puts together the home page when no home.php file exists.
 *
 * @link https://developer.wordpress.org/themes/basics/template-hierarchy/
 *
 * @package aynix
 */
 /*
  Template Name: tour.map
*/
get_header(); ?>
   
     <!-- mobile-menu-area start -->
        <div class="mobile-menu-area">
          <div class="container">
            <div class="row">
              <div class="col-md-12">
                <div class="mobile-menu">
                  <nav id="dropdown">
                    <ul>
                        <li class="active"><a href="#">Home</a>
                            <ul>
                                <li><a href="#">Sub Item</a></li>
                                <li><a href="#">Sub Item</a></li>
                                <li><a href="#">Sub Item</a></li>
                                <li><a href="#">Sub Item</a></li>
                                <li><a href="#">Sub Item</a></li>
                                <li><a href="#">Sub Item</a></li>
                                <li><a href="#">Sub Item</a></li>
                            </ul>
                        </li>
                        <li><a href="#">Projects</a></li>
                        <li><a href="#">Activities</a></li>
                        <li><a href="#">Total Jobs</a></li>
                        <li><a href="#">Flights</a></li>
                        <li><a href="#">Hotels</a></li>
                    </ul>
                  </nav>
                </div>
              </div>
            </div>
          </div>
        </div>
        <!-- mobile-menu-area end -->



    <div class="search-area has-border has-map">
        <div class="container-full">
            <div class="map-half">
                <iframe src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d387193.30594184523!2d-74.25986594809962!3d40.69714941820045!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x89c24fa5d33f083b%3A0xc80b8f06e177fe62!2sNew+York%2C+NY%2C+USA!5e0!3m2!1sen!2sbd!4v1540485618034"  frameborder="0" style="border:0" allowfullscreen></iframe>
            </div>
            <div class="scroll-content">

                <form class="searcg-form u-padding-t-20">
                    <h3 class="title">Find Your Perfect Activity</h3>

                    <div class="tf-row row">
                                <div class="tf-col col-sm-6">
                                    <label for="desti">Where</label>
                                    <div class="map mb-2">
                                        <label for="desti"><i class="fa fa-map-marker"></i></label>
                                        <input id="desti" type="text" class="form-control" placeholder="Destination: Zip Code">
                                    </div>
                                </div>
                                <div class="tf-col  col-lg-3">
                                    <label>Departure date</label>
                                    <input type="text" class="datepicker form-control" placeholder="dd/mm/yy">
                                </div>
                                <div class="tf-col col-lg-3">
                                    <label>Arrival Date</label>
                                    <input type="text" class="datepicker form-control" placeholder="dd/mm/yy">
                                    </select>
                                </div>

                                
                                <div class="col-12 col-sm-12">
                                     <button class="opt-ctrl" type="button"><span>+</span>Advance Search</button>
                                </div>

                                <div class="advance-opt col-lg-12">
                                    <div class="list-block">
                                        <h3>Hotel Theme</h3>
                                        <div class="row">

                                            <div class="col-lg-4">

                                                <div class="custom-control custom-checkbox">
                                                    <input type="checkbox" class="custom-control-input" id="wc1">
                                                    <label class="custom-control-label" for="wc1">Airport Transport</label>
                                                </div>

                                                <div class="custom-control custom-checkbox">
                                                    <input type="checkbox" class="custom-control-input" id="wc2">
                                                    <label class="custom-control-label" for="wc2"> Bathroom</label>
                                                </div>

                                                <div class="custom-control custom-checkbox">
                                                    <input type="checkbox" class="custom-control-input" id="wc3">
                                                    <label class="custom-control-label" for="wc3">Casino</label>
                                                </div>

                                                <div class="custom-control custom-checkbox">
                                                    <input type="checkbox" class="custom-control-input" id="wc4">
                                                    <label class="custom-control-label" for="wc4">Breakfast in the room</label>
                                                </div>

                                                <div class="custom-control custom-checkbox">
                                                    <input type="checkbox" class="custom-control-input" id="wc5">
                                                    <label class="custom-control-label" for="wc5">Restaurant (buffet)</label>
                                                </div>


                                            </div>

                                            <div class="col-lg-4">

                                                <div class="custom-control custom-checkbox">
                                                    <input type="checkbox" class="custom-control-input" id="ec1">
                                                    <label class="custom-control-label" for="ec1">Airport Transport</label>
                                                </div>

                                                <div class="custom-control custom-checkbox">
                                                    <input type="checkbox" class="custom-control-input" id="ec2">
                                                    <label class="custom-control-label" for="ec2"> Bathroom</label>
                                                </div>

                                                <div class="custom-control custom-checkbox">
                                                    <input type="checkbox" class="custom-control-input" id="ec3">
                                                    <label class="custom-control-label" for="ec3">Casino</label>
                                                </div>

                                                <div class="custom-control custom-checkbox">
                                                    <input type="checkbox" class="custom-control-input" id="ec4">
                                                    <label class="custom-control-label" for="ec4">Breakfast in the room</label>
                                                </div>

                                                <div class="custom-control custom-checkbox">
                                                    <input type="checkbox" class="custom-control-input" id="ec5">
                                                    <label class="custom-control-label" for="ec5">Restaurant (buffet)</label>
                                                </div>

                                               

                                            </div>

                                            <div class="col-lg-4">

                                                <div class="custom-control custom-checkbox">
                                                    <input type="checkbox" class="custom-control-input" id="c1">
                                                    <label class="custom-control-label" for="c1">Airport Transport</label>
                                                </div>

                                                <div class="custom-control custom-checkbox">
                                                    <input type="checkbox" class="custom-control-input" id="c2">
                                                    <label class="custom-control-label" for="c2"> Bathroom</label>
                                                </div>

                                                <div class="custom-control custom-checkbox">
                                                    <input type="checkbox" class="custom-control-input" id="c3">
                                                    <label class="custom-control-label" for="c3">Casino</label>
                                                </div>

                                                <div class="custom-control custom-checkbox">
                                                    <input type="checkbox" class="custom-control-input" id="c4">
                                                    <label class="custom-control-label" for="c4">Breakfast in the room</label>
                                                </div>

                                                <div class="custom-control custom-checkbox">
                                                    <input type="checkbox" class="custom-control-input" id="c5">
                                                    <label class="custom-control-label" for="c5">Restaurant (buffet)</label>
                                                </div>

                                                

                                            </div>

                                        </div>
                                    </div>

                                    <div class="list-block">
                                        <h3>Room Facilitites</h3>
                                        <div class="row">

                                            <div class="col-lg-4">

                                                <div class="custom-control custom-checkbox">
                                                    <input type="checkbox" class="custom-control-input" id="d1">
                                                    <label class="custom-control-label" for="d1">Airport Transport</label>
                                                </div>

                                                <div class="custom-control custom-checkbox">
                                                    <input type="checkbox" class="custom-control-input" id="cc2">
                                                    <label class="custom-control-label" for="cc2"> Bathroom</label>
                                                </div>

                                                <div class="custom-control custom-checkbox">
                                                    <input type="checkbox" class="custom-control-input" id="c3">
                                                    <label class="custom-control-label" for="cc3">Casino</label>
                                                </div>

                                                <div class="custom-control custom-checkbox">
                                                    <input type="checkbox" class="custom-control-input" id="c4">
                                                    <label class="custom-control-label" for="cc4">Breakfast in the room</label>
                                                </div>

                                                <div class="custom-control custom-checkbox">
                                                    <input type="checkbox" class="custom-control-input" id="cc5">
                                                    <label class="custom-control-label" for="cc5">Restaurant (buffet)</label>
                                                </div>


                                            </div>

                                            <div class="col-lg-4">

                                                <div class="custom-control custom-checkbox">
                                                    <input type="checkbox" class="custom-control-input" id="cc1">
                                                    <label class="custom-control-label" for="cc1">Airport Transport</label>
                                                </div>

                                                <div class="custom-control custom-checkbox">
                                                    <input type="checkbox" class="custom-control-input" id="cc2">
                                                    <label class="custom-control-label" for="cc2"> Bathroom</label>
                                                </div>

                                                <div class="custom-control custom-checkbox">
                                                    <input type="checkbox" class="custom-control-input" id="cc3">
                                                    <label class="custom-control-label" for="cc3">Casino</label>
                                                </div>

                                                <div class="custom-control custom-checkbox">
                                                    <input type="checkbox" class="custom-control-input" id="cc4">
                                                    <label class="custom-control-label" for="cc4">Breakfast in the room</label>
                                                </div>

                                                <div class="custom-control custom-checkbox">
                                                    <input type="checkbox" class="custom-control-input" id="cc5">
                                                    <label class="custom-control-label" for="cc5">Restaurant (buffet)</label>
                                                </div>


                                            </div>

                                            <div class="col-lg-4">

                                                <div class="custom-control custom-checkbox">
                                                    <input type="checkbox" class="custom-control-input" id="ccc1">
                                                    <label class="custom-control-label" for="ccc1">Airport Transport</label>
                                                </div>

                                                <div class="custom-control custom-checkbox">
                                                    <input type="checkbox" class="custom-control-input" id="ccc2">
                                                    <label class="custom-control-label" for="ccc2"> Bathroom</label>
                                                </div>

                                                <div class="custom-control custom-checkbox">
                                                    <input type="checkbox" class="custom-control-input" id="ccc3">
                                                    <label class="custom-control-label" for="ccc3">Casino</label>
                                                </div>

                                                <div class="custom-control custom-checkbox">
                                                    <input type="checkbox" class="custom-control-input" id="ccc4">
                                                    <label class="custom-control-label" for="ccc4">Breakfast in the room</label>
                                                </div>

                                                <div class="custom-control custom-checkbox">
                                                    <input type="checkbox" class="custom-control-input" id="ccc5">
                                                    <label class="custom-control-label" for="ccc5">Restaurant (buffet)</label>
                                                </div>

                                            </div>

                                        </div>
                                    </div>

                                    <div class="bottom row">
                                        <div class="tf-col col-lg-6">
                                            <label for="dest2">Hotel Name</label>
                                            <div class="map mb-2">
                                                <label for="dest2">
                                                    <i class="fa fa-map-marker"></i>
                                                </label>
                                                <input id="dest2" type="text" class="form-control" placeholder="">
                                            </div>
                                        </div>

                                        <div class="tf-col tf-range col-lg-6">
                                            <input type="text" id="price-ranger1" name="priceRange">
                                        </div>
                                        
                                    </div>
                                </div>


                                <div class="col-12 col-lg-12">
                                    <div class="btn-area">
                                        <button class="btn btn-primary btn-md" type="submit">Search For Tour</button>
                                    </div>
                                </div>

                            </div>
                </form>




                <div class="content-search u-padding-t-30 u-padding-b-30">

                    <div class="sec-ti u-padding-b-20">
                        <h3 class="font-weight300">Advanced Search (12)</h3>
                    </div>
                    <div class="row">

                        <div class="col-sm-6">
                            <div class="tour-item">
                                    <a href="#" class="fig">
                                        <img src="<?php echo esc_url(get_template_directory_uri());?>/img/pexels-photo-338023-260x190.jpeg">
                                        <h4>Inter Continental New</h4>
                                    </a>
                                           
                                    <div class="content">

                                        <div class="left">
                                            <div class="location">
                                                <i class="fa fa-map-marker"></i>
                                                <span> Place Vendôme Paris</span>
                                            </div>
                                            <div class="price">
                                                <i class="fa fa-money"></i>
                                                <span>$1000,00</span>
                                            </div>
                                        </div>
                                        <div class="right">
                                            <div class="cal">
                                                <i class="fa fa-calendar"></i>
                                                <span>3</span>
                                            </div>
                                             <div class="stars">
                                                <i class="fa fa-star"></i>         
                                                <i class="fa fa-star"></i>         
                                                <i class="fa fa-star"></i>         
                                                <i class="fa fa-star"></i>         
                                                <i class="fa fa-star"></i>         
                                            </div>
                                        </div>

      

                                    </div>
                            </div>
                        </div>


                        <div class="col-sm-6">
                            <div class="tour-item">
                                    <a href="#" class="fig">
                                        <img src="<?php echo esc_url(get_template_directory_uri());?>/img/pexels-photo-338023-260x190.jpeg">
                                        <h4>Inter Continental New</h4>
                                    </a>
                                           
                                    <div class="content">

                                        <div class="left">
                                            <div class="location">
                                                <i class="fa fa-map-marker"></i>
                                                <span> Place Vendôme Paris</span>
                                            </div>
                                            <div class="price">
                                                <i class="fa fa-money"></i>
                                                <span>$1000,00</span>
                                            </div>
                                        </div>
                                        <div class="right">
                                            <div class="cal">
                                                <i class="fa fa-calendar"></i>
                                                <span>3</span>
                                            </div>
                                             <div class="stars">
                                                <i class="fa fa-star"></i>         
                                                <i class="fa fa-star"></i>         
                                                <i class="fa fa-star"></i>         
                                                <i class="fa fa-star"></i>         
                                                <i class="fa fa-star"></i>         
                                            </div>
                                        </div>

      

                                    </div>
                            </div>
                        </div>


                        <div class="col-sm-6">
                            <div class="tour-item">
                                    <a href="#" class="fig">
                                        <img src="<?php echo esc_url(get_template_directory_uri());?>/img/pexels-photo-338023-260x190.jpeg">
                                        <h4>Inter Continental New</h4>
                                    </a>
                                           
                                    <div class="content">

                                        <div class="left">
                                            <div class="location">
                                                <i class="fa fa-map-marker"></i>
                                                <span> Place Vendôme Paris</span>
                                            </div>
                                            <div class="price">
                                                <i class="fa fa-money"></i>
                                                <span>$1000,00</span>
                                            </div>
                                        </div>
                                        <div class="right">
                                            <div class="cal">
                                                <i class="fa fa-calendar"></i>
                                                <span>3</span>
                                            </div>
                                             <div class="stars">
                                                <i class="fa fa-star"></i>         
                                                <i class="fa fa-star"></i>         
                                                <i class="fa fa-star"></i>         
                                                <i class="fa fa-star"></i>         
                                                <i class="fa fa-star"></i>         
                                            </div>
                                        </div>

      

                                    </div>
                            </div>
                        </div>


                        <div class="col-sm-6">
                            <div class="tour-item">
                                    <a href="#" class="fig">
                                        <img src="<?php echo esc_url(get_template_directory_uri());?>/img/pexels-photo-338023-260x190.jpeg">
                                        <h4>Inter Continental New</h4>
                                    </a>
                                           
                                    <div class="content">

                                        <div class="left">
                                            <div class="location">
                                                <i class="fa fa-map-marker"></i>
                                                <span> Place Vendôme Paris</span>
                                            </div>
                                            <div class="price">
                                                <i class="fa fa-money"></i>
                                                <span>$1000,00</span>
                                            </div>
                                        </div>
                                        <div class="right">
                                            <div class="cal">
                                                <i class="fa fa-calendar"></i>
                                                <span>3</span>
                                            </div>
                                             <div class="stars">
                                                <i class="fa fa-star"></i>         
                                                <i class="fa fa-star"></i>         
                                                <i class="fa fa-star"></i>         
                                                <i class="fa fa-star"></i>         
                                                <i class="fa fa-star"></i>         
                                            </div>
                                        </div>

      

                                    </div>
                            </div>
                        </div>


                        <div class="col-sm-6">
                            <div class="tour-item">
                                    <a href="#" class="fig">
                                        <img src="<?php echo esc_url(get_template_directory_uri());?>/img/pexels-photo-338023-260x190.jpeg">
                                        <h4>Inter Continental New</h4>
                                    </a>
                                           
                                    <div class="content">

                                        <div class="left">
                                            <div class="location">
                                                <i class="fa fa-map-marker"></i>
                                                <span> Place Vendôme Paris</span>
                                            </div>
                                            <div class="price">
                                                <i class="fa fa-money"></i>
                                                <span>$1000,00</span>
                                            </div>
                                        </div>
                                        <div class="right">
                                            <div class="cal">
                                                <i class="fa fa-calendar"></i>
                                                <span>3</span>
                                            </div>
                                             <div class="stars">
                                                <i class="fa fa-star"></i>         
                                                <i class="fa fa-star"></i>         
                                                <i class="fa fa-star"></i>         
                                                <i class="fa fa-star"></i>         
                                                <i class="fa fa-star"></i>         
                                            </div>
                                        </div>

      

                                    </div>
                            </div>
                        </div>


                        <div class="col-sm-6">
                            <div class="tour-item">
                                    <a href="#" class="fig">
                                        <img src="<?php echo esc_url(get_template_directory_uri());?>/img/pexels-photo-338023-260x190.jpeg">
                                        <h4>Inter Continental New</h4>
                                    </a>
                                           
                                    <div class="content">

                                        <div class="left">
                                            <div class="location">
                                                <i class="fa fa-map-marker"></i>
                                                <span> Place Vendôme Paris</span>
                                            </div>
                                            <div class="price">
                                                <i class="fa fa-money"></i>
                                                <span>$1000,00</span>
                                            </div>
                                        </div>
                                        <div class="right">
                                            <div class="cal">
                                                <i class="fa fa-calendar"></i>
                                                <span>3</span>
                                            </div>
                                             <div class="stars">
                                                <i class="fa fa-star"></i>         
                                                <i class="fa fa-star"></i>         
                                                <i class="fa fa-star"></i>         
                                                <i class="fa fa-star"></i>         
                                                <i class="fa fa-star"></i>         
                                            </div>
                                        </div>

      

                                    </div>
                            </div>
                        </div>


                    </div>
                </div>




            </div>
        </div>
    </div>






<?php get_footer();?>