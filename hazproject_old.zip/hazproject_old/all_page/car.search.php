<?php
/**
 * The car search template file
 *
 * This is the most generic template file in a WordPress theme
 * and one of the two required files for a theme (the other being style.css).
 * It is used to display a page when nothing more specific matches a query.
 * E.g., it puts together the home page when no home.php file exists.
 *
 * @link https://developer.wordpress.org/themes/basics/template-hierarchy/
 *
 * @package aynix
 */
 /*
  Template Name: car.search
*/
get_header(); ?>
      
      
        <!-- mobile-menu-area start -->
        <div class="mobile-menu-area">
          <div class="container">
            <div class="row">
              <div class="col-md-12">
                <div class="mobile-menu">
                  <nav id="dropdown">
                    <ul>
                        <li class="active"><a href="#">Home</a>
                            <ul>
                                <li><a href="#">Sub Item</a></li>
                                <li><a href="#">Sub Item</a></li>
                                <li><a href="#">Sub Item</a></li>
                                <li><a href="#">Sub Item</a></li>
                                <li><a href="#">Sub Item</a></li>
                                <li><a href="#">Sub Item</a></li>
                                <li><a href="#">Sub Item</a></li>
                            </ul>
                        </li>
                        <li><a href="#">Projects</a></li>
                        <li><a href="#">Activities</a></li>
                        <li><a href="#">Total Jobs</a></li>
                        <li><a href="#">Flights</a></li>
                        <li><a href="#">Hotels</a></li>
                    </ul>
                  </nav>
                </div>
              </div>
            </div>
          </div>
        </div>
        <!-- mobile-menu-area end -->



    <div class="search-area has-border u-padding-t-60">
        <div class="container">
            <form>
                        <h1 class="title">Search for Rental Cars</h1>
                            <div class="tf-row row">

                                <div class="tf-col col-lg-12">
                                    <label for="desti">Pick Up From</label>
                                    <div class="map mb-2">
                                        <label for="desti"><i class="fa fa-map-marker"></i></label>
                                        <input id="desti" type="text" class="form-control" placeholder="Destination: Zip Code">
                                    </div>
                                </div>
        
    
                                
                                <div class="tf-col tf-slect col-lg-3">
                                    <label>Pick-up Date</label>
                                    <input type="text" class="datepicker form-control" placeholder="dd/mm/yy">
                                </div>
                                
                                <div class="tf-col tf-slect col-lg-3">
                                    <label>Pick-up Time</label>
                                    <input type="text" class="timepicker form-control">
                                </div>

                                <div class="tf-col tf-slect col-lg-3">
                                    <label>Drop-off Date</label>
                                    <input placeholder="dd/mm/yy" type="text" class="datepicker form-control">
                                </div>


                                <div class="tf-col tf-slect col-lg-3">
                                    <label>Drop-off Time</label>
                                    <input type="text" class="timepicker form-control">
                                </div>

 
                                
                                <div class="col-12 col-sm-12">
                                     <button class="opt-ctrl" type="button"><span>+</span>Advance Search</button>
                                </div>

                                <div class="advance-opt col-lg-12">
                                    <div class="list-block">
                                        <h3>Hotel Theme</h3>
                                        <div class="row">

                                            <div class="col-lg-4">

                                                <div class="custom-control custom-checkbox">
                                                    <input type="checkbox" class="custom-control-input" id="wc1">
                                                    <label class="custom-control-label" for="wc1">Airport Transport</label>
                                                </div>

                                                <div class="custom-control custom-checkbox">
                                                    <input type="checkbox" class="custom-control-input" id="wc2">
                                                    <label class="custom-control-label" for="wc2"> Bathroom</label>
                                                </div>

                                                <div class="custom-control custom-checkbox">
                                                    <input type="checkbox" class="custom-control-input" id="wc3">
                                                    <label class="custom-control-label" for="wc3">Casino</label>
                                                </div>

                                                <div class="custom-control custom-checkbox">
                                                    <input type="checkbox" class="custom-control-input" id="wc4">
                                                    <label class="custom-control-label" for="wc4">Breakfast in the room</label>
                                                </div>

                                                <div class="custom-control custom-checkbox">
                                                    <input type="checkbox" class="custom-control-input" id="wc5">
                                                    <label class="custom-control-label" for="wc5">Restaurant (buffet)</label>
                                                </div>


                                            </div>

                                            <div class="col-lg-4">

                                                <div class="custom-control custom-checkbox">
                                                    <input type="checkbox" class="custom-control-input" id="ec1">
                                                    <label class="custom-control-label" for="ec1">Airport Transport</label>
                                                </div>

                                                <div class="custom-control custom-checkbox">
                                                    <input type="checkbox" class="custom-control-input" id="ec2">
                                                    <label class="custom-control-label" for="ec2"> Bathroom</label>
                                                </div>

                                                <div class="custom-control custom-checkbox">
                                                    <input type="checkbox" class="custom-control-input" id="ec3">
                                                    <label class="custom-control-label" for="ec3">Casino</label>
                                                </div>

                                                <div class="custom-control custom-checkbox">
                                                    <input type="checkbox" class="custom-control-input" id="ec4">
                                                    <label class="custom-control-label" for="ec4">Breakfast in the room</label>
                                                </div>

                                                <div class="custom-control custom-checkbox">
                                                    <input type="checkbox" class="custom-control-input" id="ec5">
                                                    <label class="custom-control-label" for="ec5">Restaurant (buffet)</label>
                                                </div>

                                               

                                            </div>

                                            <div class="col-lg-4">

                                                <div class="custom-control custom-checkbox">
                                                    <input type="checkbox" class="custom-control-input" id="c1">
                                                    <label class="custom-control-label" for="c1">Airport Transport</label>
                                                </div>

                                                <div class="custom-control custom-checkbox">
                                                    <input type="checkbox" class="custom-control-input" id="c2">
                                                    <label class="custom-control-label" for="c2"> Bathroom</label>
                                                </div>

                                                <div class="custom-control custom-checkbox">
                                                    <input type="checkbox" class="custom-control-input" id="c3">
                                                    <label class="custom-control-label" for="c3">Casino</label>
                                                </div>

                                                <div class="custom-control custom-checkbox">
                                                    <input type="checkbox" class="custom-control-input" id="c4">
                                                    <label class="custom-control-label" for="c4">Breakfast in the room</label>
                                                </div>

                                                <div class="custom-control custom-checkbox">
                                                    <input type="checkbox" class="custom-control-input" id="c5">
                                                    <label class="custom-control-label" for="c5">Restaurant (buffet)</label>
                                                </div>

                                                

                                            </div>

                                        </div>
                                    </div>

                                    <div class="list-block">
                                        <h3>Room Facilitites</h3>
                                        <div class="row">

                                            <div class="col-lg-4">

                                                <div class="custom-control custom-checkbox">
                                                    <input type="checkbox" class="custom-control-input" id="d1">
                                                    <label class="custom-control-label" for="d1">Airport Transport</label>
                                                </div>

                                                <div class="custom-control custom-checkbox">
                                                    <input type="checkbox" class="custom-control-input" id="cc2">
                                                    <label class="custom-control-label" for="cc2"> Bathroom</label>
                                                </div>

                                                <div class="custom-control custom-checkbox">
                                                    <input type="checkbox" class="custom-control-input" id="c3">
                                                    <label class="custom-control-label" for="cc3">Casino</label>
                                                </div>

                                                <div class="custom-control custom-checkbox">
                                                    <input type="checkbox" class="custom-control-input" id="c4">
                                                    <label class="custom-control-label" for="cc4">Breakfast in the room</label>
                                                </div>

                                                <div class="custom-control custom-checkbox">
                                                    <input type="checkbox" class="custom-control-input" id="cc5">
                                                    <label class="custom-control-label" for="cc5">Restaurant (buffet)</label>
                                                </div>


                                            </div>

                                            <div class="col-lg-4">

                                                <div class="custom-control custom-checkbox">
                                                    <input type="checkbox" class="custom-control-input" id="cc1">
                                                    <label class="custom-control-label" for="cc1">Airport Transport</label>
                                                </div>

                                                <div class="custom-control custom-checkbox">
                                                    <input type="checkbox" class="custom-control-input" id="cc2">
                                                    <label class="custom-control-label" for="cc2"> Bathroom</label>
                                                </div>

                                                <div class="custom-control custom-checkbox">
                                                    <input type="checkbox" class="custom-control-input" id="cc3">
                                                    <label class="custom-control-label" for="cc3">Casino</label>
                                                </div>

                                                <div class="custom-control custom-checkbox">
                                                    <input type="checkbox" class="custom-control-input" id="cc4">
                                                    <label class="custom-control-label" for="cc4">Breakfast in the room</label>
                                                </div>

                                                <div class="custom-control custom-checkbox">
                                                    <input type="checkbox" class="custom-control-input" id="cc5">
                                                    <label class="custom-control-label" for="cc5">Restaurant (buffet)</label>
                                                </div>


                                            </div>

                                            <div class="col-lg-4">

                                                <div class="custom-control custom-checkbox">
                                                    <input type="checkbox" class="custom-control-input" id="ccc1">
                                                    <label class="custom-control-label" for="ccc1">Airport Transport</label>
                                                </div>

                                                <div class="custom-control custom-checkbox">
                                                    <input type="checkbox" class="custom-control-input" id="ccc2">
                                                    <label class="custom-control-label" for="ccc2"> Bathroom</label>
                                                </div>

                                                <div class="custom-control custom-checkbox">
                                                    <input type="checkbox" class="custom-control-input" id="ccc3">
                                                    <label class="custom-control-label" for="ccc3">Casino</label>
                                                </div>

                                                <div class="custom-control custom-checkbox">
                                                    <input type="checkbox" class="custom-control-input" id="ccc4">
                                                    <label class="custom-control-label" for="ccc4">Breakfast in the room</label>
                                                </div>

                                                <div class="custom-control custom-checkbox">
                                                    <input type="checkbox" class="custom-control-input" id="ccc5">
                                                    <label class="custom-control-label" for="ccc5">Restaurant (buffet)</label>
                                                </div>

                                            </div>

                                        </div>
                                    </div>

                                    <div class="bottom row">
                                        <div class="tf-col col-lg-6">
                                            <label for="dest2">Hotel Name</label>
                                            <div class="map mb-2">
                                                <label for="dest2">
                                                    <i class="fa fa-map-marker"></i>
                                                </label>
                                                <input id="dest2" type="text" class="form-control" placeholder="">
                                            </div>
                                        </div>

                                        <div class="tf-col tf-range col-lg-6">
                                            <input type="text" id="price-ranger1" name="priceRange">
                                        </div>
                                        
                                    </div>






                                </div>


                                <div class="col-12 col-lg-12">
                                    <div class="btn-area">
                                        <button class="btn btn-primary btn-md" type="submit">Search For Car</button>
                                    </div>
                                </div>

                            </div>
                        </form>
        </div>
    </div>

    <div class="popural u-padding-t-50">
        <div class="container">
            <div class="sec-ti">
                <h2 class="font-weight300">Popular Destinations</h2>
            </div>
            <div class="row">

                <div class="col-sm-3">
                    <div class="pop-item">
                        <a href="#">
                            <img src="<?php echo esc_url(get_template_directory_uri());?>/img/Barclay-400x300.jpg">
                            <div class="content">
                                <h5>InterContinental New York Barclay</h5>
                                <p>5 reviews</p>
                                <p class="mb0">3 offers price from $130,00</p>
                            </div>
                        </a>
                    </div>
                </div>

                <div class="col-sm-3">
                    <div class="pop-item">
                        <a href="#">
                            <img src="<?php echo esc_url(get_template_directory_uri());?>/img/pexels-photo-97904-400x300.jpeg">
                            <div class="content">
                                <h5>InterContinental New York Barclay</h5>
                                <p>5 reviews</p>
                                <p class="mb0">3 offers price from $130,00</p>
                            </div>
                        </a>
                    </div>
                </div>

                <div class="col-sm-3">
                    <div class="pop-item">
                        <a href="#">
                            <img src="<?php echo esc_url(get_template_directory_uri());?>/img/Barclay-400x300.jpg">
                            <div class="content">
                                <h5>InterContinental New York Barclay</h5>
                                <p>5 reviews</p>
                                <p class="mb0">3 offers price from $130,00</p>
                            </div>
                        </a>
                    </div>
                </div>

                <div class="col-sm-3">
                    <div class="pop-item">
                        <a href="#">
                            <img src="<?php echo esc_url(get_template_directory_uri());?>/img/pexels-photo-97904-400x300.jpeg">
                            <div class="content">
                                <h5>InterContinental New York Barclay</h5>
                                <p>5 reviews</p>
                                <p class="mb0">3 offers price from $130,00</p>
                            </div>
                        </a>
                    </div>
                </div>

                <div class="col-sm-3">
                    <div class="pop-item">
                        <a href="#">
                            <img src="<?php echo esc_url(get_template_directory_uri());?>/img/Barclay-400x300.jpg">
                            <div class="content">
                                <h5>InterContinental New York Barclay</h5>
                                <p>5 reviews</p>
                                <p class="mb0">3 offers price from $130,00</p>
                            </div>
                        </a>
                    </div>
                </div>

                <div class="col-sm-3">
                    <div class="pop-item">
                        <a href="#">
                            <img src="<?php echo esc_url(get_template_directory_uri());?>/img/pexels-photo-97904-400x300.jpeg">
                            <div class="content">
                                <h5>InterContinental New York Barclay</h5>
                                <p>5 reviews</p>
                                <p class="mb0">3 offers price from $130,00</p>
                            </div>
                        </a>
                    </div>
                </div>

                <div class="col-sm-3">
                    <div class="pop-item">
                        <a href="#">
                            <img src="<?php echo esc_url(get_template_directory_uri());?>/img/Barclay-400x300.jpg">
                            <div class="content">
                                <h5>InterContinental New York Barclay</h5>
                                <p>5 reviews</p>
                                <p class="mb0">3 offers price from $130,00</p>
                            </div>
                        </a>
                    </div>
                </div>

                <div class="col-sm-3">
                    <div class="pop-item">
                        <a href="#">
                            <img src="<?php echo esc_url(get_template_directory_uri());?>/img/pexels-photo-97904-400x300.jpeg">
                            <div class="content">
                                <h5>InterContinental New York Barclay</h5>
                                <p>5 reviews</p>
                                <p class="mb0">3 offers price from $130,00</p>
                            </div>
                        </a>
                    </div>
                </div>

                <div class="col-sm-3">
                    <div class="pop-item">
                        <a href="#">
                            <img src="<?php echo esc_url(get_template_directory_uri());?>/img/Barclay-400x300.jpg">
                            <div class="content">
                                <h5>InterContinental New York Barclay</h5>
                                <p>5 reviews</p>
                                <p class="mb0">3 offers price from $130,00</p>
                            </div>
                        </a>
                    </div>
                </div>

                <div class="col-sm-3">
                    <div class="pop-item">
                        <a href="#">
                            <img src="<?php echo esc_url(get_template_directory_uri());?>/img/pexels-photo-97904-400x300.jpeg">
                            <div class="content">
                                <h5>InterContinental New York Barclay</h5>
                                <p>5 reviews</p>
                                <p class="mb0">3 offers price from $130,00</p>
                            </div>
                        </a>
                    </div>
                </div>

                <div class="col-sm-3">
                    <div class="pop-item">
                        <a href="#">
                            <img src="<?php echo esc_url(get_template_directory_uri());?>/img/Barclay-400x300.jpg">
                            <div class="content">
                                <h5>InterContinental New York Barclay</h5>
                                <p>5 reviews</p>
                                <p class="mb0">3 offers price from $130,00</p>
                            </div>
                        </a>
                    </div>
                </div>

                <div class="col-sm-3">
                    <div class="pop-item">
                        <a href="#">
                            <img src="<?php echo esc_url(get_template_directory_uri());?>/img/pexels-photo-97904-400x300.jpeg">
                            <div class="content">
                                <h5>InterContinental New York Barclay</h5>
                                <p>5 reviews</p>
                                <p class="mb0">3 offers price from $130,00</p>
                            </div>
                        </a>
                    </div>
                </div>

            </div>
        </div>
    </div>

    <div class="to-deal u-padding-t-20">
        <div class="container">
            <div class="sec-ti">
                <h2>Top Deals</h2>
            </div>
            <div class="row">

                <div class="col-12 col-sm-6 col-lg-3">
                    <div class="car-item-g">
                        <a href="#" class="fig">
                            <img src="<?php echo esc_url(get_template_directory_uri());?>/img/800x600.jpg">
                            <span class="reb">50%</span>
                        </a>
                               
                        <div class="content">
                            <h5><a href="#">InterContinental New</a></h5>
                            <div class="sub">Premium ,Standard</div>
                            <ul class="ico-set">
                                <li>
                                    <i class="fa fa-briefcase"></i>
                                    <span>x3</span>
                                </li>
                                <li>
                                    <i class="fa fa-male"></i>
                                    <span>Auto</span>
                                </li>
                                <li>
                                    <i class="fa fa-briefcase"></i>
                                    <span>x3</span>
                                </li>
                                <li>
                                    <i class="fa fa-briefcase"></i>
                                    <span>x4</span>
                                </li>
                                <li>
                                    <i class="fa fa-briefcase"></i>
                                    <span>x3</span>
                                </li>
                            </ul>
                        </div>

                        <div class="price">
                            <span class="old">$70,00</span>
                            <i class="fa fa-long-arrow-right"></i>
                            <span class="current">$66,50 /day</span>
                        </div>
                    </div>
                </div><!-- car item col -->



                <div class="col-12 col-sm-6 col-lg-3">
                    <div class="car-item-g">
                        <a href="#" class="fig">
                            <img src="<?php echo esc_url(get_template_directory_uri());?>/img/800x600.jpg">
                            <span class="reb">50%</span>
                        </a>
                               
                        <div class="content">
                            <h5><a href="#">InterContinental New</a></h5>
                            <div class="sub">Premium ,Standard</div>
                            <ul class="ico-set">
                                <li>
                                    <i class="fa fa-briefcase"></i>
                                    <span>x3</span>
                                </li>
                                <li>
                                    <i class="fa fa-male"></i>
                                    <span>Auto</span>
                                </li>
                                <li>
                                    <i class="fa fa-briefcase"></i>
                                    <span>x3</span>
                                </li>
                                <li>
                                    <i class="fa fa-briefcase"></i>
                                    <span>x4</span>
                                </li>
                                <li>
                                    <i class="fa fa-briefcase"></i>
                                    <span>x3</span>
                                </li>
                            </ul>
                        </div>

                        <div class="price">
                            <span class="old">$70,00</span>
                            <i class="fa fa-long-arrow-right"></i>
                            <span class="current">$66,50 /day</span>
                        </div>
                    </div>
                </div><!-- car item col -->



                <div class="col-12 col-sm-6 col-lg-3">
                    <div class="car-item-g">
                        <a href="#" class="fig">
                            <img src="<?php echo esc_url(get_template_directory_uri());?>/img/800x600.jpg">
                            <span class="reb">50%</span>
                        </a>
                               
                        <div class="content">
                            <h5><a href="#">InterContinental New</a></h5>
                            <div class="sub">Premium ,Standard</div>
                            <ul class="ico-set">
                                <li>
                                    <i class="fa fa-briefcase"></i>
                                    <span>x3</span>
                                </li>
                                <li>
                                    <i class="fa fa-male"></i>
                                    <span>Auto</span>
                                </li>
                                <li>
                                    <i class="fa fa-briefcase"></i>
                                    <span>x3</span>
                                </li>
                                <li>
                                    <i class="fa fa-briefcase"></i>
                                    <span>x4</span>
                                </li>
                                <li>
                                    <i class="fa fa-briefcase"></i>
                                    <span>x3</span>
                                </li>
                            </ul>
                        </div>

                        <div class="price">
                            <span class="old">$70,00</span>
                            <i class="fa fa-long-arrow-right"></i>
                            <span class="current">$66,50 /day</span>
                        </div>
                    </div>
                </div><!-- car item col -->



                <div class="col-12 col-sm-6 col-lg-3">
                    <div class="car-item-g">
                        <a href="#" class="fig">
                            <img src="<?php echo esc_url(get_template_directory_uri());?>/img/800x600.jpg">
                            <span class="reb">50%</span>
                        </a>
                               
                        <div class="content">
                            <h5><a href="#">InterContinental New</a></h5>
                            <div class="sub">Premium ,Standard</div>
                            <ul class="ico-set">
                                <li>
                                    <i class="fa fa-briefcase"></i>
                                    <span>x3</span>
                                </li>
                                <li>
                                    <i class="fa fa-male"></i>
                                    <span>Auto</span>
                                </li>
                                <li>
                                    <i class="fa fa-briefcase"></i>
                                    <span>x3</span>
                                </li>
                                <li>
                                    <i class="fa fa-briefcase"></i>
                                    <span>x4</span>
                                </li>
                                <li>
                                    <i class="fa fa-briefcase"></i>
                                    <span>x3</span>
                                </li>
                            </ul>
                        </div>

                        <div class="price">
                            <span class="old">$70,00</span>
                            <i class="fa fa-long-arrow-right"></i>
                            <span class="current">$66,50 /day</span>
                        </div>
                    </div>
                </div><!-- car item col -->



                <div class="col-12 col-sm-6 col-lg-3">
                    <div class="car-item-g">
                        <a href="#" class="fig">
                            <img src="<?php echo esc_url(get_template_directory_uri());?>/img/800x600.jpg">
                            <span class="reb">50%</span>
                        </a>
                               
                        <div class="content">
                            <h5><a href="#">InterContinental New</a></h5>
                            <div class="sub">Premium ,Standard</div>
                            <ul class="ico-set">
                                <li>
                                    <i class="fa fa-briefcase"></i>
                                    <span>x3</span>
                                </li>
                                <li>
                                    <i class="fa fa-male"></i>
                                    <span>Auto</span>
                                </li>
                                <li>
                                    <i class="fa fa-briefcase"></i>
                                    <span>x3</span>
                                </li>
                                <li>
                                    <i class="fa fa-briefcase"></i>
                                    <span>x4</span>
                                </li>
                                <li>
                                    <i class="fa fa-briefcase"></i>
                                    <span>x3</span>
                                </li>
                            </ul>
                        </div>

                        <div class="price">
                            <span class="old">$70,00</span>
                            <i class="fa fa-long-arrow-right"></i>
                            <span class="current">$66,50 /day</span>
                        </div>
                    </div>
                </div><!-- car item col -->



                <div class="col-12 col-sm-6 col-lg-3">
                    <div class="car-item-g">
                        <a href="#" class="fig">
                            <img src="<?php echo esc_url(get_template_directory_uri());?>/img/800x600.jpg">
                            <span class="reb">50%</span>
                        </a>
                               
                        <div class="content">
                            <h5><a href="#">InterContinental New</a></h5>
                            <div class="sub">Premium ,Standard</div>
                            <ul class="ico-set">
                                <li>
                                    <i class="fa fa-briefcase"></i>
                                    <span>x3</span>
                                </li>
                                <li>
                                    <i class="fa fa-male"></i>
                                    <span>Auto</span>
                                </li>
                                <li>
                                    <i class="fa fa-briefcase"></i>
                                    <span>x3</span>
                                </li>
                                <li>
                                    <i class="fa fa-briefcase"></i>
                                    <span>x4</span>
                                </li>
                                <li>
                                    <i class="fa fa-briefcase"></i>
                                    <span>x3</span>
                                </li>
                            </ul>
                        </div>

                        <div class="price">
                            <span class="old">$70,00</span>
                            <i class="fa fa-long-arrow-right"></i>
                            <span class="current">$66,50 /day</span>
                        </div>
                    </div>
                </div><!-- car item col -->



                <div class="col-12 col-sm-6 col-lg-3">
                    <div class="car-item-g">
                        <a href="#" class="fig">
                            <img src="<?php echo esc_url(get_template_directory_uri());?>/img/800x600.jpg">
                            <span class="reb">50%</span>
                        </a>
                               
                        <div class="content">
                            <h5><a href="#">InterContinental New</a></h5>
                            <div class="sub">Premium ,Standard</div>
                            <ul class="ico-set">
                                <li>
                                    <i class="fa fa-briefcase"></i>
                                    <span>x3</span>
                                </li>
                                <li>
                                    <i class="fa fa-male"></i>
                                    <span>Auto</span>
                                </li>
                                <li>
                                    <i class="fa fa-briefcase"></i>
                                    <span>x3</span>
                                </li>
                                <li>
                                    <i class="fa fa-briefcase"></i>
                                    <span>x4</span>
                                </li>
                                <li>
                                    <i class="fa fa-briefcase"></i>
                                    <span>x3</span>
                                </li>
                            </ul>
                        </div>

                        <div class="price">
                            <span class="old">$70,00</span>
                            <i class="fa fa-long-arrow-right"></i>
                            <span class="current">$66,50 /day</span>
                        </div>
                    </div>
                </div><!-- car item col -->



                <div class="col-12 col-sm-6 col-lg-3">
                    <div class="car-item-g">
                        <a href="#" class="fig">
                            <img src="<?php echo esc_url(get_template_directory_uri());?>/img/800x600.jpg">
                            <span class="reb">50%</span>
                        </a>
                               
                        <div class="content">
                            <h5><a href="#">InterContinental New</a></h5>
                            <div class="sub">Premium ,Standard</div>
                            <ul class="ico-set">
                                <li>
                                    <i class="fa fa-briefcase"></i>
                                    <span>x3</span>
                                </li>
                                <li>
                                    <i class="fa fa-male"></i>
                                    <span>Auto</span>
                                </li>
                                <li>
                                    <i class="fa fa-briefcase"></i>
                                    <span>x3</span>
                                </li>
                                <li>
                                    <i class="fa fa-briefcase"></i>
                                    <span>x4</span>
                                </li>
                                <li>
                                    <i class="fa fa-briefcase"></i>
                                    <span>x3</span>
                                </li>
                            </ul>
                        </div>

                        <div class="price">
                            <span class="old">$70,00</span>
                            <i class="fa fa-long-arrow-right"></i>
                            <span class="current">$66,50 /day</span>
                        </div>
                    </div>
                </div><!-- car item col -->



                <div class="col-12 col-sm-6 col-lg-3">
                    <div class="car-item-g">
                        <a href="#" class="fig">
                            <img src="<?php echo esc_url(get_template_directory_uri());?>/img/800x600.jpg">
                            <span class="reb">50%</span>
                        </a>
                               
                        <div class="content">
                            <h5><a href="#">InterContinental New</a></h5>
                            <div class="sub">Premium ,Standard</div>
                            <ul class="ico-set">
                                <li>
                                    <i class="fa fa-briefcase"></i>
                                    <span>x3</span>
                                </li>
                                <li>
                                    <i class="fa fa-male"></i>
                                    <span>Auto</span>
                                </li>
                                <li>
                                    <i class="fa fa-briefcase"></i>
                                    <span>x3</span>
                                </li>
                                <li>
                                    <i class="fa fa-briefcase"></i>
                                    <span>x4</span>
                                </li>
                                <li>
                                    <i class="fa fa-briefcase"></i>
                                    <span>x3</span>
                                </li>
                            </ul>
                        </div>

                        <div class="price">
                            <span class="old">$70,00</span>
                            <i class="fa fa-long-arrow-right"></i>
                            <span class="current">$66,50 /day</span>
                        </div>
                    </div>
                </div><!-- car item col -->



                <div class="col-12 col-sm-6 col-lg-3">
                    <div class="car-item-g">
                        <a href="#" class="fig">
                            <img src="<?php echo esc_url(get_template_directory_uri());?>/img/800x600.jpg">
                            <span class="reb">50%</span>
                        </a>
                               
                        <div class="content">
                            <h5><a href="#">InterContinental New</a></h5>
                            <div class="sub">Premium ,Standard</div>
                            <ul class="ico-set">
                                <li>
                                    <i class="fa fa-briefcase"></i>
                                    <span>x3</span>
                                </li>
                                <li>
                                    <i class="fa fa-male"></i>
                                    <span>Auto</span>
                                </li>
                                <li>
                                    <i class="fa fa-briefcase"></i>
                                    <span>x3</span>
                                </li>
                                <li>
                                    <i class="fa fa-briefcase"></i>
                                    <span>x4</span>
                                </li>
                                <li>
                                    <i class="fa fa-briefcase"></i>
                                    <span>x3</span>
                                </li>
                            </ul>
                        </div>

                        <div class="price">
                            <span class="old">$70,00</span>
                            <i class="fa fa-long-arrow-right"></i>
                            <span class="current">$66,50 /day</span>
                        </div>
                    </div>
                </div><!-- car item col -->



                <div class="col-12 col-sm-6 col-lg-3">
                    <div class="car-item-g">
                        <a href="#" class="fig">
                            <img src="<?php echo esc_url(get_template_directory_uri());?>/img/800x600.jpg">
                            <span class="reb">50%</span>
                        </a>
                               
                        <div class="content">
                            <h5><a href="#">InterContinental New</a></h5>
                            <div class="sub">Premium ,Standard</div>
                            <ul class="ico-set">
                                <li>
                                    <i class="fa fa-briefcase"></i>
                                    <span>x3</span>
                                </li>
                                <li>
                                    <i class="fa fa-male"></i>
                                    <span>Auto</span>
                                </li>
                                <li>
                                    <i class="fa fa-briefcase"></i>
                                    <span>x3</span>
                                </li>
                                <li>
                                    <i class="fa fa-briefcase"></i>
                                    <span>x4</span>
                                </li>
                                <li>
                                    <i class="fa fa-briefcase"></i>
                                    <span>x3</span>
                                </li>
                            </ul>
                        </div>

                        <div class="price">
                            <span class="old">$70,00</span>
                            <i class="fa fa-long-arrow-right"></i>
                            <span class="current">$66,50 /day</span>
                        </div>
                    </div>
                </div><!-- car item col -->



                <div class="col-12 col-sm-6 col-lg-3">
                    <div class="car-item-g">
                        <a href="#" class="fig">
                            <img src="<?php echo esc_url(get_template_directory_uri());?>/img/800x600.jpg">
                            <span class="reb">50%</span>
                        </a>
                               
                        <div class="content">
                            <h5><a href="#">InterContinental New</a></h5>
                            <div class="sub">Premium ,Standard</div>
                            <ul class="ico-set">
                                <li>
                                    <i class="fa fa-briefcase"></i>
                                    <span>x3</span>
                                </li>
                                <li>
                                    <i class="fa fa-male"></i>
                                    <span>Auto</span>
                                </li>
                                <li>
                                    <i class="fa fa-briefcase"></i>
                                    <span>x3</span>
                                </li>
                                <li>
                                    <i class="fa fa-briefcase"></i>
                                    <span>x4</span>
                                </li>
                                <li>
                                    <i class="fa fa-briefcase"></i>
                                    <span>x3</span>
                                </li>
                            </ul>
                        </div>

                        <div class="price">
                            <span class="old">$70,00</span>
                            <i class="fa fa-long-arrow-right"></i>
                            <span class="current">$66,50 /day</span>
                        </div>
                    </div>
                </div><!-- car item col -->



            </div>
        </div>
    </div>


<?php get_footer();?>