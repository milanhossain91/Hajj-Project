<?php
/**
 * The car details template file
 *
 * This is the most generic template file in a WordPress theme
 * and one of the two required files for a theme (the other being style.css).
 * It is used to display a page when nothing more specific matches a query.
 * E.g., it puts together the home page when no home.php file exists.
 *
 * @link https://developer.wordpress.org/themes/basics/template-hierarchy/
 *
 * @package aynix
 */
 /*
  Template Name: car.details
*/
get_header(); ?>
        <!-- mobile-menu-area start -->
        <div class="mobile-menu-area">
          <div class="container">
            <div class="row">
              <div class="col-md-12">
                <div class="mobile-menu">
                  <nav id="dropdown">
                    <ul>
                        <li class="active"><a href="#">Home</a>
                            <ul>
                                <li><a href="#">Sub Item</a></li>
                                <li><a href="#">Sub Item</a></li>
                                <li><a href="#">Sub Item</a></li>
                                <li><a href="#">Sub Item</a></li>
                                <li><a href="#">Sub Item</a></li>
                                <li><a href="#">Sub Item</a></li>
                                <li><a href="#">Sub Item</a></li>
                            </ul>
                        </li>
                        <li><a href="#">Projects</a></li>
                        <li><a href="#">Activities</a></li>
                        <li><a href="#">Total Jobs</a></li>
                        <li><a href="#">Flights</a></li>
                        <li><a href="#">Hotels</a></li>
                    </ul>
                  </nav>
                </div>
              </div>
            </div>
          </div>
        </div>
        <!-- mobile-menu-area end -->



    <div class="det-area car-det has-border u-padding-t-60 u-padding-b-60">
        <div class="container">
            <div class="det-top">
                <div class="left">
                    <h3>Maserati GranTurismo</h3>
                    <ul>
                        <li><i class="fa fa-envelope"></i>Agent E-mail</li>
                        <li><i class="fa fa-phone"></i> +123456789</li>
                    </ul>
                </div>
                <div class="right">
                    <div class="prices">
                        <div class="old">
                            Price <span>$70,00</span>
                        </div>
                        <i class="fa fa-long-arrow-right"></i>
                        <div class="cr-price">
                            $66,50 <small>/day</small>
                        </div>
                    </div>
                </div>
            </div>

            <div class="row">

                <div class="col-lg-8 col-12">
                    <div class="content-fig">
                        <div class="content-top">
                            <div class="img-slider">

                                <img src="<?php echo esc_url(get_template_directory_uri());?>/img/800x600.jpg">
                                
                            </div>

                            <div class="car-info">
                                <div class="sec-calc">
                                    <div class="calc-left">

                                        <div class="custom-control custom-checkbox">
                                            <input data-cal="3500" type="checkbox" class="custom-control-input" id="cc5">
                                            <label class="custom-control-label" for="cc5">Child Toddler Seat <span>$35,00</span></label>
                                        </div>
                                        

                                        <div class="custom-control custom-checkbox">
                                            <input data-cal="4000" type="checkbox" class="custom-control-input" id="cc6">
                                            <label class="custom-control-label" for="cc6">Ski Rack <span>$40,00</span></label>
                                        </div>
                                        

                                        <div class="custom-control custom-checkbox">
                                            <input data-cal="3500" type="checkbox" class="custom-control-input" id="cc7">
                                            <label class="custom-control-label" for="cc7">Infant Child Seat<span>$35,00</span></label>
                                        </div>
                                        

                                        <div class="custom-control custom-checkbox">
                                            <input data-cal="10000" type="checkbox" class="custom-control-input" id="cc8">
                                            <label class="custom-control-label" for="cc8">GPS Satellite <span>$100,00</span></label>
                                        </div>
                                    </div>
                                    <div class="res-right">
                                        <ul>
                                            <li>Price Per Day <span>$66,55</span></li>
                                            <li>Equipment <span>Free</span></li>
                                        </ul>
                                        <a data-toggle="modal" data-target="#booknowmodal" class="btn btn-primary" href="#">Book Now</a>
                                    </div>
                                    
                                </div>

                                <div class="disc-info">
                                    <h4>Discount Information</h4>
                                    <div class="table-responsive">
                                        <table class="table table-bordered">
                                            <tbody>
                                                <tr>
                                                    <th>#</th>
                                                    <th>Title</th>
                                                    <th>Number (Day)</th>
                                                    <th>Price</th>
                                                </tr>
                                                                <tr>
                                                    <td>1</td>
                                                    <td>Package 1</td>
                                                    <td>3 - 5</td>
                                                    <td>$70,00   
                                                    <i class="fa fa-arrow-right" style="padding: 3px "></i>
                                                        $60,00</td>
                                                </tr>
                                                                <tr>
                                                    <td>2</td>
                                                    <td>Package 2</td>
                                                    <td>6 - 12</td>
                                                    <td>$70,00                        
                                                    <i class="fa fa-arrow-right" style="padding: 3px "></i>
                                                        $55,00</td>
                                                </tr>
                                                                <tr>
                                                    <td>3</td>
                                                    <td>Package 3</td>
                                                    <td>13 - 20</td>
                                                    <td>$70,00                        
                                                    <i class="fa fa-arrow-right" style="padding: 3px "></i>
                                                        $45,00</td>
                                                </tr>
                                            </tbody>
                                        </table>
                                    </div>
                                </div>
                            </div>


                        </div>

                        <div class="car-des">
                            <h4>Car description:</h4>
                            <p>Arrive at your destination in style with this air-conditioned automatic. With room for 4 passengers and 2 pieces of luggage, it's ideal for small groups looking to get from A to B in comfort. Price can change at any moment so book now to avoid disappointment!</p>
                        </div>

                        <div class="car-feat">
                            <div class="feat-bl">
                                <h4>Car Features</h4>
                                <ul>
                                    <li>
                                       <i class="fa fa-briefcase"></i>
                                       <span>2 Pieces of Luggage</span>
                                    </li>
                                    <li>
                                       <i class="fa fa-briefcase"></i>
                                       <span>3 Doors</span>
                                    </li>
                                    <li>
                                       <i class="fa fa-briefcase"></i>
                                       <span>Automatic Transmission</span>
                                    </li>
                                    <li>
                                       <i class="fa fa-briefcase"></i>
                                       <span>Up to 4 Passengers</span>
                                    </li>
                                    <li>
                                       <i class="fa fa-briefcase"></i>
                                       <span>Gas Vehicle</span>
                                    </li>
                                </ul>
                            </div>
                            <div class="feat-bl">
                                <h4>Default Equipment</h4>
                                <ul>
                                    <li>
                                       <i class="fa fa-briefcase"></i>
                                       <span>Climate Control</span>
                                    </li>
                                    <li>
                                       <i class="fa fa-briefcase"></i>
                                       <span>FM Radio</span>
                                    </li>
                                    <li>
                                       <i class="fa fa-briefcase"></i>
                                       <span>Power Door Locks</span>
                                    </li>
                                    <li>
                                       <i class="fa fa-briefcase"></i>
                                       <span>Power Windows</span>
                                    </li>
                                    <li>
                                       <i class="fa fa-briefcase"></i>
                                       <span>Stereo CD/MP3</span>
                                    </li>
                                </ul>
                            </div>
                            <div class="feat-bl">
                                <h4>Pickup Features</h4>
                                <ul>
                                    <li>
                                       <i class="fa fa-briefcase"></i>
                                       <span>2 Pieces of Luggage</span>
                                    </li>
                                </ul>
                            </div>

                        </div>
                    </div>
                </div> <!-- col-8 end -->

                <div class="col-lg-4 col-12">
                    <div class="info-car-brand">
                        <div class="fig-top">
                            <img src="<?php echo esc_url(get_template_directory_uri());?>/img/br1.jpg">
                            <h6>Maserati</h6>
                        </div>

                        <ul>
                            <li>
                                <h5>Phone:</h5>
                                <p><i class="fa fa-phone box-icon-inline box-icon-gray"></i>+123456789</p>
                            </li>
                             <li>
                                <h5>Email:</h5>
                                <p><i class="fa fa-envelope-o box-icon-inline box-icon-gray"></i>abc@domain.com</p>
                            </li>

                            <li><h5>Pick Up:</h5>
                                <p><i class="fa fa-map-marker box-icon-inline box-icon-gray"></i>none</p>
                                <p><i class="fa fa-calendar box-icon-inline box-icon-gray"></i>01/11/2018</p>
                                <p><i class="fa fa-clock-o box-icon-inline box-icon-gray"></i>12:00 AM</p>
                            </li>
                            <li>   
                                <h5>Drop Off:</h5>
                                <p><i class="fa fa-map-marker box-icon-inline box-icon-gray"></i>none</p>
                                <p><i class="fa fa-calendar box-icon-inline box-icon-gray"></i>02/11/2018</p>
                                <p><i class="fa fa-clock-o box-icon-inline box-icon-gray"></i>12:00 AM</p>
                            </li>
                        </ul>
                        <a data-toggle="modal" data-target="#booknowmodal" class="btn btn-primary" href="#">Change Location & Date</a>
                    </div>
                </div>
            </div>
        </div>
    </div>

<?php get_footer();?>