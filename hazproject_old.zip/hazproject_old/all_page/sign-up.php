<?php
/**
 * The signup template file
 *
 * This is the most generic template file in a WordPress theme
 * and one of the two required files for a theme (the other being style.css).
 * It is used to display a page when nothing more specific matches a query.
 * E.g., it puts together the home page when no home.php file exists.
 *
 * @link https://developer.wordpress.org/themes/basics/template-hierarchy/
 *
 * @package aynix
 */
 /*
  Template Name: signup
*/
get_header(); ?>
 
         <!-- mobile-menu-area start -->
        <div class="mobile-menu-area">
          <div class="container">
            <div class="row">
              <div class="col-md-12">
                <div class="mobile-menu">
                  <nav id="dropdown">
                    <ul>
                        <li class="active"><a href="#">Home</a>
                            <ul>
                                <li><a href="#">Sub Item</a></li>
                                <li><a href="#">Sub Item</a></li>
                                <li><a href="#">Sub Item</a></li>
                                <li><a href="#">Sub Item</a></li>
                                <li><a href="#">Sub Item</a></li>
                                <li><a href="#">Sub Item</a></li>
                                <li><a href="#">Sub Item</a></li>
                            </ul>
                        </li>
                        <li><a href="#">Projects</a></li>
                        <li><a href="#">Activities</a></li>
                        <li><a href="#">Total Jobs</a></li>
                        <li><a href="#">Flights</a></li>
                        <li><a href="#">Hotels</a></li>
                    </ul>
                  </nav>
                </div>
              </div>
            </div>
          </div>
        </div>
        <!-- mobile-menu-area end -->





    














  <div class="user-page has-border">
    <div class="container">

        
        
        <div class="row u-flex--content-center">
            <div class="col-sm-8">
                <div class="intro text-center">
            <h2>Register on our site for - Activity - Rental - Flight Booking</h2>
        </div>
                <form  class="register_form" data-reset="false"  method="post" action="#" >

    <div class="row u-margin-b-30">
        <div class="col-md-12">


            <div class="form-group  form-group-icon-left">
                <label for="field-password">Select User Type</label>
            </div>
        </div>
        <div class="col-md-6 mt20">

            <div class="custom-control custom-radio">
                  <input type="radio" class="custom-control-input" id="customRadio" name="example1">
                  <label class="custom-control-label" for="customRadio">Normal User <br> <span>Used for booking services</span></label>
                </div>    

        </div>
        <div class="col-md-6 mt20">
                <div class="custom-control custom-radio">
                  <input type="radio" class="custom-control-input" id="customRadio2" name="example1">
                  <label class="custom-control-label" for="customRadio2">Partner<br> <span>Used for upload and booking services</span></label>
                </div>   
        </div>
    </div>
    <div class="row mt20 data_field">
        <div class="col-md-6">
            <div class="form-group  form-group-icon-left">
                <label for="field-user_name">User Name<span class="color-red"> (*)</span></label>
                <i class="fa fa-user input-icon input-icon-show"></i>
                <input id="field-user_name" name="user_name" class="form-control" placeholder="e.g. johndoe" type="text" value="" />
            </div>
        </div>
        <div class="col-md-6">
            <div class="form-group  form-group-icon-left">
                <label for="field-password">Password<span class="color-red"> (*)</span></label>
                <i class="fa fa-lock input-icon input-icon-show"></i>
                <input id="field-password" name="password" class="form-control" type="password" placeholder="my secret password" />
            </div>
        </div>
    </div>
    <div class="row mt20 data_field">
        <div class="col-md-6">
            <div class="form-group  form-group-icon-left">
                <label for="field-email">Email<span class="color-red"> (*)</span></label>
                <i class="fa fa-envelope input-icon input-icon-show"></i>
                <input id="field-email" name="email" class="form-control" placeholder="e.g. johndoe@gmail.com" type="text" value="" />
            </div>
        </div>
        <div class="col-md-6">
            <div class="form-group  form-group-icon-left">
                <label for="field-full_name">Full Name</label>
                <i class="fa fa-user input-icon input-icon-show"></i>
                <input id="field-full_name" name="full_name" class="form-control" placeholder="e.g. John Doe" type="text" value="" />
            </div>
        </div>
    </div>
    

            <div class="custom-control custom-checkbox u-margin-b-30">
                <input type="checkbox" class="custom-control-input" id="ec1">
                <label class="custom-control-label" for="ec1">
                    
                    I have read and accept the<a target="_blank" href="#"> terms and conditions</a> and <a href="#" target="_blank">Privacy Policy</a>        
                </label>
            </div>
        <div class="text-center mt20">
        <button class="btn btn-primary btn-lg" type="submit" >Register</button>
    </div>
</form>            
            </div>
        </div>

    </div>
  </div>


<?php get_footer();?>