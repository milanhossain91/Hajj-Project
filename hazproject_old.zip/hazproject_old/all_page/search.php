<?php
/**
 * The search template file
 *
 * This is the most generic template file in a WordPress theme
 * and one of the two required files for a theme (the other being style.css).
 * It is used to display a page when nothing more specific matches a query.
 * E.g., it puts together the home page when no home.php file exists.
 *
 * @link https://developer.wordpress.org/themes/basics/template-hierarchy/
 *
 * @package aynix
 */
 /*
  Template Name: search
*/
get_header(); ?>

  <!-- mobile-menu-area start -->
        <div class="mobile-menu-area">
          <div class="container">
            <div class="row">
              <div class="col-md-12">
                <div class="mobile-menu">
                  <nav id="dropdown">
                    <ul>
                        <li class="active"><a href="#">Home</a>
                            <ul>
                                <li><a href="#">Sub Item</a></li>
                                <li><a href="#">Sub Item</a></li>
                                <li><a href="#">Sub Item</a></li>
                                <li><a href="#">Sub Item</a></li>
                                <li><a href="#">Sub Item</a></li>
                                <li><a href="#">Sub Item</a></li>
                                <li><a href="#">Sub Item</a></li>
                            </ul>
                        </li>
                        <li><a href="#">Projects</a></li>
                        <li><a href="#">Activities</a></li>
                        <li><a href="#">Total Jobs</a></li>
                        <li><a href="#">Flights</a></li>
                        <li><a href="#">Hotels</a></li>
                    </ul>
                  </nav>
                </div>
              </div>
            </div>
          </div>
        </div>
        <!-- mobile-menu-area end -->



    <div class="search-area has-border has-map">
        <div class="container-full">
            <div class="map-half">
                <iframe src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d387193.30594184523!2d-74.25986594809962!3d40.69714941820045!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x89c24fa5d33f083b%3A0xc80b8f06e177fe62!2sNew+York%2C+NY%2C+USA!5e0!3m2!1sen!2sbd!4v1540485618034"  frameborder="0" style="border:0" allowfullscreen></iframe>
            </div>
            <div class="scroll-content">

                <form class="searcg-form u-padding-t-20">
                    <h3 class="title">Search !</h3>

                    <div class="tf-row row">
                                <div class="tf-col col-lg-12">
                                    <label for="desti">Pick Up From</label>
                                    <div class="map mb-2">
                                        <label for="desti"><i class="fa fa-map-marker"></i></label>
                                        <input id="desti" type="text" class="form-control" placeholder="Destination: Zip Code">
                                    </div>
                                </div>
        
    
                                
                                <div class="tf-col tf-slect col-lg-3">
                                    <label>Pick-up Date</label>
                                    <input type="text" class="datepicker form-control" placeholder="dd/mm/yy">
                                </div>
                                
                                <div class="tf-col tf-slect col-lg-3">
                                    <label>Pick-up Time</label>
                                    <input type="text" class="timepicker form-control">
                                </div>

                                <div class="tf-col tf-slect col-lg-3">
                                    <label>Drop-off Date</label>
                                    <input placeholder="dd/mm/yy" type="text" class="datepicker form-control">
                                </div>


                                <div class="tf-col tf-slect col-lg-3">
                                    <label>Drop-off Time</label>
                                    <input type="text" class="timepicker form-control">
                                </div>

 

                         
                                <div class="col-lg-12">
                                     <button class="opt-ctrl" type="button"><span>+</span>Advance Search</button>
                                </div>

                                <div class="advance-opt col-lg-12">
                                    <div class="list-block">
                                        <h3>Car Features</h3>
                                        <div class="row">

                                            <div class="col-lg-4">


                                                <div class="custom-control custom-checkbox">
                                                    <input type="checkbox" class="custom-control-input" id="c6">
                                                    <label class="custom-control-label" for="c6">Satellite Channels</label>
                                                </div>

                                                <div class="custom-control custom-checkbox">
                                                    <input type="checkbox" class="custom-control-input" id="c7">
                                                    <label class="custom-control-label" for="c7">Spa and wellness centre</label>
                                                </div>

                                                <div class="custom-control custom-checkbox">
                                                    <input type="checkbox" class="custom-control-input" id="c8">
                                                    <label class="custom-control-label" for="c8">Airport Transport</label>
                                                </div>

                                                <div class="custom-control custom-checkbox">
                                                    <input type="checkbox" class="custom-control-input" id="c9">
                                                    <label class="custom-control-label" for="c9">Fitness Center</label>
                                                </div>

                                                <div class="custom-control custom-checkbox">
                                                    <input type="checkbox" class="custom-control-input" id="c10">
                                                    <label class="custom-control-label" for="c10">Cable Channels</label>
                                                </div>

                                            </div>

                                            <div class="col-lg-4">


                                                <div class="custom-control custom-checkbox">
                                                    <input type="checkbox" class="custom-control-input" id="c6">
                                                    <label class="custom-control-label" for="c6">Satellite Channels</label>
                                                </div>

                                                <div class="custom-control custom-checkbox">
                                                    <input type="checkbox" class="custom-control-input" id="c7">
                                                    <label class="custom-control-label" for="c7">Spa and wellness centre</label>
                                                </div>

                                                <div class="custom-control custom-checkbox">
                                                    <input type="checkbox" class="custom-control-input" id="c8">
                                                    <label class="custom-control-label" for="c8">Airport Transport</label>
                                                </div>

                                                <div class="custom-control custom-checkbox">
                                                    <input type="checkbox" class="custom-control-input" id="c9">
                                                    <label class="custom-control-label" for="c9">Fitness Center</label>
                                                </div>

                                                <div class="custom-control custom-checkbox">
                                                    <input type="checkbox" class="custom-control-input" id="c10">
                                                    <label class="custom-control-label" for="c10">Cable Channels</label>
                                                </div>

                                            </div>

                                            <div class="col-lg-4">


                                                <div class="custom-control custom-checkbox">
                                                    <input type="checkbox" class="custom-control-input" id="c6">
                                                    <label class="custom-control-label" for="c6">Satellite Channels</label>
                                                </div>

                                                <div class="custom-control custom-checkbox">
                                                    <input type="checkbox" class="custom-control-input" id="c7">
                                                    <label class="custom-control-label" for="c7">Spa and wellness centre</label>
                                                </div>

                                                <div class="custom-control custom-checkbox">
                                                    <input type="checkbox" class="custom-control-input" id="c8">
                                                    <label class="custom-control-label" for="c8">Airport Transport</label>
                                                </div>

                                                <div class="custom-control custom-checkbox">
                                                    <input type="checkbox" class="custom-control-input" id="c9">
                                                    <label class="custom-control-label" for="c9">Fitness Center</label>
                                                </div>

                                                <div class="custom-control custom-checkbox">
                                                    <input type="checkbox" class="custom-control-input" id="c10">
                                                    <label class="custom-control-label" for="c10">Cable Channels</label>
                                                </div>

                                            </div>

                                        </div>
                                    </div>

                                    <div class="list-block">
                                        <h3>Room Facilitites</h3>
                                        <div class="row">

                                            <div class="col-lg-4">

                                                <div class="custom-control custom-checkbox">
                                                    <input type="checkbox" class="custom-control-input" id="c6">
                                                    <label class="custom-control-label" for="c6">Satellite Channels</label>
                                                </div>

                                                <div class="custom-control custom-checkbox">
                                                    <input type="checkbox" class="custom-control-input" id="c7">
                                                    <label class="custom-control-label" for="c7">Spa and wellness centre</label>
                                                </div>

                                                <div class="custom-control custom-checkbox">
                                                    <input type="checkbox" class="custom-control-input" id="c8">
                                                    <label class="custom-control-label" for="c8">Airport Transport</label>
                                                </div>

                                                <div class="custom-control custom-checkbox">
                                                    <input type="checkbox" class="custom-control-input" id="c9">
                                                    <label class="custom-control-label" for="c9">Fitness Center</label>
                                                </div>

                                                <div class="custom-control custom-checkbox">
                                                    <input type="checkbox" class="custom-control-input" id="c10">
                                                    <label class="custom-control-label" for="c10">Cable Channels</label>
                                                </div>

                                            </div>

                                            <div class="col-lg-4">

                                                <div class="custom-control custom-checkbox">
                                                    <input type="checkbox" class="custom-control-input" id="c6">
                                                    <label class="custom-control-label" for="c6">Satellite Channels</label>
                                                </div>

                                                <div class="custom-control custom-checkbox">
                                                    <input type="checkbox" class="custom-control-input" id="c7">
                                                    <label class="custom-control-label" for="c7">Spa and wellness centre</label>
                                                </div>

                                                <div class="custom-control custom-checkbox">
                                                    <input type="checkbox" class="custom-control-input" id="c8">
                                                    <label class="custom-control-label" for="c8">Airport Transport</label>
                                                </div>

                                                <div class="custom-control custom-checkbox">
                                                    <input type="checkbox" class="custom-control-input" id="c9">
                                                    <label class="custom-control-label" for="c9">Fitness Center</label>
                                                </div>

                                                <div class="custom-control custom-checkbox">
                                                    <input type="checkbox" class="custom-control-input" id="c10">
                                                    <label class="custom-control-label" for="c10">Cable Channels</label>
                                                </div>

                                            </div>

                                            <div class="col-lg-4">
                                                <div class="custom-control custom-checkbox">
                                                    <input type="checkbox" class="custom-control-input" id="c6">
                                                    <label class="custom-control-label" for="c6">Satellite Channels</label>
                                                </div>

                                                <div class="custom-control custom-checkbox">
                                                    <input type="checkbox" class="custom-control-input" id="c7">
                                                    <label class="custom-control-label" for="c7">Spa and wellness centre</label>
                                                </div>

                                                <div class="custom-control custom-checkbox">
                                                    <input type="checkbox" class="custom-control-input" id="c8">
                                                    <label class="custom-control-label" for="c8">Airport Transport</label>
                                                </div>

                                                <div class="custom-control custom-checkbox">
                                                    <input type="checkbox" class="custom-control-input" id="c9">
                                                    <label class="custom-control-label" for="c9">Fitness Center</label>
                                                </div>

                                                <div class="custom-control custom-checkbox">
                                                    <input type="checkbox" class="custom-control-input" id="c10">
                                                    <label class="custom-control-label" for="c10">Cable Channels</label>
                                                </div>

                                            </div>

                                        </div>
                                    </div>

                                    <div class="bottom row">
                                        <div class="tf-col col-lg-6">
                                            <label for="dest2">Car Name</label>
                                            <div class="map mb-2">
                                                <label for="dest2">
                                                    <i class="fa fa-sort-amount-asc"></i>
                                                </label>
                                                <input id="dest2" type="text" class="form-control" placeholder="">
                                            </div>
                                        </div>

                                        <div class="tf-col tf-range col-lg-6">
                                            <input type="text" id="car-ranger1" name="priceRange">
                                        </div>
                                    </div>
                                </div>

                                <div class="col-lg-12">
                                    <div class="btn-area">
                                        <button class="btn btn-primary btn-md" type="submit">Search For Cars</button>
                                    </div>
                                </div>

                            </div>
                </form>

                <div class="popural content-search u-padding-t-30">

                    <div class="sec-ti u-padding-b-20">
                        <h3 class="font-weight300">Hotels in Popular Destinations</h3>
                    </div>

                    <div class="row">

                        <div class="col-sm-6">
                            <div class="pop-item">
                                <a href="#">
                                    <img src="<?php echo esc_url(get_template_directory_uri());?>/img/Barclay-400x300.jpg">
                                    <div class="content">
                                        <h5>InterContinental New York Barclay</h5>
                                        <p>5 reviews</p>
                                        <p class="mb0">3 offers price from $130,00</p>
                                    </div>
                                </a>
                            </div>
                        </div>

                        <div class="col-sm-6">
                            <div class="pop-item">
                                <a href="#">
                                    <img src="<?php echo esc_url(get_template_directory_uri());?>/img/pexels-photo-97904-400x300.jpeg">
                                    <div class="content">
                                        <h5>InterContinental New York Barclay</h5>
                                        <p>5 reviews</p>
                                        <p class="mb0">3 offers price from $130,00</p>
                                    </div>
                                </a>
                            </div>
                        </div>

                        <div class="col-sm-6">
                            <div class="pop-item">
                                <a href="#">
                                    <img src="<?php echo esc_url(get_template_directory_uri());?>/img/Barclay-400x300.jpg">
                                    <div class="content">
                                        <h5>InterContinental New York Barclay</h5>
                                        <p>5 reviews</p>
                                        <p class="mb0">3 offers price from $130,00</p>
                                    </div>
                                </a>
                            </div>
                        </div>

                        <div class="col-sm-6">
                            <div class="pop-item">
                                <a href="#">
                                    <img src="<?php echo esc_url(get_template_directory_uri());?>/img/pexels-photo-97904-400x300.jpeg">
                                    <div class="content">
                                        <h5>InterContinental New York Barclay</h5>
                                        <p>5 reviews</p>
                                        <p class="mb0">3 offers price from $130,00</p>
                                    </div>
                                </a>
                            </div>
                        </div>

                        <div class="col-sm-6">
                            <div class="pop-item">
                                <a href="#">
                                    <img src="<?php echo esc_url(get_template_directory_uri());?>/img/Barclay-400x300.jpg">
                                    <div class="content">
                                        <h5>InterContinental New York Barclay</h5>
                                        <p>5 reviews</p>
                                        <p class="mb0">3 offers price from $130,00</p>
                                    </div>
                                </a>
                            </div>
                        </div>

                        <div class="col-sm-6">
                            <div class="pop-item">
                                <a href="#">
                                    <img src="<?php echo esc_url(get_template_directory_uri());?>/img/pexels-photo-97904-400x300.jpeg">
                                    <div class="content">
                                        <h5>InterContinental New York Barclay</h5>
                                        <p>5 reviews</p>
                                        <p class="mb0">3 offers price from $130,00</p>
                                    </div>
                                </a>
                            </div>
                        </div>

                    </div>
                </div>


                <div class="top-search content-search">

                    <div class="sec-ti">
                        <h3 class="font-weight300 u-padding-b-20">Top Deals</h3>
                    </div>
                    <div class="row">

                        <div class="col-sm-6">
                            <div class="top-deal-item">
                                <a href="#" class="fig">
                                    <img src="<?php echo esc_url(get_template_directory_uri());?>/img/Barclay-400x300.jpg">
                                    <span>Book Now</span>
                                </a>
                                       
                                <div class="content">
                                    <div class="icons">
                                        <i class="fa fa-star"></i>         
                                        <i class="fa fa-star"></i>         
                                        <i class="fa fa-star"></i>         
                                        <i class="fa fa-star"></i>         
                                        <i class="fa fa-star"></i>         
                                    </div>
                                    <h5><a href="#">InterContinental New</a></h5>
                                    <div class="location">
                                        <i class="fa fa-map-marker"></i>
                                        <span> Paris-Charles de Gaulle Airport, Roissy-en-France, France</span>
                                    </div>
                                    <p class="mb0">from $130,00 <small>/night</small></p>
                                </div>
                           
                            </div>
                        </div>

                        <div class="col-sm-6">
                            <div class="top-deal-item">
                                <a href="#" class="fig">
                                    <img src="<?php echo esc_url(get_template_directory_uri());?>/img/Barclay-400x300.jpg">
                                    <span>Book Now</span>
                                </a>
                                       
                                <div class="content">
                                    <div class="icons">
                                        <i class="fa fa-star"></i>         
                                        <i class="fa fa-star"></i>         
                                        <i class="fa fa-star"></i>         
                                        <i class="fa fa-star"></i>         
                                        <i class="fa fa-star"></i>         
                                    </div>
                                    <h5><a href="#">InterContinental New</a></h5>
                                    <div class="location">
                                        <i class="fa fa-map-marker"></i>
                                        <span> Paris-Charles de Gaulle Airport, Roissy-en-France, France</span>
                                    </div>
                                    <p class="mb0">from $130,00 <small>/night</small></p>
                                </div>
                           
                            </div>
                        </div>
                        

                        <div class="col-sm-6">
                            <div class="top-deal-item">
                                <a href="#" class="fig">
                                    <img src="<?php echo esc_url(get_template_directory_uri());?>/img/Barclay-400x300.jpg">
                                    <span>Book Now</span>
                                </a>
                                       
                                <div class="content">
                                    <div class="icons">
                                        <i class="fa fa-star"></i>         
                                        <i class="fa fa-star"></i>         
                                        <i class="fa fa-star"></i>         
                                        <i class="fa fa-star"></i>         
                                        <i class="fa fa-star"></i>         
                                    </div>
                                    <h5><a href="#">InterContinental New</a></h5>
                                    <div class="location">
                                        <i class="fa fa-map-marker"></i>
                                        <span> Paris-Charles de Gaulle Airport, Roissy-en-France, France</span>
                                    </div>
                                    <p class="mb0">from $130,00 <small>/night</small></p>
                                </div>
                           
                            </div>
                        </div>

                        <div class="col-sm-6">
                            <div class="top-deal-item">
                                <a href="#" class="fig">
                                    <img src="<?php echo esc_url(get_template_directory_uri());?>/img/Barclay-400x300.jpg">
                                    <span>Book Now</span>
                                </a>
                                       
                                <div class="content">
                                    <div class="icons">
                                        <i class="fa fa-star"></i>         
                                        <i class="fa fa-star"></i>         
                                        <i class="fa fa-star"></i>         
                                        <i class="fa fa-star"></i>         
                                        <i class="fa fa-star"></i>         
                                    </div>
                                    <h5><a href="#">InterContinental New</a></h5>
                                    <div class="location">
                                        <i class="fa fa-map-marker"></i>
                                        <span> Paris-Charles de Gaulle Airport, Roissy-en-France, France</span>
                                    </div>
                                    <p class="mb0">from $130,00 <small>/night</small></p>
                                </div>
                           
                            </div>
                        </div>
                        

                        <div class="col-sm-6">
                            <div class="top-deal-item">
                                <a href="#" class="fig">
                                    <img src="<?php echo esc_url(get_template_directory_uri());?>/img/Barclay-400x300.jpg">
                                    <span>Book Now</span>
                                </a>
                                       
                                <div class="content">
                                    <div class="icons">
                                        <i class="fa fa-star"></i>         
                                        <i class="fa fa-star"></i>         
                                        <i class="fa fa-star"></i>         
                                        <i class="fa fa-star"></i>         
                                        <i class="fa fa-star"></i>         
                                    </div>
                                    <h5><a href="#">InterContinental New</a></h5>
                                    <div class="location">
                                        <i class="fa fa-map-marker"></i>
                                        <span> Paris-Charles de Gaulle Airport, Roissy-en-France, France</span>
                                    </div>
                                    <p class="mb0">from $130,00 <small>/night</small></p>
                                </div>
                           
                            </div>
                        </div>

                        <div class="col-sm-6">
                            <div class="top-deal-item">
                                <a href="#" class="fig">
                                    <img src="<?php echo esc_url(get_template_directory_uri());?>/img/Barclay-400x300.jpg">
                                    <span>Book Now</span>
                                </a>
                                       
                                <div class="content">
                                    <div class="icons">
                                        <i class="fa fa-star"></i>         
                                        <i class="fa fa-star"></i>         
                                        <i class="fa fa-star"></i>         
                                        <i class="fa fa-star"></i>         
                                        <i class="fa fa-star"></i>         
                                    </div>
                                    <h5><a href="#">InterContinental New</a></h5>
                                    <div class="location">
                                        <i class="fa fa-map-marker"></i>
                                        <span> Paris-Charles de Gaulle Airport, Roissy-en-France, France</span>
                                    </div>
                                    <p class="mb0">from $130,00 <small>/night</small></p>
                                </div>
                           
                            </div>
                        </div>

                    </div>
                </div>




            </div>
        </div>
    </div>







<?php get_footer();?>