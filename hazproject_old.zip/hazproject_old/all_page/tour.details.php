<?php
/**
 * The tour details template file
 *
 * This is the most generic template file in a WordPress theme
 * and one of the two required files for a theme (the other being style.css).
 * It is used to display a page when nothing more specific matches a query.
 * E.g., it puts together the home page when no home.php file exists.
 *
 * @link https://developer.wordpress.org/themes/basics/template-hierarchy/
 *
 * @package aynix
 */
 /*
  Template Name: tour.details
*/
get_header(); ?>
    
       <!-- mobile-menu-area start -->
        <div class="mobile-menu-area">
          <div class="container">
            <div class="row">
              <div class="col-md-12">
                <div class="mobile-menu">
                  <nav id="dropdown">
                    <ul>
                        <li class="active"><a href="#">Home</a>
                            <ul>
                                <li><a href="#">Sub Item</a></li>
                                <li><a href="#">Sub Item</a></li>
                                <li><a href="#">Sub Item</a></li>
                                <li><a href="#">Sub Item</a></li>
                                <li><a href="#">Sub Item</a></li>
                                <li><a href="#">Sub Item</a></li>
                                <li><a href="#">Sub Item</a></li>
                            </ul>
                        </li>
                        <li><a href="#">Projects</a></li>
                        <li><a href="#">Activities</a></li>
                        <li><a href="#">Total Jobs</a></li>
                        <li><a href="#">Flights</a></li>
                        <li><a href="#">Hotels</a></li>
                    </ul>
                  </nav>
                </div>
              </div>
            </div>
          </div>
        </div>
        <!-- mobile-menu-area end -->



    <div class="det-area car-det has-border u-padding-t-60 u-padding-b-60">
        <div class="container">
            <div class="det-top">
                <div class="left">
                    <h3>Versailles Small Trip
</h3>
                    <p><i class="fa fa-map-marker"></i> Pierpoint Road Cairns , QLD 4870 Australia</p>
                    <ul>
                        <li><i class="fa fa-envelope"></i>Tour E-mail</li>
                    </ul>
                </div>
                <div class="right">
                    <div class="prices">
                        <div class="cr-price">
                             <small style="text-decoration: line-through;">$170,00</small>$273,00 
                        </div>
                    </div>
                </div>
            </div>  

            <div class="row">
                <div class="col-sm-4">
                    <div class="tour-aside">
                        <div class="block">
                            <h3 class="title">Similar Tours</h3>
                            <ul>
                                
                                <li>
                                   <a href="#">
                                       <figure>
                                           <img src="<?php echo esc_url(get_template_directory_uri());?>/img/pexels-photo-227405-70x60.jpeg">
                                       </figure>
                                       <div class="title-star">
                                           <h4>Kerama Islands Hotel</h4>
                                           <span class="stars">
                                               <i class="fa fa-star"></i>
                                               <i class="fa fa-star"></i>
                                               <i class="fa fa-star"></i>
                                               <i class="fa fa-star"></i>
                                               <i class="fa fa-star-o"></i>
                                           </span>
                                       </div>

                                       <span class="price">
                                           <span>Price from</span>
                                           <p>$267,00</p>
                                       </span>

                                   </a>
                                </li> <!-- item -->
                                <li>
                                   <a href="#">
                                       <figure>
                                           <img src="<?php echo esc_url(get_template_directory_uri());?>/img/pexels-photo-227405-70x60.jpeg">
                                       </figure>
                                       <div class="title-star">
                                           <h4>Kerama Islands Hotel</h4>
                                           <span class="stars">
                                               <i class="fa fa-star"></i>
                                               <i class="fa fa-star"></i>
                                               <i class="fa fa-star"></i>
                                               <i class="fa fa-star"></i>
                                               <i class="fa fa-star-o"></i>
                                           </span>
                                       </div>

                                       <span class="price">
                                           <span>Price from</span>
                                           <p>$267,00</p>
                                       </span>

                                   </a>
                                </li> <!-- item -->
                                <li>
                                   <a href="#">
                                       <figure>
                                           <img src="<?php echo esc_url(get_template_directory_uri());?>/img/pexels-photo-227405-70x60.jpeg">
                                       </figure>
                                       <div class="title-star">
                                           <h4>Kerama Islands Hotel</h4>
                                           <span class="stars">
                                               <i class="fa fa-star"></i>
                                               <i class="fa fa-star"></i>
                                               <i class="fa fa-star"></i>
                                               <i class="fa fa-star"></i>
                                               <i class="fa fa-star-o"></i>
                                           </span>
                                       </div>

                                       <span class="price">
                                           <span>Price from</span>
                                           <p>$267,00</p>
                                       </span>

                                   </a>
                                </li> <!-- item -->
                                <li>
                                   <a href="#">
                                       <figure>
                                           <img src="<?php echo esc_url(get_template_directory_uri());?>/img/pexels-photo-227405-70x60.jpeg">
                                       </figure>
                                       <div class="title-star">
                                           <h4>Kerama Islands Hotel</h4>
                                           <span class="stars">
                                               <i class="fa fa-star"></i>
                                               <i class="fa fa-star"></i>
                                               <i class="fa fa-star"></i>
                                               <i class="fa fa-star"></i>
                                               <i class="fa fa-star-o"></i>
                                           </span>
                                       </div>

                                       <span class="price">
                                           <span>Price from</span>
                                           <p>$267,00</p>
                                       </span>

                                   </a>
                                </li> <!-- item -->
                                <li>
                                   <a href="#">
                                       <figure>
                                           <img src="<?php echo esc_url(get_template_directory_uri());?>/img/pexels-photo-227405-70x60.jpeg">
                                       </figure>
                                       <div class="title-star">
                                           <h4>Kerama Islands Hotel</h4>
                                           <span class="stars">
                                               <i class="fa fa-star"></i>
                                               <i class="fa fa-star"></i>
                                               <i class="fa fa-star"></i>
                                               <i class="fa fa-star"></i>
                                               <i class="fa fa-star-o"></i>
                                           </span>
                                       </div>

                                       <span class="price">
                                           <span>Price from</span>
                                           <p>$267,00</p>
                                       </span>

                                   </a>
                                </li> <!-- item -->

                            </ul>
                        </div>
                        <div class="block u-margin-t-40">
                            <h3 class="title">Tours Nearby <strong>Versailles Small Trip</strong></h3>
                            <ul>
                                
                                <li>
                                   <a href="#">
                                       <figure>
                                           <img src="<?php echo esc_url(get_template_directory_uri());?>/img/pexels-photo-227405-70x60.jpeg">
                                       </figure>
                                       <div class="title-star">
                                           <h4>Kerama Islands Hotel</h4>
                                           <span class="stars">
                                               <i class="fa fa-star"></i>
                                               <i class="fa fa-star"></i>
                                               <i class="fa fa-star"></i>
                                               <i class="fa fa-star"></i>
                                               <i class="fa fa-star-o"></i>
                                           </span>
                                       </div>

                                       <span class="price">
                                           <span>Price from</span>
                                           <p>$267,00</p>
                                       </span>

                                   </a>
                                </li> <!-- item -->
                                <li>
                                   <a href="#">
                                       <figure>
                                           <img src="<?php echo esc_url(get_template_directory_uri());?>/img/pexels-photo-227405-70x60.jpeg">
                                       </figure>
                                       <div class="title-star">
                                           <h4>Kerama Islands Hotel</h4>
                                           <span class="stars">
                                               <i class="fa fa-star"></i>
                                               <i class="fa fa-star"></i>
                                               <i class="fa fa-star"></i>
                                               <i class="fa fa-star"></i>
                                               <i class="fa fa-star-o"></i>
                                           </span>
                                       </div>

                                       <span class="price">
                                           <span>Price from</span>
                                           <p>$267,00</p>
                                       </span>

                                   </a>
                                </li> <!-- item -->
                                <li>
                                   <a href="#">
                                       <figure>
                                           <img src="<?php echo esc_url(get_template_directory_uri());?>/img/pexels-photo-227405-70x60.jpeg">
                                       </figure>
                                       <div class="title-star">
                                           <h4>Kerama Islands Hotel</h4>
                                           <span class="stars">
                                               <i class="fa fa-star"></i>
                                               <i class="fa fa-star"></i>
                                               <i class="fa fa-star"></i>
                                               <i class="fa fa-star"></i>
                                               <i class="fa fa-star-o"></i>
                                           </span>
                                       </div>

                                       <span class="price">
                                           <span>Price from</span>
                                           <p>$267,00</p>
                                       </span>

                                   </a>
                                </li> <!-- item -->
                                <li>
                                   <a href="#">
                                       <figure>
                                           <img src="<?php echo esc_url(get_template_directory_uri());?>/img/pexels-photo-227405-70x60.jpeg">
                                       </figure>
                                       <div class="title-star">
                                           <h4>Kerama Islands Hotel</h4>
                                           <span class="stars">
                                               <i class="fa fa-star"></i>
                                               <i class="fa fa-star"></i>
                                               <i class="fa fa-star"></i>
                                               <i class="fa fa-star"></i>
                                               <i class="fa fa-star-o"></i>
                                           </span>
                                       </div>

                                       <span class="price">
                                           <span>Price from</span>
                                           <p>$267,00</p>
                                       </span>

                                   </a>
                                </li> <!-- item -->
                                <li>
                                   <a href="#">
                                       <figure>
                                           <img src="<?php echo esc_url(get_template_directory_uri());?>/img/pexels-photo-227405-70x60.jpeg">
                                       </figure>
                                       <div class="title-star">
                                           <h4>Kerama Islands Hotel</h4>
                                           <span class="stars">
                                               <i class="fa fa-star"></i>
                                               <i class="fa fa-star"></i>
                                               <i class="fa fa-star"></i>
                                               <i class="fa fa-star"></i>
                                               <i class="fa fa-star-o"></i>
                                           </span>
                                       </div>

                                       <span class="price">
                                           <span>Price from</span>
                                           <p>$267,00</p>
                                       </span>

                                   </a>
                                </li> <!-- item -->

                            </ul>
                        </div>
                    </div>
                </div> <!--  -->

                <div class="col-sm-8">
                    <div class="main-content">
                        <div class="slider-wrap">
                            <img src="<?php echo esc_url(get_template_directory_uri());?>/img/palace-park-versailles-5-800x600.jpg" alt="">
                        </div>

                        <form id="form-booking-inpage" class="form-has-guest-name" method="post" action="#booking-request">
                            <!-- Tour Package -->
                                    <!-- End Tour Package -->
                            <div class="package-info-wrapper" style="width: 100%">
                                <div class="overlay-form" style="display: none;"><i class="fa fa-refresh text-color"></i></div>
                                <div class="row">

                                    <div class="col-md-6">
                                        <div class="package-info clearfix">
                                            <i class="fa fa-info"></i>
                                            <span class="head">Tour type: </span>
                                            <span>Specific Date</span>
                                        </div>
                                        <div class="package-info clearfix">
                                            <i class="fa fa-user"></i>
                                            <span class="head">Maximum number of people: </span>
                                            18                    
                                        </div>

                                        <div class="package-info clearfix">
                                            <i class="fa fa-location-arrow"></i>
                                            <span class="head">Location: </span>
                                            France, Paris                    
                                        </div>
                                        <div class="package-info clearfix">
                                            <i class="fa fa-star"></i>
                                            <span class="head">Rate:</span>
                                            <ul class="icon-group booking-item-rating-stars">
                                                <li><i class="fa  fa-star"></i></li><li><i class="fa  fa-star"></i></li><li><i class="fa  fa-star-half-o"></i></li><li><i class="fa  fa-star-o"></i></li><li><i class="fa  fa-star-o"></i></li>                        
                                            </ul>
                                        </div>
                                    </div>
                                    <div class="col-md-6">
                                                            
                                        <div class="package-book-now-button">
                                            <input type="hidden" name="action" value="tours_add_to_cart">
                                            <input type="hidden" name="item_id" value="1030">
                                            <input type="hidden" name="type_tour" value="specific_date">
                                            <div class="div_book">
                                                <div class="row">
                                                          <div class="col-xs-12 mb5">
                                                                <a href="#list_tour_item" id="select-a-tour" class="btn btn-primary">Select a day</a>
                                                            </div>
                                                            <div class="col-xs-12 mb5" style="display: none">
                                                                <label for="check_in"><strong>Departure date: </strong></label>
                                                                <input placeholder="Select a day in the calendar" id="check_in" type="text" name="check_in" value="" readonly="readonly" class="form-control">
                                                            </div>
                                                            <div class="col-xs-12 mb5" style="display: none">
                                                                <label for="check_out"><strong>Return date: </strong></label>
                                                                <input id="check_out" type="text" name="check_out" value="" readonly="readonly" class="form-control">
                                                            </div>
                                                        </div>
    
                                                    
                                                    
                                                    <input type="hidden" data-starttime="" data-checkin="" data-checkout="" data-tourid="1030" id="starttime_hidden_load_form">

                                                <div class="row u-margin-t-20 u-margin-b-20">
                                                    <div class="col-xs-12 col-sm-4">
                                                            <label for="label_adult_number"><strong>Adults: </strong></label>
                                                            <select class="form-control">
                                                                <option>0</option>
                                                                <option>1</option>
                                                                <option>2</option>
                                                                <option>3</option>
                                                                <option>4</option>
                                                            </select>
                                                        </div>
                                                        <div class="col-xs-12 col-sm-4">
                                                            <label for="label_child_number"><strong>Children: </strong></label>
                                                            <select class="form-control">
                                                                <option>0</option>
                                                                <option>1</option>
                                                                <option>2</option>
                                                                <option>3</option>
                                                                <option>4</option>
                                                            </select>
                                                        </div>
                                                        <div class="col-xs-12 col-sm-4">
                                                            <label for="label_infant_number"><strong>Infant: </strong></label>
                                                           <select class="form-control">
                                                                <option>0</option>
                                                                <option>1</option>
                                                                <option>2</option>
                                                                <option>3</option>
                                                                <option>4</option>
                                                            </select>
                                                        </div>
                                                    </div>
                  


                                                <div class="div_btn_book_tour">
                                                <a href="#" class="btn btn-default btn-send-message-login" data-id="1030">Send message</a>       
                                                 <input type="submit" class=" btn btn-primary " value="Book Now">
                                             </div>
                                                                                                                        </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </form>



                        <div class="hotel-des">
                            <h3>Overview</h3>
                            <p>Ridens reprimique sed ei, ei qui dicta officiis. Dicat intellegebat vim in, at fastidii prodesset gloriatur qui, sed dicam eripuit necessitatibus an. Has ex enim adolescens vituperata. Nam malorum debitis reprimique no, quaestio percipitur referrentur pro te.</p>
                            <p>At qui elit nobis legimus, at eum partiendo disputando. Sit id dicunt viderer, animal suscipit voluptaria est te. Ad mollis scriptorem eos, pri id velit ludus. Cum minim nostro constituto in, ex vim bonorum tacimates referrentur. Eum ut quodsi regione adolescens. Vel ei partem accommodare, mucius facete atomorum ius no, cu quo sonet eligendi officiis</p>
                            
                        </div>


                        <div class="tour-location">
                            <h3>Tour’s Location</h3>

                            <iframe src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d387193.30594184523!2d-74.25986594809962!3d40.69714941820045!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x89c24fa5d33f083b%3A0xc80b8f06e177fe62!2sNew+York%2C+NY%2C+USA!5e0!3m2!1sen!2sbd!4v1540485618034" frameborder="0" style="border:0" allowfullscreen=""></iframe>
                        </div>


                    <div class="panel-group ac-tour">
                        <div class="panel panel-default">
                                <div class="panel-heading">
                                    <h4 class="panel-title">
                                        <a href="#collapse-614860782" data-parent="#accordion_tours" data-toggle="collapse" class="title_program collapsed">
                                            Day 1                        
                                        </a>
                                    </h4>
                                </div>
                            <div id="collapse-614860782" class="panel-collapse collapse" aria-expanded="false">
                                <div class="panel-body">
                                Aenean eu leo quam pellentesque ornare. <br>
                                 Sem lacinia quam venenatis vestibulum. <br>
                                Donec ullamcorper nulla non metus auctor fringilla.                     
                                </div>
                            </div>
                        </div>

                        <div class="panel panel-default">
                            <div class="panel-heading">
                            <h4 class="panel-title">
                                <a href="#collapse-336868109" data-parent="#accordion_tours" data-toggle="collapse" class="title_program collapsed" aria-expanded="false">
                                    Day 2                        </a>
                            </h4>
                        </div>
                            <div id="collapse-336868109" class="panel-collapse collapse " aria-expanded="false">
                                <div class="panel-body">
                                    Integer posuere erat a ante venenatis dapibus posuere velit aliquet. <br>
                                    Nullam quis risus eget urna mollis ornare vel eu leo.                     </div>
                            </div>
                        </div>

                    <div class="panel panel-default">
                        <div class="panel-heading">
                            <h4 class="panel-title">
                                <a href="#collapse-480031988" data-parent="#accordion_tours" data-toggle="collapse" class="title_program collapsed">
                                    Day 3                        
                                </a>
                            </h4>
                        </div>

                        <div id="collapse-480031988" class="panel-collapse collapse " aria-expanded="false">
                            <div class="panel-body">
                                Aenean eu leo quam pellentesque ornare. <br>
                                Sem lacinia quam venenatis vestibulum. <br>
                                Donec ullamcorper nulla non metus auctor fringilla.                     
                                                
                            </div>
                        </div>
                    </div>


                            <div class="panel panel-default">
                                <div class="panel-heading">
                                    <h4 class="panel-title">
                                        <a href="#collapse-464094997" data-parent="#accordion_tours" data-toggle="collapse" class="title_program collapsed" aria-expanded="false">
                                            Day 4                        </a>
                                    </h4>
                                </div>
                                <div id="collapse-464094997" class="panel-collapse collapse" aria-expanded="false">
                                    <div class="panel-body">
                                        Integer posuere erat a ante venenatis dapibus posuere velit aliquet. Nullam quis risus eget urna mollis ornare vel eu leo.                     
                                    </div>
                                </div>
                            </div>
                        </div>







                        <div class="hotel-rev u-padding-t-50">
                        <div class="rev-title u-margin-b-30">
                            <h3>Write a review</h3>
                        </div>
                        <ul class="booking-item-reviews list">

                            <!--comment repeted item start -->
                            <li class="st_reviews byuser comment-author-admin bypostauthor even thread-even depth-1">
                                <div class="row">
                                    <div class="col-md-2">
                                        <div class="booking-item-review-person">
                                            <a class="booking-item-review-person-avatar round" href="#">
                                                <img alt="avatar" width="70" height="70" src="https://travelerwp.com/wp-content/uploads/2017/11/pexels-photo-91227.jpeg" class="avatar avatar-96 photo origin round">                </a>
                                            <p class="booking-item-review-person-name">
                                                <cite class="fn">admin</cite>                </p>
                                            <p class="booking-item-review-person-loc">                </p>
                                            <small>
                                                <a href="#">                        73 reviews
                                                </a>
                                            </small>
                                        </div>
                                    </div>

                                    <div class="col-md-10">
                                        <div class="booking-item-review-content">
                                            <h5>"Good"</h5>
                                            <ul class="icon-group booking-item-rating-stars" data-rate="4.2">
                                                <li><i class="fa  fa-star"></i></li><li><i class="fa  fa-star"></i></li><li><i class="fa  fa-star"></i></li><li><i class="fa  fa-star"></i></li><li><i class="fa  fa-star-half-o"></i></li>
                                            </ul>
                                            
                                            <div class="comment-content">
                                                Nam ullamcorper ornare auctor rhoncus nulla pellentesque tempus penatibus tristique lobortis dignissim sollicitudin Nam...              
                                            </div>

                                            <div class="booking-item-review-more-content">
                                                <ul class="list booking-item-raiting-summary-list mt20">
                                                <li>
                                                    <div class="booking-item-raiting-list-title">Sleep</div>
                                                    <ul class="icon-group booking-item-rating-stars">
                                                        <li><i class="fa fa-smile-o "></i>
                                                        </li><li><i class="fa fa-smile-o "></i>
                                                        </li><li><i class="fa fa-smile-o "></i>
                                                        </li><li><i class="fa fa-smile-o "></i>
                                                        </li><li><i class="fa fa-smile-o text-gray"></i>
                                                    </li></ul>
                                                </li>

                                                <li>
                                                    <div class="booking-item-raiting-list-title">Location</div>
                                                    <ul class="icon-group booking-item-rating-stars">
                                                        <li><i class="fa fa-smile-o "></i>
                                                        </li><li><i class="fa fa-smile-o "></i>
                                                        </li><li><i class="fa fa-smile-o "></i>
                                                        </li><li><i class="fa fa-smile-o "></i>
                                                        </li><li><i class="fa fa-smile-o text-gray"></i>
                                                    </li></ul>
                                                </li>

                                                <li>
                                                    <div class="booking-item-raiting-list-title">Service</div>
                                                    <ul class="icon-group booking-item-rating-stars">
                                                        <li><i class="fa fa-smile-o "></i>
                                                        </li><li><i class="fa fa-smile-o "></i>
                                                        </li><li><i class="fa fa-smile-o "></i>
                                                        </li><li><i class="fa fa-smile-o "></i>
                                                        </li><li><i class="fa fa-smile-o "></i>
                                                    </li></ul>
                                                </li>

                                                <li>
                                                    <div class="booking-item-raiting-list-title">Clearness</div>
                                                    <ul class="icon-group booking-item-rating-stars">
                                                        <li><i class="fa fa-smile-o "></i>
                                                        </li><li><i class="fa fa-smile-o "></i>
                                                        </li><li><i class="fa fa-smile-o "></i>
                                                        </li><li><i class="fa fa-smile-o "></i>
                                                        </li><li><i class="fa fa-smile-o "></i>
                                                    </li></ul>
                                                </li>

                                                <li>
                                                    <div class="booking-item-raiting-list-title">Rooms</div>
                                                    <ul class="icon-group booking-item-rating-stars">
                                                        <li><i class="fa fa-smile-o "></i>
                                                        </li><li><i class="fa fa-smile-o "></i>
                                                        </li><li><i class="fa fa-smile-o "></i>
                                                        </li><li><i class="fa fa-smile-o text-gray"></i>
                                                        </li><li><i class="fa fa-smile-o text-gray"></i>
                                                    </li></ul>
                                                </li>
                            
                                            </ul>                
                                        </div>
                                            <div class="booking-item-review-expand">
                                                <span class="booking-item-review-expand-more">More <i class="fa fa-angle-down"></i></span>
                                                <span class="booking-item-review-expand-less">Less <i class="fa fa-angle-up"></i></span>
                                            </div>
                                                
                                            <p class="booking-item-review-rate">Was this review helpful?<b class="text-color"> <span class="number">56</span> like this</b>
                                            <a data-id="196" class="st-like-review fa fa-thumbs-o-up box-icon-inline round" href="#"></a>
                                                                    
                                            </p>
                           
                                        </div>
                                    </div><!-- col-10 -->
                                </div><!-- row -->
                            </li>
                            <!--comment repeted item end -->
 <!--comment repeted item start -->
                            <li class="st_reviews byuser comment-author-admin bypostauthor even thread-even depth-1">
                                <div class="row">
                                    <div class="col-md-2">
                                        <div class="booking-item-review-person">
                                            <a class="booking-item-review-person-avatar round" href="#">
                                                <img alt="avatar" width="70" height="70" src="https://travelerwp.com/wp-content/uploads/2017/11/pexels-photo-91227.jpeg" class="avatar avatar-96 photo origin round">                </a>
                                            <p class="booking-item-review-person-name">
                                                <cite class="fn">admin</cite>                </p>
                                            <p class="booking-item-review-person-loc">                </p>
                                            <small>
                                                <a href="#">                        73 reviews
                                                </a>
                                            </small>
                                        </div>
                                    </div>

                                    <div class="col-md-10">
                                        <div class="booking-item-review-content">
                                            <h5>"Good"</h5>
                                            <ul class="icon-group booking-item-rating-stars" data-rate="4.2">
                                                <li><i class="fa  fa-star"></i></li><li><i class="fa  fa-star"></i></li><li><i class="fa  fa-star"></i></li><li><i class="fa  fa-star"></i></li><li><i class="fa  fa-star-half-o"></i></li>
                                            </ul>
                                            
                                            <div class="comment-content">
                                                Nam ullamcorper ornare auctor rhoncus nulla pellentesque tempus penatibus tristique lobortis dignissim sollicitudin Nam...              
                                            </div>

                                            <div class="booking-item-review-more-content">
                                                <ul class="list booking-item-raiting-summary-list mt20">
                                                <li>
                                                    <div class="booking-item-raiting-list-title">Sleep</div>
                                                    <ul class="icon-group booking-item-rating-stars">
                                                        <li><i class="fa fa-smile-o "></i>
                                                        </li><li><i class="fa fa-smile-o "></i>
                                                        </li><li><i class="fa fa-smile-o "></i>
                                                        </li><li><i class="fa fa-smile-o "></i>
                                                        </li><li><i class="fa fa-smile-o text-gray"></i>
                                                    </li></ul>
                                                </li>

                                                <li>
                                                    <div class="booking-item-raiting-list-title">Location</div>
                                                    <ul class="icon-group booking-item-rating-stars">
                                                        <li><i class="fa fa-smile-o "></i>
                                                        </li><li><i class="fa fa-smile-o "></i>
                                                        </li><li><i class="fa fa-smile-o "></i>
                                                        </li><li><i class="fa fa-smile-o "></i>
                                                        </li><li><i class="fa fa-smile-o text-gray"></i>
                                                    </li></ul>
                                                </li>

                                                <li>
                                                    <div class="booking-item-raiting-list-title">Service</div>
                                                    <ul class="icon-group booking-item-rating-stars">
                                                        <li><i class="fa fa-smile-o "></i>
                                                        </li><li><i class="fa fa-smile-o "></i>
                                                        </li><li><i class="fa fa-smile-o "></i>
                                                        </li><li><i class="fa fa-smile-o "></i>
                                                        </li><li><i class="fa fa-smile-o "></i>
                                                    </li></ul>
                                                </li>

                                                <li>
                                                    <div class="booking-item-raiting-list-title">Clearness</div>
                                                    <ul class="icon-group booking-item-rating-stars">
                                                        <li><i class="fa fa-smile-o "></i>
                                                        </li><li><i class="fa fa-smile-o "></i>
                                                        </li><li><i class="fa fa-smile-o "></i>
                                                        </li><li><i class="fa fa-smile-o "></i>
                                                        </li><li><i class="fa fa-smile-o "></i>
                                                    </li></ul>
                                                </li>

                                                <li>
                                                    <div class="booking-item-raiting-list-title">Rooms</div>
                                                    <ul class="icon-group booking-item-rating-stars">
                                                        <li><i class="fa fa-smile-o "></i>
                                                        </li><li><i class="fa fa-smile-o "></i>
                                                        </li><li><i class="fa fa-smile-o "></i>
                                                        </li><li><i class="fa fa-smile-o text-gray"></i>
                                                        </li><li><i class="fa fa-smile-o text-gray"></i>
                                                    </li></ul>
                                                </li>
                            
                                            </ul>                
                                        </div>
                                            <div class="booking-item-review-expand">
                                                <span class="booking-item-review-expand-more">More <i class="fa fa-angle-down"></i></span>
                                                <span class="booking-item-review-expand-less">Less <i class="fa fa-angle-up"></i></span>
                                            </div>
                                                
                                            <p class="booking-item-review-rate">Was this review helpful?<b class="text-color"> <span class="number">56</span> like this</b>
                                            <a data-id="196" class="st-like-review fa fa-thumbs-o-up box-icon-inline round" href="#"></a>
                                                                    
                                            </p>
                           
                                        </div>
                                    </div><!-- col-10 -->
                                </div><!-- row -->
                            </li>
                            <!--comment repeted item end -->

                        </ul>

                      
                    </div>






<div class="box bg-gray   u-margin-t-40">   
                        <div id="respond" class="comment-respond">
        <h3 id="reply-title" class="comment-reply-title">Write a review </h3>          
        <form action="#" method="post" id="commentform" class="comment-form" novalidate="">
                
                        <div class="row">
                            <div class="col-sm-8">
                    <div class="form-group">
                                            <label>Review Title</label>
                                            <input class="form-control" type="text" name="comment_title">
                                        </div><div class="form-group">
                                            <label>Review Text</label>
                                            <textarea name="comment" id="comment" class="form-control" rows="6"></textarea>
                                        </div>
                                        </div><!--End col-sm-8-->
                                        <div class="col-sm-4"><ul class="list booking-item-raiting-summary-list stats-list-select"><li class=""><div class="booking-item-raiting-list-title">Sleep</div>
                                                    <ul class="icon-group booking-item-rating-stars">
                                                    <li class=""><i class="fa fa-smile-o"></i>
                                                    </li>
                                                    <li class=""><i class="fa fa-smile-o"></i>
                                                    </li>
                                                    <li class=""><i class="fa fa-smile-o"></i>
                                                    </li>
                                                    <li class=""><i class="fa fa-smile-o"></i>
                                                    </li>
                                                    <li><i class="fa fa-smile-o"></i>
                                                    </li>
                                                </ul>
                                                <input type="hidden" class="st_review_stats" value="0" name="st_review_stats[Sleep]">
                                                    </li><li class=""><div class="booking-item-raiting-list-title">Location</div>
                                                    <ul class="icon-group booking-item-rating-stars">
                                                    <li class=""><i class="fa fa-smile-o"></i>
                                                    </li>
                                                    <li class=""><i class="fa fa-smile-o"></i>
                                                    </li>
                                                    <li class=""><i class="fa fa-smile-o"></i>
                                                    </li>
                                                    <li class=""><i class="fa fa-smile-o"></i>
                                                    </li>
                                                    <li><i class="fa fa-smile-o"></i>
                                                    </li>
                                                </ul>
                                                <input type="hidden" class="st_review_stats" value="0" name="st_review_stats[Location]">
                                                    </li><li class=""><div class="booking-item-raiting-list-title">Service</div>
                                                    <ul class="icon-group booking-item-rating-stars">
                                                    <li class=""><i class="fa fa-smile-o"></i>
                                                    </li>
                                                    <li class=""><i class="fa fa-smile-o"></i>
                                                    </li>
                                                    <li class=""><i class="fa fa-smile-o"></i>
                                                    </li>
                                                    <li class=""><i class="fa fa-smile-o"></i>
                                                    </li>
                                                    <li><i class="fa fa-smile-o"></i>
                                                    </li>
                                                </ul>
                                                <input type="hidden" class="st_review_stats" value="0" name="st_review_stats[Service]">
                                                    </li><li class=""><div class="booking-item-raiting-list-title">Clearness</div>
                                                    <ul class="icon-group booking-item-rating-stars">
                                                    <li class=""><i class="fa fa-smile-o"></i>
                                                    </li>
                                                    <li class=""><i class="fa fa-smile-o"></i>
                                                    </li>
                                                    <li class=""><i class="fa fa-smile-o"></i>
                                                    </li>
                                                    <li class=""><i class="fa fa-smile-o"></i>
                                                    </li>
                                                    <li><i class="fa fa-smile-o"></i>
                                                    </li>
                                                </ul>
                                                <input type="hidden" class="st_review_stats" value="0" name="st_review_stats[Clearness]">
                                                    </li><li class=""><div class="booking-item-raiting-list-title">Rooms</div>
                                                    <ul class="icon-group booking-item-rating-stars">
                                                    <li class=""><i class="fa fa-smile-o"></i>
                                                    </li>
                                                    <li class=""><i class="fa fa-smile-o"></i>
                                                    </li>
                                                    <li class=""><i class="fa fa-smile-o"></i>
                                                    </li>
                                                    <li class=""><i class="fa fa-smile-o"></i>
                                                    </li>
                                                    <li><i class="fa fa-smile-o"></i>
                                                    </li>
                                                </ul>
                                                    </li></ul></div></div><!--End Row--><input name="wpml_language_code" type="hidden" value="en"><div class="row">

                                        <div class="col-md-6"><div class="form-group">
                                            <label for="author">Name*</label>
                                            <input id="author" name="author" type="text" value="" size="30" aria-required="true" class="form-control">
                                         </div></div>   
                                    <div class="col-md-6"><div class="form-group">

                                    <label for="email">Your email address *</label>
                                    <input class="form-control" id="email" type="text"></div>
                                    </div>
                                    </div><!--End row-->
                                <p class="form-submit"><input name="submit" type="submit" id="submit" class="submit btn btn-primary" value="Leave a Review"> <input type="hidden" name="comment_post_ID" value="980" id="comment_post_ID">
                                <input type="hidden" name="comment_parent" id="comment_parent" value="0"></p>            </form>
            </div><!-- #respond -->
    </div>


                    </div>
                </div>
            </div>        

        </div>
    </div>

<?php get_footer();?>