<?php
/**
 * The hotel search template file
 *
 * This is the most generic template file in a WordPress theme
 * and one of the two required files for a theme (the other being style.css).
 * It is used to display a page when nothing more specific matches a query.
 * E.g., it puts together the home page when no home.php file exists.
 *
 * @link https://developer.wordpress.org/themes/basics/template-hierarchy/
 *
 * @package aynix
 */
 /*
  Template Name: hotel.search
*/
get_header(); ?>
     
        <!-- mobile-menu-area start -->
        <div class="mobile-menu-area">
          <div class="container">
            <div class="row">
              <div class="col-md-12">
                <div class="mobile-menu">
                  <nav id="dropdown">
                    <ul>
                        <li class="active"><a href="#">Home</a>
                            <ul>
                                <li><a href="#">Sub Item</a></li>
                                <li><a href="#">Sub Item</a></li>
                                <li><a href="#">Sub Item</a></li>
                                <li><a href="#">Sub Item</a></li>
                                <li><a href="#">Sub Item</a></li>
                                <li><a href="#">Sub Item</a></li>
                                <li><a href="#">Sub Item</a></li>
                            </ul>
                        </li>
                        <li><a href="#">Projects</a></li>
                        <li><a href="#">Activities</a></li>
                        <li><a href="#">Total Jobs</a></li>
                        <li><a href="#">Flights</a></li>
                        <li><a href="#">Hotels</a></li>
                    </ul>
                  </nav>
                </div>
              </div>
            </div>
          </div>
        </div>
        <!-- mobile-menu-area end -->



    <div class="search-area has-border u-padding-t-60">
        <div class="container">
            <form>
                <h1 class="title">Search Hotel </h1>
<div class="tf-row row">
                                <div class="tf-col col-12 col-sm-12">
                                    <label for="desti">Where</label>
                                    <div class="map mb-2">
                                        <label for="desti"><i class="fa fa-map-marker"></i></label>
                                        <input id="desti" type="text" class="form-control" placeholder="Destination: Zip Code">
                                    </div>
                                </div>
                                <div class="tf-col  col-lg-3">
                                    <label>Check in</label>
                                    <input type="text" class="datepicker form-control" placeholder="dd/mm/yy">
                                </div>
                                <div class="tf-col col-lg-3">
                                    <label>Check out</label>
                                    <input type="text" class="datepicker form-control" placeholder="dd/mm/yy">
                                    </select>
                                </div>

                                <div class="tf-col col-lg-3">
                                    <label>Rooms</label>
                                    <div class="inp-more">
                                        <div class="radio-wrap">
                                            <label><input type="radio" name="room">1</label>
                                            <label><input type="radio" name="room">2</label>
                                            <label><input type="radio" name="room">3</label>
                                        </div>
                                        <span class="more-sl">3+</span>
                                    </div>
                                    </select>
                                </div>

                                <div class="tf-col col-lg-3">
                                    <label>Adult</label>
                                    <div class="inp-more">
                                        <div class="radio-wrap">
                                            <label><input type="radio" name="room">1</label>
                                            <label><input type="radio" name="room">2</label>
                                            <label><input type="radio" name="room">3</label>
                                        </div>
                                        <span class="more-sl">3+</span>
                                    </div>
                                    </select>
                                </div>

                                </div>


                                <div class="col-12 col-lg-12">
                                    <div class="btn-area">
                                        <button class="btn btn-primary btn-md" type="submit">Search For Hottel</button>
                                    </div>
                                </div>

                            </div>           
            </form>
        </div>
    </div>

    <div class="popural u-padding-t-50">
        <div class="container">
            <div class="sec-ti">
                <h2 class="font-weight300">Hotels in Popular Destinations</h2>
            </div>
            <div class="row">

                <div class="col-sm-3">
                    <div class="pop-item">
                        <a href="#">
                            <img src="<?php echo esc_url(get_template_directory_uri());?>/img/Barclay-400x300.jpg">
                            <div class="content">
                                <h5>InterContinental New York Barclay</h5>
                                <p>5 reviews</p>
                                <p class="mb0">3 offers price from $130,00</p>
                            </div>
                        </a>
                    </div>
                </div>

                <div class="col-sm-3">
                    <div class="pop-item">
                        <a href="#">
                            <img src="<?php echo esc_url(get_template_directory_uri());?>/img/pexels-photo-97904-400x300.jpeg">
                            <div class="content">
                                <h5>InterContinental New York Barclay</h5>
                                <p>5 reviews</p>
                                <p class="mb0">3 offers price from $130,00</p>
                            </div>
                        </a>
                    </div>
                </div>

                <div class="col-sm-3">
                    <div class="pop-item">
                        <a href="#">
                            <img src="<?php echo esc_url(get_template_directory_uri());?>/img/Barclay-400x300.jpg">
                            <div class="content">
                                <h5>InterContinental New York Barclay</h5>
                                <p>5 reviews</p>
                                <p class="mb0">3 offers price from $130,00</p>
                            </div>
                        </a>
                    </div>
                </div>

                <div class="col-sm-3">
                    <div class="pop-item">
                        <a href="#">
                            <img src="<?php echo esc_url(get_template_directory_uri());?>/img/pexels-photo-97904-400x300.jpeg">
                            <div class="content">
                                <h5>InterContinental New York Barclay</h5>
                                <p>5 reviews</p>
                                <p class="mb0">3 offers price from $130,00</p>
                            </div>
                        </a>
                    </div>
                </div>

                <div class="col-sm-3">
                    <div class="pop-item">
                        <a href="#">
                            <img src="<?php echo esc_url(get_template_directory_uri());?>/img/Barclay-400x300.jpg">
                            <div class="content">
                                <h5>InterContinental New York Barclay</h5>
                                <p>5 reviews</p>
                                <p class="mb0">3 offers price from $130,00</p>
                            </div>
                        </a>
                    </div>
                </div>

                <div class="col-sm-3">
                    <div class="pop-item">
                        <a href="#">
                            <img src="<?php echo esc_url(get_template_directory_uri());?>/img/pexels-photo-97904-400x300.jpeg">
                            <div class="content">
                                <h5>InterContinental New York Barclay</h5>
                                <p>5 reviews</p>
                                <p class="mb0">3 offers price from $130,00</p>
                            </div>
                        </a>
                    </div>
                </div>

                <div class="col-sm-3">
                    <div class="pop-item">
                        <a href="#">
                            <img src="<?php echo esc_url(get_template_directory_uri());?>/img/Barclay-400x300.jpg">
                            <div class="content">
                                <h5>InterContinental New York Barclay</h5>
                                <p>5 reviews</p>
                                <p class="mb0">3 offers price from $130,00</p>
                            </div>
                        </a>
                    </div>
                </div>

                <div class="col-sm-3">
                    <div class="pop-item">
                        <a href="#">
                            <img src="<?php echo esc_url(get_template_directory_uri());?>/img/pexels-photo-97904-400x300.jpeg">
                            <div class="content">
                                <h5>InterContinental New York Barclay</h5>
                                <p>5 reviews</p>
                                <p class="mb0">3 offers price from $130,00</p>
                            </div>
                        </a>
                    </div>
                </div>

                <div class="col-sm-3">
                    <div class="pop-item">
                        <a href="#">
                            <img src="<?php echo esc_url(get_template_directory_uri());?>/img/Barclay-400x300.jpg">
                            <div class="content">
                                <h5>InterContinental New York Barclay</h5>
                                <p>5 reviews</p>
                                <p class="mb0">3 offers price from $130,00</p>
                            </div>
                        </a>
                    </div>
                </div>

                <div class="col-sm-3">
                    <div class="pop-item">
                        <a href="#">
                            <img src="<?php echo esc_url(get_template_directory_uri());?>/img/pexels-photo-97904-400x300.jpeg">
                            <div class="content">
                                <h5>InterContinental New York Barclay</h5>
                                <p>5 reviews</p>
                                <p class="mb0">3 offers price from $130,00</p>
                            </div>
                        </a>
                    </div>
                </div>

                <div class="col-sm-3">
                    <div class="pop-item">
                        <a href="#">
                            <img src="<?php echo esc_url(get_template_directory_uri());?>/img/Barclay-400x300.jpg">
                            <div class="content">
                                <h5>InterContinental New York Barclay</h5>
                                <p>5 reviews</p>
                                <p class="mb0">3 offers price from $130,00</p>
                            </div>
                        </a>
                    </div>
                </div>

                <div class="col-sm-3">
                    <div class="pop-item">
                        <a href="#">
                            <img src="<?php echo esc_url(get_template_directory_uri());?>/img/pexels-photo-97904-400x300.jpeg">
                            <div class="content">
                                <h5>InterContinental New York Barclay</h5>
                                <p>5 reviews</p>
                                <p class="mb0">3 offers price from $130,00</p>
                            </div>
                        </a>
                    </div>
                </div>

            </div>
        </div>
    </div>

    <div class="to-deal u-padding-t-20">
        <div class="container">
            <div class="sec-ti">
                <h2>Top Deals</h2>
            </div>
            <div class="row">

                <div class="col-12 col-sm-6 col-lg-3">
                    <div class="top-deal-item">
                        <a href="#" class="fig">
                            <img src="<?php echo esc_url(get_template_directory_uri());?>/img/Barclay-400x300.jpg">
                            <span>Book Now</span>
                        </a>
                               
                        <div class="content">
                            <div class="icons">
                                <i class="fa fa-star"></i>         
                                <i class="fa fa-star"></i>         
                                <i class="fa fa-star"></i>         
                                <i class="fa fa-star"></i>         
                                <i class="fa fa-star"></i>         
                            </div>
                            <h5><a href="#">InterContinental New</a></h5>
                            <div class="location">
                                <i class="fa fa-map-marker"></i>
                                <span> Paris-Charles de Gaulle Airport, Roissy-en-France, France</span>
                            </div>
                            <p class="mb0">from $130,00 <small>/night</small></p>
                        </div>
                           
                    </div>
      
                </div><!-- car item col -->



                <div class="col-12 col-sm-6 col-lg-3">
                    <div class="top-deal-item">
                        <a href="#" class="fig">
                            <img src="<?php echo esc_url(get_template_directory_uri());?>/img/Barclay-400x300.jpg">
                            <span>Book Now</span>
                        </a>
                               
                        <div class="content">
                            <div class="icons">
                                <i class="fa fa-star"></i>         
                                <i class="fa fa-star"></i>         
                                <i class="fa fa-star"></i>         
                                <i class="fa fa-star"></i>         
                                <i class="fa fa-star"></i>         
                            </div>
                            <h5><a href="#">InterContinental New</a></h5>
                            <div class="location">
                                <i class="fa fa-map-marker"></i>
                                <span> Paris-Charles de Gaulle Airport, Roissy-en-France, France</span>
                            </div>
                            <p class="mb0">from $130,00 <small>/night</small></p>
                        </div>
                           
                    </div>
      
                </div><!-- car item col -->


                <div class="col-12 col-sm-6 col-lg-3">
                    <div class="top-deal-item">
                        <a href="#" class="fig">
                            <img src="<?php echo esc_url(get_template_directory_uri());?>/img/Barclay-400x300.jpg">
                            <span>Book Now</span>
                        </a>
                               
                        <div class="content">
                            <div class="icons">
                                <i class="fa fa-star"></i>         
                                <i class="fa fa-star"></i>         
                                <i class="fa fa-star"></i>         
                                <i class="fa fa-star"></i>         
                                <i class="fa fa-star"></i>         
                            </div>
                            <h5><a href="#">InterContinental New</a></h5>
                            <div class="location">
                                <i class="fa fa-map-marker"></i>
                                <span> Paris-Charles de Gaulle Airport, Roissy-en-France, France</span>
                            </div>
                            <p class="mb0">from $130,00 <small>/night</small></p>
                        </div>
                           
                    </div>
      
                </div><!-- car item col -->



                <div class="col-12 col-sm-6 col-lg-3">
                    <div class="top-deal-item">
                        <a href="#" class="fig">
                            <img src="<?php echo esc_url(get_template_directory_uri());?>/img/Barclay-400x300.jpg">
                            <span>Book Now</span>
                        </a>
                               
                        <div class="content">
                            <div class="icons">
                                <i class="fa fa-star"></i>         
                                <i class="fa fa-star"></i>         
                                <i class="fa fa-star"></i>         
                                <i class="fa fa-star"></i>         
                                <i class="fa fa-star"></i>         
                            </div>
                            <h5><a href="#">InterContinental New</a></h5>
                            <div class="location">
                                <i class="fa fa-map-marker"></i>
                                <span> Paris-Charles de Gaulle Airport, Roissy-en-France, France</span>
                            </div>
                            <p class="mb0">from $130,00 <small>/night</small></p>
                        </div>
                           
                    </div>
      
                </div><!-- car item col -->



                <div class="col-12 col-sm-6 col-lg-3">
                    <div class="top-deal-item">
                        <a href="#" class="fig">
                            <img src="<?php echo esc_url(get_template_directory_uri());?>/img/Barclay-400x300.jpg">
                            <span>Book Now</span>
                        </a>
                               
                        <div class="content">
                            <div class="icons">
                                <i class="fa fa-star"></i>         
                                <i class="fa fa-star"></i>         
                                <i class="fa fa-star"></i>         
                                <i class="fa fa-star"></i>         
                                <i class="fa fa-star"></i>         
                            </div>
                            <h5><a href="#">InterContinental New</a></h5>
                            <div class="location">
                                <i class="fa fa-map-marker"></i>
                                <span> Paris-Charles de Gaulle Airport, Roissy-en-France, France</span>
                            </div>
                            <p class="mb0">from $130,00 <small>/night</small></p>
                        </div>
                           
                    </div>
      
                </div><!-- car item col -->



                <div class="col-12 col-sm-6 col-lg-3">
                    <div class="top-deal-item">
                        <a href="#" class="fig">
                            <img src="<?php echo esc_url(get_template_directory_uri());?>/img/Barclay-400x300.jpg">
                            <span>Book Now</span>
                        </a>
                               
                        <div class="content">
                            <div class="icons">
                                <i class="fa fa-star"></i>         
                                <i class="fa fa-star"></i>         
                                <i class="fa fa-star"></i>         
                                <i class="fa fa-star"></i>         
                                <i class="fa fa-star"></i>         
                            </div>
                            <h5><a href="#">InterContinental New</a></h5>
                            <div class="location">
                                <i class="fa fa-map-marker"></i>
                                <span> Paris-Charles de Gaulle Airport, Roissy-en-France, France</span>
                            </div>
                            <p class="mb0">from $130,00 <small>/night</small></p>
                        </div>
                           
                    </div>
      
                </div><!-- car item col -->



                <div class="col-12 col-sm-6 col-lg-3">
                    <div class="top-deal-item">
                        <a href="#" class="fig">
                            <img src="<?php echo esc_url(get_template_directory_uri());?>/img/Barclay-400x300.jpg">
                            <span>Book Now</span>
                        </a>
                               
                        <div class="content">
                            <div class="icons">
                                <i class="fa fa-star"></i>         
                                <i class="fa fa-star"></i>         
                                <i class="fa fa-star"></i>         
                                <i class="fa fa-star"></i>         
                                <i class="fa fa-star"></i>         
                            </div>
                            <h5><a href="#">InterContinental New</a></h5>
                            <div class="location">
                                <i class="fa fa-map-marker"></i>
                                <span> Paris-Charles de Gaulle Airport, Roissy-en-France, France</span>
                            </div>
                            <p class="mb0">from $130,00 <small>/night</small></p>
                        </div>
                           
                    </div>
      
                </div><!-- car item col -->



                <div class="col-12 col-sm-6 col-lg-3">
                    <div class="top-deal-item">
                        <a href="#" class="fig">
                            <img src="<?php echo esc_url(get_template_directory_uri());?>/img/Barclay-400x300.jpg">
                            <span>Book Now</span>
                        </a>
                               
                        <div class="content">
                            <div class="icons">
                                <i class="fa fa-star"></i>         
                                <i class="fa fa-star"></i>         
                                <i class="fa fa-star"></i>         
                                <i class="fa fa-star"></i>         
                                <i class="fa fa-star"></i>         
                            </div>
                            <h5><a href="#">InterContinental New</a></h5>
                            <div class="location">
                                <i class="fa fa-map-marker"></i>
                                <span> Paris-Charles de Gaulle Airport, Roissy-en-France, France</span>
                            </div>
                            <p class="mb0">from $130,00 <small>/night</small></p>
                        </div>
                           
                    </div>
      
                </div><!-- car item col -->





            </div>
        </div>
    </div>



<?php get_footer();?>