<?php
/**
 * The umrah package template file
 *
 * This is the most generic template file in a WordPress theme
 * and one of the two required files for a theme (the other being style.css).
 * It is used to display a page when nothing more specific matches a query.
 * E.g., it puts together the home page when no home.php file exists.
 *
 * @link https://developer.wordpress.org/themes/basics/template-hierarchy/
 *
 * @package aynix
 */
 /*
  Template Name: umrah-package
*/
get_header(); ?>
 
           <!-- mobile-menu-area start -->
        <div class="mobile-menu-area">
          <div class="container">
            <div class="row">
              <div class="col-md-12">
                <div class="mobile-menu">
                  <nav id="dropdown">
                    <ul>
                        <li class="active"><a href="#">Home</a>
                            <ul>
                                <li><a href="#">Sub Item</a></li>
                                <li><a href="#">Sub Item</a></li>
                                <li><a href="#">Sub Item</a></li>
                                <li><a href="#">Sub Item</a></li>
                                <li><a href="#">Sub Item</a></li>
                                <li><a href="#">Sub Item</a></li>
                                <li><a href="#">Sub Item</a></li>
                            </ul>
                        </li>
                        <li><a href="#">Projects</a></li>
                        <li><a href="#">Activities</a></li>
                        <li><a href="#">Total Jobs</a></li>
                        <li><a href="#">Flights</a></li>
                        <li><a href="#">Hotels</a></li>
                    </ul>
                  </nav>
                </div>
              </div>
            </div>
          </div>
        </div>
        <!-- mobile-menu-area end -->



        <div class="umrah-pack has-border">
            <div class="container">
                <div class="umpk-top">
                   <div class="title">
                        <h3>7 Days Star Umrah Package-03- <span>(5 Star)</span></h3>
                        <button class="btn-check">BMU Selected <i class="fa fa-check"></i></button>
                        <button class="btn-check">Promotion Packages <i class="fa fa-check"></i></button>
                   </div>
                   <div class="um-cat">
                       <a href="#"><img src="<?php echo esc_url(get_template_directory_uri());?>/img/company_name.png" alt="">Flying World Travels</a>
                   </div>
                   <div class="um-meta">
                       <ul>

                           <li class="ratings exp">
                               <div class="stars">
                                   <i class="fa fa-star"></i>
                                   <i class="fa fa-star"></i>
                                   <i class="fa fa-star"></i>
                                   <i class="fa  fa-star-half-empty"></i>
                                   <i class="fa  fa-star-o"></i>
                               </div>
                               <span>3.5</span>
                           </li>

                            <li>
                                <div class="text-img">
                                    <img src="<?php echo esc_url(get_template_directory_uri());?>/img/user_icon.png">
                                    <span>Expert Rating</span>
                                </div>
                            </li>
                            
                            <li class="ratings user">
                               <div class="stars">
                                   <i class="fa fa-star"></i>
                                   <i class="fa fa-star"></i>
                                   <i class="fa fa-star"></i>
                                   <i class="fa  fa-star-half-empty"></i>
                                   <i class="fa  fa-star-o"></i>
                               </div>
                               <span>3.5</span>
                           </li>


                            <li>
                                <div class="text-img">
                                    <img src="<?php echo esc_url(get_template_directory_uri());?>/img/user_group_icon.png">
                                    <span>User Rating</span>
                                </div>
                            </li>

                       </ul>
                       
                   </div>
                </div>

                <div class="um-meta-top">
                    <div class="row">

                        <div class="col-sm-4">
                            <div class="inner">
                                <p>Choose your departure 25/09/2018 To 31/01/2019.</p>
                                <figure>
                                    <img src="<?php echo esc_url(get_template_directory_uri());?>/img/thumb_1537856321-package-image.jpg">
                                </figure>
                            </div>
                        </div>

                        <div class="col-sm-4">
                            <div class="inner">
                                <div class="lists">

                                    <div class="left">

                                        <h4>Makkah</h4>
                                        <ul>
                                            <li>
                                                <span><img src="<?php echo esc_url(get_template_directory_uri());?>/img/hotel.png"></span>
                                                <p>Gandourah ...</p>
                                            </li>
                                            <li>
                                                <span><img src="<?php echo esc_url(get_template_directory_uri());?>/img/days.png"></span>
                                                <p>18 Days</p>
                                            </li>
                                            <li>
                                                <span><img src="<?php echo esc_url(get_template_directory_uri());?>/img/nights.png"></span>
                                                <p>17 Nights</p>
                                            </li>
                                        </ul>
                                  
                                    </div>


                                    <div class="right">

                                        <h4>Madinah</h4>
                                        <ul>
                                            <li>
                                                <span><img src="<?php echo esc_url(get_template_directory_uri());?>/img/hotel.png"></span>
                                                <p>Gandourah ...</p>
                                            </li>
                                            <li>
                                                <span><img src="<?php echo esc_url(get_template_directory_uri());?>/img/days.png"></span>
                                                <p>18 Days</p>
                                            </li>
                                            <li>
                                                <span><img src="<?php echo esc_url(get_template_directory_uri());?>/img/nights.png"></span>
                                                <p>17 Nights</p>
                                            </li>
                                        </ul>
                                    </div>


                                </div>

                                <div class="img-list">
                                    <ul>
                                        <li data-toggle="tooltip" data-placement="top" title="" data-original-title="Data on top"><a href="#"><img src="<?php echo esc_url(get_template_directory_uri());?>/img/visa.png"></a></li>
                                        <li data-toggle="tooltip" data-placement="top" title="" data-original-title="Data on top"><a href="#"><img src="<?php echo esc_url(get_template_directory_uri());?>/img/transport.png"></a></li>
                                        <li data-toggle="tooltip" data-placement="top" title="" data-original-title="Data on top"><a href="#"><img src="<?php echo esc_url(get_template_directory_uri());?>/img/ticket.png"></a></li>
                                        <li data-toggle="tooltip" data-placement="top" title="" data-original-title="Data on top"><a href="#"><img src="<?php echo esc_url(get_template_directory_uri());?>/img/ziarat.png"></a></li>
                                    </ul>
                                </div>

                            </div>                            
                        </div>


                        <div class="col-sm-4">
                            <div class="left-content">

                                <div class="item">
                                    <span>Double Bed</span>
                                    <p>PKR 47,625</p>
                                </div>

                                <div class="item">
                                    <span>Triple Bed</span>
                                    <p>PKR 47,625</p>
                                </div>
                                

                                <div class="item">
                                    <span>Quad(4 Bed)</span>
                                    <p>PKR 47,625</p>
                                </div>

                                <div class="btn-area">
                                    <a href="<?php bloginfo(); ?>/book-now/" class="btn btn-primary">Book Now</a>
                                </div>

                            </div>
                        </div>


                    </div>
                </div>


                <div class="um-tab-area">

                    <ul class="nav nav-tabs" role="tablist">
                      <li class="nav-item">
                        <a class="nav-link active" href="#summary" role="tab" data-toggle="tab"><i class="fa fa-file-text-o"></i>Summary</a>
                      </li>
                      <li class="nav-item">
                        <a class="nav-link" href="#rating" role="tab" data-toggle="tab">
                            <i class="fa fa-star-o"></i>Rating
                        </a>
                      </li>
                      <li class="nav-item">
                        <a class="nav-link" href="#reviews" role="tab" data-toggle="tab">
                            <i class="fa fa-edit"></i>Reviews</a>
                      </li>
                      <li class="nav-item">
                        <a class="nav-link" href="#pricing" role="tab" data-toggle="tab">
                            <i class="fa fa-bar-chart-o"></i>Pricing</a>
                      </li>
                      <li class="nav-item">
                        <a class="nav-link" href="#policies" role="tab" data-toggle="tab">
                            <i class="fa fa-file-text-o"></i>Policies</a>
                      </li>
                      <li class="nav-item">
                        <a class="nav-link" href="#interest" role="tab" data-toggle="tab">
                            <i class="fa fa-map-marker"></i>Point of Interest</a>
                      </li>
                    </ul>

                    <!-- Tab panes -->
                    <div class="tab-content">
                      <div role="tabpanel" class="tab-pane fade in active show" id="summary">
                          <div class="wrap">
                              <div class="tab-title">
                                  <h3><img src="<?php echo esc_url(get_template_directory_uri());?>/img/summary_big.png">Summary</h3>
                              </div>

                              <div class="list-det">
                                    <div class="list-det__title">
                                        <h3>
                                            <i class="fa fa-file-text-o"></i>
                                            Package Details
                                        </h3>
                                    </div>
                                  <ul>
                                      <li>
                                        <span class="left">Agent Name:</span>
                                        <span class="right">Flying World Travels</span>
                                    </li>
                                      <li>
                                        <span class="left">Package Name:</span>
                                        <span class="right">7 Days Star Umrah Package-03</span>
                                    </li>
                                      <li>
                                        <span class="left">Total Stay:</span>
                                        <span class="right">7 Days</span>
                                    </li>
                                      <li>
                                        <span class="left">Makkah Stay:</span>
                                        <span class="right">4 Days</span>
                                    </li>
                                      <li>
                                        <span class="left">Madinah Stay:</span>
                                        <span class="right">3 Days</span>
                                    </li>
                                      <li>
                                        <span class="left">Departure Cities:</span>
                                        <span class="right">Lahore, Peshawar, Karachi, Islamabad / Rawalpindi, Faisalabad, Hafizabad, Gujranwala</span>
                                    </li>
                                      <li>
                                        <span class="left">Destination City:</span>
                                        <span class="right">Makkah , Madinah</span>
                                    </li>
                                  </ul>
                              </div>

                              <div class="list-det">
                                    <div class="list-det__title">
                                        <h3>
                                            <i class="fa fa-file-text-o"></i>
                                            Hotel Details
                                        </h3>
                                    </div>
                                  <ul>
                                      <li>
                                        <span class="left">Makkah Hotel Name:</span>
                                        <span class="right">Le Meridian Hotel 5 Star</span>
                                    </li>
                                      <li>
                                        <span class="left">Package Name:</span>
                                        <span class="right">7 Days Star Umrah Package-03</span>
                                    </li>
                                      <li>
                                        <span class="left">Total Stay:</span>
                                        <span class="right">7 Days</span>
                                    </li>
                                      <li>
                                        <span class="left">Makkah Stay:</span>
                                        <span class="right">4 Days</span>
                                    </li>
                                      <li>
                                        <span class="left">Madinah Stay:</span>
                                        <span class="right">3 Days</span>
                                    </li>
                                      <li>
                                        <span class="left">Departure Cities:</span>
                                        <span class="right">Lahore, Peshawar, Karachi, Islamabad / Rawalpindi, Faisalabad, Hafizabad, Gujranwala</span>
                                    </li>
                                      <li>
                                        <span class="left">Destination City:</span>
                                        <span class="right">Makkah , Madinah</span>
                                    </li>
                                  </ul>
                              </div>


                              <div class="list-det list-det-table">
                                    <div class="list-det__title">
                                        <h3>
                                            <img src="<?php echo esc_url(get_template_directory_uri());?>/img/facilities.png">
                                            Facilites 
                                        </h3>
                                    </div>
                                  <div class="tbl-wrap">
                                    <table>
                                        <thead>
                                            <tr>
                                                <th>Facility</th>
                                                <th>Included</th>
                                                <th>Policy</th>
                                            </tr>
                                        </thead>

                                        <tbody>

                                            <tr>
                                                <td>Visa</td>
                                                <td>VisaYes</td>
                                                <td><a href="#">View</a></td>
                                            </tr>

                                            <tr>
                                                <td>Shuttle</td>
                                                <td>No</td>
                                                <td></td>
                                            </tr>

                                            <tr>
                                                <td>Ziyarat</td>
                                                <td>No</td>
                                                <td></td>
                                            </tr>

                                            <tr>
                                                <td>Greet & Assist</td>
                                                <td>No</td>
                                                <td></td>
                                            </tr>

                                            <tr>
                                                <td>Visa</td>
                                                <td>VisaYes</td>
                                                <td><a href="#">View</a></td>
                                            </tr>

                                            <tr>
                                                <td>Shuttle</td>
                                                <td>No</td>
                                                <td></td>
                                            </tr>

                                            <tr>
                                                <td>Ziyarat</td>
                                                <td>No</td>
                                                <td></td>
                                            </tr>

                                            <tr>
                                                <td>Greet & Assist</td>
                                                <td>No</td>
                                                <td></td>
                                            </tr>

                                            <tr>
                                                <td>Visa</td>
                                                <td>VisaYes</td>
                                                <td><a href="#">View</a></td>
                                            </tr>

                                            <tr>
                                                <td>Shuttle</td>
                                                <td>No</td>
                                                <td></td>
                                            </tr>

                                            <tr>
                                                <td>Ziyarat</td>
                                                <td>No</td>
                                                <td></td>
                                            </tr>

                                            <tr>
                                                <td>Greet & Assist</td>
                                                <td>No</td>
                                                <td></td>
                                            </tr>

                                        </tbody>
                                    </table>
                                    
                                  </div>

                              </div>
                          </div>
                      </div>
                      <div role="tabpanel" class="tab-pane fade" id="rating">
                          <div class="wrap">
                              <div class="tab-title">
                                  <h3><img src="<?php echo esc_url(get_template_directory_uri());?>/img/rating-icon.png">Rating</h3>
                              </div>


                              <div class="rating-block">
                                  <div class="title__rat">
                                      <h3><img src="<?php echo esc_url(get_template_directory_uri());?>/img/user_icon_big.png">Expert Rating</h3>
                                  </div>
                                    
                                    <div class="bd-wrap">
                                    <div class="content-left">
                                      <div class="ratings">
                                          <div class="stars">
                                              <i class="fa fa-star"></i>
                                              <i class="fa fa-star"></i>
                                              <i class="fa fa-star"></i>
                                              <i class="fa fa-star"></i>
                                              <i class="fa fa-star-o"></i>
                                          </div>
                                          <h4>3.5 <small>of 5</small></h4>
                                      </div>
                                  </div>


                                <div class="content-right">
                                    <div class="rat-list">
                                        <h3>Rating Breakdown</h3>
                                        <ul>

                                            <li>
                                                <span class="labl">Religious Escort</span>
                                                <span class="lbl-cont">
                                                    <i class="fa fa-star"></i>
                                                  <i class="fa fa-star"></i>
                                                  <i class="fa fa-star"></i>
                                                  <i class="fa fa-star"></i>
                                                  <i class="fa fa-star-o"></i>
                                                </span>
                                            </li>
                                            

                                            <li>
                                                <span class="labl">Suitable for seniors</span>
                                                <span class="lbl-cont">
                                                    <i class="fa fa-star"></i>
                                                  <i class="fa fa-star"></i>
                                                  <i class="fa fa-star"></i>
                                                  <i class="fa fa-star"></i>
                                                  <i class="fa fa-star-o"></i>
                                                </span>
                                            </li>
                                            

                                            <li>
                                                <span class="labl">Organisation</span>
                                                <span class="lbl-cont">
                                                    <i class="fa fa-star"></i>
                                                  <i class="fa fa-star"></i>
                                                  <i class="fa fa-star"></i>
                                                  <i class="fa fa-star"></i>
                                                  <i class="fa fa-star-o"></i>
                                                </span>
                                            </li>


                                            <li>
                                                <span class="labl">Religious Escort</span>
                                                <span class="lbl-cont">
                                                    <i class="fa fa-star"></i>
                                                  <i class="fa fa-star"></i>
                                                  <i class="fa fa-star"></i>
                                                  <i class="fa fa-star"></i>
                                                  <i class="fa fa-star-o"></i>
                                                </span>
                                            </li>
                                            

                                            <li>
                                                <span class="labl">Suitable for seniors</span>
                                                <span class="lbl-cont">
                                                    <i class="fa fa-star"></i>
                                                  <i class="fa fa-star"></i>
                                                  <i class="fa fa-star"></i>
                                                  <i class="fa fa-star"></i>
                                                  <i class="fa fa-star-o"></i>
                                                </span>
                                            </li>
                                            

                                            <li>
                                                <span class="labl">Organisation</span>
                                                <span class="lbl-cont">
                                                    <i class="fa fa-star"></i>
                                                  <i class="fa fa-star"></i>
                                                  <i class="fa fa-star"></i>
                                                  <i class="fa fa-star"></i>
                                                  <i class="fa fa-star-o"></i>
                                                </span>
                                            </li>

                                        </ul>
                                    </div>
                                </div>
                                    </div>


                              </div>

                              <div class="rating-block">
                                  <div class="title__rat">
                                      <h3><img src="<?php echo esc_url(get_template_directory_uri());?>/img/user_icon_big.png">User Rating</h3>
                                  </div>
                                <div class="bd-wrap">
                                  <div class="content-left">
                                      <div class="ratings">
                                          <div class="stars">
                                              <i class="fa fa-star"></i>
                                              <i class="fa fa-star"></i>
                                              <i class="fa fa-star"></i>
                                              <i class="fa fa-star"></i>
                                              <i class="fa fa-star-o"></i>
                                          </div>
                                          <h4>3.5 <small>of 5</small></h4>
                                      </div>

                                      <div class="rat-summary">
                                          <h3>Rating Summary</h3>
                                          <ul>
                                              <li>
                                                <span class="left">Exellent</span>
                                                <span class="right"></span>
                                            </li>
                                              <li>
                                                <span class="left">Vey Good</span>
                                                <span class="right"></span>
                                            </li>
                                              <li>
                                                <span class="left">Average</span>
                                                <span class="right"></span>
                                            </li>
                                              <li>
                                                <span class="left">Poor</span>
                                                <span class="right"></span>
                                            </li>
                                              <li>
                                                <span class="left">Terrible</span>
                                                <span class="right"></span>
                                            </li>
                                          </ul>
                                      </div>

                                      <div class="write-review">
                                          <button class="btn btn-primary">Rate & Write Review</button>
                                      </div>
                                  </div>

                                <div class="content-right">
                                    <div class="rat-list">
                                        <h3>Rating Breakdown</h3>
                                        <ul>

                                            <li>
                                                <span class="labl">Religious Escort</span>
                                                <span class="lbl-cont">
                                                    <i class="fa fa-star"></i>
                                                  <i class="fa fa-star"></i>
                                                  <i class="fa fa-star"></i>
                                                  <i class="fa fa-star"></i>
                                                  <i class="fa fa-star-o"></i>
                                                </span>
                                            </li>
                                            

                                            <li>
                                                <span class="labl">Suitable for seniors</span>
                                                <span class="lbl-cont">
                                                    <i class="fa fa-star"></i>
                                                  <i class="fa fa-star"></i>
                                                  <i class="fa fa-star"></i>
                                                  <i class="fa fa-star"></i>
                                                  <i class="fa fa-star-o"></i>
                                                </span>
                                            </li>
                                            

                                            <li>
                                                <span class="labl">Organisation</span>
                                                <span class="lbl-cont">
                                                    <i class="fa fa-star"></i>
                                                  <i class="fa fa-star"></i>
                                                  <i class="fa fa-star"></i>
                                                  <i class="fa fa-star"></i>
                                                  <i class="fa fa-star-o"></i>
                                                </span>
                                            </li>


                                            <li>
                                                <span class="labl">Religious Escort</span>
                                                <span class="lbl-cont">
                                                    <i class="fa fa-star"></i>
                                                  <i class="fa fa-star"></i>
                                                  <i class="fa fa-star"></i>
                                                  <i class="fa fa-star"></i>
                                                  <i class="fa fa-star-o"></i>
                                                </span>
                                            </li>
                                            

                                            <li>
                                                <span class="labl">Suitable for seniors</span>
                                                <span class="lbl-cont">
                                                    <i class="fa fa-star"></i>
                                                  <i class="fa fa-star"></i>
                                                  <i class="fa fa-star"></i>
                                                  <i class="fa fa-star"></i>
                                                  <i class="fa fa-star-o"></i>
                                                </span>
                                            </li>
                                            

                                            <li>
                                                <span class="labl">Organisation</span>
                                                <span class="lbl-cont">
                                                    <i class="fa fa-star"></i>
                                                  <i class="fa fa-star"></i>
                                                  <i class="fa fa-star"></i>
                                                  <i class="fa fa-star"></i>
                                                  <i class="fa fa-star-o"></i>
                                                </span>
                                            </li>

                                        </ul>
                                    </div>
                                </div>

                              </div>
                              </div>




                          </div>
                      </div>

                      <div role="tabpanel" class="tab-pane fade" id="reviews">
                          <div class="wrap">
                                <div class="tab-title">
                                  <h3><img src="<?php echo esc_url(get_template_directory_uri());?>/img/rating-icon.png">Reviews</h3>
                              </div>
                                                        
                                <div class="review-box">
                                    <form class="left">
                                        <h3>Rate & Write a Review</h3>

                                        <div class="f-row">
                                            <label>Review Title</label>
                                            <input type="text" class="form-control">
                                        </div>
                                        

                                        <div class="f-row">
                                            <label>Review Text</label>
                                            <textarea class="form-control"></textarea>
                                        </div>

                                        <div class="rev-submit u-padding-t-15">
                                            <button class="btn btn-primary" type="submit">Leave a Review</button>
                                        </div>

                                    </form>

                                    <div class="content-right">

                                            <ul>

                                                <li>
                                                    <span class="labl">Religious Escort</span>
                                                    <span class="lbl-cont">
                                                        <i class="fa fa-star"></i>
                                                      <i class="fa fa-star"></i>
                                                      <i class="fa fa-star"></i>
                                                      <i class="fa fa-star"></i>
                                                      <i class="fa fa-star-o"></i>
                                                    </span>
                                                </li>
                                                

                                                <li>
                                                    <span class="labl">Religious Escort</span>
                                                    <span class="lbl-cont">
                                                        <i class="fa fa-star"></i>
                                                      <i class="fa fa-star"></i>
                                                      <i class="fa fa-star"></i>
                                                      <i class="fa fa-star"></i>
                                                      <i class="fa fa-star-o"></i>
                                                    </span>
                                                </li>
                                                

                                                <li>
                                                    <span class="labl">Religious Escort</span>
                                                    <span class="lbl-cont">
                                                        <i class="fa fa-star"></i>
                                                      <i class="fa fa-star"></i>
                                                      <i class="fa fa-star"></i>
                                                      <i class="fa fa-star"></i>
                                                      <i class="fa fa-star-o"></i>
                                                    </span>
                                                </li>
                                                

                                                <li>
                                                    <span class="labl">Religious Escort</span>
                                                    <span class="lbl-cont">
                                                        <i class="fa fa-star"></i>
                                                      <i class="fa fa-star"></i>
                                                      <i class="fa fa-star"></i>
                                                      <i class="fa fa-star"></i>
                                                      <i class="fa fa-star-o"></i>
                                                    </span>
                                                </li>
                                                

                                                <li>
                                                    <span class="labl">Suitable for seniors</span>
                                                    <span class="lbl-cont">
                                                        <i class="fa fa-star"></i>
                                                      <i class="fa fa-star"></i>
                                                      <i class="fa fa-star"></i>
                                                      <i class="fa fa-star"></i>
                                                      <i class="fa fa-star-o"></i>
                                                    </span>
                                                </li>
                                                

                                                <li>
                                                    <span class="labl">Organisation</span>
                                                    <span class="lbl-cont">
                                                        <i class="fa fa-star"></i>
                                                      <i class="fa fa-star"></i>
                                                      <i class="fa fa-star"></i>
                                                      <i class="fa fa-star"></i>
                                                      <i class="fa fa-star-o"></i>
                                                    </span>
                                                </li>

                                            </ul>
                                    
                                    </div>
                                </div>     

                          </div>
                      </div>

                      <div role="tabpanel" class="tab-pane fade" id="pricing">
                          <div class="wrap">
                                <div class="tab-title">
                                  <h3><img src="<?php echo esc_url(get_template_directory_uri());?>/img/price-icon.png">Pricing</h3>
                              </div>
                                
                                <div class="pricing-table">
                                    <table>
                                        <thead>
                                            <tr>
                                                <th></th>
                                                <th>Occupancy</th>
                                                <th>Price per person</th>
                                                <th>Extra night in Madina</th>
                                                <th>Extra night in Makkah</th>
                                                <th></th>
                                            </tr>
                                        </thead>

                                        <tbody>

                                            <tr>
                                                <td>
                                                    <div class="icons">
                                                        <i class="fa fa-hotel"></i>
                                                        <i class="fa fa-hotel"></i>
                                                    </div>
                                                </td>

                                                <td>Double Bed</td>
                                                <td>PKR 47,625</td>
                                                <td>PKR 5,163</td>
                                                <td>PKR 6,913</td>
                                                <td>
                                                    <div class="butn">
                                                        <a href="<?php bloginfo(); ?>/book-now/" class="btn btn-primary">Book Now</a>
                                                    </div>
                                                </td>
                                            </tr>

                                            <tr>
                                                <td>
                                                    <div class="icons">
                                                        <i class="fa fa-hotel"></i>
                                                        <i class="fa fa-hotel"></i>
                                                    </div>
                                                </td>

                                                <td>Double Bed</td>
                                                <td>PKR 47,625</td>
                                                <td>PKR 5,163</td>
                                                <td>PKR 6,913</td>
                                                <td>
                                                    <div class="butn">
                                                        <a href="<?php bloginfo(); ?>/book-now/" class="btn btn-primary">Book Now</a>
                                                    </div>
                                                </td>
                                            </tr>

                                            <tr>
                                                <td>
                                                    <div class="icons">
                                                        <i class="fa fa-hotel"></i>
                                                        <i class="fa fa-hotel"></i>
                                                    </div>
                                                </td>

                                                <td>Double Bed</td>
                                                <td>PKR 47,625</td>
                                                <td>PKR 5,163</td>
                                                <td>PKR 6,913</td>
                                                <td>
                                                    <div class="butn">
                                                        <a href="<?php bloginfo(); ?>/book-now/" class="btn btn-primary">Book Now</a>
                                                    </div>
                                                </td>
                                            </tr>

                                            <tr>
                                                <td>
                                                    <div class="icons">
                                                        <i class="fa fa-hotel"></i>
                                                        <i class="fa fa-hotel"></i>
                                                    </div>
                                                </td>

                                                <td>Double Bed</td>
                                                <td>PKR 47,625</td>
                                                <td>PKR 5,163</td>
                                                <td>PKR 6,913</td>
                                                <td>
                                                    <div class="butn">
                                                        <a href="<?php bloginfo(); ?>/book-now/" class="btn btn-primary">Book Now</a>
                                                    </div>
                                                </td>
                                            </tr>

                                            <tr>
                                                <td>
                                                    <div class="icons">
                                                        <i class="fa fa-hotel"></i>
                                                        <i class="fa fa-hotel"></i>
                                                    </div>
                                                </td>

                                                <td>Double Bed</td>
                                                <td>PKR 47,625</td>
                                                <td>PKR 5,163</td>
                                                <td>PKR 6,913</td>
                                                <td>
                                                    <div class="butn">
                                                        <a href="<?php bloginfo(); ?>/book-now/" class="btn btn-primary">Book Now</a>
                                                    </div>
                                                </td>
                                            </tr>

                                            <tr>
                                                <td>
                                                    <div class="icons">
                                                        <i class="fa fa-hotel"></i>
                                                        <i class="fa fa-hotel"></i>
                                                    </div>
                                                </td>

                                                <td>Double Bed</td>
                                                <td>PKR 47,625</td>
                                                <td>PKR 5,163</td>
                                                <td>PKR 6,913</td>
                                                <td>
                                                    <div class="butn">
                                                        <a href="<?php bloginfo(); ?>/book-now/" class="btn btn-primary">Book Now</a>
                                                    </div>
                                                </td>
                                            </tr>


                                        </tbody>
                                    </table>
                                </div>

                                <div class="note">
                                    <h6>Note</h6>
                                    <p>1- Prices mentioned above are valid from 25/09/2018 to 31/01/2019</p>
                                    <p>2- Prices mentioned above are based upon current value of SAR (Saudi Riyal). Any change in currency conversion rate (SAR) may impact these prices. However any change in rate will be communicated to you before your booking is finalized.</p>
                                </div>


                          </div>
                      </div>
                        
                        <div role="tabpanel" class="tab-pane fade" id="policies">
                            <div class="wrap">
                                <div class="tab-title">
                                      <h3><img src="<?php echo esc_url(get_template_directory_uri());?>/img/policies-icon.png">Policies</h3>
                                </div>

                              <div class="ineer-content">

                                  <div class="block">
                                      <h4><img src="<?php echo esc_url(get_template_directory_uri());?>/img/child.png">Child Policy</h4>
                                      <ul>
                                          <li>Child above 5 years will be considered as adult and will be charged with full package price.</li>
                                          <li>Child between age of 2-5 years have to pay Umrah processing fee PKR 15,000/- only.</li>
                                      </ul>
                                  </div>

                                  <div class="block">
                                      <h4><img src="<?php echo esc_url(get_template_directory_uri());?>/img/infact_policy.png">Infant Policy   </h4>
                                      <ul>
                                          <li>Infant visa Fee will be charged 15000/- PKR .</li>
                                      </ul>
                                  </div>

                                  <div class="block">
                                      <h4><img src="<?php echo esc_url(get_template_directory_uri());?>/img/terms_policy.png">Terms & Policy   </h4>
                                      <ul>
                                          <li>PKR 15,000/- will be charged in case of visa rejection from KSA.</li>
                                          <li>PKR 15,000/- will be charged in case If pilgrim decide not to travel (after visa approval).</li>
                                          <li>Validity of given Package start from 06 Shawal.</li>
                                          <li>Visa processing fee is included in package price.</li>
                                          <li>Child above 5 years will be considered as adult and will be charged with full package price.</li>
                                      </ul>
                                  </div>

                              </div>
    
                          </div>
                        </div>

                      <div role="tabpanel" class="tab-pane fade" id="interest">
                        <div class="wrap">
                                <div class="tab-title">
                                  <h3><img src="<?php echo esc_url(get_template_directory_uri());?>/img/poi-icon.png">Point Of Interest</h3>
                              </div>

                              <ul class="int-list">

                                  <li>
                                      <div class="image">
                                          <a href="#"><img src="<?php echo esc_url(get_template_directory_uri());?>/img/thumb_1457012197-poi-image.jpg"></a>
                                      </div>

                                      <div class="cont">
                                          <h3>Masjid al-Haram</h3>
                                          <p>The holiest city of Islam is home to the largest mosque in the world, al-Masjid al-Haram and the Kaaba shrine. It is also the birthplace of the Prophet Muhammad (صلى الله عليه وسلم), and each year millions of Muslims come here to complete the Hajj. Believed to be founded by Abraham and his son Ishmael in 570, Mecca is now a fascinating blend of modernity and antiquity</p>
                                      </div>
                                  </li>

                                  <li>
                                      <div class="image">
                                          <a href="#"><img src="<?php echo esc_url(get_template_directory_uri());?>/img/thumb_1457012197-poi-image.jpg"></a>
                                      </div>

                                      <div class="cont">
                                          <h3>Masjid al-Haram</h3>
                                          <p>The holiest city of Islam is home to the largest mosque in the world, al-Masjid al-Haram and the Kaaba shrine. It is also the birthplace of the Prophet Muhammad (صلى الله عليه وسلم), and each year millions of Muslims come here to complete the Hajj. Believed to be founded by Abraham and his son Ishmael in 570, Mecca is now a fascinating blend of modernity and antiquity</p>
                                      </div>
                                  </li>

                                  <li>
                                      <div class="image">
                                          <a href="#"><img src="<?php echo esc_url(get_template_directory_uri());?>/img/thumb_1457012197-poi-image.jpg"></a>
                                      </div>

                                      <div class="cont">
                                          <h3>Masjid al-Haram</h3>
                                          <p>The holiest city of Islam is home to the largest mosque in the world, al-Masjid al-Haram and the Kaaba shrine. It is also the birthplace of the Prophet Muhammad (صلى الله عليه وسلم), and each year millions of Muslims come here to complete the Hajj. Believed to be founded by Abraham and his son Ishmael in 570, Mecca is now a fascinating blend of modernity and antiquity</p>
                                      </div>
                                  </li>

                                  <li>
                                      <div class="image">
                                          <a href="#"><img src="<?php echo esc_url(get_template_directory_uri());?>/img/thumb_1457012197-poi-image.jpg"></a>
                                      </div>

                                      <div class="cont">
                                          <h3>Masjid al-Haram</h3>
                                          <p>The holiest city of Islam is home to the largest mosque in the world, al-Masjid al-Haram and the Kaaba shrine. It is also the birthplace of the Prophet Muhammad (صلى الله عليه وسلم), and each year millions of Muslims come here to complete the Hajj. Believed to be founded by Abraham and his son Ishmael in 570, Mecca is now a fascinating blend of modernity and antiquity</p>
                                      </div>
                                  </li>

                                  <li>
                                      <div class="image">
                                          <a href="#"><img src="<?php echo esc_url(get_template_directory_uri());?>/img/thumb_1457012197-poi-image.jpg"></a>
                                      </div>

                                      <div class="cont">
                                          <h3>Masjid al-Haram</h3>
                                          <p>The holiest city of Islam is home to the largest mosque in the world, al-Masjid al-Haram and the Kaaba shrine. It is also the birthplace of the Prophet Muhammad (صلى الله عليه وسلم), and each year millions of Muslims come here to complete the Hajj. Believed to be founded by Abraham and his son Ishmael in 570, Mecca is now a fascinating blend of modernity and antiquity</p>
                                      </div>
                                  </li>

                                  
                              </ul>
                          </div>
                      </div>


                    </div>

                </div>

            </div>
        </div>


<?php get_footer();?>