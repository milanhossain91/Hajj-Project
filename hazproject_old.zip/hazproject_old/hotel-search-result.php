<?php
/**
 * The rental search result template file
 *
 * This is the most generic template file in a WordPress theme
 * and one of the two required files for a theme (the other being style.css).
 * It is used to display a page when nothing more specific matches a query.
 * E.g., it puts together the home page when no home.php file exists.
 *
 * @link https://developer.wordpress.org/themes/basics/template-hierarchy/
 *
 * @package aynix
 */
 /*
  Template Name: hotel_search_result
*/
get_header(); ?>
   
     <!-- mobile-menu-area start -->
        <div class="mobile-menu-area">
          <div class="container">
            <div class="row">
              <div class="col-md-12">
                <div class="mobile-menu">
                  <nav id="dropdown">
                    <ul>
                        <li class="active"><a href="#">Home</a>
                            <ul>
                                <li><a href="#">Sub Item</a></li>
                                <li><a href="#">Sub Item</a></li>
                                <li><a href="#">Sub Item</a></li>
                                <li><a href="#">Sub Item</a></li>
                                <li><a href="#">Sub Item</a></li>
                                <li><a href="#">Sub Item</a></li>
                                <li><a href="#">Sub Item</a></li>
                            </ul>
                        </li>
                        <li><a href="#">Projects</a></li>
                        <li><a href="#">Activities</a></li>
                        <li><a href="#">Total Jobs</a></li>
                        <li><a href="#">Flights</a></li>
                        <li><a href="#">Hotels</a></li>
                    </ul>
                  </nav>
                </div>
              </div>
            </div>
          </div>
        </div>
        <!-- mobile-menu-area end -->



        <div class="search-res flight has-border">
            <div class="container">
                <div class="top-title">
                    <h3> Hotels Filter</h3>
                </div>
                <div class="row">
                    <div class="col-sm-3">
                        <div class="left-sidebar">
                            
                           

                            <div class="bar-item">
                                <div class="wrap">

                                      <a class="ac-title"  data-toggle="collapse" href="#ac2" role="button" aria-expanded="false" aria-controls="ac2">Hotel Rating</a>
                                 
                                    <div class="collapse show" id="ac1">
                                  <div class="inner">
                                     <?php
                                        $search = new WP_Advanced_Search('tourhotelrating');
                                        ?>
                                    <div class="custom-control custom-checkbox">
                                            <div class="row search-section">
                                           <div id="sidebar" class="large-3 columns">
                                              <?php $search->the_form(); ?>
                                           </div>
                        
                                    </div>
                                    </div>
                                  
                                </div>
                              </div>
                            </div>
                            </div>


                            <div class="bar-item">
                                <div class="wrap">
                                    <a class="ac-title"  data-toggle="collapse" href="#ac2" role="button" aria-expanded="false" aria-controls="ac2">Facilities</a>
                                    <div class="collapse show" id="ac2">
                                  <div class="inner">

                                        <?php
                                        $search = new WP_Advanced_Search('hotelfacilitiesall');
                                        ?>
                                    <div class="custom-control custom-checkbox">
                                            <div class="row search-section">
                                           <div id="sidebar" class="large-3 columns">
                                              <?php $search->the_form(); ?>
                                           </div>
                        
                                    </div>
                                    </div>
                                   
                                </div>
                              </div>
                            </div>
                            </div>


                            <div class="bar-item">
                                <div class="wrap">
                                    <a class="ac-title"  data-toggle="collapse" href="#ac3" role="button" aria-expanded="false" aria-controls="ac3">Departure Time</a>
                                    <div class="collapse show" id="ac3">
                                  <div class="inner">
                                        <?php
                                        $search = new WP_Advanced_Search('hoteldeparturetime');
                                        ?>
                                    <div class="custom-control custom-checkbox">
                                            <div class="row search-section">
                                           <div id="sidebar" class="large-3 columns">
                                              <?php $search->the_form(); ?>
                                           </div>
                        
                                    </div>
                                    </div>
                                </div>
                              </div>
                            </div>
                            </div>

                        </div>
                    </div> <!-- col- end -->

                    


                            <?php if(have_posts()): ?>

                                <div class="col-sm-9">
                                  

                         

                               <div id="wpas-results">

                                    
                            
                         </div>
                         </div>


                            <?php

                             else :
                  $ourteams = new WP_Query(array(
                  'post_type' => 'hotelhajj', 
                  'posts_per_page' => 0 
                  ));

                  
                    while ($ourteams->have_posts() ) : 
                 $ourteams->the_post();?>

                        <div class="col-sm-9">
                                  <div class="row hotels-res">

                            <div class="col-sm-4">
                                <div class="top-deal-item">
                                    <a href="<?php the_permalink(); ?>" class="fig">

                                          <?php 
                                                 $title=get_the_title();
                                                 the_post_thumbnail( array(251, 188),array( 'alt' =>$title) );

                                                 ?>
                                        


                                        <span>Book Now</span>
                                    </a>
                                           
                                    <div class="content">
                                        <div class="icons">
                                            <i class="fa fa-star"></i>         
                                            <i class="fa fa-star"></i>         
                                            <i class="fa fa-star"></i>         
                                            <i class="fa fa-star"></i>         
                                            <i class="fa fa-star"></i>         
                                        </div>
                                        <h5><a href="<?php the_permalink(); ?>">I<?php the_title()?></a></h5>
                                        <div class="location">
                                            <i class="fa fa-map-marker"></i>
                                            <span><?php echo get_post_meta( get_the_ID(), 'hotellocation', true );?></span>
                                        </div>
                                        <p class="mb0">from <?php echo get_post_meta( get_the_ID(), 'hotelprice', true );?> <small>/night</small></p>
                                    </div>
                               
                                </div>
                            </div>

                                 </div>
                            </div>






                              <?php 

                         endwhile;  


                         endif; ?>  






                     
                        </div>

                         
                    </div> <!--  col end-->
                </div>
            </div>
        </div>


<?php get_footer();?>