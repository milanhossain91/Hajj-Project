<?php
/**
 * The hotel search template file
 *
 * This is the most generic template file in a WordPress theme
 * and one of the two required files for a theme (the other being style.css).
 * It is used to display a page when nothing more specific matches a query.
 * E.g., it puts together the home page when no home.php file exists.
 *
 * @link https://developer.wordpress.org/themes/basics/template-hierarchy/
 *
 * @package aynix
 */
 /*
  Template Name: hotel-search
*/
get_header(); ?>
     
        <!-- mobile-menu-area start -->
        <div class="mobile-menu-area">
          <div class="container">
            <div class="row">
              <div class="col-md-12">
                <div class="mobile-menu">
                  <nav id="dropdown">
                    <ul>
                        <li class="active"><a href="#">Home</a>
                            <ul>
                                <li><a href="#">Sub Item</a></li>
                                <li><a href="#">Sub Item</a></li>
                                <li><a href="#">Sub Item</a></li>
                                <li><a href="#">Sub Item</a></li>
                                <li><a href="#">Sub Item</a></li>
                                <li><a href="#">Sub Item</a></li>
                                <li><a href="#">Sub Item</a></li>
                            </ul>
                        </li>
                        <li><a href="#">Projects</a></li>
                        <li><a href="#">Activities</a></li>
                        <li><a href="#">Total Jobs</a></li>
                        <li><a href="#">Flights</a></li>
                        <li><a href="#">Hotels</a></li>
                    </ul>
                  </nav>
                </div>
              </div>
            </div>
          </div>
        </div>
        <!-- mobile-menu-area end -->



    <div class="search-area has-border u-padding-t-60">
        <div class="container">

          <?php 

                          
                                    $args = array(
                                        
                                        'depth'               => 0,
                                        'echo'                => 1,
                                        'exclude'             => '',
                                        'exclude_tree'        => '',
                                        'feed'                => '',
                                        'feed_image'          => '',
                                        'feed_type'           => '',
                                        'hide_empty'          => 0,
                                        'hide_title_if_empty' => false,
                                        'hierarchical'        => true,
                                        'order'               => 'ASC',
                                        'orderby'             => 'name',
                                        'separator'           => '',
                                        'show_count'          => 1,
                                        'show_option_all'     => '',
                                        'show_option_none'    => __( 'No categories' ),
                                        'style'               => 'list',
                                        'taxonomy'            => 'location',
                                       
                                        'use_desc_for_title'  => 0,
                                    );

                                      $categories = get_categories($args);  
                                        $location = array();  
                                        foreach ($categories as $category_list ) 
                                        {  
                                              $location[$category_list->cat_ID] = $category_list->cat_name;  
                                        } 



                                    if($_POST['location'] && !empty($_POST['location']))
                                    {
                                        $location = $_POST['location'];
                                    }

                                    if($_POST['hotelrating'] && !empty($_POST['hotelrating']))
                                    {
                                        $hotelrating = $_POST['hotelrating'];
                                    }
                                    if($_POST['hotelfacilities'] && !empty($_POST['hotelfacilities']))
                                    {
                                        $hotelfacilities = $_POST['hotelfacilities'];
                                    }
                                  
                               
                               

                                        ?>
            <form action="<?php the_permalink(); ?>" method="post">
                <h1 class="title">Search Hotel </h1>
<div class="tf-row row">
                           
                                    <div class="tf-col col-4">

                                
                                        <label for="desti">Hotel Location</label>
                                        <div class="map mb-2">
                                          	 <select class="form-control" name="CarsLocation">
                                        <option>Select Hotel Location</option>
                                       <?php foreach ($location as $v) { ;?>
		                                     <option value="<?php echo $v;?>"><?php echo $v;?></option>
		                                    <?php } ; ?>
		                                </select>
                                        </div>
                                    </div>

                                    <?php 

                          
                                    $args = array(
                                        
                                        'depth'               => 0,
                                        'echo'                => 1,
                                        'exclude'             => '',
                                        'exclude_tree'        => '',
                                        'feed'                => '',
                                        'feed_image'          => '',
                                        'feed_type'           => '',
                                        'hide_empty'          => 0,
                                        'hide_title_if_empty' => false,
                                        'hierarchical'        => true,
                                        'order'               => 'ASC',
                                        'orderby'             => 'name',
                                        'separator'           => '',
                                        'show_count'          => 1,
                                        'show_option_all'     => '',
                                        'show_option_none'    => __( 'No categories' ),
                                        'style'               => 'list',
                                        'taxonomy'            => 'hotelrating',
                                       
                                        'use_desc_for_title'  => 0,
                                    );

                                      $categories = get_categories($args);  
                                        $hotelrating = array();  
                                        foreach ($categories as $category_list ) 
                                        {  
                                              $hotelrating[$category_list->cat_ID] = $category_list->cat_name;  
                                        } 

                               
                               

                                        ?>

                               
                                <div class="tf-col col-4">

                                
                                        <label for="desti">Hotel Rating</label>
                                        <div class="map mb-2">
                                          	 <select class="form-control" name="hotelrating">
                                        <option>Select Hotel Location</option>
                                       <?php foreach ($hotelrating as $v) { ;?>
		                                     <option value="<?php echo $v;?>"><?php echo $v;?></option>
		                                    <?php } ; ?>
		                                </select>
                                        </div>
                                    </div>

                                    <?php 

                          
                                    $args = array(
                                        
                                        'depth'               => 0,
                                        'echo'                => 1,
                                        'exclude'             => '',
                                        'exclude_tree'        => '',
                                        'feed'                => '',
                                        'feed_image'          => '',
                                        'feed_type'           => '',
                                        'hide_empty'          => 0,
                                        'hide_title_if_empty' => false,
                                        'hierarchical'        => true,
                                        'order'               => 'ASC',
                                        'orderby'             => 'name',
                                        'separator'           => '',
                                        'show_count'          => 1,
                                        'show_option_all'     => '',
                                        'show_option_none'    => __( 'No categories' ),
                                        'style'               => 'list',
                                        'taxonomy'            => 'hotelfacilities',
                                       
                                        'use_desc_for_title'  => 0,
                                    );

                                      $categories = get_categories($args);  
                                        $hotelfacilities = array();  
                                        foreach ($categories as $category_list ) 
                                        {  
                                              $hotelfacilities[$category_list->cat_ID] = $category_list->cat_name;  
                                        } 

                               
                               

                                        ?>

                               <div class="tf-col col-4">

                                
                                        <label for="desti">Hotel Facilities</label>
                                        <div class="map mb-2">
                                          	 <select class="form-control" name="hotelfacilities">
                                        <option>Select Hotel Facilities</option>
                                       <?php foreach ($hotelfacilities as $v) { ;?>
		                                     <option value="<?php echo $v;?>"><?php echo $v;?></option>
		                                    <?php } ; ?>
		                                </select>
                                        </div>
                                    </div>

                            

                          

                                </div>


                                <div class="col-12 col-lg-12">
                                    <div class="btn-area">
                                        <button class="btn btn-primary btn-md" type="submit">Search For Hottel</button>
                                    </div>
                                </div>

                            </div>           
            </form>
        </div>
    </div>

    <div class="popural u-padding-t-50">
        <div class="container">
            <div class="sec-ti">
                <h2 class="font-weight300">Hotels in Popular Destinations</h2>
            </div>
            <div class="row">

            <?php

	              $args = array(
                                      'order' => 'asc',
                                      'order_by' => 'title',
                                      'post_type' => 'hotelhajj', 
                                      'posts_per_page' => 0,
                                          'tax_query' => array(

                                            'relation' => 'AND',

                                            array(
                                                
                                                'taxonomy' => 'location', 
                                                'field' => 'slug',
                                                'terms' => $location,
                                                
                                                
                                            ),

                                             array(
                                                
                                                'taxonomy' => 'hotelrating', 
                                                'field' => 'slug',
                                                'terms' => $hotelrating,
                                                
                                                
                                            ),

                                              array(
                                                
                                                'taxonomy' => 'hotelfacilities', 
                                                'field' => 'slug',
                                                'terms' => $hotelfacilities,
                                                'operator' => 'AND'
                                                
                                                
                                                
                                            ),


                                         

                                      
                                        )
                                      );

          
                             

               $query = new WP_Query($args);
             
               if ($query -> have_posts()):
               while($query -> have_posts()) : $query -> the_post();?>






                <div class="col-sm-3">
                    <div class="pop-item">
                        <a href="<?php the_permalink(); ?>">
                             <?php 
                                                 $title=get_the_title();
                                                 the_post_thumbnail( array(251, 188),array( 'alt' =>$title) );

                                                 ?>
                            <div class="content">
                                <h5><?php the_title(); ?></h5>
                                
                                <p class="mb0">Price from $<?php echo get_post_meta( get_the_ID(), 'hotelprice', true );?></p>
                            </div>
                        </a>
                    </div>
                </div>

                        <?php 
						   endwhile; 

						else : 


                $ourteams = new WP_Query(array(
                  'post_type' => 'hotelhajj', 
                  'posts_per_page' => 0 
                  ));
                
                    while ($ourteams->have_posts() ) : 
                 $ourteams->the_post();
                 $post_type = get_post_type_object($post->post_type);


                    ?>

                  <div class="col-sm-3">
                    <div class="pop-item">
                        <a href="<?php the_permalink(); ?>">
                             <?php 
                                                 $title=get_the_title();
                                                 the_post_thumbnail( array(251, 188),array( 'alt' =>$title) );

                                                 ?>
                            <div class="content">
                                <h5><?php the_title(); ?></h5>
                               
                                <p class="mb0">Price from $<?php echo get_post_meta( get_the_ID(), 'hotelprice', true );?></p>
                            </div>
                        </a>
                    </div>
                </div>


                    	   <?php
						    endwhile;
						endif; 
						wp_reset_query();
						?>

                

            </div>
        </div>
    </div>




<?php get_footer();?>