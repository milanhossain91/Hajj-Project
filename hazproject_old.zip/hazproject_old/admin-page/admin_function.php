<?php   
 
  global $wpdb; 
//csv data upload in mysql
    if(isset($_POST["Import_csv"]))
    {  

          $type_id = $_POST["type_id"]; 
        $added_date = date('Y-m-d', strtotime($emapData0));  

        
    $filename=$_FILES["file"]["tmp_name"];
    if($_FILES["file"]["size"] > 0)
    { 
        $file = fopen($filename, "r"); 

        $row = 0;
        while (($emapData = fgetcsv($file, 10000, ",")) !== FALSE)
        {
           /*print_r($emapData);
          echo '</br>';  */


       // with commma 
		  
        

      

         //type 1
          if($type_id ==1){
            

            $home_type = $emapData[0];  
            $sales = str_replace(',', '', $emapData[1]); 
            $dollar_volume_part = str_replace(',', '', $emapData[2]);  
            $dollar_volume = str_replace('$','',$dollar_volume_part);
           
            $average_price_part = str_replace(',', '', $emapData[3]);
            $average_price =  str_replace('$','',$average_price_part);
            
            $new_listings = str_replace(',', '', $emapData[4]);
            
            $SNLR_part = str_replace(',', '', $emapData[5]);
            $SNLR = str_replace('%', '', $SNLR_part);

            $active_listings = str_replace(',', '', $emapData[6]);             
            $MOI = str_replace(',', '', $emapData[8]); 

            $average_splp_part = str_replace(',', '', $emapData[7]);
            $average_splp = str_replace('%', '', $average_splp_part);

            $average_dom = str_replace(',', '', $emapData[8]);  
      if($row==1){ 
      $addReportSql ="INSERT INTO `report_page_csv_lists_1`(`type_id`, `home_type`, `sales`, `dollar_volume`, `average_price`, `new_listings`, `SNLR`, `active_listings`, `MOI`, `average_splp`, `average_dom`, `added_date`) VALUES ('$type_id', '$home_type', '$sales', '$dollar_volume', '$average_price', '$new_listings', '$SNLR', '$active_listings', '$MOI', '$average_splp', '$average_dom', '$added_date')";

               $query = $wpdb->query($addReportSql);  
                continue; 
              }

          }


//type 2
          if($type_id ==2){
            

            $community = $emapData[0];  
            $home_type = $emapData[1];  
            $sales = str_replace(',', '', $emapData[2]); 
            $dollar_volume_part = str_replace(',', '', $emapData[3]);  
            $dollar_volume = str_replace('$','',$dollar_volume_part);
           
            $average_price_part = str_replace(',', '', $emapData[4]);
            $average_price =  str_replace('$','',$average_price_part);
            
            $new_listings = str_replace(',', '', $emapData[5]);
            
            $SNLR_part = str_replace(',', '', $emapData[6]);
            $SNLR = str_replace('%', '', $SNLR_part); 
           
            $average_splp_part = str_replace(',', '', $emapData[7]);
            $average_splp = str_replace('%', '', $average_splp_part);

            $average_dom = str_replace(',', '', $emapData[8]);  
      if($row==1){ 
      $addReportSql ="INSERT INTO `report_page_csv_lists_2`(`community`, `type_id`, `home_type`, `sales`, `dollar_volume`, `average_price`, `new_listings`, `SNLR`, `average_splp`, `average_dom`, `added_date`) VALUES ('$community', '$type_id', '$home_type', '$sales', '$dollar_volume', '$average_price', '$new_listings', '$SNLR', '$average_splp', '$average_dom', '$added_date')";

               $query = $wpdb->query($addReportSql);  
                continue; 
              }

          }


            //type 3 
        
        if($type_id ==3){
        $area = $emapData[0]; 
        $municipality = $emapData[1];   
        $community = str_replace(',', '', $emapData[2]); 
        $sales = str_replace(',', '', $emapData[3]); 
        $dollar_volume_part = str_replace(',', '', $emapData[4]);  
        $dollar_volume = str_replace('$','',$dollar_volume_part);
        $average_price_part = str_replace(',', '', $emapData[5]);
        $average_price =  str_replace('$','',$average_price_part);
        $new_listings = str_replace(',', '', $emapData[6]);
        $average_splp_part = str_replace(',', '', $emapData[7]); 
        $average_splp = str_replace('%', '', $average_splp_part); 
        $average_dom = str_replace(',', '', $emapData[8]); 
       

         if($row==1){    
                 $addReportSql ="INSERT INTO `report_page_csv_lists_3`(`type_id`, `area`, `municipality`, `community`, `sales`, `dollar_volume`, `average_price`, `new_listings`, `average_splp`, `average_dom`, `added_date`) VALUES ('$type_id', '$area', '$municipality', '$community', '$sales', '$dollar_volume', '$average_price', '$new_listings', '$average_splp', '$average_dom', '$added_date')";
             $query = $wpdb->query($addReportSql);   
         
           continue;
           }
         }




      
        $row++;  }
        fclose($file);
        $msg = 'CSV File has been successfully Imported';
        //header('Location: index.php');
    }
    else
        echo 'Invalid File:Please Upload CSV File';
    }
 
 
           

 //number format 
    function number_format_func($totalData){ 
      return number_format($totalData, 2); 
    }



 