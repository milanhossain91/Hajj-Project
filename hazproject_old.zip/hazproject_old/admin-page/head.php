<?php 
  include('admin_function.php');  
?>
	<!-- Bootstrap Styles-->

    <link href="<?php echo get_template_directory_uri(); ?>/admin-page/css/bootstrap.css" rel="stylesheet" />

     <!-- FontAwesome Styles-->

    <link href="<?php echo get_template_directory_uri(); ?>/admin-page/css/font-awesome.css" rel="stylesheet" />

     <!-- Morris Chart Styles-->
 
   

     <!-- Google Fonts-->

   <link href='http://fonts.googleapis.com/css?family=Open+Sans' rel='stylesheet' type='text/css' />

     <!-- TABLE STYLES-->

    <link href="<?php echo get_template_directory_uri(); ?>/admin-page/css/datatables.min.css" rel="stylesheet" />

	<style>

	button, html input[type="button"], input[type="reset"], input[type="submit"]{ background:none; border:0; color:blue; }

	input[type="submit"]:hover{text-decoration:underline;}

	
#dataTables-example {
	width: 100%;
	text-align: left;
}


	.page-title-action{

	background: hsl(0, 0%, 97%) none repeat scroll 0 0;

    border: 1px solid hsl(0, 0%, 80%);

    border-radius: 2px;

    color: hsl(199, 100%, 33%);

    cursor: pointer;

    font-size: 13px;

    font-weight: 600;

    line-height: normal;

    margin-left: 4px;

    outline: 0 none;

    padding: 4px 8px;

    position: relative;

    text-decoration: none;

    text-shadow: none;

    top: -3px;}

	input[type="submit"]{

	background: hsl(0, 0%, 97%) none repeat scroll 0 0;

    border: 1px solid hsl(0, 0%, 80%);

    border-radius: 2px;

    color: hsl(199, 100%, 33%);

    cursor: pointer;

    font-size: 13px;

    font-weight: 600;

    line-height: normal;

    margin-left: 4px;

    outline: 0 none;

    padding: 4px 8px;

    position: relative;

    text-decoration: none;

    text-shadow: none;

    top: -3px;

	

	

	}

	input[type="text"],input[type="password"]{

	height:35px; padding:5px; width:250px;}

	.wp-admin select{ height:35px!important; width:250px;}
	</style>

<script type="text/javascript">

var requrl = '<?php echo get_template_directory_uri(); ?>';

</script>



<script>

jQuery('document').ready(function(){ 
	

	jQuery('#location').change(function(){

									   

			//alert('1st step');

	

		 	var c_id = jQuery('#location').val();

			//alert(c_id);

			var ajaxhandler = requrl+'/ajaxhandler.php';

			

			//alert(ajaxhandler );

		

			jQuery.ajax({

				url:ajaxhandler,

				type:"post",

				data:{type:'location',c_id:c_id},

				success:function(data){

				//alert(data);

					jQuery("#shops_name").html(data);



					  

				}

				});

			

			

			});

			

			

			

			

			});

</script>


      
             

    

	

	

	

	

	

	

	

	

	

	

	

	

	

	

	

	<script src="<?php echo get_template_directory_uri(); ?>/admin-page/assets/js/jquery-1.10.2.js"></script>

      <!-- Bootstrap Js -->

    <script src="<?php echo get_template_directory_uri(); ?>/admin-page/assets/js/bootstrap.min.js"></script>

    <!-- Metis Menu Js -->

    <script src="<?php echo get_template_directory_uri(); ?>/admin-page/assets/js/jquery.metisMenu.js"></script>

     <!-- DATA TABLE SCRIPTS -->

    <script src="<?php echo get_template_directory_uri(); ?>/admin-page/assets/js/dataTables/jquery.dataTables.js"></script>

    <script src="<?php echo get_template_directory_uri(); ?>/admin-page/assets/js/dataTables/dataTables.bootstrap.js"></script>

        <script>

            $(document).ready(function () {

                $('#dataTables-example').dataTable();

            });

    </script>

         <!-- Custom Js -->

    <script src="<?php echo get_template_directory_uri(); ?>/admin-page/assets/js/custom-scripts.js"></script>