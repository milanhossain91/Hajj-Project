
   <?php include('head.php'); ?> 

<script type="text/javascript" src="https://code.jquery.com/jquery-3.3.1.js"></script>
<script type="text/javascript" src="https://cdn.datatables.net/1.10.19/js/jquery.dataTables.min.js"></script>
<script type="text/javascript" src="https://cdn.datatables.net/1.10.19/js/dataTables.bootstrap.min.js"></script>



<link rel="stylesheet" type="text/css" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">
<link rel="stylesheet" type="text/css" href="https://cdn.datatables.net/1.10.19/css/dataTables.bootstrap.min.css">

<div id="page-wrapper" >
	<div id="page-inner">
		<div class="row">
			<div class="col-md-12">
				<h1 class="page-header">
					Umrah Packages List View
				</h1>
			</div>
		</div> 
		<!-- /. ROW  -->

		<div class="row">
			<div class="col-md-12">
				<!-- Advanced Tables -->
				<div class="panel">

					<div class="panel-body_old">


						<?php if(isset($_GET['details'])) { ?>
								<table class="table table-striped table-bordered table-hover" style="width: 60%">
									<?php	
									//  global $post;	
									  $id	= $_GET['id'];	
									// $upost = get_post(459);
									// print_r($upost);

							?>



								<tr>  
								<th>Photo</th> 
								<td><?php 
                                                  echo get_the_post_thumbnail($id, 'thumbnail');

                                                 ?></td>
								</tr>
								
								<tr> 

								<th>Title</th>
								<td><?php echo get_the_title( $id, 'title'); ?></td>

								</tr>
								<tr> 

								<th>Agent Name</th>

								<td><?php echo get_post_meta( $id, 'agentname', true );?></td> 

								</tr>


								<tr> 

								<th>Makkah Hotel Name</th>
								<td><?php echo get_post_meta( $id, 'makkahhotelhame', true );?></td> 
								</tr>
								<tr> 

								<th>Makkah Stay</th>
								<td><?php echo get_post_meta( $id, 'makkahstay', true );?> Days</td>
								</tr>
								<tr> 

								<th>Madina Hotel Name</th>

								<td><?php echo get_post_meta( $id, 'madinahhotelname', true );?></td> 

								</tr>
								<tr> 

								<th>Madina Stay</th>

								<td><?php echo get_post_meta( $id, 'madinahstay', true );?> Days</td> 

								</tr>
								<tr> 

								<th>Double Bed</th>

								<td>PKR <?php echo get_post_meta( $id, 'umrahdouble', true );?></td> 

								</tr>

								<tr> 

								<th>Triple Bed</th>
								<td>PKR <?php echo get_post_meta( $id, 'umrahtriplebed', true );?></td> 

								</tr>

								<tr> 

								<th>Quad(4 Bed)</th>
								<td>PKR <?php echo get_post_meta( $id, 'umrahfourbed', true );?></td> 

								</tr>
								<tr> 

								<th>Facilites</th>  
								<td><?php echo get_post_meta( $id, 'umrahfacilites', true );?></td>  

                                 
								</tr>

								<?php

							   $id = $_GET['id'];
							   global $wpdb;
							
							  $show_details = $wpdb->get_results("SELECT * FROM umratinguser WHERE upostid ='$id'"); 
	
							  //var_dump($show_details);


								?>

								<th>Rating</th>  
								<td><?php 

								 foreach ( $show_details as $show_detail) 
							     { 

							     	?>

							     	<?php if( $show_detail->rating == '1'): ?>★<?php endif; ?>
							     	<?php if( $show_detail->rating == '2'): ?>★★<?php endif; ?>
							     	<?php if( $show_detail->rating == '3'): ?>★★★<?php endif; ?>
							     	<?php if( $show_detail->rating == '4'): ?>★★★★<?php endif; ?>
							     	<?php if( $show_detail->rating == '5'): ?>★★★★★<?php endif; ?>

							     	<?php
                                    
                           
					


							     $ratingPercentaa = $show_detail->rating; 

							     $maxrating = ($ratingPercentaa * 5)/100;

							     echo 'Average rating: ', $maxrating;

                              }



							   

								?></td>  

                                 
								</tr>
							
							 

							  </table> 


							    

                                <div class ="ratingselect">

                                 <?php

								              $id = $_GET['id'];
									            global $wpdb;
									            //$table = wp_contact;
									            $data = array(
									                'upostid' => $_POST['upostid'],
									                'rating'    => $_POST['rating'],
									            
									            );
									           
									            $success = $wpdb->insert('umratinguser',$data);
									            if($success){
									            echo 'data has been saved' ; 
									             }
							  ?>


                                <form action="" method="post" novalidate="novalidate">

                        

                                    <div class="form-group" style="display:none;">
							          <label for="exampleFormControlTextarea1">ID</label>
							  
							       <input type="text" class="form-control" name="upostid" value="<?php echo $id;?>">

							       </div>
                                 <div class="form-group" >
							     <label for="exampleFormControlTextarea1">Rating</label>  
	                            <select  name="rating">
								  <option name="1">1</option>
								  <option name="2">2</option>
								  <option name="3">3</option>
								  <option name="4">4</option>
								  <option name="5">5</option>
								</select>
                               </div>
								 
							  <button type="submit" name="treasure" class="btn btn-primary">Submit</button>
	                              </form>

	                          
		                        </div>


			

				


						<?php } else{ ?>
          <div class="table-responsive">  
    
       <table class="table table-striped table-bordered table-hover" id="example">
       	<thead> 
            <tr>
               <th>Photo</th>
                
                 <th>Agent Name</th>
                 <th>Departure </th>
                <th>Makkah Stay</th>
                 <th>Madinah Stay</th>
                 <th>Double Bed</th>
                 <th>Triple Bed</th>
                 <th>Quad(4 Bed)</th>
                 <th>Action</th>
              
      
              
            </tr>
            </thead> 
            	<tbody>
               <?php    

                                
	                              $ourteams = new WP_Query(array(
										'post_type'=> 'umrah',
										'orderby'    => 'ID',
										
										'order'    => 'DESC',
										'posts_per_page' => -1 // this will retrive all the post that is published 
										));



                    while ($ourteams->have_posts() ) : 
                 $ourteams->the_post();?>
    
               <tr class="odd gradeA">

                    <td>

                       <?php 
                                                 $title=get_the_title();
                                                 the_post_thumbnail( array(150, 78),array( 'alt' =>$title) );

                                                 ?>

                  
                    </td> 
                  

                    

                    <td><?php echo get_post_meta( get_the_ID(), 'agentname', true );?>

                    </td> 
                    <td><?php echo get_post_meta( get_the_ID(), 'locationcheckins', true );?> To <?php echo get_post_meta( get_the_ID(), 'locationcheckout', true );?>

                    </td> 
                      <td><?php echo get_post_meta( get_the_ID(), 'makkahstay', true );?>-Days

                      </td> 
                    <td><?php echo get_post_meta( get_the_ID(), 'madinahstay', true );?>-Days

                    </td>

                          <td>PKR <?php echo get_post_meta( get_the_ID(), 'umrahdouble', true );?>

                      </td> 
                    <td>PKR <?php echo get_post_meta( get_the_ID(), 'umrahtriplebed', true );?>

                    </td>
                     <td>PKR <?php echo get_post_meta( get_the_ID(), 'umrahfourbed', true );?>

                    </td>

                    <td>  
											
<a class="center btn btn-primary" href="?page=idia_for_admin_menu&id=<?php the_ID(); ?>&details=yes">View</a>
										</td>
                  
                 
                   
          
					                </tr>
					             <?php endwhile;?>


					       </tbody>

					       	<tr>

									<th>Photo</th>
                
					                 <th>Agent Name</th>
					                 <th>Departure </th>
					                <th>Makkah Stay</th>
					                 <th>Madinah Stay</th>
					                 <th>Double Bed</th>
					                 <th>Triple Bed</th>
					                 <th>Quad(4 Bed)</th>
					                 <th>Action</th> 
								</tr>
					      </table>

					  </div>  

					  <?php } ?>
					</div>
				</div>
				<!--End Advanced Tables -->
			</div>
		</div>
	</div>

</div>



<script type="text/javascript">
$(document).ready(function() {
    $('#example').DataTable( {
        "pagingType": "full_numbers"
    } );
} );

</script>




  <?php include('footer.php'); ?> 