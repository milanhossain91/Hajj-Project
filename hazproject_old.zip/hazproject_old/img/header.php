
<?php
/**
 * The header for our theme
 *
 * This is the template that displays all of the <head> section and everything up until <div id="content">
 *
 * @link https://developer.wordpress.org/themes/basics/template-files/#template-partials
 *
 * @package venox
 */

?>
<!doctype html>
<html <?php language_attributes(); ?>>
<head>
	<meta charset="<?php bloginfo( 'charset' ); ?>">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<link rel="profile" href="https://gmpg.org/xfn/11">

    <title>International Hajj Project</title>
    <link href="https://fonts.googleapis.com/css?family=Open+Sans:300,400,400i,600,700,800" rel="stylesheet">

    
    <script src="<?php echo esc_url(get_template_directory_uri());?>/js/modernizr-2.8.3.min.js"></script>

	<?php wp_head(); ?>
</head>

<body <?php body_class(); ?>>
    
    <header>
        <div id="top_toolbar" class="hidden_topbar_in_mobile">
            <div class="container">
                <div class="row">
                    <div class="col-md-6 col-xs-12 text-left left_topbar">                   
                        <ul class="top-user-area-list list list-horizontal list-border clearfix">
                            <li><a href="#" target=""> <i class="fa fa-facebook-f mr5"></i></a></li>
                            <li><a href="#" target=""><i class="fa fa-twitter mr5"></i></a></li>
                            <li><a href="#" target=""> <i class="fa fa-linkedin mr5"></i></a></li>
                            <li><a href="#" target=""> <i class="fa fa-google-plus mr5"></i></a></li>
                        </ul>
                    </div>

                    <div class="col-md-6 col-sm-12 text-right right_topbar top-user-area">         
                        <ul class="top-user-area-list list list-horizontal list-border clearfix">

                            <li>
                            	<a href="" target=""> <i class="fa  mr5"></i>Call us: (000) 999 - 656 -888</a>
                            </li>

                            <li>
                            	<a href="#" target=""> <i class="fa fa-envelope-o mr5"></i>contact@domain.com</a></li>
                            <li class="top-user-area-shopping">
                                <a id="show-mini-cart-button" href="#"><i class="fa fa-shopping-cart"></i><span class="badge"><?php global $woocommerce; 
$woocommerce->cart->add_to_cart(598);?></span></a>
                            </li>

                        </ul>
                                    
                    </div>
                </div>
            </div>
        </div>


        <div class="header-top ">
        <div class="container">
            <div class="row">
                <div class="col-md-3">
                    <a class="logo" href="<?php echo esc_url( home_url( '/' ) ); ?>">
                        <img src="<?php global $redux_demo; echo $redux_demo['logo'] ['url'];?>" alt="logo">
                    </a>
                </div>
                <div class="col-md-9">
                <div class="top-user-area clearfix">
                    <ul class="top-user-area-list list list-horizontal list-border">
                         <li class="nav-drop">  
							<div class="dropdown">
							  <a class="btn btn-secondary dropdown-toggle" href="#" id="dropdownMenuButton" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
							    Account
							  </a>
							  <div class="dropdown-menu" aria-labelledby="dropdownMenuButton">
							    <a class="dropdown-item" href="<?php bloginfo(); ?>/log-in/">Sign In</a>
							    <a class="dropdown-item" href="<?php bloginfo(); ?>/sign-up/">Sign Up</a>
							  </div>
							</div>

                        </li>    
   

                    </ul>
                <form class="main-header-search" action="https://travelerwp.com/" method="get">
                    <div class="form-group form-group-icon-left">
                        <i class="fa fa-search input-icon"></i>
                        <span class="twitter-typeahead">
                            <input type="text" data-lang="en" value="" class="form-control st-top-ajax-search tt-hint" disabled="" autocomplete="off" spellcheck="false"><input type="text" placeholder="" data-lang="en" name="s" value="" class="form-control st-top-ajax-search tt-input" autocomplete="off" spellcheck="false" dir="auto" ></pre><span class="tt-dropdown-menu" ><div class="tt-dataset-0"></div></span>
                        </span>
                        <input type="hidden" name="post_type" value="post" />
                    </div>
                </form>
                
                </div>
            </div>
        </div>
        </div>
    </div>


    <div class="header-nav">
        <div class="container">
           
                 <?php wp_nav_menu(array(


              'theme_location' => 'main_menu',
              'container'  => false,
              'menu_class' => 'nav',
              'menu_id' => 'top-navigation'
              





              ));?>
       
          
        </div>
    </div>
</header>


