<?php
/**
 * The template for displaying all single posts
 *
 * @link https://developer.wordpress.org/themes/basics/template-hierarchy/#single-post
 *
 * @package venox
 */
 /*
  Template Name: cart
*/

get_header();

while (have_posts() ) : the_post();


?>
 <div class="search-res umrah has-border">
            <div class="container">
                <div class="top-title">
                    <h3><?php the_title();?></h3>


<?php
the_content();?>

    </div>
   </div>	
</div>

<?php
endwhile; 
           wp_reset_postdata();
                
get_footer();
?>