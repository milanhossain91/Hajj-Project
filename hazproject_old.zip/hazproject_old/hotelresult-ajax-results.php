<?php 
/*
 * template-ajax-results.php
 * This file should be created in the root of your theme directory
 */

if ( have_posts() ) :             
   while ( have_posts() ) : the_post(); 
   $post_type = get_post_type_object($post->post_type);
   ?>
   
                     
                        <div class="col-sm-4">

                         <div class="top-deal-item">
                                    <a href="<?php the_permalink(); ?>" class="fig">

                                          <?php 
                                                 $title=get_the_title();
                                                 the_post_thumbnail( array(251, 188),array( 'alt' =>$title) );

                                                 ?>
                                        


                                        <span>Book Now</span>
                                    </a>
                                           
                                    <div class="content">
                                        <div class="icons">
                                            <i class="fa fa-star"></i>         
                                            <i class="fa fa-star"></i>         
                                            <i class="fa fa-star"></i>         
                                            <i class="fa fa-star"></i>         
                                            <i class="fa fa-star"></i>         
                                        </div>
                                        <h5><a href="<?php the_permalink(); ?>">I<?php the_title()?></a></h5>
                                        <div class="location">
                                            <i class="fa fa-map-marker"></i>
                                            <span><?php echo get_post_meta( get_the_ID(), 'hotellocation', true );?></span>
                                        </div>
                                        <p class="mb0">from <?php echo get_post_meta( get_the_ID(), 'hotelprice', true );?> <small>/night</small></p>
                                    </div>
                               
                                </div>
                       </div>

    
   <?php 
   endwhile; 

else :
   echo '<p>Sorry, no results matched your search.</p>';
endif; 
wp_reset_query();
?>