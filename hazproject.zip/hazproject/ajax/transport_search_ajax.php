<?php  
include '../../../../wp-load.php'; 
include('../rating/rating.php');
global $wpdb;  
$transport_location="";
 
     $transport_location = $_POST['transport_location'];  
     $transport_time_post = $_POST['transport_time']; 
     $part = explode(' ', $transport_time_post);  
      $transport_time =  $part[0];   
       $transport_am_pm = $part[1];  
     $service_type = 'transports';

        
                      $wp_post_db = "transport_details";  
                      //echo "SELECT * FROM $wp_post_db WHERE transport_location LIKE '%$transport_location%' OR (transport_time ='$transport_time' AND transport_am_pm ='$transport_am_pm') ORDER BY id DESC";
                       $show_vendor_posts = $wpdb->get_results("SELECT * FROM $wp_post_db WHERE transport_location LIKE '%$transport_location%' OR (transport_time ='$transport_time' AND transport_am_pm ='$transport_am_pm') ORDER BY id DESC"); 
                      $num_rows = $wpdb->num_rows; 

                      ?>

                   <div class="sec-ti u-padding-b-20">
                        <h3 class="font-weight300">Advanced Search (<?php echo $num_rows; ?>)</h3>
                    </div>
                    <div class="row " >
                      <?php
                       if($num_rows  > 0){
                      $i=0;
                      foreach( $show_vendor_posts as $show_vendor_post)  
                      {   
                      //print_r($show_vendor_post);
                       $tid =  $show_vendor_post->id; 
                      $transport_title =  $show_vendor_post->transport_title; 
                      $transport_description =  $show_vendor_post->transport_description; 
                      $transport_location =  $show_vendor_post->transport_location;       
                      $transport_price =  $show_vendor_post->transport_price;                                                
                      ?>    
                       
                        <div class="col-sm-6 col-lg-6">
                            <div class="transport-item">
                              


                      <a href="<?php echo site_url().'/transport-details/?transport_id='.$tid;?>" class="fig">
                      <img style="height:190px;" src="<?php echo getImageSrcById($tid, $service_type); ?>">
                                        <h4><?php echo $transport_title; ?></h4>
                                    </a>

                                    <div class="content">

                                        <div class="left">
                                            <div class="location">
                                                <i class="fa fa-map-marker"></i>
                                                <span><?php echo $transport_location; ?></span>
                                            </div>
                                            <div class="price">
                                                <i class="fa fa-money"></i>
                                                <span>$<?php echo $transport_price; ?></span>
                                            </div>
                                        </div>
                                        <div class="right">
                                            <div class="cal">
                                                <i class="fa fa-calendar"></i>
                                                <span>3</span>
                                            </div>
                                             <div class="stars">
                                                 <?php  echo ratingsViewFunctions($tid, $service_type); ?>          
                                            </div>
                                        </div>
                                    </div>
                            </div>
                        </div> <!-- col -6 --> 


                        <?php } }else{ ?>

                <h4>No data found.</h4>

              <?php } ?>
                        </div><!-- row-->
 