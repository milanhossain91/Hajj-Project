<?php 
include '../../../../wp-load.php'; 
global $woocommerce, $product, $post, $wpdb, $current_user;  
get_currentuserinfo();  


 
 
 
  function login_after_register($username,$password){
	  
	$credentials = array( 'user_login' =>  $username, 'user_password' => $password, 'remember' => true ); 
	$secure_cookie = is_ssl(); 
	$secure_cookie = apply_filters('secure_signon_cookie', $secure_cookie, $credentials);
	add_filter('authenticate', 'wp_authenticate_cookie', 30, 3);
	
	$user = wp_authenticate($credentials['user_login'], $credentials['user_password']);
	wp_set_auth_cookie($user->ID, $credentials["remember"], $secure_cookie);
	do_action('wp_login', $user->user_login, $user); 
	
	return $user->ID;
 }
 
  
if(isset($_GET['email_add'])){  

	 $email_add = $_GET['email_add'];  
	 $current_pass = $_GET['pass_user'];  
	 
	 // $post_id = $_GET['post_id'];  
	   
	 
	  $user_ID = login_after_register($email_add,$current_pass); 
	  if($user_ID){
		  //echo 'mass_?user='.$user_ID.'&post='.$post_id; 

		  echo 'Logged in successfully.'; 

	}else{
		echo 'Incorrect login information';
	}
	
 
} 



 