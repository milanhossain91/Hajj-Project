
<?php
/**
 * The flight search template file
 *
 * This is the most generic template file in a WordPress theme
 * and one of the two required files for a theme (the other being style.css).
 * It is used to display a page when nothing more specific matches a query.
 * E.g., it puts together the home page when no home.php file exists.
 *
 * @link https://developer.wordpress.org/themes/basics/template-hierarchy/
 *
 * @package aynix
 */
 /*
  Template Name: flight-search
*/
get_header(); ?>


      
      
        <!-- mobile-menu-area start -->
        <div class="mobile-menu-area">
          <div class="container">
            <div class="row">
              <div class="col-md-12">
                <div class="mobile-menu">
                  <nav id="dropdown">
                    <ul>
                        <li class="active"><a href="#">Home</a>
                            <ul>
                                <li><a href="#">Sub Item</a></li>
                                <li><a href="#">Sub Item</a></li>
                                <li><a href="#">Sub Item</a></li>
                                <li><a href="#">Sub Item</a></li>
                                <li><a href="#">Sub Item</a></li>
                                <li><a href="#">Sub Item</a></li>
                                <li><a href="#">Sub Item</a></li>
                            </ul>
                        </li>
                        <li><a href="#">Projects</a></li>
                        <li><a href="#">Activities</a></li>
                        <li><a href="#">Total Jobs</a></li>
                        <li><a href="#">Flights</a></li>
                        <li><a href="#">Hotels</a></li>
                    </ul>
                  </nav>
                </div>
              </div>
            </div>
          </div>
        </div>
        <!-- mobile-menu-area end -->



        <div class="search-res flight has-border">
            <div class="container">
                <div class="top-title">
                    <h3>2 Flights from Berlin to Paris on Oct 25 for 1 passenger</h3>


                        <form class="flight-res">
                            <div class="tf-row row">

                                
                                <div class="tf-col col-lg-3">
                                    <label for="desti">From</label>
                                    <select class="form-control" name="Locationform">
                                        <option><i class="fa fa-map-marker"></i>Select Locations</option>
                                           <?php
                                        $locationform = get_terms([
                                        'taxonomy' => 'locationform',
                                        'hide_empty' => false,
                                        ]);

                                       foreach($locationform as $package_city_rows){  

                                        ?>
                                          <option value="<?php echo $package_city_rows->slug; ?>"><?php echo $package_city_rows->name; ?></option>
                                      <?php } ?>
                                </select>
                                </div>


                                <div class="tf-col col-lg-3">
                                    <label for="desti">To</label>
                                    <select class="form-control" name="Locationto">
                                        <option><i class="fa fa-map-marker"></i>Select Locations</option>
                                           <?php
                                        $locationto = get_terms([
                                        'taxonomy' => 'locationto',
                                        'hide_empty' => false,
                                        ]);

                                       foreach($locationto as $package_city_rows){  

                                        ?>
                                          <option value="<?php echo $package_city_rows->slug; ?>"><?php echo $package_city_rows->name; ?></option>
                                      <?php } ?>
                                </select>
                                </div>



                                <div class="tf-col col-lg-2">

                                 <label>Date</label>
                                   <select class="form-control" name="Departuredate">
                                        <option><i class="fa fa-map-marker"></i>Select Date</option>
                                           <?php
                                        $departuredate = get_terms([
                                        'taxonomy' => 'departuredate',
                                        'hide_empty' => false,
                                        ]);

                                       foreach($departuredate as $package_city_rows){  

                                        ?>
                                          <option value="<?php echo $package_city_rows->slug; ?>"><?php echo $package_city_rows->name; ?></option>
                                      <?php } ?>
                                </select>
                                    
                                </div>


                                <div class="tf-col col-lg-2">
                                    <label>Passenger</label>
                                    <select class="form-control" name="Passenger">
                                        <option><i class="fa fa-map-marker"></i>Select Passenger</option>
                                           <?php
                                        $passenger = get_terms([
                                        'taxonomy' => 'passenger',
                                        'hide_empty' => false,
                                        ]);

                                       foreach($passenger as $package_city_rows){  

                                        ?>
                                          <option value="<?php echo $package_city_rows->slug; ?>"><?php echo $package_city_rows->name; ?></option>
                                      <?php } ?>
                                </select>
                                    
                                </div>
                                
                                <div class="col-lg-2">
                                    <div class="btn-area">
                                        <button class="btn btn-primary btn-md" type="submit">Update Search</button>
                                    </div>
                                </div>

                            </div>
                        </form>
                </div>
                <div class="row">
                    <div class="col-12 col-lg-3 mini-order-last">
                        <div class="left-sidebar">
                            <div class="bar-title">
                                Filter By:
                            </div>

                            <div class="bar-item">
                                <div class="wrap">
                                    <a class="ac-title"  data-toggle="collapse" href="#ac1" role="button" aria-expanded="false" aria-controls="ac1">Stops</a>
                                    <div class="collapse show" id="ac1">
                                  <div class="inner">
                                    <div class="custom-control custom-checkbox">
                                        <input type="checkbox" class="custom-control-input" id="a1">
                                        <label class="custom-control-label" for="a1">Non-stop</label>
                                    </div>
                                    <div class="custom-control custom-checkbox">
                                        <input type="checkbox" class="custom-control-input" id="a2">
                                        <label class="custom-control-label" for="a2">1 Stop</label>
                                    </div>
                                    <div class="custom-control custom-checkbox">
                                        <input type="checkbox" class="custom-control-input" id="a3">
                                        <label class="custom-control-label" for="a3">2 Stop</label>
                                    </div>
                                </div>
                              </div>
                            </div>
                            </div>

                            <div class="bar-item">
                                <div class="wrap">
                                    <a class="ac-title"  data-toggle="collapse" href="#ac4" role="button" aria-expanded="false" aria-controls="ac4">Price</a>
                                    <div class="collapse show" id="ac4">
                                  <div class="inner">
                                    <div class="price-filter">
                                        <input type="text" id="price-filter" name="priceRange">
                                        <button class="btn btn-primary button-filter-price" type="submit">Filter</button>
                                    </div>
                                </div>
                              </div>
                            </div>
                            </div>

                            <div class="bar-item">
                                <div class="wrap">
                                    <a class="ac-title"  data-toggle="collapse" href="#ac2" role="button" aria-expanded="false" aria-controls="ac2">Airlines</a>
                                    <div class="collapse show" id="ac2">
                                  <div class="inner">
                                    <div class="custom-control custom-checkbox">
                                        <input type="checkbox" class="custom-control-input" id="b1">
                                        <label class="custom-control-label" for="b1">Non-stop</label>
                                    </div>
                                    <div class="custom-control custom-checkbox">
                                        <input type="checkbox" class="custom-control-input" id="b2">
                                        <label class="custom-control-label" for="b2">1 Stop</label>
                                    </div>
                                    <div class="custom-control custom-checkbox">
                                        <input type="checkbox" class="custom-control-input" id="b3">
                                        <label class="custom-control-label" for="b3">2 Stop</label>
                                    </div>
                                </div>
                              </div>
                            </div>
                            </div>


                            <div class="bar-item">
                                <div class="wrap">
                                    <a class="ac-title"  data-toggle="collapse" href="#ac3" role="button" aria-expanded="false" aria-controls="ac3">Departure Time</a>
                                    <div class="collapse show" id="ac3">
                                  <div class="inner">
                                    <div class="custom-control custom-checkbox">
                                        <input type="checkbox" class="custom-control-input" id="b10">
                                        <label class="custom-control-label" for="b10">Non-stop</label>
                                    </div>
                                    <div class="custom-control custom-checkbox">
                                        <input type="checkbox" class="custom-control-input" id="b20">
                                        <label class="custom-control-label" for="b20">1 Stop</label>
                                    </div>
                                    <div class="custom-control custom-checkbox">
                                        <input type="checkbox" class="custom-control-input" id="b30">
                                        <label class="custom-control-label" for="b30">2 Stop</label>
                                    </div>
                                </div>
                              </div>
                            </div>
                            </div>

                        </div>
                    </div> <!-- col- end -->

                    <div class="col-12 col-md-8 col-lg-6">
                        <div class="search-content">
                            
                            <div class="flight-block">
                                <div class="title">
                                    <h4>Departure Berlin (BER) to Paris (CDG)</h4>
                                </div>
                                <div class="f-item">
                                    <div class="f-logo">
                                        <img src="<?php echo esc_url(get_template_directory_uri());?>/img/air-berlin-128x50.png">
                                    </div>
                                    <div class="f-inf">
                                        <div class="cl left">
                                            <p>12:35 PM</p>
                                            <span>THU, OCT 25</span>
                                        </div>
                                        <div class="cl mid">
                                            <div class="top">4H 0M</div>
                                            <div class="bottom">Direct Flight</div>
                                            <div class="hand-l">
                                                <span>CDG</span>
                                            </div>
                                            <div class="hand-r">
                                                <span>BER</span>
                                            </div>
                                        </div>
                                        <div class="cl right">
                                            <p>12:35 PM</p>
                                            <span>THU, OCT 25</span>
                                        </div>
                                    </div>
                                    <div class="f-end">
                                        <div class="item-price">
                                            <p>$400,00 <small>/person</small></p>
                                            <span>Class Economy</span>
                                            <div class="btn-rdo">
                                                <div class="custom-control custom-radio">
                                                    <input type="radio" id="customRadio1" name="customRadio" class="custom-control-input">
                                                    <label class="custom-control-label" for="customRadio1"></label>
                                                </div>
                                            </div>
                                        </div>
                                        <div class="item-price">
                                            <p>$400,00 <small>/person</small></p>
                                            <span>Class Economy</span>
                                            <div class="btn-rdo">
                                                <div class="custom-control custom-radio">
                                                    <input type="radio" id="customRadio2" name="customRadio" class="custom-control-input">
                                                    <label class="custom-control-label" for="customRadio2"></label>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                <div class="f-item">
                                    <div class="f-logo">
                                        <img src="<?php echo esc_url(get_template_directory_uri());?>/img/air-berlin-128x50.png">
                                    </div>
                                    <div class="f-inf">
                                        <div class="cl left">
                                            <p>12:35 PM</p>
                                            <span>THU, OCT 25</span>
                                        </div>
                                        <div class="cl mid">
                                            <div class="top">4H 0M</div>
                                            <div class="bottom">Direct Flight</div>
                                            <div class="hand-l">
                                                <span>CDG</span>
                                            </div>
                                            <div class="hand-r">
                                                <span>BER</span>
                                            </div>
                                        </div>
                                        <div class="cl right">
                                            <p>12:35 PM</p>
                                            <span>THU, OCT 25</span>
                                        </div>
                                    </div>
                                    <div class="f-end">
                                        <div class="item-price">
                                            <p>$400,00 <small>/person</small></p>
                                            <span>Class Economy</span>
                                            <div class="btn-rdo">
                                                <div class="custom-control custom-radio">
                                                    <input type="radio" id="customRadio1" name="customRadio" class="custom-control-input">
                                                    <label class="custom-control-label" for="customRadio1"></label>
                                                </div>
                                            </div>
                                        </div>
                                        <div class="item-price">
                                            <p>$400,00 <small>/person</small></p>
                                            <span>Class Economy</span>
                                            <div class="btn-rdo">
                                                <div class="custom-control custom-radio">
                                                    <input type="radio" id="customRadio2" name="customRadio" class="custom-control-input">
                                                    <label class="custom-control-label" for="customRadio2"></label>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>

                            <div class="flight-block">
                                <div class="title">
                                    <h4>Return Paris (CDG) to Berlin (BER)</h4>
                                </div>
                                <div class="f-item">
                                    <div class="f-logo">
                                        <img src="<?php echo esc_url(get_template_directory_uri());?>/img/Virgin-Australia-168x50.png">
                                    </div>
                                    <div class="f-inf">
                                        <div class="cl left">
                                            <p>12:35 PM</p>
                                            <span>THU, OCT 25</span>
                                        </div>
                                        <div class="cl mid">
                                            <div class="top">4H 0M</div>
                                            <div class="bottom">Direct Flight</div>
                                            <div class="hand-l">
                                                <span>CDG</span>
                                            </div>
                                            <div class="hand-r">
                                                <span>BER</span>
                                            </div>
                                        </div>
                                        <div class="cl right">
                                            <p>12:35 PM</p>
                                            <span>THU, OCT 25</span>
                                        </div>
                                    </div>
                                    <div class="f-end">
                                        <div class="item-price">
                                            <p>$400,00 <small>/person</small></p>
                                            <span>Class Economy</span>
                                            <div class="btn-rdo">
                                                <div class="custom-control custom-radio">
                                                    <input type="radio" id="customRadio1" name="customRadio" class="custom-control-input">
                                                    <label class="custom-control-label" for="customRadio1"></label>
                                                </div>
                                            </div>
                                        </div>
                                        <div class="item-price">
                                            <p>$400,00 <small>/person</small></p>
                                            <span>Class Economy</span>
                                            <div class="btn-rdo">
                                                <div class="custom-control custom-radio">
                                                    <input type="radio" id="customRadio2" name="customRadio" class="custom-control-input">
                                                    <label class="custom-control-label" for="customRadio2"></label>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                <div class="f-item">
                                    <div class="f-logo">
                                        <img src="<?php echo esc_url(get_template_directory_uri());?>/img/Virgin-Australia-168x50.png">
                                    </div>
                                    <div class="f-inf">
                                        <div class="cl left">
                                            <p>12:35 PM</p>
                                            <span>THU, OCT 25</span>
                                        </div>
                                        <div class="cl mid">
                                            <div class="top">4H 0M</div>
                                            <div class="bottom">Direct Flight</div>
                                            <div class="hand-l">
                                                <span>CDG</span>
                                            </div>
                                            <div class="hand-r">
                                                <span>BER</span>
                                            </div>
                                        </div>
                                        <div class="cl right">
                                            <p>12:35 PM</p>
                                            <span>THU, OCT 25</span>
                                        </div>
                                    </div>
                                    <div class="f-end">
                                        <div class="item-price">
                                            <p>$400,00 <small>/person</small></p>
                                            <span>Class Economy</span>
                                            <div class="btn-rdo">
                                                <div class="custom-control custom-radio">
                                                    <input type="radio" id="customRadio1" name="customRadio" class="custom-control-input">
                                                    <label class="custom-control-label" for="customRadio1"></label>
                                                </div>
                                            </div>
                                        </div>
                                        <div class="item-price">
                                            <p>$400,00 <small>/person</small></p>
                                            <span>Class Economy</span>
                                            <div class="btn-rdo">
                                                <div class="custom-control custom-radio">
                                                    <input type="radio" id="customRadio2" name="customRadio" class="custom-control-input">
                                                    <label class="custom-control-label" for="customRadio2"></label>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div> <!--  col end-->

                    <div class="col-12 col-md-4 col-lg-3">
                        <div class="sidebar-right">
                            <div class="title">
                                Flight Information
                            </div>
                            <div class="bar-inner">

                                <div class="bar-bl">
                                    <h5 class="bt">Departure Flight</h5>
                                    <ul>
                                        <li><span>From:</span> Berlin (BER)</li>
                                        <li><span>To:</span> Paris (CDG)</li>
                                        <li><span>Departure Date:</span> 25/10/2018</li>
                                        <li><span>Fare:</span>  $650,00</li>
                                        <li><span>Tax:</span> $65,00</li>
                                        <li><span>Total:</span> $715,00</li>
                                    </ul>
                                </div>

                                <div class="bar-bl">
                                    <h5 class="bt">Return Flight</h5>
                                    <ul>
                                        <li><span>From:</span> Berlin (BER)</li>
                                        <li><span>To:</span> Paris (CDG)</li>
                                        <li><span>Departure Date:</span> 25/10/2018</li>
                                        <li><span>Fare:</span>  $650,00</li>
                                        <li><span>Tax:</span> $65,00</li>
                                        <li><span>Total:</span> $715,00</li>
                                    </ul>
                                </div>

                                <div class="sub-total">
                                    <p>Number of passengers: 1</p>
                                    <h6><span>Grand Total:</span> $1.331,00</h6>
                                    <a class="btn btn-primary" href="#">Book Now</a>
                                </div>

                            </div>
                        </div>
                    </div><!--  col end-->
                </div>
            </div>
        </div>

<?php get_footer();?>