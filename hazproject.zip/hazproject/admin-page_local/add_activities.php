<?php include('head.php');

 
  ?>  

 
<div style="padding:50px;border:1px solid blue;">
<h2><?php if(isset($_POST['add_activitys_submit_btn'])){ echo $msg;  } ?><h2>
<h4>Added Activity</h4> </br> </br>


 <form action="<?php echo get_stylesheet_directory_uri();?>/admin-page/upload.php" method="post" class="dropzone" id="my-awesome-dropzone" enctype="multipart/form-data">
   
  <div class="form-group row">
    <label for="colFormLabel" class="col-sm-2 col-form-label">activity Title</label>
    <div class="col-sm-10">
      <input type="text" class="form-control" id="colFormLabel" name="activity_title">
    </div>
  </div> 


  <div class="form-group row">
    <label for="colFormLabelLg" class="col-sm-2 col-form-label col-form-label-lg">activity Description</label>
    <div class="col-sm-10">
       <textarea name="activity_description"    style="resize:none;height:300px;width:40%;float:left"></textarea>
    </div>
  </div>


   
  </br> </br>

  


      <div class="form-group row">
    <label for="colFormLabel" class="col-sm-2 col-form-label">activity Location</label>
    <div class="col-sm-10">
      <input type="text" class="form-control" id="colFormLabel" name="activity_location">
    </div>
  </div>


    <div class="form-group row">
    <label for="colFormLabel" class="col-sm-2 col-form-label">activity Email</label>
    <div class="col-sm-10">
      <input type="text" class="form-control" id="colFormLabel" name="activity_email">
    </div>
  </div>


    <div class="form-group row">
    <label for="colFormLabel" class="col-sm-2 col-form-label">activity Phone No</label>
    <div class="col-sm-10">
      <input type="text" class="form-control" id="colFormLabel" name="activity_phone_no">
    </div>
  </div>


   <div class="form-group row">
    <label for="colFormLabel" class="col-sm-2 col-form-label">activity Price</label>
    <div class="col-sm-10">
      <input type="text" class="form-control" id="colFormLabel" name="activity_price">
    </div>
  </div>


   <div class="form-group row">
    <label for="colFormLabel" class="col-sm-2 col-form-label">Total activity</label>
    <div class="col-sm-10">
      <input type="text" class="form-control" id="colFormLabel" name="total_activity">
    </div>
  </div>


 <div class="form-group row">
    <label for="colFormLabel" class="col-sm-2 col-form-label">Video</label>
    <div class="col-sm-10">
      <input type="text" class="form-control" id="colFormLabel" name="video">
    </div>
  </div>

  



   <div class="form-group row">
    <label for="colFormLabel" class="col-sm-2 col-form-label">Package Name</label>
    <div class="col-sm-10">

    <div class="form-group">
                    <label for="">Package Name<sup>*</sup></label>
                    <input placeholder="Enter Package Name" class="form-control" type="text" name="activity_name[]">
                </div>
                <div class="form-group">
                    <label for="">Package Description<sup>*</sup></label>
                    <textarea placeholder="Enter Package description" class="form-control" type="text" name="activity_description[]"></textarea>
                </div>
     <div id="injectPkg"></div>
                            
            <div class="cr-pkg" style="margin-bottom: 15px;">
            <a href="#"><span> <i class="fa fa-plus"></i></span> Create Package</a>
        </div>
    </div>
  </div>


 

 


<div class="form-group row">
    <label for="colFormLabel" class="col-sm-2 col-form-label">activity Category</label>
    <div class="col-sm-10">
      <?php 

        global $wpdb;
        $wp_post_db = "activity_categories";
        $show_vendor_posts = $wpdb->get_results("SELECT * FROM $wp_post_db ORDER BY id DESC"); 
        $i=0;
        foreach( $show_vendor_posts as $show_vendor_post) 
        {  
         ?> 
       
            <label for="choice_<?php echo $show_vendor_post->id; ?>">
            <input name="category_id" id="choice_<?php echo $show_vendor_post->id; ?>" type="radio" value="<?php echo $show_vendor_post->id; ?>" <?php if($i==0){ ?> checked="checked" <?php } ?> tabindex="28">
                <?php echo $show_vendor_post->category_name; ?>
              </label> 

            <?php $i++; } ?>
       
    </div>
  </div> 



 

  
 <div class="form-group row">
    <label for="colFormLabel" class="col-sm-2 col-form-label">Hotel Gallery</label>
    <div class="col-sm-10">
 
<input type="file"  name="files[]" multiple="multiple" accept="image/*" /> 
</div>
</div>
 



  <div class="form-group row"> 
    <div class="col-sm-10">
     <input type="hidden" name="service_type" value="activities">
      <input type="submit" id="submit-all" class="btn-primary"   name="add_activitys_submit_btn"  >
    </div>
  </div> 

</form>
</div>


<?php include('footer.php'); ?>


 

  <h1>List of activitys</h1>
  <table class="table table-striped table-bordered table-hover" id="dataTables-example">
     
      <thead>
          <tr>   
               <th>activity ID</th>
               <th>activity Image</th>
              <th>activity Title</th>
               <th>activity Description</th>
               <th>activity Price</th>  
               <th>Added Date</th>
               <th>Action</th>
             </tr>
      </thead>

      <tbody>
      <?php     
        $service_type = 'activities';           
        $wp_post_db = "activity_details";  


        $show_vendor_posts = $wpdb->get_results("SELECT * FROM $wp_post_db ORDER BY id DESC"); 
        $i=0;
        foreach( $show_vendor_posts as $show_vendor_post)  
        {   
          //print_r($show_vendor_post);
          $aid             =  $show_vendor_post->id; 
          $activity_title       =  $show_vendor_post->activity_title; 
          $activity_description =  $show_vendor_post->activity_description;    
          $activity_price       =  $show_vendor_post->activity_price;  
          $date_added      =  $show_vendor_post->date_added;
                                                          
        ?>   

         <tr class="odd gradeA">   
            <td><?php echo $cid;?></td>
            <th> <img src="<?php echo getImageSrcById($aid, $service_type); ?>" width="60" height="60"></th>
            <td><?php echo $activity_title;?></td>
            <td><?php echo substr($activity_description, '0', '20');?></td>
            <td><?php echo $activity_price;?></td>  
            <td><?php echo $date_added; ?></td>
            <td class="center"> <a class="btn btn-danger" href="?page=add_activities&id=<?php echo $tid;?>&delete=activities&page=add_activities">Delete</a></td> 
         </tr>

<?php } ?>  
                
    </tbody>

      <tr>   
        <th>activity ID</th>
        <th>activity Image</th>
        <th>activity Title</th>
        <th>activity Description</th>
        <th>activity Price</th> 
        <th>Added Date</th>
        <th>Action</th>
      </tr>
</table>


<script>
         $(".cr-pkg a").on("click", function(e){
            e.preventDefault();
            $("#injectPkg").append(` 
                <div class="form-group">
                    <label for="">Package Name<sup>*</sup></label>
                    <input placeholder="Enter Package Name" class="form-control" type="text" name="activity_name[]">
                </div>
                <div class="form-group">
                    <label for="">Package Description<sup>*</sup></label>
                    <textarea placeholder="Enter Package description" class="form-control" type="text" name="activity_description[]"></textarea>
                </div>`);
         })
     </script>