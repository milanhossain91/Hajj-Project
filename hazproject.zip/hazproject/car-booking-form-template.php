<?php
/**
 * Template Name: Car Booking Form 
 */

get_header();

 
require_once('functions/car_functions.php');

?>
 <form method="post">
     <div class="booking-page has-border-top">
        <div class="container">
         <?php echo $msg; ?>
            <div class="row u-flex--content-center">

                <div class="col-lg-8">
                    <div class="booking_s_form">
                        <h3 style="margin-bottom: 20px;">Booking Submission</h3>
                        <div class="row">

                            <div class="col-lg-12">
                                <div class="form-group form-group-icon-left">
                                    <label for="">Pickup location<sup>*</sup></label>
                                    <input placeholder="Enter pickup location" name="pickup_location" class="form-control" type="text" required>
                                    <i class="fa fa-map-marker input-icon "></i>
                                </div>
                            </div>

                                
                            <div class="col-lg-12">
                                <div class="is-dropof" style="margin-bottom: 15px;">
                                    <div class="custom-control custom-checkbox">
                                        <input type="checkbox" class="custom-control-input" id="dropoffCh" value="1" name="is_different">
                                        <label class="custom-control-label" for="dropoffCh">
                                            Is drop off location different       
                                        </label>
                                    </div>
                                </div>
                                <div class="form-group form-group-icon-left" id="DropOffLocCtrl">
                                    <label for="">Drop off location<sup>*</sup></label>
                                    <input placeholder="Enter drop off location" class="form-control" type="text" name="drop_off_location" required>
                                    <i class="fa fa-map-marker input-icon "></i>
                                </div>
                            </div>

                            <div class="col-lg-6">
                                <div class="form-group form-group-icon-left">
                                    <label for="">Name <sup>*</sup></label>
                                    <input placeholder="Name" class="form-control" type="text" name="u_name" required>
                                    <i class="fa fa-user input-icon "></i>
                                </div>
                            </div>

                            <div class="col-lg-6">
                                <div class="form-group form-group-icon-left">
                                    <label for="">Email <sup>*</sup></label>
                                    <input placeholder="Email" class="form-control" type="text" name="u_email"  required>
                                    <i class="fa fa-envelope  input-icon "></i>
                                </div>
                            </div>


                            <div class="col-lg-4">
                                <div class="form-group form-group-icon-left">
                                    <label for="">Phone  <sup>*</sup></label>
                                    <input placeholder="Phone " class="form-control" type="text" name="u_cell" required>
                                    <i class="fa fa-phone  input-icon "></i>
                                </div>
                            </div>

                            <div class="col-lg-4">
                                <div class="form-group form-group-icon-left">
                                    <label for="">Date of journey<sup>*</sup></label>
                                    <input placeholder="Pick a date" class="form-control datepicker" type="text"  name="date_of_journey" required>
                                    <i class="fa fa-calendar  input-icon "></i>
                                </div>
                            </div>

                            <div class="col-lg-4">
                                <div class="form-group form-group-icon-left">
                                    <label for="">Select time<sup>*</sup></label>
                                    <select class="form-control"  name="time_of_journey" required>
                                        <option value="12 PM">12 PM</option>
                                         <option value="10 PM">10 PM</option>
                                          <option value="6 PM">6 PM</option>
                                           <option value="5 PM">5 PM</option>
                                    </select>
                                    <i class="fa fa-clock-o  input-icon "></i>
                                </div>
                            </div>
                        </div>
                    </div>
    

                    <div class="form-submit text-center" style="padding-top: 10px;">
                       <button style="width: 150px" class="btn btn-primary" name="car_booking_submit">Submit</button>
                    </div>
                </div> <!-- col 8 -->

                    
    

            </div> <!-- row -->
        </div>
    </div>
 
  </form>

<?php

get_footer();
?>


<script>
 jQuery('.datepicker').datepicker();
</script>   