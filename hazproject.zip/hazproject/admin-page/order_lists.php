<?php include('head.php');

 
  ?>  
 


<?php include('footer.php'); ?>


 
  <div class="crow"> 
    <div class="col-sm-12">
  <h1>List of Orders</h1>
  <table class="table table-striped table-bordered table-hover" id="dataTables-example">
     
      <thead>
          <tr>   
               <th>Order ID</th>
               <th>Order Image</th>
               <th>User Name</th>
               <th>Order Description</th>
               <th>Order Price</th>  
               <th>Added Date</th>
               <th>Action</th>
             </tr>
      </thead>

      <tbody>
      <?php     
      global $wpdb;
        $service_type = 'main_booking_details';           
        $wp_post_db = "main_booking_details";  


        $show_vendor_posts = $wpdb->get_results("SELECT * FROM $wp_post_db ORDER BY id DESC"); 
        $i=0;
        foreach( $show_vendor_posts as $show_vendor_post)  
        {   
           print_r($show_vendor_post);
          $aid             =  $show_vendor_post->id; 
          $u_name       =  $show_vendor_post->u_name; 
          $Order_description =  $show_vendor_post->Order_description;    
          $Order_price       =  $show_vendor_post->Order_price;  
          $date_added      =  $show_vendor_post->date_added;
                                                          
        ?>   

         <tr class="odd gradeA">   
            <td><?php echo $cid;?></td>
            <th> <img src="<?php echo getImageSrcById($aid, $service_type); ?>" width="60" height="60"></th>
            <td><?php echo $u_name;?></td>
            <td><?php echo substr($Order_description, '0', '20');?></td>
            <td><?php echo $Order_price;?></td>  
            <td><?php echo $date_added; ?></td>
            <td class="center"> <a class="btn btn-danger" href="?page=add_activities&id=<?php echo $tid;?>&delete=activities&page=add_activities">Delete</a></td> 
         </tr>

<?php } ?>  
                
    </tbody>

      <tr>   
        <th>Order ID</th>
        <th>Order Image</th>
         <th>User Name</th>
        <th>Order Description</th>
        <th>Order Price</th> 
        <th>Added Date</th>
        <th>Action</th>
      </tr>
</table>
	  </div>
</div>

 