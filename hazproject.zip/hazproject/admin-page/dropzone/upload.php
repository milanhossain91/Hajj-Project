<?php

	include('../../../../../wp-load.php');    
	global $wpdb, $current_user;    
	session_start();
 
 // Multiple file upload
   
    $current_user = wp_get_current_user(); 
    $current_user_ID = $current_user->ID;   
    

$service_type = $_POST['service_type'];

$target_dir = get_stylesheet_directory().'/uploads/'.$service_type;    
 


if($service_type == 'cars'){  
    // Create rooms object
    $data5 = array(  
     'user_id'           => get_current_user_id(), 
      'total_car'       => $_POST['total_car'],
      'package_id'       => $_POST['package_id'],
      'car_description' => $_POST['car_description'],  
      'car_location' => $_POST['car_location'],   
      'car_email' => $_POST['car_email'],  
      'car_phone_no' => $_POST['car_phone_no'],  
      'car_price' => $_POST['car_price'],   
      
    );  
    $lastId =  $wpdb->insert('car_details', $data5 );   
}


if($service_type == 'tours'){  
    // Create rooms object
    $data5 = array(  
     'user_id'           => get_current_user_id(), 
      'total_tour'       => $_POST['total_tour'],
      'category_id'       => $_POST['category_id'],
      'tour_description' => $_POST['tour_description'],  
      'tour_location' => $_POST['tour_location'],   
      'tour_email' => $_POST['tour_email'],  
      'tour_phone_no' => $_POST['tour_phone_no'],  
      'tour_price' => $_POST['tour_price'],  
      'video' => $_POST['video'],
      
    );  
    $wpdb->insert('tour_details', $data5 );   
    $lastId = $wpdb->insert_id;

     //tour activities   
         $activity_descriptions = $_POST['activity_description'];
        $activity_names = $_POST['activity_name']; 
        foreach($activity_names as  $key=>$activity_name) {

            $data6 = array(  
            'tour_id' => $lastId, 
            'activity_name' => $activity_names[$key], 
            'activity_description' => $activity_descriptions[$key], 
            );  
            $wpdb->insert('tour_activities', $data6 );  // print_r($data); 
        } 


       
       
       /* foreach($activity_descriptions as $activity_description) {

            $data7 = array(  
            'tour_id' => $lastId, 
            'activity_description' => $activity_description, 
            );  
            $wpdb->insert('tour_activities2', $data7 );  // print_r($data); 
        } */




}



if($service_type == 'rooms'){
  


// Create rooms object
$data3 = array( 
  'user_id'           => get_current_user_id(), 
  
  'hotel_id'           => $_POST['hotel_id'],

  'total_room'       => $_POST['total_room'],
  'room_title'       => $_POST['room_title'],
  'room_description' => $_POST['room_description'],   
   
  'room_check_in'    => $_POST['room_check_in'],
  'room_check_out'   => $_POST['room_check_out'], 
  'room_email'       => $_POST['room_email'],
  'room_phone_no'    => $_POST['room_phone_no'],
  'room_price'       => $_POST['room_price'], 
);  

 $wpdb->insert('available_rooms', $data3 );    
 $lastId = $wpdb->insert_id;


}
if($service_type == 'hotels'){


// Create rooms object
$data1 = array( 
  'user_id'           => get_current_user_id(), 
  'hotel_title'       => $_POST['hotel_title'],
  'hotel_description' => $_POST['hotel_description'],   
   
  'hotel_check_in'    => $_POST['hotel_check_in'],
  'hotel_check_out'   => $_POST['hotel_check_out'],
  'hotel_location'    => $_POST['hotel_location'],


 
  'hotel_email'       => $_POST['hotel_email'],
  'hotel_phone_no'    => $_POST['hotel_phone_no'],
  'hotel_price'       => $_POST['hotel_price'],


   
  'hotel_website'          => $_POST['hotel_website'],
  'hotel_cancelled_repayment'       => $_POST['hotel_cancelled_repayment'],
  'hotel_children_and_extrabed' => $_POST['hotel_children_and_extrabed'],
);  

//print_r($data1);

 $wpdb->insert('hotel_details', $data1 );   
 $lastId = $wpdb->insert_id;

  $service_name_ids = $_POST['service_name_ids'];
        foreach($service_name_ids as $service_name_id) {

            $data2 = array(  
            'hotel_id' => $lastId, 
            'service_id' => $lastId, 
            'service_type' => $service_type, 
            );  
            $wpdb->insert('hotel_offers_relation', $data2 );  // print_r($data); 
        } 
  


}




  $msg =  'Insert Successfully.....'; 
 
   
  foreach($_FILES['file']['name'] as $index=>$name){   
            
        $filename = $name;  
        $root = get_stylesheet_directory();
        $directory  = $root."/uploads/".$service_type."/gallary";
        $folder_name ='image_'.$lastId;
        
        //image url insert
        $arrg= array(  
        'service_id' =>  $lastId, 
        'user_id' =>  $current_user_ID, 
        'img_name' => $name, 
        'service_type' => $service_type, 
        'img_url' => "/uploads/".$service_type."/gallary/".$folder_name.'/'.$name,
        );

       
         $wpdb->insert('new_order_img', $arrg ); 
             
      if(!file_exists(  get_stylesheet_directory()."/uploads/".$service_type."/gallary/".$folder_name.'/'.$filename)){ 
        if (!file_exists($directory."/".$folder_name)) {
        mkdir($directory."/".$folder_name, 0777, true);
        } 
        move_uploaded_file($_FILES["file"]["tmp_name"][$index], get_stylesheet_directory()."/uploads/".$service_type."/gallary/".$folder_name.'/'.$filename);  
          }   
            
     } 
 


     

 

    
 


      
     

     


 
 
   





?>