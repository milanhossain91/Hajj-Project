<html>
<head>



  <link rel="stylesheet" href="css/runnable.css" />
  <link rel="stylesheet" href="css/dropzone.css" />
<script src="js/jquery-1.11.2.min.js"></script>
  <script src="js/dropzone.js"></script>



</head>

<body>
  <h1>Drag and Drop files using Dropzone.js</h1>




<form action="upload.php" method="post" class="dropzone" id="my-awesome-dropzone" enctype="multipart/form-data">
 
    <div class="dropzone-previews"></div>
 
    <div class="fallback">
       <input name="file" type="file" multiple/>
    </div>
 
</form>
 
 <button type="submit" id="submit-all" class="btn btn-primary btn-xs">Upload the file</button>

 


<script type="text/javascript">
 
 // The camelized version of the ID of the form element
 
 Dropzone.options.myAwesomeDropzone = { 
 
 // set following configuration
 
    autoProcessQueue: false,
    uploadMultiple: true,
    parallelUploads: 10,
    maxFiles: 10,
    addRemoveLinks: true,
    previewsContainer: ".dropzone-previews",
    dictRemoveFile: "Remove",
    dictCancelUpload: "Cancel",
    dictDefaultMessage: "Drop the images you want to upload here",
    dictFileTooBig: "Image size is too big. Max size: 10mb.",
    dictMaxFilesExceeded: "Only 10 images allowed per upload.",
    acceptedFiles: ".jpeg,.jpg,.png,.gif,.JPEG,.JPG,.PNG,.GIF",
 
   // The setting up of the dropzone
 
   init: function() {
     var myDropzone = this;
 
   // Upload images when submit button is clicked.
 
   jQuery("#submit-all").click(function (e) {
       e.preventDefault();
       e.stopPropagation();
       myDropzone.processQueue();
 
    });
 
 
   // Refresh page when all images are uploaded
 
    myDropzone.on("complete", function (file) {
         if (myDropzone.getUploadingFiles().length === 0 && myDropzone.getQueuedFiles().length === 0) {
        window.location.reload();
        }
      });
 
    }
 
 }
 
 
 </script>
</body>
</html>