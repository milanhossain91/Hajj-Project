<?php include('head.php');?>  

<?php 

if(isset($_GET['page'])){
   $slug_type = $_GET['page'];
   $part = explode('add_city_', $slug_type);
 
}
 
 if(isset($_POST['add_city_btn'])){
  
   global $wpdb;
    // Create rooms object
    $data3 = array(  
      'city_name'       => $_POST['city_name'], 
      'service_type' => $_POST['service_type'],   
    );  
    $results = $wpdb->insert('city_list', $data3 ); 
    if($results){
    $msg = "Successfully Inserted..";
    }
}
?> 

<div class="admin_form">
		<div class="crow">
		<div class="col-md-12">
  			<h2 style="color:blue;"><?php if(isset($_POST['add_city_btn'])){ echo $msg;  } ?><h2>
  			<h4>Added City</h4>  
				<br>
				<br>
	</div>
</div>
   <form method="post" enctype="multipart/form-data">

     
    <div class="form-group crow">
      <label for="colFormLabel" class="col-sm-2 col-form-label">City Name</label>
      <div class="col-sm-4">
        <input type="text" class="form-control" id="colFormLabel" name="city_name" required>
      </div>
    </div> 
 
    <div class="form-group crow"> 
      <div class="col-sm-1">
		  <div class="admin_form_submit"> 
       <input type="hidden" name="service_type" value="<?php echo $part[1]; ?>">
        <input type="submit"  class="btn-primary"   name="add_city_btn" >
      </div>
    </div> 
	   </div>

</form>

</div>

<?php include('footer.php'); ?>


  

   