<?php

if(isset($_POST['add_hotels_submit_btn'])){
	

  $target_dir = get_stylesheet_directory().'/uploads/hotels/';   

// Create rooms object
$data = array( 
  'user_id'           => get_current_user_id(), 
  'hotel_title'       => $_POST['hotel_title'],
  'hotel_description' => $_POST['hotel_description'],



  'hotel_image'       => $_FILES["thumbnail"]["name"],
  'hotel_check_in'    => $_POST['hotel_check_in'],
  'hotel_check_out'   => $_POST['hotel_check_out'],
  'hotel_location'    => $_POST['hotel_location'],


 
  'hotel_email'       => $_POST['hotel_email'],
  'hotel_phone_no'    => $_POST['hotel_phone_no'],
  'hotel_price'       => $_POST['hotel_price'],


   
  'hotel_website'          => $_POST['hotel_website'],
  'hotel_cancelled_repayment'       => $_POST['hotel_cancelled_repayment'],
  'hotel_children_and_extrabed' => $_POST['hotel_children_and_extrabed'],
); 


 
 $lastId =  $wpdb->insert('hotel_details', $data ); 
 if($_FILES["thumbnail"]["name"]){
  Generate_Featured_Image( $target_dir.$_FILES["thumbnail"]["name"], $lastId  ); //hotel image 

  $msg =  'Insert Successfully.....';

}


}




 
        
 function Generate_Featured_Image($target_dir){
        
        $target_file = $target_dir . basename($_FILES["thumbnail"]["name"]);

        $uploadOk = 1;
        $imageFileType = strtolower(pathinfo($target_file,PATHINFO_EXTENSION));
// Check if image file is a actual image or fake image
        
            $check = getimagesize($_FILES["thumbnail"]["tmp_name"]);
            if($check !== false) {
                //echo "File is an image - " . $check["mime"] . ".";
                $uploadOk = 1;
            } else {
                echo "File is not an image.";
                $uploadOk = 0;
            }
      
// Check if file already exists
     /*   if (file_exists($target_file)) {
            echo "Sorry, file already exists.";
            $uploadOk = 0;
        }*/
// Check file size
       /* if ($_FILES["video_thumbnail"]["size"] > 500000000) {
            //echo "Sorry, your file is too large.";
            $uploadOk = 0;
        }*/
// Allow certain file formats
        if($imageFileType != "jpg" && $imageFileType != "png" && $imageFileType != "jpeg"
            && $imageFileType != "gif" ) {
           //echo "Sorry, only JPG, JPEG, PNG & GIF files are allowed.";
        $uploadOk = 0;
    }
// Check if $uploadOk is set to 0 by an error
    if ($uploadOk == 0) {
       // echo "Sorry, your file was not uploaded.";
// if everything is ok, try to upload file
    } else {
        if (move_uploaded_file($_FILES["thumbnail"]["tmp_name"], $target_file)) {
            //echo "The file has been uploaded.";
        } else {
            echo "Sorry, there was an error uploading your file.";
        }
    }

}




 
 
  
             
         
         



      
  

 