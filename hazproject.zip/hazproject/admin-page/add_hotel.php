<?php include('head.php');  

  


?>  

 
<div class="admin_form">
	<div class="crow">
		<div class="col-md-12">
<h2><?php if(isset($_POST['add_hotels_submit_btn'])){ echo $msg;  } ?><h2>
<h4>Added Hotels</h4> </br> </br>
		</div>
	</div>
			
<form action="<?php echo get_stylesheet_directory_uri();?>/admin-page/upload.php" method="post" class="dropzone" id="my-awesome-dropzone" enctype="multipart/form-data"> 
   
  <div class="form-group crow">
    <label for="colFormLabel" class="col-sm-2 col-form-label">Hotel Title</label>
    <div class="col-sm-10">
      <input type="text" class="form-control" id="colFormLabel" name="hotel_title">
    </div>
  </div> 


  <div class="form-group crow">
    <label for="colFormLabelLg" class="col-sm-2 col-form-label col-form-label-lg">Hotel Description</label>
    <div class="col-sm-10">
       <textarea name="hotel_description"  class="form-control"  style="resize:none;height:300px;width:40%;float:left"></textarea>
    </div>
  </div>


   
  </br> </br>


<div class="form-group crow">
    <label for="colFormLabel" class="col-sm-2 col-form-label">Hotel Check In</label>
    <div class="col-sm-10">
      <input type="date" class="form-control" id="colFormLabel" name="hotel_check_in">
    </div>
  </div> 


    <div class="form-group crow">
    <label for="colFormLabel" class="col-sm-2 col-form-label">Hotel Check Out</label>
    <div class="col-sm-10">
      <input type="date" class="form-control" id="colFormLabel" name="hotel_check_out">
    </div>
  </div>


    <div class="form-group crow">
    <label for="colFormLabel" class="col-sm-2 col-form-label">Hotel Cancelled Repayment</label>
    <div class="col-sm-10">
      <input type="text" class="form-control" id="colFormLabel" name="hotel_cancelled_repayment">
    </div>
  </div>



      <div class="form-group crow">
    <label for="colFormLabel" class="col-sm-2 col-form-label">hotel Location</label>
    <div class="col-sm-10">
    

     <select name="hotel_location">
     <?php 
          global $wpdb;
          $service_type ='hotels';
          $wp_post_db = "city_list";
          $show_vendor_posts = $wpdb->get_results("SELECT * FROM $wp_post_db WHERE service_type ='$service_type' ORDER BY id DESC"); 
          $i=0;
          foreach( $show_vendor_posts as $show_vendor_post) 
          {  
            ?>
         <option value="<?php echo $show_vendor_post->city_name; ?>"><?php echo $show_vendor_post->city_name; ?></option>

       <?php } ?> 
       </select> 
        
    </div>
  </div>


    <div class="form-group crow">
    <label for="colFormLabel" class="col-sm-2 col-form-label">Hotel Email</label>
    <div class="col-sm-10">
      <input type="text" class="form-control" id="colFormLabel" name="hotel_email">
    </div>
  </div>


    <div class="form-group crow">
    <label for="colFormLabel" class="col-sm-2 col-form-label">Hotel Phone No</label>
    <div class="col-sm-10">
      <input type="text" class="form-control" id="colFormLabel" name="hotel_phone_no">
    </div>
  </div>


   <div class="form-group crow">
    <label for="colFormLabel" class="col-sm-2 col-form-label">Hotel Price</label>
    <div class="col-sm-10">
      <input type="text" class="form-control" id="colFormLabel" name="hotel_price">
    </div>
  </div>

     <div class="form-group crow">
    <label for="colFormLabel" class="col-sm-2 col-form-label">Hotel Website</label>
    <div class="col-sm-10">
      <input type="text" class="form-control" id="colFormLabel" name="hotel_website">
    </div>
  </div>




    <div class="form-group crow">
    <label for="colFormLabel" class="col-sm-2 col-form-label">Hotel Children and Extrabed</label>
    <div class="col-sm-10">
      <input type="text" class="form-control" id="colFormLabel" name="hotel_children_and_extrabed">
    </div>
  </div>


    <div class="form-group crow">
    <label for="colFormLabel" class="col-sm-2 col-form-label">Hotel Pets</label>
    <div class="col-sm-10">
      <input type="text" class="form-control" id="colFormLabel" name="hotel_pets">
    </div>
  </div> 


<div class="form-group crow">
    <label for="colFormLabel" class="col-sm-2 col-form-label">Hotel Services</label>
    <div class="col-sm-10">
          <?php 

          global $wpdb;
          $wp_post_db = "hotel_offers";
          $show_vendor_posts = $wpdb->get_results("SELECT * FROM $wp_post_db ORDER BY id DESC"); 
          $i=0;
          foreach( $show_vendor_posts as $show_vendor_post) 
          {  
          ?> 

            <label for="choice_<?php echo $show_vendor_post->id; ?>">
            <input name="service_name_ids[]" id="choice_<?php echo $show_vendor_post->id; ?>" type="checkbox" value="<?php echo $show_vendor_post->id; ?>" <?php if($i==0){ ?> checked="checked" <?php } ?> tabindex="28">
                <?php echo $show_vendor_post->service_name; ?>
            </label> 

          <?php $i++; } ?>
       
    </div>
  </div> 



<div class="form-group crow">
    <label for="colFormLabel" class="col-sm-2 col-form-label">Hotel Gallery</label>
    <div class="col-sm-10">
 
<input type="file" class="form-control"  name="files[]" multiple="multiple" accept="image/*" /> 
</div>
</div>

 
  <div class="form-group crow"> 
    <div class="col-sm-10">
		<div class="admin_form_submit"> 
     <input type="hidden" name="service_type" value="hotels">
      <input type="submit" id="submit-all" class="btn btn-primary"   name="add_hotels_submit_btn" >
    </div>
  </div> 
</div>
</form>

</div>





<?php include('footer.php'); ?>

 



 <div class="crow"> 
    <div class="col-sm-12">
  <h1>List of Hotels</h1>
  <table class="table table-striped table-bordered table-hover" id="dataTables-example">
      <thead>
          <tr>   
               <th>Hotel ID</th>
               <th>Hotel Image</th>
                <th>Hotel Title</th>
               <th>Hotel Description</th>
               <th>Hotel Price</th>  
               <th>Added Date</th>
                <th>Action</th>
             </tr>
      </thead>
      <tbody>

      <?php     
                      $service_type = 'hotels'; 
                        

                      $wp_post_db = "hotel_details";  
                      $show_vendor_posts = $wpdb->get_results("SELECT * FROM $wp_post_db ORDER BY id DESC"); 
                      $i=0;
                      foreach( $show_vendor_posts as $show_vendor_post)  
                      {   
                      //print_r($show_vendor_post);
                      $hid =  $show_vendor_post->id; 
                      $hotel_title =  $show_vendor_post->hotel_title; 
                      $hotel_description =  $show_vendor_post->hotel_description;    
                      $hotel_price =  $show_vendor_post->hotel_price;  
                      $added_date =  $show_vendor_post->added_date;                                                
                      ?>   

        <tr class="odd gradeA">    
                      
                      <td><?php echo $hid;?></td>
                      <th> <img src="<?php echo getImageSrcById($hid, $service_type); ?>" width="60" height="60"></th>
                      <td><?php echo $hotel_title;?></td>
                      <td><?php echo substr($hotel_description, '0', '20');?></td>
                      <td><?php echo $hotel_price;?></td>  
                      <td><?php echo $added_date; ?></td>
                       <td class="center"> <a class="btn btn-danger" href="?page=add_hotels&id=<?php echo $hid;?>&delete=hotels&page=add_hotels">Delete</a></td> 
                     </tr>
         <?php } ?>

         
      </tbody>
      <tr>   
               <th>Hotel ID</th>
                <th>Hotel Image</th>
                <th>Hotel Title</th>
               <th>Hotel Description</th>
               <th>Hotel Price</th> 
               <th>Added Date</th>
                <th>Action</th>
       </tr>
  </table>
	 </div>
</div>