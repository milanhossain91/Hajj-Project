<?php 
  include('../../../../wp-load.php');    
	global $wpdb, $current_user;    
	session_start();
 
 // Multiple file upload
   
    $current_user = wp_get_current_user(); 
    $current_user_ID = $current_user->ID;   
    

$service_type = $_POST['service_type'];

$target_dir = get_stylesheet_directory().'/uploads/'.$service_type;    
 


if($service_type == 'cars'){  
    // Create rooms object
    $data1 = array(  
     'user_id'           => get_current_user_id(), 
      'total_car'       => $_POST['total_car'],
      'package_id'       => $_POST['package_id'],
      'car_description' => $_POST['car_description'],  
      'car_location' => $_POST['car_location'],   
      'car_email' => $_POST['car_email'],  
      'car_phone_no' => $_POST['car_phone_no'],  
      'car_price' => $_POST['car_price'],    
    );  
     $wpdb->insert('car_details', $data1 );   
      $lastId = $wpdb->insert_id;
}


if($service_type == 'tours'){  
    // Create rooms object
    $data2 = array(  
     'user_id'           => get_current_user_id(), 
      'total_tour'       => $_POST['total_tour'],
      'category_id'       => $_POST['category_id'],
      'tour_description' => $_POST['tour_description'],  
      'tour_location' => $_POST['tour_location'],   
      'tour_email' => $_POST['tour_email'],  
      'tour_phone_no' => $_POST['tour_phone_no'],  
      'tour_price' => $_POST['tour_price'],  
      'video' => $_POST['video'],
      
    );  
    $wpdb->insert('tour_details', $data2 );   
    $lastId = $wpdb->insert_id;

     //tour activities   
         $activity_descriptions = $_POST['activity_description'];
        $activity_names = $_POST['activity_name']; 
        foreach($activity_names as  $key=>$activity_name) {

            $data3 = array(  
            'tour_id' => $lastId, 
            'activity_name' => $activity_names[$key], 
            'activity_description' => $activity_descriptions[$key], 
            );  
            $wpdb->insert('tour_activities', $data3 );  // print_r($data); 
        } 
 


}



if($service_type == 'rooms'){
  


// Create rooms object
$data4 = array( 
  'user_id'           => get_current_user_id(), 
  
  'hotel_id'           => $_POST['hotel_id'],

  'total_room'       => $_POST['total_room'],
  'room_title'       => $_POST['room_title'],
  'room_description' => $_POST['room_description'],   
   
  'room_check_in'    => $_POST['room_check_in'],
  'room_check_out'   => $_POST['room_check_out'], 
  'room_email'       => $_POST['room_email'],
  'room_phone_no'    => $_POST['room_phone_no'],
  'room_price'       => $_POST['room_price'], 
);  

 $wpdb->insert('available_rooms', $data4 );    
 $lastId = $wpdb->insert_id;

   $service_name_ids = $_POST['service_name_ids'];
        foreach($service_name_ids as $service_name_id) {

            $data5 = array(  
            'hotel_id' => $lastId, 
            'service_id' => $service_name_id, 
            'service_type' => $service_type, 
            );  
            $wpdb->insert('hotel_offers_relation', $data5 );  // print_r($data); 
        }  


}
if($service_type == 'hotels'){


// Create rooms object
$data6 = array( 
  'user_id'           => get_current_user_id(), 
  'hotel_title'       => $_POST['hotel_title'],
  'hotel_description' => $_POST['hotel_description'],   
   
  'hotel_check_in'    => $_POST['hotel_check_in'],
  'hotel_check_out'   => $_POST['hotel_check_out'],
  'hotel_location'    => $_POST['hotel_location'],


 
  'hotel_email'       => $_POST['hotel_email'],
  'hotel_phone_no'    => $_POST['hotel_phone_no'],
  'hotel_price'       => $_POST['hotel_price'],


   
  'hotel_website'          => $_POST['hotel_website'],
  'hotel_cancelled_repayment'       => $_POST['hotel_cancelled_repayment'],
  'hotel_children_and_extrabed' => $_POST['hotel_children_and_extrabed'],
);  

//print_r($data1);

 $wpdb->insert('hotel_details', $data6 );   
 $lastId = $wpdb->insert_id;

  $service_name_ids = $_POST['service_name_ids'];
        foreach($service_name_ids as $service_name_id) {

            $data7 = array(  
            'hotel_id' => $lastId, 
            'service_id' => $service_name_id, 
            'service_type' => $service_type, 
            );  
            $wpdb->insert('hotel_offers_relation', $data7 );  // print_r($data); 
        }  

}


if($service_type == 'activities'){  
    // Create rooms object
    $data8 = array(  
     'user_id'           => get_current_user_id(), 
      'total_activity'       => $_POST['total_activity'],
      'category_id'       => $_POST['category_id'],
      'activity_description' => $_POST['activity_description'],  
      'activity_location' => $_POST['activity_location'],   
      'activity_email' => $_POST['activity_email'],  
      'activity_phone_no' => $_POST['activity_phone_no'],  
      'activity_price' => $_POST['activity_price'],  
      'video' => $_POST['video'],
      
    );  
    $wpdb->insert('activity_details', $data8 );   
    $lastId = $wpdb->insert_id;

     //activity activities   
         $activity_descriptions = $_POST['activity_description'];
        $activity_names = $_POST['activity_name']; 
        foreach($activity_names as  $key=>$activity_name) {

            $data9 = array(  
            'activity_id' => $lastId, 
            'activity_name' => $activity_names[$key], 
            'activity_description' => $activity_descriptions[$key], 
            );  
            $wpdb->insert('activity_activities', $data9 );  // print_r($data); 
        }  


}

//guide

if($service_type == 'guides'){  
    // Create rooms object
    $data9 = array(  
     'user_id'           => get_current_user_id(), 
      'total_guide'       => $_POST['total_guide'],
      'category_id'       => $_POST['category_id'],
      'guide_description' => $_POST['guide_description'],  
      'guide_location' => $_POST['guide_location'],   
      'guide_email' => $_POST['guide_email'],  
      'guide_phone_no' => $_POST['guide_phone_no'],  
      'guide_price' => $_POST['guide_price'],  
      'video' => $_POST['video'],
      
    );  
    $wpdb->insert('guide_details', $data9 );   
    $lastId = $wpdb->insert_id;
     //print_r($data10);
     //guide activities   
        $guide_descriptions = $_POST['guide_description'];
        $guide_names = $_POST['guide_name']; 
        foreach($guide_names as  $key=>$guide_name) {

            $data11 = array(  
            'guide_id' => $lastId, 
            'package_name' => $guide_names[$key], 
            'package_description' => $guide_descriptions[$key], 
            );  
            $wpdb->insert('guide_packages', $data11 );  // print_r($data); 
        }   
} 



//Transport

if($service_type == 'transports'){  
    // Create rooms object
    $data10 = array(  
     'user_id'           => get_current_user_id(), 
      'total_transport'       => $_POST['total_transport'], 
      'transport_description' => $_POST['transport_description'],  
      'transport_location' => $_POST['transport_location'],   
      'transport_email' => $_POST['transport_email'],  
      'transport_phone_no' => $_POST['transport_phone_no'],  
      'transport_price' => $_POST['transport_price'],  
      'video' => $_POST['video'],
      
    );  
    $wpdb->insert('transport_details', $data10 );   
    $lastId = $wpdb->insert_id;
     // print_r($data10);
     //transport activities   
        $service_name_ids = $_POST['service_name_ids']; 
        foreach($service_name_ids as  $key=>$service_name_id) { 

            $data11 = array(  
            'transport_id' => $lastId, 
            'service_id' => $service_name_id, 
            'service_type' => 'transports', 
            );  
            $wpdb->insert('transport_stopage_relations', $data11 );  // print_r($data); 
        }   
} 


//restaurant

if($service_type == 'restaurants'){  
    // Create rooms object
    $data11 = array(  
     'user_id'           => get_current_user_id(),  
      'restaurant_description' => $_POST['restaurant_description'],  
      'restaurant_location' => $_POST['restaurant_location'],   
      'restaurant_email' => $_POST['restaurant_email'],  
      'restaurant_phone_no' => $_POST['restaurant_phone_no'],   
      'video' => $_POST['video'], 
    );  
    $wpdb->insert('restaurant_details', $data11 );   
    $lastId = $wpdb->insert_id;
   
     
} 


  $msg =  'Insert Successfully.....'; 

 
   
  foreach($_FILES['files']['name'] as $index=>$name){   
            
        $filename = $name;  
        $root = get_stylesheet_directory();
        $directory  = $root."/uploads/".$service_type."/gallary";
        $folder_name ='image_'.$lastId;
        
        //image url insert
        $arrg= array(  
        'service_id' =>  $lastId, 
        'user_id' =>  $current_user_ID, 
        'img_name' => $name, 
        'service_type' => $service_type, 
        'img_url' => "/uploads/".$service_type."/gallary/".$folder_name.'/'.$name,
        );
 //print_r($arrg);
       
      $wpdb->insert('new_order_img', $arrg );  



            $valid_formats = array("jpg", "png", "gif", "zip", "bmp");
            $max_file_size = 1024*50000; //100 kb
            $path = "uploads/"; // Upload directory
            $count = 0;

            if(isset($_POST) and $_SERVER["REQUEST_METHOD"] == "POST"){
            // Loop $_FILES to exeicute all files
                foreach ($_FILES["files"]["name"] as $f => $name) {
                    if ($_FILES["files"]["error"][$f] == 4) {
            continue; // Skip file if any error found
            }
            if ($_FILES["files"]["error"][$f] == 0) {
                if ($_FILES["files"]["size"][$f] > $max_file_size) {
                    $message[] = "$name is too large!.";
            continue; // Skip large files
            }
            elseif( ! in_array(pathinfo($name, PATHINFO_EXTENSION), $valid_formats) ){
                $message[] = "$name is not a valid format";
            continue; // Skip invalid file formats
            }
            else{ // No error found! Move uploaded files
               // if(move_uploaded_file($_FILES["files"]["tmp_name"][$f], $path.$name))

                if(!file_exists(  get_stylesheet_directory()."/uploads/".$service_type."/gallary/".$folder_name.'/'.$name)){ 
                  if (!file_exists($directory."/".$folder_name)) {
                  mkdir($directory."/".$folder_name, 0777, true);
                  } 
                  move_uploaded_file($_FILES["files"]["tmp_name"][$index], get_stylesheet_directory()."/uploads/".$service_type."/gallary/".$folder_name.'/'.$name);  
                    }   


                 $count++; // Number of successfully uploaded file
            }
            }
            }
            }

            


     } 
 

   
     
if($lastId ){ 
 
//success msg 
    echo '<script type="text/javascript">'; 
    echo 'alert("Sucessfully Inserted ");'; 
    echo 'window.history.back();';
     echo 'window.location.href="'.site_url().'/wp-admin/admin.php?page=add_'.$service_type.'"';
    echo '</script>'; 
    
  }else {  
    echo '<script type="text/javascript">'; 
     echo 'alert("Message not Sent, 400 error");'; 
    echo 'window.history.back();';
    echo '</script>';
  }
 

    
 


      
     

     


 
 
   





?>