<?php include('head.php');?>  

<?php 
global $wpdb;
 if(isset($_POST['add_stopage_submit_btn'])){
  
   global $wpdb;
    // Create rooms object

 
    $data3 = array(  
      'stopage_name'       => $_POST['stopage_name'], 
      'stopage_description' => $_POST['stopage_description'],   
       'added_date' => $_POST['added_date'].' '.$_POST['time'].' '.$_POST['am_pm'],   

    );  
    if(isset($_GET['edit'])){
       $editId = $_GET['id']; 
       $results = $wpdb->update('transport_stopage', $data3, array('id'=>$editId ) ); 
    }else{
    $results = $wpdb->insert('transport_stopage', $data3 ); 
  }
   // print_r($data3);
    if($results){
    $msg = "Successfully Inserted..";
    }
}

//edit options
 if(isset($_GET['edit'])){
      
      $editId = $_GET['id']; 
      $wp_post_db = "transport_stopage";  
      $show_vendor_posts = $wpdb->get_results("SELECT * FROM $wp_post_db WHERE id='$editId'");  
      foreach( $show_vendor_posts as $show_vendor_posts) 
      {  
        //print_r($show_vendor_posts);
          $stopage_name = $show_vendor_posts->stopage_name;
           $stopage_description = $show_vendor_posts->stopage_description; 
      }
    }
   


?>



<div class="admin_form">
		<div class="crow">
		<div class="col-md-12">
  			<h2 style="color:blue;"><?php if(isset($_POST['add_stopage_submit_btn'])){ echo $msg;  } ?><h2>
  			<h4>Added stopage</h4>  
				<br>
				<br>
	</div>
</div>
   <form method="post" enctype="multipart/form-data">

     
    <div class="form-group crow">
      <label for="colFormLabel" class="col-sm-2 col-form-label">stopage Name</label>
      <div class="col-sm-10">
        <input type="text" class="form-control" id="colFormLabel" name="stopage_name" <?php if(isset($stopage_name)){ ?> value="<?php echo $stopage_name; ?>" <?php } ?>>
      </div>
    </div> 

    <div class="form-group crow">
      <label for="colFormLabelLg" class="col-sm-2 col-form-label col-form-label-lg">stopage Description</label>
      <div class="col-sm-10">
         <textarea name="stopage_description" class="form-control" style="resize:none;height:300px;width:40%;"><?php if(isset($stopage_description)){  echo $stopage_description;  } ?></textarea>
      </div>
    </div>    


<div class="form-group crow">
      <label for="colFormLabelLg" class="col-sm-2 col-form-label col-form-label-lg">Date Time</label>
      <div class="col-sm-10">
          <input type="date" name="added_date"> 
          <input type="time" name="time" >

          <select name="am_pm" style="width:100px;" >
                <option selected="" value="AM"> AM </option>
                <option value="PM"> PM </option>
              </select>
      </div>
    </div>    



   
     
    <div class="form-group crow"> 
      <div class="col-sm-10">
		  <div class="admin_form_submit"> 
       <input type="hidden" name="service_type" value="stopages">
        <input type="submit"  class="btn-primary"   name="add_stopage_submit_btn" >
      </div>
    </div> 
	   </div>

</form>

</div>



 
  <div class="crow"> 
    <div class="col-sm-12">
  <h1>List of transports Stopage</h1>
  <table class="table table-striped table-bordered table-hover" id="dataTables-example">
     
      <thead>
          <tr>   
               <th>Stopage ID</th>
               <th>Stopage Name</th> 
               <th>Stopage Description</th> 
               <th>Added Date</th>
               <th>Action</th>
             </tr>
      </thead>

      <tbody>
      <?php     
        $service_type = 'transports';           
        $wp_post_db = "transport_stopage";  

       /// echo "SELECT * FROM $wp_post_db ORDER BY id DESC";
        global $wpdb;


        $show_vendor_posts = $wpdb->get_results("SELECT * FROM $wp_post_db ORDER BY id DESC"); 
        $i=0;
        foreach( $show_vendor_posts as $show_vendor_post)  
        {   
         // print_r($show_vendor_post);
          $sid             =  $show_vendor_post->id; 
          $stopage_name       =  $show_vendor_post->stopage_name; 
          $stopage_description =  $show_vendor_post->stopage_description;    
          $added_date      =  $show_vendor_post->added_date;
                                                          
        ?>   

         <tr class="odd gradeA">   
            <td><?php echo $sid;?></td> 
            <td><?php echo $stopage_name;?></td>
            <td><?php echo substr($stopage_description, '0', '20');?></td> 
            <td><?php echo $added_date; ?></td>
            <td class="center"> <a class="btn btn-warning" href="?page=add_transport_stopage&id=<?php echo $sid;?>&edit=transport_stopage">Edit</a>

            <a class="btn btn-danger" href="?page=add_transport_stopage&id=<?php echo $sid;?>&delete=transport_stopage">Delete</a>
            </td> 
         </tr>

<?php } ?>  
                
    </tbody>

      <tr>   
               <th>Stopage ID</th>
               <th>Stopage Name</th> 
               <th>Stopage Description</th> 
               <th>Added Date</th>
               <th>Action</th>
             </tr>
</table>
    </div>
</div>



<?php include('footer.php'); ?>


  

   