<div class="wpb_column vc_column_container vc_col-sm-6">
<div class="vc_column-inner vc_custom_1480503285007">
<div class="wpb_wrapper"></div>
</div>
</div>
<div class="wpb_column vc_column_container vc_col-sm-6">
<div class="vc_column-inner vc_custom_1484830876823">
<div class="wpb_wrapper">
<div class="vc_row wpb_row vc_inner vc_row-fluid">
<div class="wpb_column vc_column_container vc_col-sm-12">
<div class="vc_column-inner">
<div class="wpb_wrapper">
<div class="vc_empty_space" style="height: 50px;"></div>
<div id="argenta-custom-5da3659619047" class="heading-wrapper text-left">
<h3 class="second-title text-left">Stylish Portfolio</h3>
</div>
<div class="vc_empty_space" style="height: 5px;"></div>
<div id="argenta-custom-5da3659619237" class="text-wrapper thin-text">

Featured portfolio functionality with masonry grid layout,<br class="vc_hidden-xs" />beautiful animations and flexible settings.

</div>
<div class="vc_empty_space feature-spacer" style="height: 40px;"></div>
</div>
</div>
</div>
</div>
<div class="vc_row wpb_row vc_inner vc_row-fluid vc_row-o-equal-height vc_row-o-content-top vc_row-flex">
<div class="padding-xs-reset arg-hide-border wpb_column vc_column_container vc_col-sm-6 vc_col-has-fill">
<div class="vc_column-inner vc_custom_1485163511695" style="padding-right: 30px; border-right: 1px solid #ddd; border-bottom: 1px solid #ddd; padding-bottom: 30px;">
<div class="wpb_wrapper">
<div class="icon-box-left">
<div class="icon-box-image brand-color brand-border-color"><img src="https://aykormela.com/wp-content/uploads/2019/10/arg_mp_promo_icon16.svg" alt="Masonry Layout" /></div>
<div class="icon-box-wrap-content">
<h3 class="title icon-box-title">Masonry Layout</h3>
<p class="subtitle icon-box-subtitle">Cascading grid library</p>

</div>
<p class="icon-box-description content-full">Great magazine layout for your blog. Customize the columns and the animation of the appearance.</p>

</div>
</div>
</div>
</div>
<div class="padding-xs-reset arg-hide-border wpb_column vc_column_container vc_col-sm-6 vc_col-has-fill">
<div class="vc_column-inner vc_custom_1485163523966" style="padding-right: 30px; padding-left: 30px; border-bottom: 1px solid #ddd;">
<div class="wpb_wrapper">
<div class="icon-box-left">
<div class="icon-box-image brand-color brand-border-color"><img src="https://aykormela.com/wp-content/uploads/2019/10/arg_mp_promo_icon19.svg" alt="Single Project" /></div>
<div class="icon-box-wrap-content">
<h3 class="title icon-box-title">Single Project</h3>
<p class="subtitle icon-box-subtitle">Premade project layouts</p>

</div>
<p class="icon-box-description content-full">Choose one of carefully crafted layouts for your stunning portfolio projects.</p>

</div>
</div>
</div>
</div>
</div>
<div class="vc_row wpb_row vc_inner vc_row-fluid vc_row-o-equal-height vc_row-o-content-top vc_row-flex">
<div class="padding-xs-reset arg-hide-border wpb_column vc_column_container vc_col-sm-6 vc_col-has-fill">
<div class="vc_column-inner vc_custom_1485163528791" style="padding-right: 30px; border-right: 1px solid #ddd;">
<div class="wpb_wrapper">
<div class="icon-box-left">
<div class="icon-box-image brand-color brand-border-color"><img src="https://aykormela.com/wp-content/uploads/2019/10/arg_mp_promo_icon22.svg" alt="Flexible Settings" /></div>
<div class="icon-box-wrap-content">
<h3 class="title icon-box-title">Flexible Settings</h3>
<p class="subtitle icon-box-subtitle">Custom content control</p>

</div>
<p class="icon-box-description content-full">You can customize the appearance and behavior of your projects. Sliders, social sharing, links, etc.</p>

</div>
</div>
</div>
</div>
<div class="padding-xs-reset arg-hide-border wpb_column vc_column_container vc_col-sm-6">
<div class="vc_column-inner vc_custom_1485163533207" style="padding-right: 30px; padding-left: 30px; padding-top: 40px;">
<div class="wpb_wrapper">
<div class="icon-box-left">
<div class="icon-box-image brand-color brand-border-color"><img src="https://aykormela.com/wp-content/uploads/2019/10/arg_mp_promo_icon26.svg" alt="Popup Preview" /></div>
<div class="icon-box-wrap-content">
<h3 class="title icon-box-title">Popup Preview</h3>
<p class="subtitle icon-box-subtitle">Quick project preview</p>

</div>
<p class="icon-box-description content-full">Stylish appearance of your projects in the popup window. This preview can be enabled in shortcodes.</p>

</div>
</div>
</div>
</div>
</div>


<div class="padding-xs-reset arg-hide-border wpb_column vc_column_container vc_col-sm-12">
<div class="vc_column-inner vc_custom_1485163533207" style="padding-right: 30px; padding-left: 30px; padding-top: 30px;">
<div class="wpb_wrapper">
<div class="icon-box-left">
<div class="icon-box-image brand-color brand-border-color"><img src="https://aykormela.com/wp-content/uploads/2019/10/arg_mp_promo_icon26.svg" alt="Popup Preview" /></div>
<div class="icon-box-wrap-content">
<h3 class="title icon-box-title">Popup Preview2</h3>
<p class="subtitle icon-box-subtitle">Quick project preview</p>

</div>
<p class="icon-box-description content-full">Stylish appearance of your projects in the popup window. This preview can be enabled in shortcodes.</p>

</div>
</div>
</div>
</div>
</div>



<div class="vc_empty_space arg-spacer arg-spacer-huge vc_hidden-xs" style="height: 120px;"></div>
<div class="vc_empty_space arg-spacer" style="height: 90px;"></div>
</div>
</div>
</div>