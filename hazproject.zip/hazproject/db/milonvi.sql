-- phpMyAdmin SQL Dump
-- version 4.8.0.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Oct 08, 2019 at 10:10 PM
-- Server version: 10.1.32-MariaDB
-- PHP Version: 7.2.5

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `milonvi`
--

-- --------------------------------------------------------

--
-- Table structure for table `activity_activities`
--

CREATE TABLE `activity_activities` (
  `id` int(11) NOT NULL,
  `activity_id` int(11) NOT NULL,
  `activity_name` varchar(100) NOT NULL,
  `activity_description` varchar(500) NOT NULL,
  `service_type` varchar(100) NOT NULL,
  `status` int(2) NOT NULL DEFAULT '0',
  `added_date` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `activity_categories`
--

CREATE TABLE `activity_categories` (
  `id` int(11) NOT NULL,
  `category_name` varchar(100) NOT NULL,
  `category_description` varchar(500) NOT NULL,
  `status` int(2) NOT NULL DEFAULT '0',
  `added_date` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `activity_details`
--

CREATE TABLE `activity_details` (
  `id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `total_activity` int(11) NOT NULL,
  `category_id` int(11) NOT NULL,
  `activity_type` int(11) NOT NULL,
  `activity_title` varchar(100) NOT NULL,
  `activity_description` text NOT NULL,
  `activity_image` varchar(255) NOT NULL,
  `activity_check_in` varchar(63) NOT NULL,
  `activity_check_out` varchar(63) NOT NULL,
  `activity_location` varchar(111) NOT NULL,
  `activity_email` varchar(63) NOT NULL,
  `activity_phone_no` varchar(111) NOT NULL,
  `activity_price` varchar(111) NOT NULL,
  `video` varchar(500) NOT NULL,
  `date_added` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `available_rooms`
--

CREATE TABLE `available_rooms` (
  `id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `hotel_id` int(11) NOT NULL,
  `total_room` int(11) NOT NULL,
  `room_title` varchar(100) NOT NULL,
  `room_description` text NOT NULL,
  `room_image` varchar(255) NOT NULL,
  `room_check_in` varchar(63) NOT NULL,
  `room_check_out` varchar(63) NOT NULL,
  `room_location` varchar(111) NOT NULL,
  `room_email` varchar(63) NOT NULL,
  `room_phone_no` varchar(111) NOT NULL,
  `room_price` varchar(111) NOT NULL,
  `date_added` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `available_rooms`
--

INSERT INTO `available_rooms` (`id`, `user_id`, `hotel_id`, `total_room`, `room_title`, `room_description`, `room_image`, `room_check_in`, `room_check_out`, `room_location`, `room_email`, `room_phone_no`, `room_price`, `date_added`) VALUES
(2, 1, 1, 10, 'aaaa', 'sssssss', '', '2019-06-15', '2019-06-14', '', 'm.rabiul09@gmail.com', '01717677966', '3333', '2019-06-24 16:09:07'),
(3, 1, 1, 10, 'bbbbb', 'ssssssss', '', '2015-08-05', '2019-06-14', '', 'm.rabiul09@gmail.com', '01717677966', '3333', '2019-06-27 15:02:36'),
(4, 1, 2, 10, 'ccccc', 'radison room type  radison room type  radison room type  radison room type  radison room type  radison room type  radison room type  radison room type  radison room type  radison room type  radison room type  radison room type  radison room type  radison room type  radison room type  radison room type  radison room type  radison room type  radison room type  ', '', '2019-06-22', '2019-06-29', '', 'm.rabiul09@gmail.com', '01717677966', '3333', '2019-06-30 16:04:11'),
(5, 1, 4, 8, 'ddddd', 'radison hotel2 radison hotel2 radison hotel2 radison hotel2 radison hotel2 ', '', '2019-06-21', '2019-06-25', '', 'm.rabiul09@gmail.com', '01717677966', '3333', '2019-06-30 16:29:25'),
(6, 1, 49, 10, 'ss', 'sss', '', '2019-07-08', '2019-07-19', '', 'm.rabiul09@gmail.com', '01717677966', '3333', '2019-07-21 16:55:44');

-- --------------------------------------------------------

--
-- Table structure for table `booking_info`
--

CREATE TABLE `booking_info` (
  `id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `post_id` int(11) NOT NULL,
  `u_city` varchar(255) NOT NULL,
  `u_bed` varchar(111) NOT NULL,
  `u_adults` varchar(11) NOT NULL,
  `u_name` varchar(255) NOT NULL,
  `u_children` varchar(111) NOT NULL,
  `u_infants` varchar(111) NOT NULL,
  `u_lname` varchar(111) NOT NULL,
  `u_cell` varchar(111) NOT NULL,
  `u_email` varchar(111) NOT NULL,
  `u_address` varchar(111) NOT NULL,
  `u_ucity` varchar(111) NOT NULL,
  `u_comments` varchar(111) NOT NULL,
  `date_added` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `car_details`
--

CREATE TABLE `car_details` (
  `id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `total_car` int(11) NOT NULL,
  `package_id` int(11) NOT NULL,
  `car_title` varchar(100) NOT NULL,
  `car_description` text NOT NULL,
  `car_image` varchar(255) NOT NULL,
  `car_check_in` varchar(63) NOT NULL,
  `car_check_out` varchar(63) NOT NULL,
  `car_location` varchar(111) NOT NULL,
  `car_email` varchar(63) NOT NULL,
  `car_phone_no` varchar(111) NOT NULL,
  `car_price` varchar(111) NOT NULL,
  `date_added` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `car_details`
--

INSERT INTO `car_details` (`id`, `user_id`, `total_car`, `package_id`, `car_title`, `car_description`, `car_image`, `car_check_in`, `car_check_out`, `car_location`, `car_email`, `car_phone_no`, `car_price`, `date_added`) VALUES
(2, 0, 0, 0, 'qqqqqqqqqqqq', '', '', '', '', 'Dinajpur', 'm.rabiul09@gmail.com', '', '', '2019-07-08 17:29:06'),
(3, 0, 0, 0, 'qqqqqqqqqqqq', '', '', '', '', 'Fulbari', '', '', '', '2019-07-08 17:34:01'),
(4, 1, 0, 6, '', 'aaa', '', '', '', 'dhaka', 'm.rabiul09@gmail.com', '01717677966', '121212', '2019-07-21 16:17:55'),
(5, 1, 21212, 5, '', 'Banglamotor\r\nKawran Bazar', '', '', '', 'rtrtrt', 'm.rabiul09@gmail.com', '01717677966', '121212', '2019-07-21 16:20:13'),
(6, 1, 21212, 5, '', 'rrrrrrrrrrrr', '', '', '', 'rrrrr', 'm.rabiul09@gmail.com', '01717677966', '121212', '2019-07-21 16:22:38'),
(7, 1, 21212, 6, '', 'tttttttttt', '', '', '', 'qqqqqqq', 'm.rabiul09@gmail.com', '01717677966', '121212', '2019-07-21 16:26:23'),
(8, 1, 21212, 6, '', 'sss', '', '', '', 'dhaka', 'm.rabiul09@gmail.com', '01717677966', '121212', '2019-07-21 16:36:14'),
(9, 1, 21212, 6, '', 'yyyy', '', '', '', 'dhaka', 'm.rabiul09@gmail.com', '01717677966', '121212', '2019-07-21 16:38:28'),
(10, 1, 21212, 6, '', 'yyyy', '', '', '', 'dhaka', 'm.rabiul09@gmail.com', '01717677966', '121212', '2019-07-21 16:40:40'),
(11, 1, 21212, 6, 'asasasas', 'yyyy', '', '', '', 'dhaka', 'm.rabiul09@gmail.com', '01717677966', '121212', '2019-07-21 16:42:47');

-- --------------------------------------------------------

--
-- Table structure for table `car_packages`
--

CREATE TABLE `car_packages` (
  `id` int(11) NOT NULL,
  `package_name` varchar(100) NOT NULL,
  `package_description` varchar(500) NOT NULL,
  `service_type` varchar(100) NOT NULL,
  `package_price` int(10) NOT NULL,
  `status` int(2) NOT NULL DEFAULT '0',
  `added_date` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `car_packages`
--

INSERT INTO `car_packages` (`id`, `package_name`, `package_description`, `service_type`, `package_price`, `status`, `added_date`) VALUES
(1, 'CAr Package 1', '', 'car', 600, 0, '2019-07-10 18:34:54'),
(2, 'Car Package 2', '', 'car', 500, 0, '2019-07-10 18:34:48'),
(3, 'aaaaaaaaaaa', 'bbbbbbbbbb', 'aaaaaaaaaaaa', 400, 0, '2019-07-10 18:34:58'),
(4, 'ttttttttttt', '', '', 0, 0, '2019-07-08 17:06:36'),
(5, 'aaa', 'aaaaaa', '', 0, 0, '2019-07-08 17:07:17'),
(6, 'qqq', 'qqqqqqqqqqqqqqqqqq', 'cars', 0, 0, '2019-07-08 17:08:01'),
(7, 'eeee', 'eeeeeeeee', 'cars', 0, 0, '2019-07-08 17:08:44');

-- --------------------------------------------------------

--
-- Table structure for table `city_list`
--

CREATE TABLE `city_list` (
  `id` int(11) NOT NULL,
  `city_name` varchar(100) NOT NULL,
  `service_type` varchar(100) NOT NULL,
  `status` int(2) NOT NULL DEFAULT '0',
  `added_date` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `city_list`
--

INSERT INTO `city_list` (`id`, `city_name`, `service_type`, `status`, `added_date`) VALUES
(1, 'Dhaka', 'cars', 0, '2019-10-04 15:44:26');

-- --------------------------------------------------------

--
-- Table structure for table `guide_categories`
--

CREATE TABLE `guide_categories` (
  `id` int(11) NOT NULL,
  `category_name` varchar(100) NOT NULL,
  `category_description` varchar(500) NOT NULL,
  `status` int(2) NOT NULL DEFAULT '0',
  `added_date` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `guide_categories`
--

INSERT INTO `guide_categories` (`id`, `category_name`, `category_description`, `status`, `added_date`) VALUES
(1, 'Guide Category 1 ', 'Tour Category 1 Tour Category 1 Tour Category 1 Tour Category 1 Tour Category 1 Tour Category 1 Tour Category 1 Tour Category 1 Tour Category 1 Tour Category 1 Tour Category 1 Tour Category 1 Tour Category 1 Tour Category 1 Tour Category 1 Tour Category 1 Tour Category 1 Tour Category 1 ', 0, '2019-07-25 19:45:13'),
(2, 'Guide  Categiry 2 ', 'Tour Categiry 2 Tour Categiry 2 Tour Categiry 2 Tour Categiry 2 Tour Categiry 2 Tour Categiry 2 Tour Categiry 2 Tour Categiry 2 Tour Categiry 2 Tour Categiry 2 Tour Categiry 2 Tour Categiry 2 Tour Categiry 2 Tour Categiry 2 Tour Categiry 2 ', 0, '2019-07-25 19:45:18'),
(3, 'gude name ', 'gude name gude name gude name gude name gude name gude name gude name gude name gude name gude name gude name gude name gude name gude name gude name gude name gude name gude name gude name gude name gude name gude name gude name gude name gude name gude name gude name gude name gude name gude name gude name gude name ', 0, '2019-07-25 16:33:45');

-- --------------------------------------------------------

--
-- Table structure for table `guide_details`
--

CREATE TABLE `guide_details` (
  `id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `total_guide` int(11) NOT NULL,
  `category_id` int(11) NOT NULL,
  `guide_type` int(11) NOT NULL,
  `guide_title` varchar(100) NOT NULL,
  `guide_description` text NOT NULL,
  `guide_image` varchar(255) NOT NULL,
  `guide_check_in` varchar(63) NOT NULL,
  `guide_check_out` varchar(63) NOT NULL,
  `guide_location` varchar(111) NOT NULL,
  `guide_email` varchar(63) NOT NULL,
  `guide_phone_no` varchar(111) NOT NULL,
  `guide_price` varchar(111) NOT NULL,
  `video` varchar(500) NOT NULL,
  `date_added` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `guide_packages`
--

CREATE TABLE `guide_packages` (
  `id` int(11) NOT NULL,
  `guide_id` int(11) NOT NULL,
  `package_name` varchar(100) NOT NULL,
  `package_description` varchar(500) NOT NULL,
  `service_type` varchar(100) NOT NULL,
  `status` int(2) NOT NULL DEFAULT '0',
  `added_date` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `hotel_details`
--

CREATE TABLE `hotel_details` (
  `id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `hotel_id` int(11) NOT NULL,
  `hotel_title` varchar(100) NOT NULL,
  `hotel_description` text NOT NULL,
  `hotel_image` varchar(255) NOT NULL,
  `hotel_check_in` varchar(63) NOT NULL,
  `hotel_check_out` varchar(63) NOT NULL,
  `hotel_location` varchar(111) NOT NULL,
  `hotel_email` varchar(63) NOT NULL,
  `hotel_phone_no` varchar(111) NOT NULL,
  `hotel_price` varchar(111) NOT NULL,
  `hotel_website` varchar(111) NOT NULL,
  `hotel_cancelled_repayment` text NOT NULL,
  `hotel_children_and_extrabed` varchar(111) NOT NULL,
  `hotel_pets` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `hotel_details`
--

INSERT INTO `hotel_details` (`id`, `user_id`, `hotel_id`, `hotel_title`, `hotel_description`, `hotel_image`, `hotel_check_in`, `hotel_check_out`, `hotel_location`, `hotel_email`, `hotel_phone_no`, `hotel_price`, `hotel_website`, `hotel_cancelled_repayment`, `hotel_children_and_extrabed`, `hotel_pets`) VALUES
(6, 1, 0, 'qqqqqqqqqqqqqqqqqqqq', 'qqqqqqqqqqqqqqqqqqqq', '', '2019-07-13', '2019-07-13', 'aaa', 'm.rabiul09@gmail.com', '01717677966', '2323', 'wewewe', 'aaa', 'wewew', ''),
(7, 1, 0, 'zzzzzzzzz', 'zzzzzzzzzz', '', '2019-07-25', '2019-07-25', 'aaa', 'm.rabiul09@gmail.com', '01717677966', '4444', 'wewewe', 'aaa', 'wewew', ''),
(8, 1, 0, 'm.rabiul09@gmail.com', 'aaaaaaaaaaaaaaaaaaaaaaaaaa', '', '2019-07-18', '2019-07-27', 'dhaka', 'm.rabiul09@gmail.com', '01717677966', '2323', 'wewewe', 'aaaaaaa', 'wewew', ''),
(9, 1, 0, 'ssss', 'sssssss', '', '2019-07-12', '2019-07-18', 'dhaka', 'm.rabiul09@gmail.com', '01717677966', '2323', 'wewewe', 'aaaaaaa', 'wewew', ''),
(10, 1, 0, 'sss', 'ssssssssss', '', '2019-07-17', '2019-07-13', 'dhaka', 'm.rabiul09@gmail.com', '01717677966', '2323', '2222', 'aaaaaaa', '2222', ''),
(11, 1, 0, 'sss', 'sdsd', '', '2019-07-18', '2019-07-27', 'dhaka', 'm.rabiul09@gmail.com', '01717677966', '2323', '2222', 'aaaaaaa', 'wewew', ''),
(12, 1, 0, 'wp_post_db', 'wp_post_db', '', '2019-07-18', '2019-07-26', 'dhaka', 'm.rabiul09@gmail.com', '01717677966', '2323', 'wewewe', 'aaa', 'wewew', ''),
(13, 1, 0, 'aaaaaaaaaaa', 'aaaaaa', '', '2019-07-18', '2019-07-27', 'dhaka', 'm.rabiul09@gmail.com', '01717677966', '2323', 'wewewe', 'aaa', 'wewew', ''),
(15, 1, 0, 'asasas', 'asasas', '', '2019-07-19', '2019-07-18', 'dhaka', 'm.rabiul09@gmail.com', '01717677966', '2323', 'wewewe', 'aaaaaaa', 'wewew', ''),
(16, 1, 0, 'aaa', 'aaa', '', '2019-07-18', '2019-07-26', 'dhaka', 'm.rabiul09@gmail.com', '01717677966', '2323', 'wewewe', 'aaa', 'wewew', ''),
(17, 1, 0, 'aaaaaaaa', 'aaaaaaaaaa', '', '2019-07-26', '2019-07-16', 'dhaka', 'm.rabiul09@gmail.com', '01717677966', '2323', 'wewewe', 'aaa', 'wewew', ''),
(18, 1, 0, 'aaaaaaaa', 'aaaaaaaaaa', '', '2019-07-26', '2019-07-16', 'dhaka', 'm.rabiul09@gmail.com', '01717677966', '2323', 'wewewe', 'aaa', 'wewew', ''),
(19, 1, 0, 'aaaaaaaa', 'aaaaaaaaaa', '', '2019-07-26', '2019-07-16', 'dhaka', 'm.rabiul09@gmail.com', '01717677966', '2323', 'wewewe', 'aaa', 'wewew', ''),
(21, 1, 0, 'bbbbbbbbbbb', 'bbbbbbbbbbbbbbbbbbb', '', '2019-07-26', '2019-07-16', 'dhaka', 'm.rabiul09@gmail.com', '01717677966', '2323', 'wewewe', 'aaa', 'wewew', ''),
(22, 1, 0, 'bbbbbbbbbbb', 'bbbbbbbbbbbbbbbbbbb', '', '2019-07-26', '2019-07-16', 'dhaka', 'm.rabiul09@gmail.com', '01717677966', '2323', 'wewewe', 'aaa', 'wewew', ''),
(23, 1, 0, 'bbbbbbbbbbb', 'bbbbbbbbbbbbbbbbbbb', '', '2019-07-26', '2019-07-16', 'dhaka', 'm.rabiul09@gmail.com', '01717677966', '2323', 'wewewe', 'aaa', 'wewew', ''),
(24, 1, 0, 'www', 'www', '', '2019-07-19', '2019-07-19', 'dhaka', 'm.rabiul09@gmail.com', '01717677966', '2323', 'wewewe', 'aaa', 'wewew', ''),
(25, 1, 0, 'aaaaaaaa', 'aaaaaaaa', '', '2019-07-19', '2019-07-17', 'dhaka', 'm.rabiul09@gmail.com', '01717677966', '2323', 'wewewe', 'aaa', 'wewew', ''),
(26, 1, 0, 'aaaaaaaa', 'aaaaaaaa', '', '2019-07-19', '2019-07-17', 'dhaka', 'm.rabiul09@gmail.com', '01717677966', '2323', 'wewewe', 'aaa', 'wewew', ''),
(27, 1, 0, 'aaaaaaaa', 'aaaaaaaa', '', '2019-07-19', '2019-07-17', 'dhaka', 'm.rabiul09@gmail.com', '01717677966', '2323', 'wewewe', 'aaa', 'wewew', ''),
(28, 1, 0, 'aaaaaaaa', 'aaaaaaaa', '', '2019-07-19', '2019-07-17', 'dhaka', 'm.rabiul09@gmail.com', '01717677966', '2323', 'wewewe', 'aaa', 'wewew', ''),
(29, 1, 0, 'aaaaaaaa', 'aaaaaaaa', '', '2019-07-19', '2019-07-17', 'dhaka', 'm.rabiul09@gmail.com', '01717677966', '2323', 'wewewe', 'aaa', 'wewew', ''),
(30, 1, 0, 'aaaaaaaa', 'aaaaaaaa', '', '2019-07-19', '2019-07-17', 'dhaka', 'm.rabiul09@gmail.com', '01717677966', '2323', 'wewewe', 'aaa', 'wewew', ''),
(31, 1, 0, 'aaaaaaaa', 'aaaaaaaa', '', '2019-07-19', '2019-07-17', 'dhaka', 'm.rabiul09@gmail.com', '01717677966', '2323', 'wewewe', 'aaa', 'wewew', ''),
(32, 1, 0, 'aaaaaaaa', 'aaaaaaaa', '', '2019-07-19', '2019-07-17', 'dhaka', 'm.rabiul09@gmail.com', '01717677966', '2323', 'wewewe', 'aaa', 'wewew', ''),
(33, 1, 0, 'aaaaaaaa', 'aaaaaaaa', '', '2019-07-19', '2019-07-17', 'dhaka', 'm.rabiul09@gmail.com', '01717677966', '2323', 'wewewe', 'aaa', 'wewew', ''),
(34, 1, 0, 'aaaaaaaa', 'aaaaaaaa', '', '2019-07-19', '2019-07-17', 'dhaka', 'm.rabiul09@gmail.com', '01717677966', '2323', 'wewewe', 'aaa', 'wewew', ''),
(35, 1, 0, 'asas', 'asas', '', '2019-07-12', '2019-07-18', 'dhaka', 'm.rabiul09@gmail.com', '01717677966', '2323', '2222', 'aaa', 'wewew', ''),
(36, 1, 0, 'asas', 'asas', '', '2019-07-12', '2019-07-18', 'dhaka', 'm.rabiul09@gmail.com', '01717677966', '2323', '2222', 'aaa', 'wewew', ''),
(37, 1, 0, 'asas', 'asas', '', '2019-07-12', '2019-07-18', 'dhaka', 'm.rabiul09@gmail.com', '01717677966', '2323', '2222', 'aaa', 'wewew', ''),
(38, 1, 0, 'asasa', 'asasa', '', '2019-07-12', '2019-07-20', 'dhaka', 'm.rabiul09@gmail.com', '01717677966', '2323', 'wewewe', 'aaa', '2323', ''),
(39, 1, 0, 'asasa', 'asasa', '', '2019-07-12', '2019-07-20', 'dhaka', 'm.rabiul09@gmail.com', '01717677966', '2323', 'wewewe', 'aaa', '2323', ''),
(40, 1, 0, 'asasa', 'asasa', '', '2019-07-12', '2019-07-20', 'dhaka', 'm.rabiul09@gmail.com', '01717677966', '2323', 'wewewe', 'aaa', '2323', ''),
(41, 1, 0, 'asasa', 'asasa', '', '2019-07-12', '2019-07-20', 'dhaka', 'm.rabiul09@gmail.com', '01717677966', '2323', 'wewewe', 'aaa', '2323', ''),
(42, 1, 0, 'asasa', 'asasa', '', '2019-07-12', '2019-07-20', 'dhaka', 'm.rabiul09@gmail.com', '01717677966', '2323', 'wewewe', 'aaa', '2323', ''),
(43, 1, 0, 'asasa', 'asasa', '', '2019-07-12', '2019-07-20', 'dhaka', 'm.rabiul09@gmail.com', '01717677966', '2323', 'wewewe', 'aaa', '2323', ''),
(44, 1, 0, 'asasa', 'asasa', '', '2019-07-12', '2019-07-20', 'dhaka', 'm.rabiul09@gmail.com', '01717677966', '2323', 'wewewe', 'aaa', '2323', ''),
(45, 1, 0, 'asasa', 'asasa', '', '2019-07-12', '2019-07-20', 'dhaka', 'm.rabiul09@gmail.com', '01717677966', '2323', 'wewewe', 'aaa', '2323', ''),
(46, 1, 0, 'asasa', 'asasa', '', '2019-07-12', '2019-07-20', 'dhaka', 'm.rabiul09@gmail.com', '01717677966', '2323', 'wewewe', 'aaa', '2323', ''),
(47, 1, 0, 'asasa', 'asasa', '', '2019-07-12', '2019-07-20', 'dhaka', 'm.rabiul09@gmail.com', '01717677966', '2323', 'wewewe', 'aaa', '2323', ''),
(48, 1, 0, 'asasa', 'asasa', '', '2019-07-12', '2019-07-20', 'dhaka', 'm.rabiul09@gmail.com', '01717677966', '2323', 'wewewe', 'aaa', '2323', ''),
(49, 1, 0, 'asasa', 'asasa', '', '2019-07-12', '2019-07-20', 'dhaka', 'm.rabiul09@gmail.com', '01717677966', '2323', 'wewewe', 'aaa', '2323', ''),
(50, 1, 0, '3203.', '663\r\n', '', '2019-07-11', '2019-07-18', '', '', '', '', '', 'wewe', '', ''),
(51, 1, 0, '3203.', '663\r\n', '', '2019-07-11', '2019-07-18', '', '', '', '', '', 'wewe', '', ''),
(52, 1, 0, '3203.', '663\r\n', '', '2019-07-11', '2019-07-18', '', '', '', '', '', 'wewe', '', ''),
(53, 1, 0, '3203.', '663\r\n', '', '2019-07-11', '2019-07-18', '', '', '', '', '', 'wewe', '', ''),
(54, 1, 0, 'fgfg', 'fgff', '', '2019-07-11', '2019-07-13', ' 8', 'm.rabiul09@gmail.com', '01717677966', '2323', 'wewewe', 'aaa   ', 'no', ''),
(55, 1, 0, 'fgfg', 'fgff', '', '2019-07-11', '2019-07-13', ' 8', 'm.rabiul09@gmail.com', '01717677966', '2323', 'wewewe', 'aaa   ', 'no', ''),
(56, 1, 0, '33333333', '33333333333', '', '2019-07-19', '2019-07-26', 'dhaka', 'm.rabiul09@gmail.com', '01717677966', '2323', 'wewewe', 'aaa', 'wewew', '');

-- --------------------------------------------------------

--
-- Table structure for table `hotel_offers`
--

CREATE TABLE `hotel_offers` (
  `id` int(11) NOT NULL,
  `service_name` varchar(500) NOT NULL,
  `service_img` varchar(100) NOT NULL,
  `status` int(2) NOT NULL DEFAULT '0',
  `added_date` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `hotel_offers`
--

INSERT INTO `hotel_offers` (`id`, `service_name`, `service_img`, `status`, `added_date`) VALUES
(1, 'Airport Transport', 'Shuttle Bus Service.jpg', 0, '2019-07-18 16:54:55'),
(2, 'Shuttle Bus Service', 'Restaurant.jpg', 0, '2019-07-18 16:55:07'),
(3, 'Wi-Fi Internet', 'Wi-Fi Internet.jpg', 0, '2019-07-18 16:55:07'),
(4, 'Shuttle Bus Service', 'Wi-Fi Internet.jpg', 0, '2019-07-18 16:55:07'),
(5, 'Outdoor pool (all year)', 'Shuttle Bus Service.jpg', 0, '2019-07-18 16:54:55'),
(6, 'Shuttle Bus Service', 'Restaurant.jpg', 0, '2019-07-18 16:55:07'),
(7, 'Wi-Fi Internet', 'Wi-Fi Internet.jpg', 0, '2019-07-18 16:55:07'),
(8, 'Shuttle Bus Service', 'Wi-Fi Internet.jpg', 0, '2019-07-18 16:55:07'),
(9, 'Bathrobe', 'Shuttle Bus Service.jpg', 0, '2019-07-18 16:54:55');

-- --------------------------------------------------------

--
-- Table structure for table `hotel_offers_relation`
--

CREATE TABLE `hotel_offers_relation` (
  `id` int(11) NOT NULL,
  `hotel_id` int(11) NOT NULL,
  `service_id` int(11) NOT NULL,
  `service_type` varchar(100) NOT NULL,
  `status` int(2) NOT NULL DEFAULT '0',
  `added_date` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `hotel_offers_relation`
--

INSERT INTO `hotel_offers_relation` (`id`, `hotel_id`, `service_id`, `service_type`, `status`, `added_date`) VALUES
(1, 2, 1, 'hotels', 0, '2019-07-18 18:34:10'),
(2, 2, 2, 'hotels', 0, '2019-07-18 18:34:07'),
(3, 2, 4, 'hotels', 0, '2019-07-18 18:34:18'),
(4, 1, 1, '', 0, '2019-06-23 18:50:56'),
(5, 1, 0, 'rooms', 0, '2019-06-24 16:03:30'),
(6, 1, 2, 'rooms', 0, '2019-07-23 18:47:59'),
(7, 1, 2, 'rooms', 0, '2019-07-23 18:48:06'),
(8, 4, 1, 'rooms', 0, '2019-07-23 18:49:44'),
(9, 1, 1, 'rooms', 0, '2019-06-30 16:04:12'),
(10, 1, 1, 'rooms', 0, '2019-06-30 16:04:13'),
(11, 1, 1, 'rooms', 0, '2019-06-30 16:29:25'),
(12, 1, 1, 'rooms', 0, '2019-06-30 16:29:25'),
(14, 5, 5, 'hotels', 0, '2019-07-18 19:20:55'),
(15, 5, 5, 'hotels', 0, '2019-07-18 19:20:55'),
(16, 5, 5, 'hotels', 0, '2019-07-18 19:20:55'),
(17, 6, 6, 'hotels', 0, '2019-07-18 19:30:02'),
(18, 6, 6, 'hotels', 0, '2019-07-18 19:30:02'),
(19, 6, 6, 'hotels', 0, '2019-07-18 19:30:02'),
(20, 7, 7, 'hotels', 0, '2019-07-18 19:38:43'),
(21, 7, 7, 'hotels', 0, '2019-07-18 19:38:44'),
(22, 8, 8, 'hotels', 0, '2019-07-18 19:48:52'),
(23, 8, 8, 'hotels', 0, '2019-07-18 19:48:53'),
(24, 9, 9, 'hotels', 0, '2019-07-18 19:52:48'),
(25, 9, 9, 'hotels', 0, '2019-07-18 19:52:49'),
(26, 9, 9, 'hotels', 0, '2019-07-18 19:52:49'),
(27, 10, 10, 'hotels', 0, '2019-07-18 19:55:29'),
(28, 10, 10, 'hotels', 0, '2019-07-18 19:55:29'),
(29, 10, 10, 'hotels', 0, '2019-07-18 19:55:29'),
(30, 11, 11, 'hotels', 0, '2019-07-18 19:57:46'),
(31, 11, 11, 'hotels', 0, '2019-07-18 19:57:47'),
(32, 11, 11, 'hotels', 0, '2019-07-18 19:57:47'),
(33, 12, 12, 'hotels', 0, '2019-07-19 18:43:10'),
(34, 12, 12, 'hotels', 0, '2019-07-19 18:43:10'),
(35, 13, 13, 'hotels', 0, '2019-07-19 18:46:54'),
(36, 13, 13, 'hotels', 0, '2019-07-19 18:46:54'),
(37, 13, 13, 'hotels', 0, '2019-07-19 18:46:54'),
(38, 13, 13, 'hotels', 0, '2019-07-19 18:46:54'),
(39, 14, 14, 'hotels', 0, '2019-07-19 19:40:52'),
(40, 14, 14, 'hotels', 0, '2019-07-19 19:40:52'),
(41, 14, 14, 'hotels', 0, '2019-07-19 19:40:52'),
(42, 14, 14, 'hotels', 0, '2019-07-19 19:40:52'),
(43, 14, 14, 'hotels', 0, '2019-07-19 19:40:52'),
(44, 15, 15, 'hotels', 0, '2019-07-19 19:44:05'),
(45, 15, 15, 'hotels', 0, '2019-07-19 19:44:05'),
(46, 15, 15, 'hotels', 0, '2019-07-19 19:44:05'),
(47, 16, 16, 'hotels', 0, '2019-07-19 19:48:26'),
(48, 16, 16, 'hotels', 0, '2019-07-19 19:48:26'),
(49, 16, 16, 'hotels', 0, '2019-07-19 19:48:26'),
(50, 16, 16, 'hotels', 0, '2019-07-19 19:48:26'),
(51, 16, 16, 'hotels', 0, '2019-07-19 19:48:26'),
(52, 17, 17, 'hotels', 0, '2019-07-21 14:55:26'),
(53, 17, 17, 'hotels', 0, '2019-07-21 14:55:26'),
(54, 18, 18, 'hotels', 0, '2019-07-21 14:56:29'),
(55, 18, 18, 'hotels', 0, '2019-07-21 14:56:29'),
(56, 19, 19, 'hotels', 0, '2019-07-21 14:56:54'),
(57, 19, 19, 'hotels', 0, '2019-07-21 14:56:54'),
(58, 20, 20, 'hotels', 0, '2019-07-21 14:58:27'),
(59, 20, 20, 'hotels', 0, '2019-07-21 14:58:27'),
(60, 21, 21, 'hotels', 0, '2019-07-21 14:59:04'),
(61, 21, 21, 'hotels', 0, '2019-07-21 14:59:04'),
(62, 21, 21, 'hotels', 0, '2019-07-21 14:59:04'),
(63, 22, 22, 'hotels', 0, '2019-07-21 14:59:16'),
(64, 22, 22, 'hotels', 0, '2019-07-21 14:59:16'),
(65, 22, 22, 'hotels', 0, '2019-07-21 14:59:16'),
(66, 23, 23, 'hotels', 0, '2019-07-21 15:00:20'),
(67, 23, 23, 'hotels', 0, '2019-07-21 15:00:20'),
(68, 23, 23, 'hotels', 0, '2019-07-21 15:00:20'),
(69, 23, 23, 'hotels', 0, '2019-07-21 15:00:20'),
(70, 24, 24, 'hotels', 0, '2019-07-21 15:28:32'),
(71, 24, 24, 'hotels', 0, '2019-07-21 15:28:32'),
(72, 25, 25, 'hotels', 0, '2019-07-21 15:37:15'),
(73, 25, 25, 'hotels', 0, '2019-07-21 15:37:16'),
(74, 25, 25, 'hotels', 0, '2019-07-21 15:37:16'),
(75, 25, 25, 'hotels', 0, '2019-07-21 15:37:16'),
(76, 26, 26, 'hotels', 0, '2019-07-21 15:37:18'),
(77, 26, 26, 'hotels', 0, '2019-07-21 15:37:18'),
(78, 26, 26, 'hotels', 0, '2019-07-21 15:37:18'),
(79, 26, 26, 'hotels', 0, '2019-07-21 15:37:18'),
(80, 27, 27, 'hotels', 0, '2019-07-21 15:37:21'),
(81, 27, 27, 'hotels', 0, '2019-07-21 15:37:21'),
(82, 27, 27, 'hotels', 0, '2019-07-21 15:37:21'),
(83, 27, 27, 'hotels', 0, '2019-07-21 15:37:21'),
(84, 28, 28, 'hotels', 0, '2019-07-21 15:37:23'),
(85, 28, 28, 'hotels', 0, '2019-07-21 15:37:23'),
(86, 28, 28, 'hotels', 0, '2019-07-21 15:37:24'),
(87, 28, 28, 'hotels', 0, '2019-07-21 15:37:24'),
(88, 29, 29, 'hotels', 0, '2019-07-21 15:37:36'),
(89, 29, 29, 'hotels', 0, '2019-07-21 15:37:36'),
(90, 29, 29, 'hotels', 0, '2019-07-21 15:37:36'),
(91, 29, 29, 'hotels', 0, '2019-07-21 15:37:36'),
(92, 30, 30, 'hotels', 0, '2019-07-21 15:37:39'),
(93, 30, 30, 'hotels', 0, '2019-07-21 15:37:39'),
(94, 30, 30, 'hotels', 0, '2019-07-21 15:37:39'),
(95, 30, 30, 'hotels', 0, '2019-07-21 15:37:39'),
(96, 31, 31, 'hotels', 0, '2019-07-21 15:38:13'),
(97, 31, 31, 'hotels', 0, '2019-07-21 15:38:13'),
(98, 31, 31, 'hotels', 0, '2019-07-21 15:38:13'),
(99, 31, 31, 'hotels', 0, '2019-07-21 15:38:13'),
(100, 32, 32, 'hotels', 0, '2019-07-21 15:38:15'),
(101, 32, 32, 'hotels', 0, '2019-07-21 15:38:15'),
(102, 32, 32, 'hotels', 0, '2019-07-21 15:38:15'),
(103, 32, 32, 'hotels', 0, '2019-07-21 15:38:15'),
(104, 33, 33, 'hotels', 0, '2019-07-21 15:38:17'),
(105, 33, 33, 'hotels', 0, '2019-07-21 15:38:17'),
(106, 33, 33, 'hotels', 0, '2019-07-21 15:38:17'),
(107, 33, 33, 'hotels', 0, '2019-07-21 15:38:17'),
(108, 34, 34, 'hotels', 0, '2019-07-21 15:38:19'),
(109, 34, 34, 'hotels', 0, '2019-07-21 15:38:19'),
(110, 34, 34, 'hotels', 0, '2019-07-21 15:38:19'),
(111, 34, 34, 'hotels', 0, '2019-07-21 15:38:19'),
(112, 35, 35, 'hotels', 0, '2019-07-21 15:39:29'),
(113, 35, 35, 'hotels', 0, '2019-07-21 15:39:29'),
(114, 36, 36, 'hotels', 0, '2019-07-21 15:39:31'),
(115, 36, 36, 'hotels', 0, '2019-07-21 15:39:31'),
(116, 37, 37, 'hotels', 0, '2019-07-21 15:39:34'),
(117, 37, 37, 'hotels', 0, '2019-07-21 15:39:34'),
(118, 38, 38, 'hotels', 0, '2019-07-21 15:51:00'),
(119, 38, 38, 'hotels', 0, '2019-07-21 15:51:00'),
(120, 39, 39, 'hotels', 0, '2019-07-21 15:52:38'),
(121, 39, 39, 'hotels', 0, '2019-07-21 15:52:38'),
(122, 40, 40, 'hotels', 0, '2019-07-21 15:52:49'),
(123, 40, 40, 'hotels', 0, '2019-07-21 15:52:49'),
(124, 41, 41, 'hotels', 0, '2019-07-21 15:53:23'),
(125, 41, 41, 'hotels', 0, '2019-07-21 15:53:24'),
(126, 42, 42, 'hotels', 0, '2019-07-21 15:54:01'),
(127, 42, 42, 'hotels', 0, '2019-07-21 15:54:01'),
(128, 43, 43, 'hotels', 0, '2019-07-21 15:54:19'),
(129, 43, 43, 'hotels', 0, '2019-07-21 15:54:19'),
(130, 44, 44, 'hotels', 0, '2019-07-21 15:54:57'),
(131, 44, 44, 'hotels', 0, '2019-07-21 15:54:57'),
(132, 45, 45, 'hotels', 0, '2019-07-21 15:56:34'),
(133, 45, 45, 'hotels', 0, '2019-07-21 15:56:34'),
(134, 46, 46, 'hotels', 0, '2019-07-21 15:56:35'),
(135, 46, 46, 'hotels', 0, '2019-07-21 15:56:36'),
(136, 47, 47, 'hotels', 0, '2019-07-21 15:56:46'),
(137, 47, 47, 'hotels', 0, '2019-07-21 15:56:46'),
(138, 48, 48, 'hotels', 0, '2019-07-21 15:57:33'),
(139, 48, 48, 'hotels', 0, '2019-07-21 15:57:33'),
(140, 49, 49, 'hotels', 0, '2019-07-21 15:59:19'),
(141, 49, 49, 'hotels', 0, '2019-07-21 15:59:19'),
(142, 50, 50, 'hotels', 0, '2019-07-21 16:03:05'),
(143, 51, 51, 'hotels', 0, '2019-07-21 16:03:06'),
(144, 52, 52, 'hotels', 0, '2019-07-21 16:03:06'),
(145, 53, 53, 'hotels', 0, '2019-07-21 16:03:07'),
(146, 54, 54, 'hotels', 0, '2019-07-21 16:05:24'),
(147, 55, 55, 'hotels', 0, '2019-07-21 16:05:59'),
(148, 56, 56, 'hotels', 0, '2019-07-21 16:24:32'),
(149, 56, 56, 'hotels', 0, '2019-07-21 16:24:32');

-- --------------------------------------------------------

--
-- Table structure for table `main_booking_details`
--

CREATE TABLE `main_booking_details` (
  `id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `post_parent_id` int(11) NOT NULL,
  `post_id` int(11) NOT NULL,
  `booking_total` int(11) NOT NULL,
  `u_name` varchar(255) NOT NULL,
  `check_in` varchar(60) NOT NULL,
  `check_out` varchar(60) NOT NULL,
  `u_rooms` int(11) NOT NULL,
  `u_adults` varchar(20) NOT NULL,
  `u_children` varchar(111) NOT NULL,
  `u_infants` varchar(111) NOT NULL,
  `u_cell` varchar(111) NOT NULL,
  `u_email` varchar(111) NOT NULL,
  `u_address` varchar(111) NOT NULL,
  `u_address2` varchar(200) NOT NULL,
  `u_city` varchar(111) NOT NULL,
  `u_state` varchar(100) NOT NULL,
  `u_zip` varchar(100) NOT NULL,
  `u_country` varchar(100) NOT NULL,
  `pickup_location` varchar(200) NOT NULL,
  `drop_off_location` varchar(200) NOT NULL,
  `date_of_journey` varchar(100) NOT NULL,
  `time_of_journey` varchar(100) NOT NULL,
  `is_different` int(2) NOT NULL DEFAULT '0',
  `u_comments` varchar(111) NOT NULL,
  `payment_status` int(2) NOT NULL DEFAULT '0',
  `payment_type` varchar(20) NOT NULL,
  `service_type` varchar(100) NOT NULL,
  `date_added` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `main_booking_details`
--

INSERT INTO `main_booking_details` (`id`, `user_id`, `post_parent_id`, `post_id`, `booking_total`, `u_name`, `check_in`, `check_out`, `u_rooms`, `u_adults`, `u_children`, `u_infants`, `u_cell`, `u_email`, `u_address`, `u_address2`, `u_city`, `u_state`, `u_zip`, `u_country`, `pickup_location`, `drop_off_location`, `date_of_journey`, `time_of_journey`, `is_different`, `u_comments`, `payment_status`, `payment_type`, `service_type`, `date_added`) VALUES
(1, 1, 1, 3, 5, 'aaa', '2019-06-28', '2019-06-21', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 0, '', 1, '', 'hotels', '2019-07-03 18:05:53'),
(2, 1, 2, 4, 10, 'bbb', '2019-06-23', '2019-06-21', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 0, '', 1, '', 'hotels', '2019-07-03 19:00:10'),
(3, 1, 3, 5, 2, 'ccc', '2019-06-31', '2019-06-21', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 0, '', 1, '', 'hotels', '2019-07-04 16:08:40'),
(4, 1, 1, 3, 0, '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 0, '', 0, '', '', '2019-07-09 17:35:47'),
(5, 1, 1, 3, 0, '', '2019-07-20', '2019-05-14', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 0, '', 0, '', '', '2019-07-09 17:36:56'),
(6, 1, 1, 3, 0, '', '2019-07-20', '2019-05-14', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 0, '', 0, '', '', '2019-07-09 17:38:10'),
(7, 1, 1, 3, 2222222, 'aaaaaaaaaaaaa', '2019-07-20', '2019-05-14', 3, '3', '2', '', 'aaaaaaaaaaaaaaaaaaaaa', 'aaaaaaaaaaaaa', 'aaaaaaaaaaaaaa', '', 'aaaaaaaaaaaaaaa', '', '', '', '', '', '', '', 0, '', 0, '', '', '2019-07-09 17:39:28'),
(8, 1, 1, 3, 2147483647, '', '2019-07-20', '2019-05-14', 3, '3', '2', '', '', '', '', '', '', '', '', '', '', '', '', '', 0, '', 0, '', '', '2019-07-09 17:40:34'),
(9, 1, 1, 3, 2147483647, 'aaaaaaaaaaa', '2019-07-20', '2019-05-14', 3, '3', '2', '', '01717677966', 'm.rabiul09@gmail.com', 'Banglamotor, Kawran Bazar', '', 'Dhaka', '', '', '', '', '', '', '', 0, '', 0, '', '', '2019-07-09 17:41:03'),
(10, 1, 1, 3, 2147483647, '', '2019-07-20', '2019-05-14', 3, '3', '2', '', '', '', '', '', '', '', '', '', '', '', '', '', 0, '', 0, '', '', '2019-07-09 17:41:11'),
(11, 1, 1, 3, 2147483647, '', '2019-07-20', '2019-05-14', 3, '3', '2', '', '', '', '', '', '', '', '', '', '', '', '', '', 0, '', 0, '', '', '2019-07-09 17:42:26'),
(12, 1, 1, 3, 2147483647, '', '2019-07-20', '2019-05-14', 3, '3', '2', '', '', '', '', '', '', '', '', '', '', '', '', '', 0, '', 0, '', '', '2019-07-09 17:43:09'),
(13, 1, 2, 1, 333, 'Mr Rabiul Islam', '', '', 0, '', '', '', '01717677966', 'm.rabiul09@gmail.com', '', '', '', '', '', '', 'dhaka', 'khulna', '07/11/2019', '6 PM<', 1, '', 0, '', 'cars', '2019-07-10 17:11:04'),
(14, 1, 2, 1, 333, 'Mr Rabiul Islam', '', '', 0, '', '', '', '01717677966', 'm.rabiul09@gmail.com', '', '', '', '', '', '', 'dhaka', 'khulna', '07/11/2019', '6 PM<', 1, '', 0, '', 'cars', '2019-07-10 17:13:09'),
(15, 0, 2, 1, 0, 'Mr Rabiul Islam', '', '', 0, '', '', '', '01717677966', 'm.rabiul09@gmail.com', '', '', '', '', '', '', 'www', 'www', '07/31/2019', '6 PM', 0, '', 0, '', 'cars', '2019-07-11 15:18:39'),
(16, 0, 2, 1, 600, 'Mr Rabiul Islam', '', '', 0, '', '', '', '01717677966', 'm.rabiul09@gmail.com', '', '', '', '', '', '', 'www', 'www', '07/31/2019', '6 PM', 0, '', 0, '', 'cars', '2019-07-11 15:20:04'),
(17, 0, 2, 1, 600, 'Mr Rabiul Islam', '', '', 0, '', '', '', '01717677966', 'm.rabiul09@gmail.com', '', '', '', '', '', '', 'www', 'www', '07/31/2019', '6 PM', 0, '', 0, '', 'cars', '2019-07-11 15:20:37'),
(18, 0, 2, 1, 600, 'Mr Rabiul Islam', '', '', 0, '', '', '', '01717677966', 'm.rabiul09@gmail.com', '', '', '', '', '', '', 'www', 'www', '07/31/2019', '6 PM', 0, '', 0, '', 'cars', '2019-07-11 15:21:07'),
(19, 0, 2, 1, 600, 'Mr Rabiul Islam', '', '', 0, '', '', '', '01717677966', 'm.rabiul09@gmail.com', '', '', '', '', '', '', 'www', 'www', '07/31/2019', '6 PM', 0, '', 0, '', 'cars', '2019-07-11 15:21:24'),
(20, 0, 2, 1, 600, 'Mr Rabiul Islam', '', '', 0, '', '', '', '01717677966', 'm.rabiul09@gmail.com', '', '', '', '', '', '', 'www', 'www', '07/31/2019', '6 PM', 0, '', 0, '', 'cars', '2019-07-11 15:21:41'),
(21, 0, 2, 1, 600, 'Mr Rabiul Islam', '', '', 0, '', '', '', '01717677966', 'm.rabiul09@gmail.com', '', '', '', '', '', '', 'www', 'www', '07/31/2019', '6 PM', 0, '', 0, '', 'cars', '2019-07-11 15:22:05'),
(22, 0, 2, 1, 600, 'Mr Rabiul Islam', '', '', 0, '', '', '', '01717677966', 'm.rabiul09@gmail.com', '', '', '', '', '', '', 'www', 'www', '07/31/2019', '6 PM', 0, '', 0, '', 'cars', '2019-07-11 15:22:24'),
(23, 0, 2, 1, 600, 'Mr Rabiul Islam', '', '', 0, '', '', '', '01717677966', 'm.rabiul09@gmail.com', '', '', '', '', '', '', 'www', 'www', '07/31/2019', '6 PM', 0, '', 0, '', 'cars', '2019-07-11 15:23:10'),
(24, 0, 4, 2, 500, 'Mr Rabiul Islam', '', '', 0, '', '', '', '01717677966', 'm.rabiul09@gmail.com', '', '', '', '', '', '', 'dhaka', 'www', '07/19/2019', '6 PM', 0, '', 0, '', 'cars', '2019-07-11 15:48:48'),
(25, 1, 11, 2, 2222, 'aaaaaaaaaa', '2019-07-03', '', 0, '', '', '', '01717677966', 'm.rabiul09@gmail.com', '', '', '', '', '', '', '', '', '', '', 0, '', 0, '', 'tours', '2019-07-16 18:07:06'),
(26, 1, 11, 2, 2222, 'Mr Rabiul Islam', '2019-07-03', '', 0, '', '', '', '01717677966', 'm.rabiul09@gmail.com', '', '', '', '', '', '', '', '', '', '', 0, '', 0, '', 'tours', '2019-07-16 18:16:10'),
(27, 1, 1, 3, 2222, 'aaaa', '2019-07-18', '', 0, '', '', '', '01717677966', 'm.rabiul09@gmail.com', '', '', '', '', '', '', '', '', '', '', 0, '', 0, '', 'activitys', '2019-07-22 18:43:58');

-- --------------------------------------------------------

--
-- Table structure for table `newpluginform`
--

CREATE TABLE `newpluginform` (
  `id` int(11) NOT NULL,
  `desti` varchar(122) NOT NULL,
  `datefist` varchar(212) NOT NULL,
  `datetwo` varchar(111) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `newpluginform`
--

INSERT INTO `newpluginform` (`id`, `desti`, `datefist`, `datetwo`) VALUES
(1, 'wewew', 'wwewew', 'sdsds');

-- --------------------------------------------------------

--
-- Table structure for table `new_order_img`
--

CREATE TABLE `new_order_img` (
  `id` int(11) NOT NULL,
  `service_id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `img_name` varchar(500) NOT NULL,
  `service_type` varchar(100) NOT NULL,
  `img_url` varchar(500) NOT NULL,
  `status` int(2) NOT NULL DEFAULT '0',
  `added_date` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `new_order_img`
--

INSERT INTO `new_order_img` (`id`, `service_id`, `user_id`, `img_name`, `service_type`, `img_url`, `status`, `added_date`) VALUES
(2, 4, 1, '62647957_2466997336697120_2993306194849824768_n.jpg', 'hotels', '/uploads/hotels/gallary/image_1/62647957_2466997336697120_2993306194849824768_n.jpg', 0, '2019-07-13 17:04:12'),
(3, 0, 1, '242-150x150.jpg', '1', '/uploads/hotels/gallary/image_1/242-150x150.jpg', 0, '2019-06-23 18:50:56'),
(4, 0, 1, '242-150x150.jpg', '1', '/uploads/hotels/gallary/image_1/242-150x150.jpg', 0, '2019-06-23 18:50:56'),
(6, 4, 1, '62647957_2466997336697120_2993306194849824768_n.jpg', 'rooms', '/uploads/rooms/gallary/image_1/62647957_2466997336697120_2993306194849824768_n.jpg', 0, '2019-07-24 16:43:32'),
(11, 3, 1, '1.jpg', 'rooms', '/uploads/rooms/gallary/image_1/1.jpg', 0, '2019-07-04 18:51:50'),
(12, 0, 1, '242-150x150.jpg', 'cars', '/uploads/cars/gallary/image_/242-150x150.jpg', 0, '2019-07-08 17:19:53'),
(13, 0, 1, '62647957_2466997336697120_2993306194849824768_n.jpg', 'cars', '/uploads/cars/gallary/image_/62647957_2466997336697120_2993306194849824768_n.jpg', 0, '2019-07-08 17:19:53'),
(14, 0, 1, '62647957_2466997336697120_2993306194849824768_n.jpg', 'cars', '/uploads/cars/gallary/image_/62647957_2466997336697120_2993306194849824768_n.jpg', 0, '2019-07-08 17:24:25'),
(15, 0, 1, '62647957_2466997336697120_2993306194849824768_n.jpg', 'cars', '/uploads/cars/gallary/image_/62647957_2466997336697120_2993306194849824768_n.jpg', 0, '2019-07-08 17:36:19'),
(16, 0, 1, '22933164_0_working-(1).png', 'tours', '/uploads/tours/gallary/image_/22933164_0_working-(1).png', 0, '2019-07-12 16:21:18'),
(17, 0, 1, 'bg.jpg', 'tours', '/uploads/tours/gallary/image_/bg.jpg', 0, '2019-07-12 16:21:18'),
(18, 0, 1, 'clippingpath.png', 'tours', '/uploads/tours/gallary/image_/clippingpath.png', 0, '2019-07-12 16:21:18'),
(19, 0, 1, 'natural-shadow.png', 'tours', '/uploads/tours/gallary/image_/natural-shadow.png', 0, '2019-07-12 16:21:18'),
(20, 0, 1, '22933164_0_working-(1).png', 'tours', '/uploads/tours/gallary/image_/22933164_0_working-(1).png', 0, '2019-07-12 16:24:06'),
(21, 0, 1, 'clippingpath.png', 'tours', '/uploads/tours/gallary/image_/clippingpath.png', 0, '2019-07-12 16:24:06'),
(22, 0, 1, 'natural-shadow.png', 'tours', '/uploads/tours/gallary/image_/natural-shadow.png', 0, '2019-07-12 16:24:06'),
(23, 0, 1, '22933164_0_working-(1).png', 'tours', '/uploads/tours/gallary/image_/22933164_0_working-(1).png', 0, '2019-07-12 16:26:16'),
(24, 0, 1, 'natural-shadow.png', 'tours', '/uploads/tours/gallary/image_/natural-shadow.png', 0, '2019-07-12 16:26:17'),
(25, 0, 1, '22933164_0_working-(1).png', 'tours', '/uploads/tours/gallary/image_/22933164_0_working-(1).png', 0, '2019-07-12 16:29:32'),
(26, 0, 1, 'natural-shadow.png', 'tours', '/uploads/tours/gallary/image_/natural-shadow.png', 0, '2019-07-12 16:29:32'),
(37, 8, 1, 'lede.jpg', 'tours', '/uploads/tours/gallary/image_8/lede.jpg', 0, '2019-07-15 15:29:53'),
(38, 9, 1, 'a-b.jpg', 'tours', '/uploads/tours/gallary/image_9/a-b.jpg', 0, '2019-07-15 15:40:45'),
(39, 10, 1, 'lede.jpg', 'tours', '/uploads/tours/gallary/image_10/lede.jpg', 0, '2019-07-15 15:47:36'),
(40, 11, 1, 'after befor.jpg', 'tours', '/uploads/tours/gallary/image_11/after befor.jpg', 0, '2019-07-15 15:49:18'),
(41, 11, 1, 'after befor.jpg', 'tours', '/uploads/tours/gallary/image_11/after befor.jpg', 0, '2019-07-15 15:49:18'),
(43, 13, 1, 'buty retoucing.jpg', 'tours', '/uploads/tours/gallary/image_13/buty retoucing.jpg', 0, '2019-07-15 18:49:25'),
(44, 14, 1, 'aaa -bbb.jpg', 'tours', '/uploads/tours/gallary/image_14/aaa -bbb.jpg', 0, '2019-07-16 15:21:58'),
(47, 15, 1, 'buty retoucing.jpg', 'tours', '/uploads/tours/gallary/image_15/buty retoucing.jpg', 0, '2019-07-18 19:26:47'),
(48, 6, 1, 'Image Manipulation 1.jpg', 'hotels', '/uploads/hotels/gallary/image_6/Image Manipulation 1.jpg', 0, '2019-07-18 19:30:02'),
(49, 7, 1, 'after befor.jpg', 'hotels', '/uploads/hotels/gallary/image_7/after befor.jpg', 0, '2019-07-18 19:38:44'),
(50, 8, 1, 'lede.jpg', 'hotels', '/uploads/hotels/gallary/image_8/lede.jpg', 0, '2019-07-18 19:48:53'),
(51, 9, 1, 'clippingpath.jpg', 'hotels', '/uploads/hotels/gallary/image_9/clippingpath.jpg', 0, '2019-07-18 19:52:49'),
(52, 10, 1, 'resize images.jpg', 'hotels', '/uploads/hotels/gallary/image_10/resize images.jpg', 0, '2019-07-18 19:55:30'),
(53, 11, 1, 'after befor.jpg', 'hotels', '/uploads/hotels/gallary/image_11/after befor.jpg', 0, '2019-07-18 19:57:47'),
(54, 11, 1, 'Photoshop-drop-shadow.jpg', 'hotels', '/uploads/hotels/gallary/image_11/Photoshop-drop-shadow.jpg', 0, '2019-07-18 19:57:47'),
(55, 12, 1, 'buty retoucing.jpg', 'hotels', '/uploads/hotels/gallary/image_12/buty retoucing.jpg', 0, '2019-07-19 18:43:11'),
(56, 13, 1, 'buty retoucing.jpg', 'hotels', '/uploads/hotels/gallary/image_13/buty retoucing.jpg', 0, '2019-07-19 18:46:55'),
(57, 13, 1, 'clippingpath.jpg', 'hotels', '/uploads/hotels/gallary/image_13/clippingpath.jpg', 0, '2019-07-19 18:46:55'),
(58, 13, 1, 'Image Manipulation 1.jpg', 'hotels', '/uploads/hotels/gallary/image_13/Image Manipulation 1.jpg', 0, '2019-07-19 18:46:55'),
(61, 15, 1, '22933164_0_working-(1).png', 'hotels', '/uploads/hotels/gallary/image_15/22933164_0_working-(1).png', 0, '2019-07-19 19:44:05'),
(62, 15, 1, 'bg.jpg', 'hotels', '/uploads/hotels/gallary/image_15/bg.jpg', 0, '2019-07-19 19:44:05'),
(63, 15, 1, 'blog-bg.jpg', 'hotels', '/uploads/hotels/gallary/image_15/blog-bg.jpg', 0, '2019-07-19 19:44:05'),
(64, 15, 1, 'natural-shadow.png', 'hotels', '/uploads/hotels/gallary/image_15/natural-shadow.png', 0, '2019-07-19 19:44:05'),
(65, 16, 1, '22933164_0_working-(1).png', 'hotels', '/uploads/hotels/gallary/image_16/22933164_0_working-(1).png', 0, '2019-07-19 19:48:26'),
(66, 16, 1, 'bg.jpg', 'hotels', '/uploads/hotels/gallary/image_16/bg.jpg', 0, '2019-07-19 19:48:26'),
(67, 16, 1, 'blog-bg.jpg', 'hotels', '/uploads/hotels/gallary/image_16/blog-bg.jpg', 0, '2019-07-19 19:48:27'),
(68, 16, 1, 'natural-shadow.png', 'hotels', '/uploads/hotels/gallary/image_16/natural-shadow.png', 0, '2019-07-19 19:48:27'),
(69, 17, 1, '22933164_0_working (1).tif', 'hotels', '/uploads/hotels/gallary/image_17/22933164_0_working (1).tif', 0, '2019-07-21 14:55:26'),
(70, 17, 1, 'buty retoucing 2.tif', 'hotels', '/uploads/hotels/gallary/image_17/buty retoucing 2.tif', 0, '2019-07-21 14:55:26'),
(71, 18, 1, '22933164_0_working (1).tif', 'hotels', '/uploads/hotels/gallary/image_18/22933164_0_working (1).tif', 0, '2019-07-21 14:56:29'),
(72, 18, 1, 'buty retoucing 2.tif', 'hotels', '/uploads/hotels/gallary/image_18/buty retoucing 2.tif', 0, '2019-07-21 14:56:29'),
(73, 19, 1, '22933164_0_working (1).tif', 'hotels', '/uploads/hotels/gallary/image_19/22933164_0_working (1).tif', 0, '2019-07-21 14:56:54'),
(74, 19, 1, 'buty retoucing 2.tif', 'hotels', '/uploads/hotels/gallary/image_19/buty retoucing 2.tif', 0, '2019-07-21 14:56:54'),
(75, 20, 1, '22933164_0_working (1).tif', 'hotels', '/uploads/hotels/gallary/image_20/22933164_0_working (1).tif', 0, '2019-07-21 14:58:27'),
(76, 20, 1, 'buty retoucing 2.tif', 'hotels', '/uploads/hotels/gallary/image_20/buty retoucing 2.tif', 0, '2019-07-21 14:58:27'),
(77, 21, 1, 'photo-1509118796018-30cc4ce216f1.jpg', 'hotels', '/uploads/hotels/gallary/image_21/photo-1509118796018-30cc4ce216f1.jpg', 0, '2019-07-21 14:59:04'),
(78, 22, 1, 'photo-1509118796018-30cc4ce216f1.jpg', 'hotels', '/uploads/hotels/gallary/image_22/photo-1509118796018-30cc4ce216f1.jpg', 0, '2019-07-21 14:59:16'),
(79, 23, 1, 'photo-1519084906448-095ffc4e194d.jpg', 'hotels', '/uploads/hotels/gallary/image_23/photo-1519084906448-095ffc4e194d.jpg', 0, '2019-07-21 15:00:20'),
(80, 23, 1, 'pink-lipstick-through-bright-blue-paper.jpg', 'hotels', '/uploads/hotels/gallary/image_23/pink-lipstick-through-bright-blue-paper.jpg', 0, '2019-07-21 15:00:20'),
(81, 23, 1, 'smiling-man-woman-pug.jpg', 'hotels', '/uploads/hotels/gallary/image_23/smiling-man-woman-pug.jpg', 0, '2019-07-21 15:00:20'),
(82, 24, 1, 'aa-bb.jpg', 'hotels', '/uploads/hotels/gallary/image_24/aa-bb.jpg', 0, '2019-07-21 15:28:32'),
(83, 24, 1, 'a-b.jpg', 'hotels', '/uploads/hotels/gallary/image_24/a-b.jpg', 0, '2019-07-21 15:28:32'),
(84, 24, 1, 'after befor.jpg', 'hotels', '/uploads/hotels/gallary/image_24/after befor.jpg', 0, '2019-07-21 15:28:32'),
(85, 25, 1, 'Photoshop-drop-shadow.jpg', 'hotels', '/uploads/hotels/gallary/image_25/Photoshop-drop-shadow.jpg', 0, '2019-07-21 15:37:16'),
(86, 25, 1, 'resize images.jpg', 'hotels', '/uploads/hotels/gallary/image_25/resize images.jpg', 0, '2019-07-21 15:37:16'),
(87, 25, 1, 'Vector Drawing.jpg', 'hotels', '/uploads/hotels/gallary/image_25/Vector Drawing.jpg', 0, '2019-07-21 15:37:16'),
(88, 26, 1, 'Photoshop-drop-shadow.jpg', 'hotels', '/uploads/hotels/gallary/image_26/Photoshop-drop-shadow.jpg', 0, '2019-07-21 15:37:18'),
(89, 26, 1, 'resize images.jpg', 'hotels', '/uploads/hotels/gallary/image_26/resize images.jpg', 0, '2019-07-21 15:37:18'),
(90, 26, 1, 'Vector Drawing.jpg', 'hotels', '/uploads/hotels/gallary/image_26/Vector Drawing.jpg', 0, '2019-07-21 15:37:18'),
(91, 27, 1, 'Photoshop-drop-shadow.jpg', 'hotels', '/uploads/hotels/gallary/image_27/Photoshop-drop-shadow.jpg', 0, '2019-07-21 15:37:21'),
(92, 27, 1, 'resize images.jpg', 'hotels', '/uploads/hotels/gallary/image_27/resize images.jpg', 0, '2019-07-21 15:37:21'),
(93, 27, 1, 'Vector Drawing.jpg', 'hotels', '/uploads/hotels/gallary/image_27/Vector Drawing.jpg', 0, '2019-07-21 15:37:21'),
(94, 28, 1, 'Photoshop-drop-shadow.jpg', 'hotels', '/uploads/hotels/gallary/image_28/Photoshop-drop-shadow.jpg', 0, '2019-07-21 15:37:24'),
(95, 28, 1, 'resize images.jpg', 'hotels', '/uploads/hotels/gallary/image_28/resize images.jpg', 0, '2019-07-21 15:37:24'),
(96, 28, 1, 'Vector Drawing.jpg', 'hotels', '/uploads/hotels/gallary/image_28/Vector Drawing.jpg', 0, '2019-07-21 15:37:24'),
(97, 29, 1, 'Photoshop-drop-shadow.jpg', 'hotels', '/uploads/hotels/gallary/image_29/Photoshop-drop-shadow.jpg', 0, '2019-07-21 15:37:36'),
(98, 29, 1, 'resize images.jpg', 'hotels', '/uploads/hotels/gallary/image_29/resize images.jpg', 0, '2019-07-21 15:37:36'),
(99, 29, 1, 'Vector Drawing.jpg', 'hotels', '/uploads/hotels/gallary/image_29/Vector Drawing.jpg', 0, '2019-07-21 15:37:36'),
(100, 30, 1, 'Photoshop-drop-shadow.jpg', 'hotels', '/uploads/hotels/gallary/image_30/Photoshop-drop-shadow.jpg', 0, '2019-07-21 15:37:39'),
(101, 30, 1, 'resize images.jpg', 'hotels', '/uploads/hotels/gallary/image_30/resize images.jpg', 0, '2019-07-21 15:37:39'),
(102, 30, 1, 'Vector Drawing.jpg', 'hotels', '/uploads/hotels/gallary/image_30/Vector Drawing.jpg', 0, '2019-07-21 15:37:39'),
(103, 31, 1, 'Photoshop-drop-shadow.jpg', 'hotels', '/uploads/hotels/gallary/image_31/Photoshop-drop-shadow.jpg', 0, '2019-07-21 15:38:13'),
(104, 31, 1, 'resize images.jpg', 'hotels', '/uploads/hotels/gallary/image_31/resize images.jpg', 0, '2019-07-21 15:38:13'),
(105, 31, 1, 'Vector Drawing.jpg', 'hotels', '/uploads/hotels/gallary/image_31/Vector Drawing.jpg', 0, '2019-07-21 15:38:13'),
(106, 32, 1, 'Photoshop-drop-shadow.jpg', 'hotels', '/uploads/hotels/gallary/image_32/Photoshop-drop-shadow.jpg', 0, '2019-07-21 15:38:15'),
(107, 32, 1, 'resize images.jpg', 'hotels', '/uploads/hotels/gallary/image_32/resize images.jpg', 0, '2019-07-21 15:38:16'),
(108, 32, 1, 'Vector Drawing.jpg', 'hotels', '/uploads/hotels/gallary/image_32/Vector Drawing.jpg', 0, '2019-07-21 15:38:16'),
(109, 33, 1, 'Photoshop-drop-shadow.jpg', 'hotels', '/uploads/hotels/gallary/image_33/Photoshop-drop-shadow.jpg', 0, '2019-07-21 15:38:17'),
(110, 33, 1, 'resize images.jpg', 'hotels', '/uploads/hotels/gallary/image_33/resize images.jpg', 0, '2019-07-21 15:38:17'),
(111, 33, 1, 'Vector Drawing.jpg', 'hotels', '/uploads/hotels/gallary/image_33/Vector Drawing.jpg', 0, '2019-07-21 15:38:17'),
(112, 34, 1, 'Photoshop-drop-shadow.jpg', 'hotels', '/uploads/hotels/gallary/image_34/Photoshop-drop-shadow.jpg', 0, '2019-07-21 15:38:19'),
(113, 34, 1, 'resize images.jpg', 'hotels', '/uploads/hotels/gallary/image_34/resize images.jpg', 0, '2019-07-21 15:38:19'),
(114, 34, 1, 'Vector Drawing.jpg', 'hotels', '/uploads/hotels/gallary/image_34/Vector Drawing.jpg', 0, '2019-07-21 15:38:19'),
(115, 35, 1, 'Image Manipulation.jpg', 'hotels', '/uploads/hotels/gallary/image_35/Image Manipulation.jpg', 0, '2019-07-21 15:39:29'),
(116, 35, 1, 'Mirror Effect.jpg', 'hotels', '/uploads/hotels/gallary/image_35/Mirror Effect.jpg', 0, '2019-07-21 15:39:29'),
(117, 35, 1, 'Photoshop-drop-shadow.jpg', 'hotels', '/uploads/hotels/gallary/image_35/Photoshop-drop-shadow.jpg', 0, '2019-07-21 15:39:29'),
(118, 36, 1, 'Image Manipulation.jpg', 'hotels', '/uploads/hotels/gallary/image_36/Image Manipulation.jpg', 0, '2019-07-21 15:39:31'),
(119, 36, 1, 'Mirror Effect.jpg', 'hotels', '/uploads/hotels/gallary/image_36/Mirror Effect.jpg', 0, '2019-07-21 15:39:31'),
(120, 36, 1, 'Photoshop-drop-shadow.jpg', 'hotels', '/uploads/hotels/gallary/image_36/Photoshop-drop-shadow.jpg', 0, '2019-07-21 15:39:31'),
(121, 37, 1, 'Image Manipulation.jpg', 'hotels', '/uploads/hotels/gallary/image_37/Image Manipulation.jpg', 0, '2019-07-21 15:39:34'),
(122, 37, 1, 'Mirror Effect.jpg', 'hotels', '/uploads/hotels/gallary/image_37/Mirror Effect.jpg', 0, '2019-07-21 15:39:34'),
(123, 37, 1, 'Photoshop-drop-shadow.jpg', 'hotels', '/uploads/hotels/gallary/image_37/Photoshop-drop-shadow.jpg', 0, '2019-07-21 15:39:34'),
(124, 38, 1, 'after befor.jpg', 'hotels', '/uploads/hotels/gallary/image_38/after befor.jpg', 0, '2019-07-21 15:51:00'),
(125, 38, 1, 'clippingpath.jpg', 'hotels', '/uploads/hotels/gallary/image_38/clippingpath.jpg', 0, '2019-07-21 15:51:00'),
(126, 39, 1, 'after befor.jpg', 'hotels', '/uploads/hotels/gallary/image_39/after befor.jpg', 0, '2019-07-21 15:52:38'),
(127, 39, 1, 'clippingpath.jpg', 'hotels', '/uploads/hotels/gallary/image_39/clippingpath.jpg', 0, '2019-07-21 15:52:38'),
(128, 40, 1, 'after befor.jpg', 'hotels', '/uploads/hotels/gallary/image_40/after befor.jpg', 0, '2019-07-21 15:52:50'),
(129, 40, 1, 'clippingpath.jpg', 'hotels', '/uploads/hotels/gallary/image_40/clippingpath.jpg', 0, '2019-07-21 15:52:50'),
(130, 41, 1, 'after befor.jpg', 'hotels', '/uploads/hotels/gallary/image_41/after befor.jpg', 0, '2019-07-21 15:53:24'),
(131, 41, 1, 'clippingpath.jpg', 'hotels', '/uploads/hotels/gallary/image_41/clippingpath.jpg', 0, '2019-07-21 15:53:24'),
(132, 42, 1, 'after befor.jpg', 'hotels', '/uploads/hotels/gallary/image_42/after befor.jpg', 0, '2019-07-21 15:54:01'),
(133, 42, 1, 'clippingpath.jpg', 'hotels', '/uploads/hotels/gallary/image_42/clippingpath.jpg', 0, '2019-07-21 15:54:01'),
(134, 43, 1, 'after befor.jpg', 'hotels', '/uploads/hotels/gallary/image_43/after befor.jpg', 0, '2019-07-21 15:54:19'),
(135, 43, 1, 'clippingpath.jpg', 'hotels', '/uploads/hotels/gallary/image_43/clippingpath.jpg', 0, '2019-07-21 15:54:19'),
(136, 44, 1, 'after befor.jpg', 'hotels', '/uploads/hotels/gallary/image_44/after befor.jpg', 0, '2019-07-21 15:54:57'),
(137, 44, 1, 'clippingpath.jpg', 'hotels', '/uploads/hotels/gallary/image_44/clippingpath.jpg', 0, '2019-07-21 15:54:57'),
(138, 45, 1, 'after befor.jpg', 'hotels', '/uploads/hotels/gallary/image_45/after befor.jpg', 0, '2019-07-21 15:56:34'),
(139, 45, 1, 'clippingpath.jpg', 'hotels', '/uploads/hotels/gallary/image_45/clippingpath.jpg', 0, '2019-07-21 15:56:34'),
(140, 46, 1, 'after befor.jpg', 'hotels', '/uploads/hotels/gallary/image_46/after befor.jpg', 0, '2019-07-21 15:56:36'),
(141, 46, 1, 'clippingpath.jpg', 'hotels', '/uploads/hotels/gallary/image_46/clippingpath.jpg', 0, '2019-07-21 15:56:36'),
(142, 47, 1, 'after befor.jpg', 'hotels', '/uploads/hotels/gallary/image_47/after befor.jpg', 0, '2019-07-21 15:56:46'),
(143, 47, 1, 'clippingpath.jpg', 'hotels', '/uploads/hotels/gallary/image_47/clippingpath.jpg', 0, '2019-07-21 15:56:46'),
(144, 48, 1, 'after befor.jpg', 'hotels', '/uploads/hotels/gallary/image_48/after befor.jpg', 0, '2019-07-21 15:57:33'),
(145, 48, 1, 'clippingpath.jpg', 'hotels', '/uploads/hotels/gallary/image_48/clippingpath.jpg', 0, '2019-07-21 15:57:33'),
(146, 49, 1, 'after befor.jpg', 'hotels', '/uploads/hotels/gallary/image_49/after befor.jpg', 0, '2019-07-21 15:59:19'),
(147, 49, 1, 'clippingpath.jpg', 'hotels', '/uploads/hotels/gallary/image_49/clippingpath.jpg', 0, '2019-07-21 15:59:19'),
(148, 50, 1, '', 'hotels', '/uploads/hotels/gallary/image_50/', 0, '2019-07-21 16:03:05'),
(149, 51, 1, '', 'hotels', '/uploads/hotels/gallary/image_51/', 0, '2019-07-21 16:03:06'),
(150, 52, 1, '', 'hotels', '/uploads/hotels/gallary/image_52/', 0, '2019-07-21 16:03:07'),
(151, 53, 1, '', 'hotels', '/uploads/hotels/gallary/image_53/', 0, '2019-07-21 16:03:07'),
(152, 54, 1, 'lede.jpg', 'hotels', '/uploads/hotels/gallary/image_54/lede.jpg', 0, '2019-07-21 16:05:24'),
(153, 55, 1, 'Image Manipulation 1.jpg', 'hotels', '/uploads/hotels/gallary/image_55/Image Manipulation 1.jpg', 0, '2019-07-21 16:05:59'),
(154, 1, 1, 'clippingpath.jpg', 'cars', '/uploads/cars/gallary/image_1/clippingpath.jpg', 0, '2019-07-21 16:17:55'),
(155, 1, 1, 'Image Manipulation 1.jpg', 'cars', '/uploads/cars/gallary/image_1/Image Manipulation 1.jpg', 0, '2019-07-21 16:17:55'),
(156, 1, 1, 'lede.jpg', 'cars', '/uploads/cars/gallary/image_1/lede.jpg', 0, '2019-07-21 16:17:55'),
(157, 1, 1, 'masking a-b.jpg', 'cars', '/uploads/cars/gallary/image_1/masking a-b.jpg', 0, '2019-07-21 16:17:56'),
(158, 1, 1, 'buty retoucing.jpg', 'cars', '/uploads/cars/gallary/image_1/buty retoucing.jpg', 0, '2019-07-21 16:20:13'),
(159, 1, 1, 'clippingpath.jpg', 'cars', '/uploads/cars/gallary/image_1/clippingpath.jpg', 0, '2019-07-21 16:20:14'),
(160, 1, 1, 'buty retoucing.jpg', 'cars', '/uploads/cars/gallary/image_1/buty retoucing.jpg', 0, '2019-07-21 16:22:38'),
(161, 1, 1, 'clippingpath.jpg', 'cars', '/uploads/cars/gallary/image_1/clippingpath.jpg', 0, '2019-07-21 16:22:38'),
(162, 1, 1, 'lede.jpg', 'cars', '/uploads/cars/gallary/image_1/lede.jpg', 0, '2019-07-21 16:22:38'),
(163, 56, 1, 'buty retoucing.jpg', 'hotels', '/uploads/hotels/gallary/image_56/buty retoucing.jpg', 0, '2019-07-21 16:24:32'),
(164, 56, 1, 'clippingpath.jpg', 'hotels', '/uploads/hotels/gallary/image_56/clippingpath.jpg', 0, '2019-07-21 16:24:32'),
(165, 56, 1, 'Image Manipulation 1.jpg', 'hotels', '/uploads/hotels/gallary/image_56/Image Manipulation 1.jpg', 0, '2019-07-21 16:24:32'),
(166, 1, 1, 'after befor.jpg', 'cars', '/uploads/cars/gallary/image_1/after befor.jpg', 0, '2019-07-21 16:26:23'),
(167, 1, 1, 'Image Manipulation 1.jpg', 'cars', '/uploads/cars/gallary/image_1/Image Manipulation 1.jpg', 0, '2019-07-21 16:26:23'),
(168, 1, 1, 'lede.jpg', 'cars', '/uploads/cars/gallary/image_1/lede.jpg', 0, '2019-07-21 16:26:23'),
(169, 16, 1, 'buty retoucing.jpg', 'tours', '/uploads/tours/gallary/image_16/buty retoucing.jpg', 0, '2019-07-21 16:31:09'),
(170, 16, 1, 'clippingpath.jpg', 'tours', '/uploads/tours/gallary/image_16/clippingpath.jpg', 0, '2019-07-21 16:31:09'),
(171, 16, 1, 'Image Manipulation 1.jpg', 'tours', '/uploads/tours/gallary/image_16/Image Manipulation 1.jpg', 0, '2019-07-21 16:31:09'),
(172, 16, 1, 'masking a-b.jpg', 'tours', '/uploads/tours/gallary/image_16/masking a-b.jpg', 0, '2019-07-21 16:31:09'),
(173, 17, 1, 'buty retoucing.jpg', 'tours', '/uploads/tours/gallary/image_17/buty retoucing.jpg', 0, '2019-07-21 16:33:00'),
(174, 17, 1, 'clippingpath.jpg', 'tours', '/uploads/tours/gallary/image_17/clippingpath.jpg', 0, '2019-07-21 16:33:00'),
(175, 1, 1, 'resize images.jpg', 'cars', '/uploads/cars/gallary/image_1/resize images.jpg', 0, '2019-07-21 16:36:14'),
(176, 1, 1, 'Vector Drawing.jpg', 'cars', '/uploads/cars/gallary/image_1/Vector Drawing.jpg', 0, '2019-07-21 16:36:14'),
(177, 1, 1, 'clippingpath.jpg', 'cars', '/uploads/cars/gallary/image_1/clippingpath.jpg', 0, '2019-07-21 16:38:29'),
(178, 1, 1, 'Image Manipulation 1.jpg', 'cars', '/uploads/cars/gallary/image_1/Image Manipulation 1.jpg', 0, '2019-07-21 16:38:29'),
(179, 1, 1, 'clippingpath.jpg', 'cars', '/uploads/cars/gallary/image_1/clippingpath.jpg', 0, '2019-07-21 16:40:40'),
(180, 1, 1, 'Image Manipulation 1.jpg', 'cars', '/uploads/cars/gallary/image_1/Image Manipulation 1.jpg', 0, '2019-07-21 16:40:40'),
(181, 11, 1, 'clippingpath.jpg', 'cars', '/uploads/cars/gallary/image_11/clippingpath.jpg', 0, '2019-07-21 16:42:47'),
(182, 11, 1, 'Image Manipulation 1.jpg', 'cars', '/uploads/cars/gallary/image_11/Image Manipulation 1.jpg', 0, '2019-07-21 16:42:47'),
(183, 6, 1, 'Image Manipulation.jpg', 'rooms', '/uploads/rooms/gallary/image_6/Image Manipulation.jpg', 0, '2019-07-21 16:55:44'),
(184, 6, 1, 'Image Retouching.jpg', 'rooms', '/uploads/rooms/gallary/image_6/Image Retouching.jpg', 0, '2019-07-21 16:55:45'),
(185, 6, 1, 'lede.jpg', 'rooms', '/uploads/rooms/gallary/image_6/lede.jpg', 0, '2019-07-21 16:55:45'),
(186, 6, 1, 'masking a-b.jpg', 'rooms', '/uploads/rooms/gallary/image_6/masking a-b.jpg', 0, '2019-07-21 16:55:45'),
(187, 1, 1, '1.png', 'activities', '/uploads/activities/gallary/image_1/1.png', 0, '2019-07-21 18:57:18'),
(188, 1, 1, '2.png', 'activities', '/uploads/activities/gallary/image_1/2.png', 0, '2019-07-21 18:57:18'),
(189, 1, 1, '4.png', 'activities', '/uploads/activities/gallary/image_1/4.png', 0, '2019-07-21 18:57:18'),
(190, 0, 1, 'photo-1509118796018-30cc4ce216f1.jpg', 'guides', '/uploads/guides/gallary/image_0/photo-1509118796018-30cc4ce216f1.jpg', 0, '2019-07-25 16:36:20'),
(191, 0, 1, 'photo-1519084906448-095ffc4e194d.jpg', 'guides', '/uploads/guides/gallary/image_0/photo-1519084906448-095ffc4e194d.jpg', 0, '2019-07-25 16:36:20'),
(192, 0, 1, 'pink-lipstick-through-bright-blue-paper.jpg', 'guides', '/uploads/guides/gallary/image_0/pink-lipstick-through-bright-blue-paper.jpg', 0, '2019-07-25 16:36:20'),
(193, 0, 1, 'smiling-man-woman-pug.jpg', 'guides', '/uploads/guides/gallary/image_0/smiling-man-woman-pug.jpg', 0, '2019-07-25 16:36:20'),
(194, 0, 1, 'photo-1509118796018-30cc4ce216f1.jpg', 'guides', '/uploads/guides/gallary/image_0/photo-1509118796018-30cc4ce216f1.jpg', 0, '2019-07-25 16:50:48'),
(195, 0, 1, 'photo-1519084906448-095ffc4e194d.jpg', 'guides', '/uploads/guides/gallary/image_0/photo-1519084906448-095ffc4e194d.jpg', 0, '2019-07-25 16:50:48'),
(196, 0, 1, 'pink-lipstick-through-bright-blue-paper.jpg', 'guides', '/uploads/guides/gallary/image_0/pink-lipstick-through-bright-blue-paper.jpg', 0, '2019-07-25 16:50:48'),
(197, 0, 1, 'smiling-man-woman-pug.jpg', 'guides', '/uploads/guides/gallary/image_0/smiling-man-woman-pug.jpg', 0, '2019-07-25 16:50:48'),
(198, 0, 1, 'photo-1509118796018-30cc4ce216f1.jpg', 'guides', '/uploads/guides/gallary/image_0/photo-1509118796018-30cc4ce216f1.jpg', 0, '2019-07-25 16:52:30'),
(199, 0, 1, 'photo-1519084906448-095ffc4e194d.jpg', 'guides', '/uploads/guides/gallary/image_0/photo-1519084906448-095ffc4e194d.jpg', 0, '2019-07-25 16:52:30'),
(200, 0, 1, 'pink-lipstick-through-bright-blue-paper.jpg', 'guides', '/uploads/guides/gallary/image_0/pink-lipstick-through-bright-blue-paper.jpg', 0, '2019-07-25 16:52:30'),
(201, 0, 1, 'smiling-man-woman-pug.jpg', 'guides', '/uploads/guides/gallary/image_0/smiling-man-woman-pug.jpg', 0, '2019-07-25 16:52:30'),
(202, 0, 1, 'photo-1509118796018-30cc4ce216f1.jpg', 'guides', '/uploads/guides/gallary/image_0/photo-1509118796018-30cc4ce216f1.jpg', 0, '2019-07-25 16:57:50'),
(203, 0, 1, 'photo-1519084906448-095ffc4e194d.jpg', 'guides', '/uploads/guides/gallary/image_0/photo-1519084906448-095ffc4e194d.jpg', 0, '2019-07-25 16:57:50'),
(204, 0, 1, 'pink-lipstick-through-bright-blue-paper.jpg', 'guides', '/uploads/guides/gallary/image_0/pink-lipstick-through-bright-blue-paper.jpg', 0, '2019-07-25 16:57:50'),
(205, 0, 1, 'smiling-man-woman-pug.jpg', 'guides', '/uploads/guides/gallary/image_0/smiling-man-woman-pug.jpg', 0, '2019-07-25 16:57:50'),
(206, 0, 1, 'pink-lipstick-through-bright-blue-paper.jpg', 'guides', '/uploads/guides/gallary/image_0/pink-lipstick-through-bright-blue-paper.jpg', 0, '2019-07-25 16:59:25'),
(207, 0, 1, 'pink-lipstick-through-bright-blue-paper.jpg', 'guides', '/uploads/guides/gallary/image_0/pink-lipstick-through-bright-blue-paper.jpg', 0, '2019-07-25 17:01:12'),
(208, 18, 1, 'pink-lipstick-through-bright-blue-paper.jpg', 'guides', '/uploads/guides/gallary/image_18/pink-lipstick-through-bright-blue-paper.jpg', 0, '2019-07-25 17:01:29'),
(209, 0, 1, 'pink-lipstick-through-bright-blue-paper.jpg', 'guides', '/uploads/guides/gallary/image_0/pink-lipstick-through-bright-blue-paper.jpg', 0, '2019-07-25 17:02:39'),
(210, 19, 1, 'pink-lipstick-through-bright-blue-paper.jpg', 'guides', '/uploads/guides/gallary/image_19/pink-lipstick-through-bright-blue-paper.jpg', 0, '2019-07-25 17:07:17'),
(211, 20, 1, 'pink-lipstick-through-bright-blue-paper.jpg', 'guides', '/uploads/guides/gallary/image_20/pink-lipstick-through-bright-blue-paper.jpg', 0, '2019-07-25 17:09:09'),
(212, 1, 1, 'A1-3.jpg', 'transports', '/uploads/transports/gallary/image_1/A1-3.jpg', 0, '2019-07-28 19:04:34'),
(213, 0, 1, '3.jpg', 'transports', '/uploads/transports/gallary/image_0/3.jpg', 0, '2019-07-28 19:14:58'),
(214, 0, 1, '242-150x150.jpg', 'transports', '/uploads/transports/gallary/image_0/242-150x150.jpg', 0, '2019-07-28 19:14:58'),
(215, 0, 1, '3.jpg', 'transports', '/uploads/transports/gallary/image_0/3.jpg', 0, '2019-07-28 19:16:50'),
(216, 0, 1, '242-150x150.jpg', 'transports', '/uploads/transports/gallary/image_0/242-150x150.jpg', 0, '2019-07-28 19:16:50'),
(217, 0, 1, '3.jpg', 'transports', '/uploads/transports/gallary/image_0/3.jpg', 0, '2019-07-28 19:17:05'),
(218, 0, 1, '242-150x150.jpg', 'transports', '/uploads/transports/gallary/image_0/242-150x150.jpg', 0, '2019-07-28 19:17:05'),
(219, 0, 1, '3.jpg', 'transports', '/uploads/transports/gallary/image_0/3.jpg', 0, '2019-07-28 19:19:01'),
(220, 0, 1, '3.jpg', 'transports', '/uploads/transports/gallary/image_0/3.jpg', 0, '2019-07-28 19:20:15'),
(221, 0, 1, '242-150x150.jpg', 'transports', '/uploads/transports/gallary/image_0/242-150x150.jpg', 0, '2019-07-28 19:21:16'),
(222, 0, 1, '242-150x150.jpg', 'transports', '/uploads/transports/gallary/image_0/242-150x150.jpg', 0, '2019-07-28 19:21:50'),
(223, 2, 1, '242-150x150.jpg', 'transports', '/uploads/transports/gallary/image_2/242-150x150.jpg', 0, '2019-07-28 19:22:19'),
(224, 3, 1, '242-150x150.jpg', 'transports', '/uploads/transports/gallary/image_3/242-150x150.jpg', 0, '2019-07-28 19:30:47'),
(225, 4, 1, '242-150x150.jpg', 'transports', '/uploads/transports/gallary/image_4/242-150x150.jpg', 0, '2019-07-28 19:31:09'),
(226, 0, 1, 'A1-3.jpg', 'restaurants', '/uploads/restaurants/gallary/image_0/A1-3.jpg', 0, '2019-07-29 17:52:30'),
(227, 0, 1, 'A1-3.jpg', 'restaurants', '/uploads/restaurants/gallary/image_0/A1-3.jpg', 0, '2019-07-29 17:52:56'),
(228, 0, 1, '62647957_2466997336697120_2993306194849824768_n.jpg', 'restaurants', '/uploads/restaurants/gallary/image_0/62647957_2466997336697120_2993306194849824768_n.jpg', 0, '2019-07-29 18:04:20'),
(229, 0, 1, 'A1-3.jpg', 'restaurants', '/uploads/restaurants/gallary/image_0/A1-3.jpg', 0, '2019-07-29 18:05:38'),
(230, 5, 1, 'A1-3.jpg', 'restaurants', '/uploads/restaurants/gallary/image_5/A1-3.jpg', 0, '2019-07-29 18:06:08'),
(231, 6, 1, 'A1-3.jpg', 'restaurants', '/uploads/restaurants/gallary/image_6/A1-3.jpg', 0, '2019-07-29 18:06:28');

-- --------------------------------------------------------

--
-- Table structure for table `ratings`
--

CREATE TABLE `ratings` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `user_id` bigint(20) NOT NULL,
  `service_id` bigint(20) UNSIGNED NOT NULL DEFAULT '0',
  `ratings_val` varchar(20) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `service_type` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL,
  `date_added` datetime DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `ratings`
--

INSERT INTO `ratings` (`id`, `user_id`, `service_id`, `ratings_val`, `service_type`, `date_added`) VALUES
(1, 1, 2, '5', 'hotels', NULL),
(2, 1, 2, '5', 'tours', NULL),
(3, 1, 0, '5', 'tours', NULL),
(4, 1, 2, '4', 'transports', NULL);

-- --------------------------------------------------------

--
-- Table structure for table `restaurant_details`
--

CREATE TABLE `restaurant_details` (
  `id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `total_restaurant` int(11) NOT NULL,
  `category_id` int(11) NOT NULL,
  `restaurant_type` int(11) NOT NULL,
  `restaurant_title` varchar(100) NOT NULL,
  `restaurant_description` text NOT NULL,
  `restaurant_image` varchar(255) NOT NULL,
  `restaurant_check_in` varchar(63) NOT NULL,
  `restaurant_check_out` varchar(63) NOT NULL,
  `restaurant_location` varchar(111) NOT NULL,
  `restaurant_email` varchar(63) NOT NULL,
  `restaurant_phone_no` varchar(111) NOT NULL,
  `restaurant_price` varchar(111) NOT NULL,
  `video` varchar(500) NOT NULL,
  `restaurant_time` varchar(100) NOT NULL,
  `restaurant_am_pm` varchar(63) NOT NULL,
  `date_added` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `star`
--

CREATE TABLE `star` (
  `id` int(11) NOT NULL,
  `id_post` int(11) NOT NULL,
  `ip` varchar(40) NOT NULL,
  `rate` int(11) NOT NULL,
  `dt_rated` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `tour_activities`
--

CREATE TABLE `tour_activities` (
  `id` int(11) NOT NULL,
  `tour_id` int(11) NOT NULL,
  `activity_name` varchar(100) NOT NULL,
  `activity_description` varchar(500) NOT NULL,
  `service_type` varchar(100) NOT NULL,
  `status` int(2) NOT NULL DEFAULT '0',
  `added_date` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `tour_activities`
--

INSERT INTO `tour_activities` (`id`, `tour_id`, `activity_name`, `activity_description`, `service_type`, `status`, `added_date`) VALUES
(1, 12, 'sss', 'sss', '', 0, '2019-07-15 18:48:30'),
(2, 12, 'ddd', 'ddd', '', 0, '2019-07-15 18:48:31'),
(3, 12, 'fff', 'fff', '', 0, '2019-07-15 18:48:31'),
(4, 13, 'aaa', 'aaaaaaaaaaaaaaaa', '', 0, '2019-07-15 18:49:25'),
(5, 13, 'ssss', 'ssssssssssssssssss', '', 0, '2019-07-15 18:49:25'),
(6, 13, 'dddd', 'ddddddddddddd', '', 0, '2019-07-15 18:49:25'),
(7, 14, 'aaaa', 'sss', '', 0, '2019-07-16 15:21:58'),
(8, 15, 'aaaa', 'ssss', '', 0, '2019-07-18 19:26:47'),
(9, 16, 'aaaa', 'ghghgh', '', 0, '2019-07-21 16:31:09'),
(10, 17, 'rrr', 'rrr', '', 0, '2019-07-21 16:33:00');

-- --------------------------------------------------------

--
-- Table structure for table `tour_details`
--

CREATE TABLE `tour_details` (
  `id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `total_tour` int(11) NOT NULL,
  `category_id` int(11) NOT NULL,
  `tour_type` int(11) NOT NULL,
  `tour_title` varchar(100) NOT NULL,
  `tour_description` text NOT NULL,
  `tour_image` varchar(255) NOT NULL,
  `tour_check_in` varchar(63) NOT NULL,
  `tour_check_out` varchar(63) NOT NULL,
  `tour_location` varchar(111) NOT NULL,
  `tour_email` varchar(63) NOT NULL,
  `tour_phone_no` varchar(111) NOT NULL,
  `tour_price` varchar(111) NOT NULL,
  `video` varchar(500) NOT NULL,
  `date_added` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `tour_details`
--

INSERT INTO `tour_details` (`id`, `user_id`, `total_tour`, `category_id`, `tour_type`, `tour_title`, `tour_description`, `tour_image`, `tour_check_in`, `tour_check_out`, `tour_location`, `tour_email`, `tour_phone_no`, `tour_price`, `video`, `date_added`) VALUES
(8, 1, 22, 2, 0, '', 'aaa', '', '', '', 'aaa', 'm.rabiul09@gmail.com', '01717677966', '333', '', '2019-07-15 15:29:53'),
(9, 1, 22, 2, 0, '', 'eeee', '', '', '', 'eeee', 'm.rabiul09@gmail.com', '01717677966', '2222', '', '2019-07-15 15:40:45'),
(10, 1, 22, 2, 0, '', 'aaa', '', '', '', 'aaa', 'm.rabiul09@gmail.com', '01717677966', '2222', '', '2019-07-15 15:47:36'),
(11, 1, 22, 2, 0, 'green tour', 'aaa', '', '', '', 'dhaka', 'm.rabiul09@gmail.com', '01717677966', '2222', '', '2019-07-15 15:49:18'),
(13, 1, 0, 2, 0, '', 'aaa', '', '', '', 'aaa', 'aaa', 'aaa', 'aa', '', '2019-07-15 18:49:25'),
(14, 1, 44, 2, 0, '', 'aaa', '', '', '', 'aaa', 'm.rabiul09@gmail.com', '01717677966', '444', 'https://www.youtube.com/watch?v=DG2jnLw_S7k', '2019-07-16 15:21:58'),
(15, 1, 22, 2, 0, '', 'sssssssssssssssss', '', '', '', 'sssssssssssss', 'm.rabiul09@gmail.com', '01717677966', '2222', 'Dhaka', '2019-07-18 19:26:47'),
(16, 1, 22, 2, 0, '', 'ghghgh', '', '', '', 'ghgh', 'm.rabiul09@gmail.com', '01717677966', '2222', 'Dhaka', '2019-07-21 16:31:09'),
(17, 1, 22, 2, 0, '', 'rrr', '', '', '', 'dhaka', 'm.rabiul09@gmail.com', '01717677966', '2222', 'Dhaka', '2019-07-21 16:32:59');

-- --------------------------------------------------------

--
-- Table structure for table `transport_details`
--

CREATE TABLE `transport_details` (
  `id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `total_transport` int(11) NOT NULL,
  `category_id` int(11) NOT NULL,
  `transport_type` int(11) NOT NULL,
  `transport_title` varchar(100) NOT NULL,
  `transport_description` text NOT NULL,
  `transport_image` varchar(255) NOT NULL,
  `transport_check_in` varchar(63) NOT NULL,
  `transport_check_out` varchar(63) NOT NULL,
  `transport_location` varchar(111) NOT NULL,
  `transport_email` varchar(63) NOT NULL,
  `transport_phone_no` varchar(111) NOT NULL,
  `transport_price` varchar(111) NOT NULL,
  `video` varchar(500) NOT NULL,
  `transport_time` varchar(100) NOT NULL,
  `transport_am_pm` varchar(63) NOT NULL,
  `date_added` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `transport_packages`
--

CREATE TABLE `transport_packages` (
  `id` int(11) NOT NULL,
  `guide_id` int(11) NOT NULL,
  `package_name` varchar(100) NOT NULL,
  `package_description` varchar(500) NOT NULL,
  `service_type` varchar(100) NOT NULL,
  `status` int(2) NOT NULL DEFAULT '0',
  `added_date` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `transport_stopage`
--

CREATE TABLE `transport_stopage` (
  `id` int(11) NOT NULL,
  `stopage_name` varchar(100) NOT NULL,
  `stopage_description` varchar(500) NOT NULL,
  `status` int(2) NOT NULL DEFAULT '0',
  `added_date` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `transport_stopage`
--

INSERT INTO `transport_stopage` (`id`, `stopage_name`, `stopage_description`, `status`, `added_date`) VALUES
(1, 'Tour Category 1 ', '', 0, '2019-07-12 15:55:53'),
(2, 'Tour Categiry 2 ', '', 0, '2019-07-12 15:58:37'),
(3, 'stopage_description', 'stopage_descriptionstopage_descriptionstopage_descriptionstopage_description', 0, '2019-07-28 17:30:40');

-- --------------------------------------------------------

--
-- Table structure for table `transport_stopage_relations`
--

CREATE TABLE `transport_stopage_relations` (
  `id` int(11) NOT NULL,
  `transport_id` int(11) NOT NULL,
  `service_id` int(11) NOT NULL,
  `service_type` varchar(100) NOT NULL,
  `status` int(2) NOT NULL DEFAULT '0',
  `added_date` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `umratinguser`
--

CREATE TABLE `umratinguser` (
  `id` int(11) NOT NULL,
  `upostid` int(12) NOT NULL,
  `rating` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `umratinguser`
--

INSERT INTO `umratinguser` (`id`, `upostid`, `rating`) VALUES
(1, 196, 3),
(2, 595, 4),
(3, 597, 3),
(4, 614, 5);

-- --------------------------------------------------------

--
-- Table structure for table `wp_awebooking_availability`
--

CREATE TABLE `wp_awebooking_availability` (
  `room_id` bigint(20) UNSIGNED NOT NULL DEFAULT '0',
  `year` smallint(5) UNSIGNED NOT NULL DEFAULT '0',
  `month` tinyint(3) UNSIGNED NOT NULL DEFAULT '0',
  `d1` bigint(20) UNSIGNED NOT NULL DEFAULT '0',
  `d2` bigint(20) UNSIGNED NOT NULL DEFAULT '0',
  `d3` bigint(20) UNSIGNED NOT NULL DEFAULT '0',
  `d4` bigint(20) UNSIGNED NOT NULL DEFAULT '0',
  `d5` bigint(20) UNSIGNED NOT NULL DEFAULT '0',
  `d6` bigint(20) UNSIGNED NOT NULL DEFAULT '0',
  `d7` bigint(20) UNSIGNED NOT NULL DEFAULT '0',
  `d8` bigint(20) UNSIGNED NOT NULL DEFAULT '0',
  `d9` bigint(20) UNSIGNED NOT NULL DEFAULT '0',
  `d10` bigint(20) UNSIGNED NOT NULL DEFAULT '0',
  `d11` bigint(20) UNSIGNED NOT NULL DEFAULT '0',
  `d12` bigint(20) UNSIGNED NOT NULL DEFAULT '0',
  `d13` bigint(20) UNSIGNED NOT NULL DEFAULT '0',
  `d14` bigint(20) UNSIGNED NOT NULL DEFAULT '0',
  `d15` bigint(20) UNSIGNED NOT NULL DEFAULT '0',
  `d16` bigint(20) UNSIGNED NOT NULL DEFAULT '0',
  `d17` bigint(20) UNSIGNED NOT NULL DEFAULT '0',
  `d18` bigint(20) UNSIGNED NOT NULL DEFAULT '0',
  `d19` bigint(20) UNSIGNED NOT NULL DEFAULT '0',
  `d20` bigint(20) UNSIGNED NOT NULL DEFAULT '0',
  `d21` bigint(20) UNSIGNED NOT NULL DEFAULT '0',
  `d22` bigint(20) UNSIGNED NOT NULL DEFAULT '0',
  `d23` bigint(20) UNSIGNED NOT NULL DEFAULT '0',
  `d24` bigint(20) UNSIGNED NOT NULL DEFAULT '0',
  `d25` bigint(20) UNSIGNED NOT NULL DEFAULT '0',
  `d26` bigint(20) UNSIGNED NOT NULL DEFAULT '0',
  `d27` bigint(20) UNSIGNED NOT NULL DEFAULT '0',
  `d28` bigint(20) UNSIGNED NOT NULL DEFAULT '0',
  `d29` bigint(20) UNSIGNED NOT NULL DEFAULT '0',
  `d30` bigint(20) UNSIGNED NOT NULL DEFAULT '0',
  `d31` bigint(20) UNSIGNED NOT NULL DEFAULT '0'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `wp_awebooking_booking`
--

CREATE TABLE `wp_awebooking_booking` (
  `room_id` bigint(20) UNSIGNED NOT NULL DEFAULT '0',
  `year` smallint(5) UNSIGNED NOT NULL DEFAULT '0',
  `month` tinyint(3) UNSIGNED NOT NULL DEFAULT '0',
  `d1` bigint(20) UNSIGNED NOT NULL DEFAULT '0',
  `d2` bigint(20) UNSIGNED NOT NULL DEFAULT '0',
  `d3` bigint(20) UNSIGNED NOT NULL DEFAULT '0',
  `d4` bigint(20) UNSIGNED NOT NULL DEFAULT '0',
  `d5` bigint(20) UNSIGNED NOT NULL DEFAULT '0',
  `d6` bigint(20) UNSIGNED NOT NULL DEFAULT '0',
  `d7` bigint(20) UNSIGNED NOT NULL DEFAULT '0',
  `d8` bigint(20) UNSIGNED NOT NULL DEFAULT '0',
  `d9` bigint(20) UNSIGNED NOT NULL DEFAULT '0',
  `d10` bigint(20) UNSIGNED NOT NULL DEFAULT '0',
  `d11` bigint(20) UNSIGNED NOT NULL DEFAULT '0',
  `d12` bigint(20) UNSIGNED NOT NULL DEFAULT '0',
  `d13` bigint(20) UNSIGNED NOT NULL DEFAULT '0',
  `d14` bigint(20) UNSIGNED NOT NULL DEFAULT '0',
  `d15` bigint(20) UNSIGNED NOT NULL DEFAULT '0',
  `d16` bigint(20) UNSIGNED NOT NULL DEFAULT '0',
  `d17` bigint(20) UNSIGNED NOT NULL DEFAULT '0',
  `d18` bigint(20) UNSIGNED NOT NULL DEFAULT '0',
  `d19` bigint(20) UNSIGNED NOT NULL DEFAULT '0',
  `d20` bigint(20) UNSIGNED NOT NULL DEFAULT '0',
  `d21` bigint(20) UNSIGNED NOT NULL DEFAULT '0',
  `d22` bigint(20) UNSIGNED NOT NULL DEFAULT '0',
  `d23` bigint(20) UNSIGNED NOT NULL DEFAULT '0',
  `d24` bigint(20) UNSIGNED NOT NULL DEFAULT '0',
  `d25` bigint(20) UNSIGNED NOT NULL DEFAULT '0',
  `d26` bigint(20) UNSIGNED NOT NULL DEFAULT '0',
  `d27` bigint(20) UNSIGNED NOT NULL DEFAULT '0',
  `d28` bigint(20) UNSIGNED NOT NULL DEFAULT '0',
  `d29` bigint(20) UNSIGNED NOT NULL DEFAULT '0',
  `d30` bigint(20) UNSIGNED NOT NULL DEFAULT '0',
  `d31` bigint(20) UNSIGNED NOT NULL DEFAULT '0'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `wp_awebooking_booking_itemmeta`
--

CREATE TABLE `wp_awebooking_booking_itemmeta` (
  `meta_id` bigint(20) UNSIGNED NOT NULL,
  `booking_item_id` bigint(20) UNSIGNED NOT NULL,
  `meta_key` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `meta_value` longtext COLLATE utf8mb4_unicode_ci
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `wp_awebooking_booking_items`
--

CREATE TABLE `wp_awebooking_booking_items` (
  `booking_item_id` bigint(20) UNSIGNED NOT NULL,
  `booking_item_name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `booking_item_type` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `booking_item_parent` bigint(20) UNSIGNED NOT NULL,
  `object_id` bigint(20) UNSIGNED NOT NULL,
  `booking_id` bigint(20) UNSIGNED NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `wp_awebooking_pricing`
--

CREATE TABLE `wp_awebooking_pricing` (
  `rate_id` bigint(20) UNSIGNED NOT NULL DEFAULT '0',
  `year` smallint(5) UNSIGNED NOT NULL DEFAULT '0',
  `month` tinyint(3) UNSIGNED NOT NULL DEFAULT '0',
  `d1` bigint(20) UNSIGNED NOT NULL DEFAULT '0',
  `d2` bigint(20) UNSIGNED NOT NULL DEFAULT '0',
  `d3` bigint(20) UNSIGNED NOT NULL DEFAULT '0',
  `d4` bigint(20) UNSIGNED NOT NULL DEFAULT '0',
  `d5` bigint(20) UNSIGNED NOT NULL DEFAULT '0',
  `d6` bigint(20) UNSIGNED NOT NULL DEFAULT '0',
  `d7` bigint(20) UNSIGNED NOT NULL DEFAULT '0',
  `d8` bigint(20) UNSIGNED NOT NULL DEFAULT '0',
  `d9` bigint(20) UNSIGNED NOT NULL DEFAULT '0',
  `d10` bigint(20) UNSIGNED NOT NULL DEFAULT '0',
  `d11` bigint(20) UNSIGNED NOT NULL DEFAULT '0',
  `d12` bigint(20) UNSIGNED NOT NULL DEFAULT '0',
  `d13` bigint(20) UNSIGNED NOT NULL DEFAULT '0',
  `d14` bigint(20) UNSIGNED NOT NULL DEFAULT '0',
  `d15` bigint(20) UNSIGNED NOT NULL DEFAULT '0',
  `d16` bigint(20) UNSIGNED NOT NULL DEFAULT '0',
  `d17` bigint(20) UNSIGNED NOT NULL DEFAULT '0',
  `d18` bigint(20) UNSIGNED NOT NULL DEFAULT '0',
  `d19` bigint(20) UNSIGNED NOT NULL DEFAULT '0',
  `d20` bigint(20) UNSIGNED NOT NULL DEFAULT '0',
  `d21` bigint(20) UNSIGNED NOT NULL DEFAULT '0',
  `d22` bigint(20) UNSIGNED NOT NULL DEFAULT '0',
  `d23` bigint(20) UNSIGNED NOT NULL DEFAULT '0',
  `d24` bigint(20) UNSIGNED NOT NULL DEFAULT '0',
  `d25` bigint(20) UNSIGNED NOT NULL DEFAULT '0',
  `d26` bigint(20) UNSIGNED NOT NULL DEFAULT '0',
  `d27` bigint(20) UNSIGNED NOT NULL DEFAULT '0',
  `d28` bigint(20) UNSIGNED NOT NULL DEFAULT '0',
  `d29` bigint(20) UNSIGNED NOT NULL DEFAULT '0',
  `d30` bigint(20) UNSIGNED NOT NULL DEFAULT '0',
  `d31` bigint(20) UNSIGNED NOT NULL DEFAULT '0'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `wp_awebooking_rooms`
--

CREATE TABLE `wp_awebooking_rooms` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `name` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `room_type` bigint(20) UNSIGNED NOT NULL,
  `order` bigint(20) UNSIGNED NOT NULL DEFAULT '0'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `wp_awebooking_tax_rates`
--

CREATE TABLE `wp_awebooking_tax_rates` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `rate` varchar(8) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `name` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `priority` bigint(20) UNSIGNED NOT NULL DEFAULT '0',
  `compound` int(1) NOT NULL DEFAULT '0'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `wp_booking`
--

CREATE TABLE `wp_booking` (
  `booking_id` bigint(20) UNSIGNED NOT NULL,
  `trash` bigint(10) NOT NULL DEFAULT '0',
  `sync_gid` varchar(200) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `is_new` bigint(10) NOT NULL DEFAULT '1',
  `status` varchar(200) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `sort_date` datetime DEFAULT NULL,
  `modification_date` datetime DEFAULT NULL,
  `form` text COLLATE utf8mb4_unicode_ci,
  `booking_type` bigint(10) NOT NULL DEFAULT '1'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `wp_booking`
--

INSERT INTO `wp_booking` (`booking_id`, `trash`, `sync_gid`, `is_new`, `status`, `sort_date`, `modification_date`, `form`, `booking_type`) VALUES
(1, 0, '', 1, '', '2019-04-05 00:00:00', '2019-04-03 12:56:36', 'text^name1^Jony~text^secondname1^Smith~text^email1^example-free@wpbookingcalendar.com~text^phone1^458-77-77~textarea^details1^Reserve a room with sea view', 1),
(2, 0, '', 1, '', '2019-04-04 00:00:00', '2019-04-03 06:58:36', 'text^name1^Milon~text^secondname1^Hossain~email^email1^milondiucse@gmail.com~text^phone1^01736699819~textarea^details1^Booking Calendar', 1);

-- --------------------------------------------------------

--
-- Table structure for table `wp_bookingdates`
--

CREATE TABLE `wp_bookingdates` (
  `booking_id` bigint(20) UNSIGNED NOT NULL,
  `booking_date` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `approved` bigint(20) UNSIGNED NOT NULL DEFAULT '0'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `wp_bookingdates`
--

INSERT INTO `wp_bookingdates` (`booking_id`, `booking_date`, `approved`) VALUES
(1, '2019-04-05 00:00:00', 0),
(1, '2019-04-06 00:00:00', 0),
(1, '2019-04-07 00:00:00', 0),
(2, '2019-04-04 00:00:00', 0),
(2, '2019-04-08 00:00:00', 0),
(2, '2019-04-09 00:00:00', 0),
(2, '2019-04-10 00:00:00', 0),
(2, '2019-04-11 00:00:00', 0),
(2, '2019-04-12 00:00:00', 0),
(2, '2019-04-13 00:00:00', 0),
(2, '2019-04-14 00:00:00', 0),
(2, '2019-04-15 00:00:00', 0),
(2, '2019-04-16 00:00:00', 0),
(2, '2019-04-17 00:00:00', 0),
(2, '2019-04-18 00:00:00', 0),
(2, '2019-04-19 00:00:00', 0),
(2, '2019-04-20 00:00:00', 0);

-- --------------------------------------------------------

--
-- Table structure for table `wp_booking_package_calendaraccount`
--

CREATE TABLE `wp_booking_package_calendaraccount` (
  `key` int(11) NOT NULL,
  `name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `type` varchar(50) COLLATE utf8mb4_unicode_ci DEFAULT 'day',
  `cost` int(11) DEFAULT '0',
  `maxAccountScheduleDay` int(11) DEFAULT '30',
  `unavailableDaysFromToday` int(11) DEFAULT '1',
  `numberOfRoomsAvailable` int(11) DEFAULT '1',
  `numberOfPeopleInRoom` int(11) DEFAULT '2',
  `includeChildrenInRoom` int(1) DEFAULT '0',
  `expressionsCheck` int(1) DEFAULT '0',
  `status` varchar(50) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `courseTitle` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `courseBool` int(1) DEFAULT '0',
  `hasMultipleServices` int(1) DEFAULT '0',
  `created` int(11) DEFAULT NULL,
  `googleCalendarID` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `idForGoogleWebhook` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `expirationForGoogleWebhook` int(1) DEFAULT '0',
  `uploadDate` int(11) DEFAULT NULL,
  `enableFixCalendar` int(11) DEFAULT '0',
  `yearForFixCalendar` int(11) DEFAULT '0',
  `monthForFixCalendar` int(11) DEFAULT '0',
  `displayRemainingCapacity` int(11) DEFAULT '0',
  `subscriptionIdForStripe` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT '',
  `enableSubscriptionForStripe` int(11) DEFAULT '0',
  `termsOfServiceForSubscription` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT '',
  `enableTermsOfServiceForSubscription` int(11) DEFAULT '0',
  `privacyPolicyForSubscription` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT '',
  `enablePrivacyPolicyForSubscription` int(11) DEFAULT '0',
  `displayRemainingCapacityInCalendar` int(1) DEFAULT '0',
  `displayThresholdOfRemainingCapacity` int(3) DEFAULT '50',
  `displayRemainingCapacityInCalendarAsNumber` int(1) DEFAULT '0',
  `displayRemainingCapacityHasMoreThenThreshold` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT '',
  `displayRemainingCapacityHasLessThenThreshold` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT '',
  `displayRemainingCapacityHas0` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT '',
  `startOfWeek` int(1) DEFAULT '0',
  `ical` int(1) DEFAULT '0',
  `icalToken` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT '0',
  `cancellationOfBooking` int(1) DEFAULT '0',
  `displayDetailsOfCanceled` int(1) DEFAULT '1',
  `allowCancellationVisitor` int(1) DEFAULT '0',
  `allowCancellationUser` int(1) DEFAULT '0',
  `refuseCancellationOfBooking` varchar(20) COLLATE utf8mb4_unicode_ci DEFAULT 'not_refuse',
  `preparationTime` int(1) DEFAULT '0',
  `positionPreparationTime` varchar(20) COLLATE utf8mb4_unicode_ci DEFAULT 'before_after',
  `timezone` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT 'none'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `wp_booking_package_calendaraccount`
--

INSERT INTO `wp_booking_package_calendaraccount` (`key`, `name`, `type`, `cost`, `maxAccountScheduleDay`, `unavailableDaysFromToday`, `numberOfRoomsAvailable`, `numberOfPeopleInRoom`, `includeChildrenInRoom`, `expressionsCheck`, `status`, `courseTitle`, `courseBool`, `hasMultipleServices`, `created`, `googleCalendarID`, `idForGoogleWebhook`, `expirationForGoogleWebhook`, `uploadDate`, `enableFixCalendar`, `yearForFixCalendar`, `monthForFixCalendar`, `displayRemainingCapacity`, `subscriptionIdForStripe`, `enableSubscriptionForStripe`, `termsOfServiceForSubscription`, `enableTermsOfServiceForSubscription`, `privacyPolicyForSubscription`, `enablePrivacyPolicyForSubscription`, `displayRemainingCapacityInCalendar`, `displayThresholdOfRemainingCapacity`, `displayRemainingCapacityInCalendarAsNumber`, `displayRemainingCapacityHasMoreThenThreshold`, `displayRemainingCapacityHasLessThenThreshold`, `displayRemainingCapacityHas0`, `startOfWeek`, `ical`, `icalToken`, `cancellationOfBooking`, `displayDetailsOfCanceled`, `allowCancellationVisitor`, `allowCancellationUser`, `refuseCancellationOfBooking`, `preparationTime`, `positionPreparationTime`, `timezone`) VALUES
(1, 'First Calendar', 'day', 0, 30, 1, 1, 2, 0, 0, 'open', NULL, 0, 0, 1554286000, NULL, NULL, 0, 1554286000, 0, 0, 0, 0, '', 0, '', 0, '', 0, 0, 50, 0, '', '', '', 0, 0, '969fdd54dd343a80cb85cf9c5a42115898c43e37', 0, 1, 0, 0, 'not_refuse', 0, 'before_after', 'UTC'),
(2, 'First Calendar for hotel', 'hotel', 0, 30, 1, 5, 2, 1, 0, 'open', NULL, 0, 0, 1554286000, NULL, NULL, 0, 1554286000, 0, 0, 0, 0, '', 0, '', 0, '', 0, 0, 50, 0, '', '', '', 0, 0, '969fdd54dd343a80cb85cf9c5a42115898c43e37', 0, 1, 0, 0, 'not_refuse', 0, 'before_after', 'UTC'),
(3, 'New Calendar', 'day', 0, 30, 0, 1, 2, 0, 0, 'open', '', 0, 0, 1554286333, NULL, NULL, 0, 1554286333, 0, 2019, 0, 0, '', 0, '', 0, '', 0, 0, 10, 0, '{\"symbol\":\"\",\"color\":\"#969696\"}', '{\"symbol\":\"\",\"color\":\"#969696\"}', '{\"symbol\":\"\",\"color\":\"#969696\"}', 0, 0, '9222dbf17e0815039dd37606f9cb0735a1889b8d', 0, 1, 0, 0, 'not_refuse', 0, 'before_after', 'UTC'),
(4, 'New Calendar', 'hotel', 0, 30, 0, 58, 2, 1, 2, 'open', '', 0, 0, 1554286775, NULL, NULL, 0, 1554286775, 1, 2019, 0, 0, '', 0, '', 0, '', 0, 0, 10, 0, '{\"symbol\":\"A phrase or symbol on a day when the remaining capacity has more than threshold\",\"color\":\"#969696\"}', '{\"symbol\":\"A phrase or symbol on a day when the remaining capacity has more than threshold\",\"color\":\"#969696\"}', '{\"symbol\":\"10\",\"color\":\"#969696\"}', 0, 0, '63587c6dca0066fd05c4823ea2ebddaa9b11c47d', 0, 1, 0, 0, 'not_refuse', 0, 'before_after', 'UTC'),
(5, 'First Calendar for hotel', 'hotel', 0, 30, 1, 5, 2, 1, 0, 'open', NULL, 0, 0, 1554286000, NULL, NULL, 0, 1554286000, 0, 0, 0, 0, '', 0, '', 0, '', 0, 0, 50, 0, '', '', '', 0, 0, '969fdd54dd343a80cb85cf9c5a42115898c43e37', 0, 1, 0, 0, 'not_refuse', 0, 'before_after', 'UTC');

-- --------------------------------------------------------

--
-- Table structure for table `wp_booking_package_coursedata`
--

CREATE TABLE `wp_booking_package_coursedata` (
  `key` int(11) NOT NULL,
  `accountKey` int(11) NOT NULL,
  `name` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `time` int(11) DEFAULT NULL,
  `cost` float DEFAULT NULL,
  `active` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `ranking` int(11) NOT NULL,
  `selectOptions` int(11) DEFAULT '0',
  `options` text COLLATE utf8mb4_unicode_ci,
  `timeToProvide` text COLLATE utf8mb4_unicode_ci
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `wp_booking_package_emailsetting`
--

CREATE TABLE `wp_booking_package_emailsetting` (
  `key` int(11) NOT NULL,
  `accountKey` int(11) NOT NULL,
  `mail_id` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `enable` int(1) DEFAULT '1',
  `format` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT 'text',
  `subject` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `content` text COLLATE utf8mb4_unicode_ci,
  `data` text COLLATE utf8mb4_unicode_ci
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `wp_booking_package_emailsetting`
--

INSERT INTO `wp_booking_package_emailsetting` (`key`, `accountKey`, `mail_id`, `enable`, `format`, `subject`, `content`, `data`) VALUES
(1, 1, 'mail_new_admin', 1, 'text', NULL, NULL, '1554286016'),
(2, 1, 'mail_approved', 1, 'text', NULL, NULL, '1554286016'),
(3, 1, 'mail_pending', 1, 'text', NULL, NULL, '1554286016'),
(4, 1, 'mail_deleted', 1, 'text', NULL, NULL, '1554286016'),
(5, 1, 'mail_canceled_by_visitor_user', 1, 'text', NULL, NULL, '1554286016'),
(6, 2, 'mail_new_admin', 1, 'text', NULL, NULL, '1554286025'),
(7, 2, 'mail_approved', 1, 'text', NULL, NULL, '1554286025'),
(8, 2, 'mail_pending', 1, 'text', NULL, NULL, '1554286025'),
(9, 2, 'mail_deleted', 1, 'text', NULL, NULL, '1554286025'),
(10, 2, 'mail_canceled_by_visitor_user', 1, 'text', NULL, NULL, '1554286025'),
(11, 3, 'mail_new_admin', 1, 'text', NULL, NULL, '1554286412'),
(12, 3, 'mail_approved', 1, 'text', NULL, NULL, '1554286412'),
(13, 3, 'mail_pending', 1, 'text', NULL, NULL, '1554286413'),
(14, 3, 'mail_deleted', 1, 'text', NULL, NULL, '1554286413'),
(15, 3, 'mail_canceled_by_visitor_user', 1, 'text', NULL, NULL, '1554286413'),
(16, 4, 'mail_new_admin', 1, 'text', NULL, NULL, '1554286889'),
(17, 4, 'mail_approved', 1, 'text', NULL, NULL, '1554286889'),
(18, 4, 'mail_pending', 1, 'text', NULL, NULL, '1554286889'),
(19, 4, 'mail_deleted', 1, 'text', NULL, NULL, '1554286889'),
(20, 4, 'mail_canceled_by_visitor_user', 1, 'text', NULL, NULL, '1554286889'),
(21, 5, 'mail_new_admin', 1, 'text', NULL, NULL, '1554286025'),
(22, 5, 'mail_approved', 1, 'text', NULL, NULL, '1554286025'),
(23, 5, 'mail_pending', 1, 'text', NULL, NULL, '1554286025'),
(24, 5, 'mail_deleted', 1, 'text', NULL, NULL, '1554286025'),
(25, 5, 'mail_canceled_by_visitor_user', 1, 'text', NULL, NULL, '1554286025');

-- --------------------------------------------------------

--
-- Table structure for table `wp_booking_package_form`
--

CREATE TABLE `wp_booking_package_form` (
  `key` int(11) NOT NULL,
  `accountKey` int(11) NOT NULL,
  `data` text COLLATE utf8mb4_unicode_ci
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `wp_booking_package_form`
--

INSERT INTO `wp_booking_package_form` (`key`, `accountKey`, `data`) VALUES
(1, 1, '[{\"id\":\"firstname\",\"name\":\"First name\",\"value\":\"\",\"type\":\"TEXT\",\"active\":\"true\",\"options\":\"\",\"required\":\"true\",\"isName\":\"true\",\"isAddress\":\"false\",\"isEmail\":\"false\",\"isTerms\":\"false\"},{\"id\":\"lastname\",\"name\":\"Last name\",\"value\":\"\",\"type\":\"TEXT\",\"active\":\"true\",\"options\":\"\",\"required\":\"true\",\"isName\":\"true\",\"isAddress\":\"false\",\"isEmail\":\"false\",\"isTerms\":\"false\"},{\"id\":\"email\",\"name\":\"Email\",\"value\":\"\",\"type\":\"TEXT\",\"active\":\"true\",\"options\":\"\",\"required\":\"true\",\"isName\":\"false\",\"isAddress\":\"false\",\"isEmail\":\"true\",\"isTerms\":\"false\"},{\"id\":\"phone\",\"name\":\"Phone\",\"value\":\"\",\"type\":\"TEXT\",\"active\":\"true\",\"options\":\"\",\"required\":\"true\",\"isName\":\"false\",\"isAddress\":\"false\",\"isEmail\":\"false\",\"isTerms\":\"false\"},{\"id\":\"zip\",\"name\":\"Zip\",\"value\":\"\",\"type\":\"TEXT\",\"options\":\"\",\"required\":\"false\",\"isName\":\"false\",\"isAddress\":\"false\",\"isEmail\":\"false\",\"isTerms\":\"false\"},{\"id\":\"address\",\"name\":\"Address\",\"value\":\"\",\"type\":\"TEXT\",\"active\":\"true\",\"options\":\"\",\"required\":\"false\",\"isName\":\"false\",\"isAddress\":\"true\",\"isEmail\":\"false\",\"isTerms\":\"false\"},{\"id\":\"terms\",\"name\":\"Terms of Service\",\"value\":\"\",\"type\":\"CHECK\",\"active\":\"true\",\"options\":\"I agree\",\"required\":\"false\",\"isName\":\"false\",\"isAddress\":\"true\",\"isEmail\":\"false\",\"isTerms\":\"true\"}]'),
(2, 2, '[{\"id\":\"firstname\",\"name\":\"First name\",\"value\":\"\",\"type\":\"TEXT\",\"active\":\"true\",\"options\":\"\",\"required\":\"true\",\"isName\":\"true\",\"isAddress\":\"false\",\"isEmail\":\"false\",\"isTerms\":\"false\"},{\"id\":\"lastname\",\"name\":\"Last name\",\"value\":\"\",\"type\":\"TEXT\",\"active\":\"true\",\"options\":\"\",\"required\":\"true\",\"isName\":\"true\",\"isAddress\":\"false\",\"isEmail\":\"false\",\"isTerms\":\"false\"},{\"id\":\"email\",\"name\":\"Email\",\"value\":\"\",\"type\":\"TEXT\",\"active\":\"true\",\"options\":\"\",\"required\":\"true\",\"isName\":\"false\",\"isAddress\":\"false\",\"isEmail\":\"true\",\"isTerms\":\"false\"},{\"id\":\"phone\",\"name\":\"Phone\",\"value\":\"\",\"type\":\"TEXT\",\"active\":\"true\",\"options\":\"\",\"required\":\"true\",\"isName\":\"false\",\"isAddress\":\"false\",\"isEmail\":\"false\",\"isTerms\":\"false\"},{\"id\":\"zip\",\"name\":\"Zip\",\"value\":\"\",\"type\":\"TEXT\",\"options\":\"\",\"required\":\"false\",\"isName\":\"false\",\"isAddress\":\"false\",\"isEmail\":\"false\",\"isTerms\":\"false\"},{\"id\":\"address\",\"name\":\"Address\",\"value\":\"\",\"type\":\"TEXT\",\"active\":\"true\",\"options\":\"\",\"required\":\"false\",\"isName\":\"false\",\"isAddress\":\"true\",\"isEmail\":\"false\",\"isTerms\":\"false\"},{\"id\":\"terms\",\"name\":\"Terms of Service\",\"value\":\"\",\"type\":\"CHECK\",\"active\":\"true\",\"options\":\"I agree\",\"required\":\"false\",\"isName\":\"false\",\"isAddress\":\"true\",\"isEmail\":\"false\",\"isTerms\":\"true\"}]'),
(3, 3, '[{\"id\":\"firstname\",\"name\":\"First name\",\"value\":\"\",\"type\":\"TEXT\",\"active\":\"true\",\"options\":\"\",\"required\":\"true\",\"isName\":\"true\",\"isAddress\":\"false\",\"isEmail\":\"false\",\"isTerms\":\"false\"},{\"id\":\"lastname\",\"name\":\"Last name\",\"value\":\"\",\"type\":\"TEXT\",\"active\":\"true\",\"options\":\"\",\"required\":\"true\",\"isName\":\"true\",\"isAddress\":\"false\",\"isEmail\":\"false\",\"isTerms\":\"false\"},{\"id\":\"email\",\"name\":\"Email\",\"value\":\"\",\"type\":\"TEXT\",\"active\":\"true\",\"options\":\"\",\"required\":\"true\",\"isName\":\"false\",\"isAddress\":\"false\",\"isEmail\":\"true\",\"isTerms\":\"false\"},{\"id\":\"phone\",\"name\":\"Phone\",\"value\":\"\",\"type\":\"TEXT\",\"active\":\"true\",\"options\":\"\",\"required\":\"true\",\"isName\":\"false\",\"isAddress\":\"false\",\"isEmail\":\"false\",\"isTerms\":\"false\"},{\"id\":\"zip\",\"name\":\"Zip\",\"value\":\"\",\"type\":\"TEXT\",\"options\":\"\",\"required\":\"false\",\"isName\":\"false\",\"isAddress\":\"false\",\"isEmail\":\"false\",\"isTerms\":\"false\"},{\"id\":\"address\",\"name\":\"Address\",\"value\":\"\",\"type\":\"TEXT\",\"active\":\"true\",\"options\":\"\",\"required\":\"false\",\"isName\":\"false\",\"isAddress\":\"true\",\"isEmail\":\"false\",\"isTerms\":\"false\"},{\"id\":\"terms\",\"name\":\"Terms of Service\",\"value\":\"\",\"type\":\"CHECK\",\"active\":\"true\",\"options\":\"I agree\",\"required\":\"false\",\"isName\":\"false\",\"isAddress\":\"true\",\"isEmail\":\"false\",\"isTerms\":\"true\"}]'),
(4, 4, '[{\"id\":\"firstname\",\"name\":\"First name\",\"value\":\"\",\"type\":\"TEXT\",\"active\":\"true\",\"options\":\"\",\"required\":\"true\",\"isName\":\"true\",\"isAddress\":\"false\",\"isEmail\":\"false\",\"isTerms\":\"false\"},{\"id\":\"lastname\",\"name\":\"Last name\",\"value\":\"\",\"type\":\"TEXT\",\"active\":\"true\",\"options\":\"\",\"required\":\"true\",\"isName\":\"true\",\"isAddress\":\"false\",\"isEmail\":\"false\",\"isTerms\":\"false\"},{\"id\":\"email\",\"name\":\"Email\",\"value\":\"\",\"type\":\"TEXT\",\"active\":\"true\",\"options\":\"\",\"required\":\"true\",\"isName\":\"false\",\"isAddress\":\"false\",\"isEmail\":\"true\",\"isTerms\":\"false\"},{\"id\":\"phone\",\"name\":\"Phone\",\"value\":\"\",\"type\":\"TEXT\",\"active\":\"true\",\"options\":\"\",\"required\":\"true\",\"isName\":\"false\",\"isAddress\":\"false\",\"isEmail\":\"false\",\"isTerms\":\"false\"},{\"id\":\"zip\",\"name\":\"Zip\",\"value\":\"\",\"type\":\"TEXT\",\"options\":\"\",\"required\":\"false\",\"isName\":\"false\",\"isAddress\":\"false\",\"isEmail\":\"false\",\"isTerms\":\"false\"},{\"id\":\"address\",\"name\":\"Address\",\"value\":\"\",\"type\":\"TEXT\",\"active\":\"true\",\"options\":\"\",\"required\":\"false\",\"isName\":\"false\",\"isAddress\":\"true\",\"isEmail\":\"false\",\"isTerms\":\"false\"},{\"id\":\"terms\",\"name\":\"Terms of Service\",\"value\":\"\",\"type\":\"CHECK\",\"active\":\"true\",\"options\":\"I agree\",\"required\":\"false\",\"isName\":\"false\",\"isAddress\":\"true\",\"isEmail\":\"false\",\"isTerms\":\"true\"}]'),
(5, 5, '[{\"id\":\"firstname\",\"name\":\"First name\",\"value\":\"\",\"type\":\"TEXT\",\"active\":\"true\",\"options\":\"\",\"required\":\"true\",\"isName\":\"true\",\"isAddress\":\"false\",\"isEmail\":\"false\",\"isTerms\":\"false\"},{\"id\":\"lastname\",\"name\":\"Last name\",\"value\":\"\",\"type\":\"TEXT\",\"active\":\"true\",\"options\":\"\",\"required\":\"true\",\"isName\":\"true\",\"isAddress\":\"false\",\"isEmail\":\"false\",\"isTerms\":\"false\"},{\"id\":\"email\",\"name\":\"Email\",\"value\":\"\",\"type\":\"TEXT\",\"active\":\"true\",\"options\":\"\",\"required\":\"true\",\"isName\":\"false\",\"isAddress\":\"false\",\"isEmail\":\"true\",\"isTerms\":\"false\"},{\"id\":\"phone\",\"name\":\"Phone\",\"value\":\"\",\"type\":\"TEXT\",\"active\":\"true\",\"options\":\"\",\"required\":\"true\",\"isName\":\"false\",\"isAddress\":\"false\",\"isEmail\":\"false\",\"isTerms\":\"false\"},{\"id\":\"zip\",\"name\":\"Zip\",\"value\":\"\",\"type\":\"TEXT\",\"options\":\"\",\"required\":\"false\",\"isName\":\"false\",\"isAddress\":\"false\",\"isEmail\":\"false\",\"isTerms\":\"false\"},{\"id\":\"address\",\"name\":\"Address\",\"value\":\"\",\"type\":\"TEXT\",\"active\":\"true\",\"options\":\"\",\"required\":\"false\",\"isName\":\"false\",\"isAddress\":\"true\",\"isEmail\":\"false\",\"isTerms\":\"false\"},{\"id\":\"terms\",\"name\":\"Terms of Service\",\"value\":\"\",\"type\":\"CHECK\",\"active\":\"true\",\"options\":\"I agree\",\"required\":\"false\",\"isName\":\"false\",\"isAddress\":\"true\",\"isEmail\":\"false\",\"isTerms\":\"true\"}]');

-- --------------------------------------------------------

--
-- Table structure for table `wp_booking_package_guests`
--

CREATE TABLE `wp_booking_package_guests` (
  `key` int(11) NOT NULL,
  `accountKey` int(11) NOT NULL,
  `name` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `target` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT 'adult',
  `json` text COLLATE utf8mb4_unicode_ci,
  `ranking` int(11) NOT NULL,
  `required` int(1) DEFAULT '0'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `wp_booking_package_guests`
--

INSERT INTO `wp_booking_package_guests` (`key`, `accountKey`, `name`, `target`, `json`, `ranking`, `required`) VALUES
(1, 2, 'Number of adults', 'adult', '[{\"number\":1,\"price\":0,\"name\":\"1 adult\"},{\"number\":2,\"price\":0,\"name\":\"2 adults\"}]', 1, 1),
(2, 2, 'Number of children', 'children', '[{\"number\":1,\"price\":0,\"name\":\"1 child\"},{\"number\":2,\"price\":0,\"name\":\"2 children\"}]', 2, 0),
(3, 3, 'Number of adults', 'adult', '[{\"number\":1,\"price\":0,\"name\":\"1 adult\"},{\"number\":2,\"price\":0,\"name\":\"2 adults\"}]', 1, 1),
(4, 3, 'Number of children', 'children', '[{\"number\":1,\"price\":0,\"name\":\"1 child\"},{\"number\":2,\"price\":0,\"name\":\"2 children\"}]', 2, 0),
(5, 4, 'Number of adults', 'adult', '[{\"number\":1,\"price\":0,\"name\":\"1 adult\"},{\"number\":2,\"price\":0,\"name\":\"2 adults\"}]', 1, 1),
(6, 4, 'Number of children', 'children', '[{\"number\":1,\"price\":0,\"name\":\"1 child\"},{\"number\":2,\"price\":0,\"name\":\"2 children\"}]', 2, 0),
(7, 5, 'Number of adults', 'adult', '[{\"number\":1,\"price\":0,\"name\":\"1 adult\"},{\"number\":2,\"price\":0,\"name\":\"2 adults\"}]', 1, 1),
(8, 5, 'Number of children', 'children', '[{\"number\":1,\"price\":0,\"name\":\"1 child\"},{\"number\":2,\"price\":0,\"name\":\"2 children\"}]', 2, 0);

-- --------------------------------------------------------

--
-- Table structure for table `wp_booking_package_regular_holidays`
--

CREATE TABLE `wp_booking_package_regular_holidays` (
  `key` int(11) NOT NULL,
  `accountKey` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL,
  `day` int(1) DEFAULT NULL,
  `month` int(2) NOT NULL,
  `year` int(4) NOT NULL,
  `unixTime` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL,
  `status` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL,
  `update` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT ''
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `wp_booking_package_schedule`
--

CREATE TABLE `wp_booking_package_schedule` (
  `key` int(11) NOT NULL,
  `accountKey` int(11) NOT NULL,
  `unixTime` int(11) NOT NULL,
  `year` int(11) NOT NULL,
  `month` int(11) NOT NULL,
  `day` int(11) NOT NULL,
  `weekKey` int(11) NOT NULL,
  `hour` int(11) NOT NULL,
  `min` int(11) NOT NULL,
  `title` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `cost` float DEFAULT NULL,
  `capacity` int(11) NOT NULL,
  `remainder` int(11) NOT NULL,
  `deadlineTime` int(11) NOT NULL DEFAULT '0',
  `waitingRemainder` int(11) NOT NULL DEFAULT '0',
  `stop` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `holiday` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `uploadDate` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `wp_booking_package_schedule`
--

INSERT INTO `wp_booking_package_schedule` (`key`, `accountKey`, `unixTime`, `year`, `month`, `day`, `weekKey`, `hour`, `min`, `title`, `cost`, `capacity`, `remainder`, `deadlineTime`, `waitingRemainder`, `stop`, `holiday`, `uploadDate`) VALUES
(102, 2, 1557273600, 2019, 5, 8, 3, 0, 0, '', 0, 5, 5, 0, 0, 'false', 'false', 1554784212),
(105, 4, 1557273600, 2019, 5, 8, 3, 0, 0, '', 0, 58, 58, 0, 0, 'false', 'false', 1554784212),
(108, 5, 1557273600, 2019, 5, 8, 3, 0, 0, '', 0, 5, 5, 0, 0, 'false', 'false', 1554784212),
(109, 2, 1557360000, 2019, 5, 9, 4, 0, 0, '', 0, 5, 5, 0, 0, 'false', 'false', 1554873035),
(110, 4, 1557360000, 2019, 5, 9, 4, 0, 0, '', 0, 58, 58, 0, 0, 'false', 'false', 1554873035),
(111, 5, 1557360000, 2019, 5, 9, 4, 0, 0, '', 0, 5, 5, 0, 0, 'false', 'false', 1554873035),
(112, 2, 1557532800, 2019, 5, 11, 6, 0, 0, '', 0, 5, 5, 0, 0, 'false', 'false', 1557569829),
(113, 2, 1557619200, 2019, 5, 12, 0, 0, 0, '', 0, 5, 5, 0, 0, 'false', 'false', 1557569829),
(114, 2, 1557705600, 2019, 5, 13, 1, 0, 0, '', 0, 5, 5, 0, 0, 'false', 'false', 1557569829),
(115, 2, 1557792000, 2019, 5, 14, 2, 0, 0, '', 0, 5, 5, 0, 0, 'false', 'false', 1557569829),
(116, 2, 1557878400, 2019, 5, 15, 3, 0, 0, '', 0, 5, 5, 0, 0, 'false', 'false', 1557569829),
(117, 2, 1557964800, 2019, 5, 16, 4, 0, 0, '', 0, 5, 5, 0, 0, 'false', 'false', 1557569829),
(118, 2, 1558051200, 2019, 5, 17, 5, 0, 0, '', 0, 5, 5, 0, 0, 'false', 'false', 1557569829),
(119, 2, 1558137600, 2019, 5, 18, 6, 0, 0, '', 0, 5, 5, 0, 0, 'false', 'false', 1557569829),
(120, 2, 1558224000, 2019, 5, 19, 0, 0, 0, '', 0, 5, 5, 0, 0, 'false', 'false', 1557569829),
(121, 2, 1558310400, 2019, 5, 20, 1, 0, 0, '', 0, 5, 5, 0, 0, 'false', 'false', 1557569829),
(122, 2, 1558396800, 2019, 5, 21, 2, 0, 0, '', 0, 5, 5, 0, 0, 'false', 'false', 1557569829),
(123, 2, 1558483200, 2019, 5, 22, 3, 0, 0, '', 0, 5, 5, 0, 0, 'false', 'false', 1557569829),
(124, 2, 1558569600, 2019, 5, 23, 4, 0, 0, '', 0, 5, 5, 0, 0, 'false', 'false', 1557569829),
(125, 2, 1558656000, 2019, 5, 24, 5, 0, 0, '', 0, 5, 5, 0, 0, 'false', 'false', 1557569829),
(126, 2, 1558742400, 2019, 5, 25, 6, 0, 0, '', 0, 5, 5, 0, 0, 'false', 'false', 1557569829),
(127, 2, 1558828800, 2019, 5, 26, 0, 0, 0, '', 0, 5, 5, 0, 0, 'false', 'false', 1557569829),
(128, 2, 1558915200, 2019, 5, 27, 1, 0, 0, '', 0, 5, 5, 0, 0, 'false', 'false', 1557569829),
(129, 2, 1559001600, 2019, 5, 28, 2, 0, 0, '', 0, 5, 5, 0, 0, 'false', 'false', 1557569829),
(130, 2, 1559088000, 2019, 5, 29, 3, 0, 0, '', 0, 5, 5, 0, 0, 'false', 'false', 1557569829),
(131, 2, 1559174400, 2019, 5, 30, 4, 0, 0, '', 0, 5, 5, 0, 0, 'false', 'false', 1557569829),
(132, 2, 1559260800, 2019, 5, 31, 5, 0, 0, '', 0, 5, 5, 0, 0, 'false', 'false', 1557569829),
(133, 2, 1559347200, 2019, 6, 1, 6, 0, 0, '', 0, 5, 5, 0, 0, 'false', 'false', 1557569829),
(134, 2, 1559433600, 2019, 6, 2, 0, 0, 0, '', 0, 5, 5, 0, 0, 'false', 'false', 1557569829),
(135, 2, 1559520000, 2019, 6, 3, 1, 0, 0, '', 0, 5, 5, 0, 0, 'false', 'false', 1557569829),
(136, 2, 1559606400, 2019, 6, 4, 2, 0, 0, '', 0, 5, 5, 0, 0, 'false', 'false', 1557569829),
(137, 2, 1559692800, 2019, 6, 5, 3, 0, 0, '', 0, 5, 5, 0, 0, 'false', 'false', 1557569829),
(138, 2, 1559779200, 2019, 6, 6, 4, 0, 0, '', 0, 5, 5, 0, 0, 'false', 'false', 1557569829),
(139, 2, 1559865600, 2019, 6, 7, 5, 0, 0, '', 0, 5, 5, 0, 0, 'false', 'false', 1557569829),
(140, 2, 1559952000, 2019, 6, 8, 6, 0, 0, '', 0, 5, 5, 0, 0, 'false', 'false', 1557569829),
(141, 2, 1560038400, 2019, 6, 9, 0, 0, 0, '', 0, 5, 5, 0, 0, 'false', 'false', 1557569829),
(142, 4, 1557532800, 2019, 5, 11, 6, 0, 0, '', 0, 58, 58, 0, 0, 'false', 'false', 1557569829),
(143, 4, 1557619200, 2019, 5, 12, 0, 0, 0, '', 0, 58, 58, 0, 0, 'false', 'false', 1557569829),
(144, 4, 1557705600, 2019, 5, 13, 1, 0, 0, '', 0, 58, 58, 0, 0, 'false', 'false', 1557569829),
(145, 4, 1557792000, 2019, 5, 14, 2, 0, 0, '', 0, 58, 58, 0, 0, 'false', 'false', 1557569829),
(146, 4, 1557878400, 2019, 5, 15, 3, 0, 0, '', 0, 58, 58, 0, 0, 'false', 'false', 1557569829),
(147, 4, 1557964800, 2019, 5, 16, 4, 0, 0, '', 0, 58, 58, 0, 0, 'false', 'false', 1557569829),
(148, 4, 1558051200, 2019, 5, 17, 5, 0, 0, '', 0, 58, 58, 0, 0, 'false', 'false', 1557569829),
(149, 4, 1558137600, 2019, 5, 18, 6, 0, 0, '', 0, 58, 58, 0, 0, 'false', 'false', 1557569829),
(150, 4, 1558224000, 2019, 5, 19, 0, 0, 0, '', 0, 58, 58, 0, 0, 'false', 'false', 1557569829),
(151, 4, 1558310400, 2019, 5, 20, 1, 0, 0, '', 0, 58, 58, 0, 0, 'false', 'false', 1557569829),
(152, 4, 1558396800, 2019, 5, 21, 2, 0, 0, '', 0, 58, 58, 0, 0, 'false', 'false', 1557569829),
(153, 4, 1558483200, 2019, 5, 22, 3, 0, 0, '', 0, 58, 58, 0, 0, 'false', 'false', 1557569829),
(154, 4, 1558569600, 2019, 5, 23, 4, 0, 0, '', 0, 58, 58, 0, 0, 'false', 'false', 1557569829),
(155, 4, 1558656000, 2019, 5, 24, 5, 0, 0, '', 0, 58, 58, 0, 0, 'false', 'false', 1557569829),
(156, 4, 1558742400, 2019, 5, 25, 6, 0, 0, '', 0, 58, 58, 0, 0, 'false', 'false', 1557569829),
(157, 4, 1558828800, 2019, 5, 26, 0, 0, 0, '', 0, 58, 58, 0, 0, 'false', 'false', 1557569829),
(158, 4, 1558915200, 2019, 5, 27, 1, 0, 0, '', 0, 58, 58, 0, 0, 'false', 'false', 1557569829),
(159, 4, 1559001600, 2019, 5, 28, 2, 0, 0, '', 0, 58, 58, 0, 0, 'false', 'false', 1557569829),
(160, 4, 1559088000, 2019, 5, 29, 3, 0, 0, '', 0, 58, 58, 0, 0, 'false', 'false', 1557569829),
(161, 4, 1559174400, 2019, 5, 30, 4, 0, 0, '', 0, 58, 58, 0, 0, 'false', 'false', 1557569829),
(162, 4, 1559260800, 2019, 5, 31, 5, 0, 0, '', 0, 58, 58, 0, 0, 'false', 'false', 1557569829),
(163, 4, 1559347200, 2019, 6, 1, 6, 0, 0, '', 0, 58, 58, 0, 0, 'false', 'false', 1557569829),
(164, 4, 1559433600, 2019, 6, 2, 0, 0, 0, '', 0, 58, 58, 0, 0, 'false', 'false', 1557569829),
(165, 4, 1559520000, 2019, 6, 3, 1, 0, 0, '', 0, 58, 58, 0, 0, 'false', 'false', 1557569829),
(166, 4, 1559606400, 2019, 6, 4, 2, 0, 0, '', 0, 58, 58, 0, 0, 'false', 'false', 1557569829),
(167, 4, 1559692800, 2019, 6, 5, 3, 0, 0, '', 0, 58, 58, 0, 0, 'false', 'false', 1557569829),
(168, 4, 1559779200, 2019, 6, 6, 4, 0, 0, '', 0, 58, 58, 0, 0, 'false', 'false', 1557569829),
(169, 4, 1559865600, 2019, 6, 7, 5, 0, 0, '', 0, 58, 58, 0, 0, 'false', 'false', 1557569829),
(170, 4, 1559952000, 2019, 6, 8, 6, 0, 0, '', 0, 58, 58, 0, 0, 'false', 'false', 1557569829),
(171, 4, 1560038400, 2019, 6, 9, 0, 0, 0, '', 0, 58, 58, 0, 0, 'false', 'false', 1557569829),
(172, 5, 1557532800, 2019, 5, 11, 6, 0, 0, '', 0, 5, 5, 0, 0, 'false', 'false', 1557569829),
(173, 5, 1557619200, 2019, 5, 12, 0, 0, 0, '', 0, 5, 5, 0, 0, 'false', 'false', 1557569829),
(174, 5, 1557705600, 2019, 5, 13, 1, 0, 0, '', 0, 5, 5, 0, 0, 'false', 'false', 1557569829),
(175, 5, 1557792000, 2019, 5, 14, 2, 0, 0, '', 0, 5, 5, 0, 0, 'false', 'false', 1557569829),
(176, 5, 1557878400, 2019, 5, 15, 3, 0, 0, '', 0, 5, 5, 0, 0, 'false', 'false', 1557569829),
(177, 5, 1557964800, 2019, 5, 16, 4, 0, 0, '', 0, 5, 5, 0, 0, 'false', 'false', 1557569829),
(178, 5, 1558051200, 2019, 5, 17, 5, 0, 0, '', 0, 5, 5, 0, 0, 'false', 'false', 1557569829),
(179, 5, 1558137600, 2019, 5, 18, 6, 0, 0, '', 0, 5, 5, 0, 0, 'false', 'false', 1557569829),
(180, 5, 1558224000, 2019, 5, 19, 0, 0, 0, '', 0, 5, 5, 0, 0, 'false', 'false', 1557569829),
(181, 5, 1558310400, 2019, 5, 20, 1, 0, 0, '', 0, 5, 5, 0, 0, 'false', 'false', 1557569829),
(182, 5, 1558396800, 2019, 5, 21, 2, 0, 0, '', 0, 5, 5, 0, 0, 'false', 'false', 1557569829),
(183, 5, 1558483200, 2019, 5, 22, 3, 0, 0, '', 0, 5, 5, 0, 0, 'false', 'false', 1557569829),
(184, 5, 1558569600, 2019, 5, 23, 4, 0, 0, '', 0, 5, 5, 0, 0, 'false', 'false', 1557569829),
(185, 5, 1558656000, 2019, 5, 24, 5, 0, 0, '', 0, 5, 5, 0, 0, 'false', 'false', 1557569829),
(186, 5, 1558742400, 2019, 5, 25, 6, 0, 0, '', 0, 5, 5, 0, 0, 'false', 'false', 1557569829),
(187, 5, 1558828800, 2019, 5, 26, 0, 0, 0, '', 0, 5, 5, 0, 0, 'false', 'false', 1557569829),
(188, 5, 1558915200, 2019, 5, 27, 1, 0, 0, '', 0, 5, 5, 0, 0, 'false', 'false', 1557569829),
(189, 5, 1559001600, 2019, 5, 28, 2, 0, 0, '', 0, 5, 5, 0, 0, 'false', 'false', 1557569829),
(190, 5, 1559088000, 2019, 5, 29, 3, 0, 0, '', 0, 5, 5, 0, 0, 'false', 'false', 1557569829),
(191, 5, 1559174400, 2019, 5, 30, 4, 0, 0, '', 0, 5, 5, 0, 0, 'false', 'false', 1557569829),
(192, 5, 1559260800, 2019, 5, 31, 5, 0, 0, '', 0, 5, 5, 0, 0, 'false', 'false', 1557569829),
(193, 5, 1559347200, 2019, 6, 1, 6, 0, 0, '', 0, 5, 5, 0, 0, 'false', 'false', 1557569829),
(194, 5, 1559433600, 2019, 6, 2, 0, 0, 0, '', 0, 5, 5, 0, 0, 'false', 'false', 1557569829),
(195, 5, 1559520000, 2019, 6, 3, 1, 0, 0, '', 0, 5, 5, 0, 0, 'false', 'false', 1557569829),
(196, 5, 1559606400, 2019, 6, 4, 2, 0, 0, '', 0, 5, 5, 0, 0, 'false', 'false', 1557569829),
(197, 5, 1559692800, 2019, 6, 5, 3, 0, 0, '', 0, 5, 5, 0, 0, 'false', 'false', 1557569829),
(198, 5, 1559779200, 2019, 6, 6, 4, 0, 0, '', 0, 5, 5, 0, 0, 'false', 'false', 1557569829),
(199, 5, 1559865600, 2019, 6, 7, 5, 0, 0, '', 0, 5, 5, 0, 0, 'false', 'false', 1557569829),
(200, 5, 1559952000, 2019, 6, 8, 6, 0, 0, '', 0, 5, 5, 0, 0, 'false', 'false', 1557569829),
(201, 5, 1560038400, 2019, 6, 9, 0, 0, 0, '', 0, 5, 5, 0, 0, 'false', 'false', 1557569829),
(202, 2, 1560124800, 2019, 6, 10, 1, 0, 0, '', 0, 5, 5, 0, 0, 'false', 'false', 1557655709),
(203, 4, 1560124800, 2019, 6, 10, 1, 0, 0, '', 0, 58, 58, 0, 0, 'false', 'false', 1557655709),
(204, 5, 1560124800, 2019, 6, 10, 1, 0, 0, '', 0, 5, 5, 0, 0, 'false', 'false', 1557655709),
(205, 2, 1560211200, 2019, 6, 11, 2, 0, 0, '', 0, 5, 5, 0, 0, 'false', 'false', 1557987180),
(206, 2, 1560297600, 2019, 6, 12, 3, 0, 0, '', 0, 5, 5, 0, 0, 'false', 'false', 1557987180),
(207, 2, 1560384000, 2019, 6, 13, 4, 0, 0, '', 0, 5, 5, 0, 0, 'false', 'false', 1557987180),
(208, 2, 1560470400, 2019, 6, 14, 5, 0, 0, '', 0, 5, 5, 0, 0, 'false', 'false', 1557987180),
(209, 4, 1560211200, 2019, 6, 11, 2, 0, 0, '', 0, 58, 58, 0, 0, 'false', 'false', 1557987180),
(210, 4, 1560297600, 2019, 6, 12, 3, 0, 0, '', 0, 58, 58, 0, 0, 'false', 'false', 1557987180),
(211, 4, 1560384000, 2019, 6, 13, 4, 0, 0, '', 0, 58, 58, 0, 0, 'false', 'false', 1557987180),
(212, 4, 1560470400, 2019, 6, 14, 5, 0, 0, '', 0, 58, 58, 0, 0, 'false', 'false', 1557987180),
(213, 5, 1560211200, 2019, 6, 11, 2, 0, 0, '', 0, 5, 5, 0, 0, 'false', 'false', 1557987180),
(214, 5, 1560297600, 2019, 6, 12, 3, 0, 0, '', 0, 5, 5, 0, 0, 'false', 'false', 1557987180),
(215, 5, 1560384000, 2019, 6, 13, 4, 0, 0, '', 0, 5, 5, 0, 0, 'false', 'false', 1557987180),
(216, 5, 1560470400, 2019, 6, 14, 5, 0, 0, '', 0, 5, 5, 0, 0, 'false', 'false', 1557987180),
(217, 2, 1560556800, 2019, 6, 15, 6, 0, 0, '', 0, 5, 5, 0, 0, 'false', 'false', 1558254765),
(218, 2, 1560643200, 2019, 6, 16, 0, 0, 0, '', 0, 5, 5, 0, 0, 'false', 'false', 1558254765),
(219, 2, 1560729600, 2019, 6, 17, 1, 0, 0, '', 0, 5, 5, 0, 0, 'false', 'false', 1558254765),
(220, 4, 1560556800, 2019, 6, 15, 6, 0, 0, '', 0, 58, 58, 0, 0, 'false', 'false', 1558254765),
(221, 4, 1560643200, 2019, 6, 16, 0, 0, 0, '', 0, 58, 58, 0, 0, 'false', 'false', 1558254765),
(222, 4, 1560729600, 2019, 6, 17, 1, 0, 0, '', 0, 58, 58, 0, 0, 'false', 'false', 1558254765),
(223, 5, 1560556800, 2019, 6, 15, 6, 0, 0, '', 0, 5, 5, 0, 0, 'false', 'false', 1558254765),
(224, 5, 1560643200, 2019, 6, 16, 0, 0, 0, '', 0, 5, 5, 0, 0, 'false', 'false', 1558254765),
(225, 5, 1560729600, 2019, 6, 17, 1, 0, 0, '', 0, 5, 5, 0, 0, 'false', 'false', 1558254765),
(226, 2, 1560816000, 2019, 6, 18, 2, 0, 0, '', 0, 5, 5, 0, 0, 'false', 'false', 1558505244),
(227, 2, 1560902400, 2019, 6, 19, 3, 0, 0, '', 0, 5, 5, 0, 0, 'false', 'false', 1558505244),
(228, 2, 1560988800, 2019, 6, 20, 4, 0, 0, '', 0, 5, 5, 0, 0, 'false', 'false', 1558505244),
(229, 4, 1560816000, 2019, 6, 18, 2, 0, 0, '', 0, 58, 58, 0, 0, 'false', 'false', 1558505244),
(230, 4, 1560902400, 2019, 6, 19, 3, 0, 0, '', 0, 58, 58, 0, 0, 'false', 'false', 1558505244),
(231, 4, 1560988800, 2019, 6, 20, 4, 0, 0, '', 0, 58, 58, 0, 0, 'false', 'false', 1558505244),
(232, 5, 1560816000, 2019, 6, 18, 2, 0, 0, '', 0, 5, 5, 0, 0, 'false', 'false', 1558505244),
(233, 5, 1560902400, 2019, 6, 19, 3, 0, 0, '', 0, 5, 5, 0, 0, 'false', 'false', 1558505244),
(234, 5, 1560988800, 2019, 6, 20, 4, 0, 0, '', 0, 5, 5, 0, 0, 'false', 'false', 1558505244);

-- --------------------------------------------------------

--
-- Table structure for table `wp_booking_package_subscriptions`
--

CREATE TABLE `wp_booking_package_subscriptions` (
  `key` int(11) NOT NULL,
  `accountKey` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL,
  `name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `subscription` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `active` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `ranking` int(11) DEFAULT '1',
  `renewal` int(11) DEFAULT '1',
  `limit` int(11) DEFAULT '1',
  `numberOfTimes` int(11) DEFAULT '1'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `wp_booking_package_taxes`
--

CREATE TABLE `wp_booking_package_taxes` (
  `key` int(11) NOT NULL,
  `accountKey` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL,
  `name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `active` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `type` varchar(20) COLLATE utf8mb4_unicode_ci DEFAULT 'tax',
  `tax` varchar(20) COLLATE utf8mb4_unicode_ci DEFAULT 'tax_inclusive',
  `method` varchar(20) COLLATE utf8mb4_unicode_ci DEFAULT 'addition',
  `target` varchar(20) COLLATE utf8mb4_unicode_ci DEFAULT 'guest',
  `scope` varchar(20) COLLATE utf8mb4_unicode_ci DEFAULT 'day',
  `value` float DEFAULT '0',
  `ranking` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `wp_booking_package_templateschedule`
--

CREATE TABLE `wp_booking_package_templateschedule` (
  `key` int(11) NOT NULL,
  `accountKey` int(11) NOT NULL,
  `weekKey` int(11) NOT NULL,
  `hour` int(11) NOT NULL,
  `min` int(11) NOT NULL,
  `title` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `cost` int(11) DEFAULT NULL,
  `capacity` int(11) NOT NULL,
  `deadlineTime` int(11) NOT NULL DEFAULT '0',
  `stop` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `holiday` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `uploadDate` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `wp_booking_package_userpraivatedata`
--

CREATE TABLE `wp_booking_package_userpraivatedata` (
  `key` int(11) NOT NULL,
  `reserveTime` int(11) NOT NULL,
  `remainderTime` int(11) DEFAULT NULL,
  `remainderBool` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT 'false',
  `maintenanceTime` int(11) DEFAULT '0',
  `permission` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT 'private',
  `status` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `type` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT 'day',
  `accountKey` int(11) NOT NULL,
  `accountName` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `accountCost` int(11) DEFAULT NULL,
  `checkIn` int(11) DEFAULT '0',
  `checkOut` int(11) DEFAULT '0',
  `scheduleUnixTime` int(11) DEFAULT '0',
  `scheduleWeek` int(11) DEFAULT '0',
  `scheduleTitle` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `scheduleCost` int(11) DEFAULT NULL,
  `scheduleKey` int(11) DEFAULT NULL,
  `applicantCount` int(11) DEFAULT '1',
  `courseKey` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `courseTitle` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `courseName` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `courseTime` int(11) DEFAULT NULL,
  `courseCost` int(11) DEFAULT NULL,
  `options` text COLLATE utf8mb4_unicode_ci,
  `tax` int(11) DEFAULT '0',
  `payMode` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `payId` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `payName` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `payToken` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `currency` varchar(3) COLLATE utf8mb4_unicode_ci DEFAULT 'usd',
  `praivateData` text COLLATE utf8mb4_unicode_ci,
  `accommodationDetails` text COLLATE utf8mb4_unicode_ci,
  `iCalUIDforGoogleCalendar` varchar(60) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `iCalIDforGoogleCalendar` varchar(60) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `resultOfGoogleCalendar` int(1) DEFAULT NULL,
  `resultModeOfGoogleCalendar` varchar(60) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `cancellationToken` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `permalink` text COLLATE utf8mb4_unicode_ci,
  `preparation` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `taxes` text COLLATE utf8mb4_unicode_ci
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `wp_booking_package_users`
--

CREATE TABLE `wp_booking_package_users` (
  `key` int(11) NOT NULL,
  `status` int(1) DEFAULT NULL,
  `firstname` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL,
  `lastname` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL,
  `email` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL,
  `value` longtext COLLATE utf8mb4_unicode_ci,
  `user_activation_key` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT '',
  `subscription_list` longtext COLLATE utf8mb4_unicode_ci
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `wp_booking_package_webhook`
--

CREATE TABLE `wp_booking_package_webhook` (
  `key` int(11) NOT NULL,
  `target` varchar(20) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `server` text COLLATE utf8mb4_unicode_ci,
  `post` text COLLATE utf8mb4_unicode_ci,
  `json` text COLLATE utf8mb4_unicode_ci,
  `date` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `wp_bs_bookings`
--

CREATE TABLE `wp_bs_bookings` (
  `bookingID` int(10) NOT NULL,
  `calendarID` int(10) NOT NULL DEFAULT '0',
  `formID` int(10) NOT NULL DEFAULT '0',
  `startDate` int(11) NOT NULL DEFAULT '0',
  `endDate` int(11) NOT NULL DEFAULT '0',
  `createdDate` int(11) NOT NULL DEFAULT '0',
  `bookingData` text NOT NULL,
  `bookingStatus` tinytext NOT NULL,
  `bookingRead` varchar(1) NOT NULL DEFAULT '0'
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='WP Booking System - Bookings';

--
-- Dumping data for table `wp_bs_bookings`
--

INSERT INTO `wp_bs_bookings` (`bookingID`, `calendarID`, `formID`, `startDate`, `endDate`, `createdDate`, `bookingData`, `bookingStatus`, `bookingRead`) VALUES
(1, 1, 1, 1551830400, 1552003200, 1551851036, '{\"car\":\"bfdgfdgf\"}', 'accepted', '1'),
(2, 1, 1, 1552003200, 1552089600, 1551851579, '{\"car\":\"ghgh\"}', 'accepted', '1'),
(3, 1, 1, 1552089600, 1552176000, 1551858432, '{\"First Name\":\"Milon\",\"Last Name\":\"ho\",\"Call\":\"1222\",\"Email\":\"milondiucse@gmail.com\",\"Address\":\"mirpur\",\"City\":\"Dhaka\",\"Comments\":\"mirpur\"}', 'accepted', '1'),
(4, 1, 1, 1561939200, 1562198400, 1558803427, '{\"First Name\":\"fghfgh\",\"Last Name\":\"fghgfh\",\"Call\":\"2255\",\"Email\":\"milon@admin.com\",\"Address\":\"mirpur\",\"City\":\"dhaka\",\"Comments\":\"test\"}', 'accepted', '1');

-- --------------------------------------------------------

--
-- Table structure for table `wp_bs_calendars`
--

CREATE TABLE `wp_bs_calendars` (
  `calendarID` int(10) NOT NULL,
  `calendarTitle` text,
  `createdDate` int(11) DEFAULT NULL,
  `modifiedDate` int(11) DEFAULT NULL,
  `calendarData` text,
  `calendarLegend` text
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='WP Booking System - Calendars';

--
-- Dumping data for table `wp_bs_calendars`
--

INSERT INTO `wp_bs_calendars` (`calendarID`, `calendarTitle`, `createdDate`, `modifiedDate`, `calendarData`, `calendarLegend`) VALUES
(1, 'Umrah Cars Available & Booked', 1551847530, 1558803557, '{\"2019\":{\"3\":{\"2\":\"1\",\"3\":\"1\",\"7\":\"1\",\"9\":\"default\",\"10\":\"default\",\"11\":\"1\",\"description-8\":\"1500\",\"description-9\":\"200\",\"description-10\":\"100\"}}}', '{\"default\":{\"name\":{\"default\":\"Available\",\"hr\":\"Slobodno\",\"cs\":\"Volno\",\"da\":\"Ledigt\",\"nl\":\"Vrij\",\"en\":\"Available\",\"fr\":\"Libre\",\"de\":\"Frei\",\"hu\":\"Szabad\",\"it\":\"Libero\",\"ro\":\"Disponobil\",\"ru\":\"\\u0414\\u043e\\u0441\\u0442\\u0443\\u043f\\u043d\\u043e\",\"sk\":\"Vo\\u013en\\u00fd\",\"es\":\"Libre\",\"sv\":\"Ledigt\",\"uk\":\"B\\u0456\\u043b\\u044c\\u043d\\u043e\",\"no\":\"\"},\"color\":\"#DDFFCC\",\"splitColor\":false,\"bookable\":\"yes\"},\"1\":{\"name\":{\"default\":\"Booked\",\"hr\":\"Zauzeto\",\"cs\":\"Obsazeno\",\"da\":\"Booket\",\"nl\":\"Bezet\",\"en\":\"Booked\",\"fr\":\"Occup\\u00e9\",\"de\":\"Belegt\",\"hu\":\"Foglalt\",\"it\":\"Prenotato\",\"ro\":\"Rezervat\",\"ru\":\"\\u0417\\u0430\\u043d\\u044f\\u0442\\u043e\",\"sk\":\"Obsaden\\u00fd\",\"es\":\"Reservado\",\"sv\":\"Bokat\",\"uk\":\"\\u0417\\u0430\\u0439\\u043d\\u044f\\u0442\\u043e\",\"no\":\"\"},\"color\":\"#FFC0BD\",\"splitColor\":false,\"bookable\":false}}');

-- --------------------------------------------------------

--
-- Table structure for table `wp_bs_forms`
--

CREATE TABLE `wp_bs_forms` (
  `formID` int(10) NOT NULL,
  `formTitle` text,
  `formData` text,
  `formOptions` text
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='WP Booking System - Forms';

--
-- Dumping data for table `wp_bs_forms`
--

INSERT INTO `wp_bs_forms` (`formID`, `formTitle`, `formData`, `formOptions`) VALUES
(1, 'Book my Car', '{\"1\":{\"fieldId\":1,\"fieldName\":\"First Name\",\"fieldType\":\"text\",\"fieldOptions\":\"\",\"fieldRequired\":true,\"fieldLanguages\":{\"en\":\"First Name\"},\"fieldOptionsLanguages\":{\"en\":\"\"}},\"2\":{\"fieldId\":2,\"fieldName\":\"Last Name\",\"fieldType\":\"text\",\"fieldOptions\":\"\",\"fieldRequired\":true,\"fieldLanguages\":{\"en\":\"Last Name\"},\"fieldOptionsLanguages\":{\"en\":\"\"}},\"3\":{\"fieldId\":3,\"fieldName\":\"Call\",\"fieldType\":\"text\",\"fieldOptions\":\"\",\"fieldRequired\":\"false\",\"fieldLanguages\":{\"en\":\"call\"},\"fieldOptionsLanguages\":{\"en\":\"\"}},\"4\":{\"fieldId\":4,\"fieldName\":\"Email\",\"fieldType\":\"email\",\"fieldOptions\":\"\",\"fieldRequired\":true,\"fieldLanguages\":{\"en\":\"email\"},\"fieldOptionsLanguages\":{\"en\":\"\"}},\"5\":{\"fieldId\":5,\"fieldName\":\"Address\",\"fieldType\":\"text\",\"fieldOptions\":\"\",\"fieldRequired\":\"false\",\"fieldLanguages\":{\"en\":\"Address\"},\"fieldOptionsLanguages\":{\"en\":\"\"}},\"6\":{\"fieldId\":6,\"fieldName\":\"City\",\"fieldType\":\"text\",\"fieldOptions\":\"\",\"fieldRequired\":\"false\",\"fieldLanguages\":{\"en\":\"City\"},\"fieldOptionsLanguages\":{\"en\":\"\"}},\"7\":{\"fieldId\":7,\"fieldName\":\"Comments\",\"fieldType\":\"textarea\",\"fieldOptions\":\"\",\"fieldRequired\":\"false\",\"fieldLanguages\":{\"en\":\"Comments\"},\"fieldOptionsLanguages\":{\"en\":\"\"}}}', '{\"sendTo\":\"admin@admin.com\",\"confirmationMessage\":\"An order confirmation email tells your customer that you\\u2019ve received their order, you\\u2019re processing it, and that their order will be with them shortly.\",\"submitLabel\":{\"default\":\"button class=\\\\\\\\\\\\&quot;btn btn-primary\\\\\\\\\\\\&quot;\",\"en\":\"Book Now\"}}');

-- --------------------------------------------------------

--
-- Table structure for table `wp_commentmeta`
--

CREATE TABLE `wp_commentmeta` (
  `meta_id` bigint(20) UNSIGNED NOT NULL,
  `comment_id` bigint(20) UNSIGNED NOT NULL DEFAULT '0',
  `meta_key` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `meta_value` longtext COLLATE utf8mb4_unicode_ci
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `wp_commentmeta`
--

INSERT INTO `wp_commentmeta` (`meta_id`, `comment_id`, `meta_key`, `meta_value`) VALUES
(6, 3, 'rating', '4'),
(7, 3, 'verified', '0');

-- --------------------------------------------------------

--
-- Table structure for table `wp_comments`
--

CREATE TABLE `wp_comments` (
  `comment_ID` bigint(20) UNSIGNED NOT NULL,
  `comment_post_ID` bigint(20) UNSIGNED NOT NULL DEFAULT '0',
  `comment_author` tinytext COLLATE utf8mb4_unicode_ci NOT NULL,
  `comment_author_email` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `comment_author_url` varchar(200) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `comment_author_IP` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `comment_date` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `comment_date_gmt` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `comment_content` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `comment_karma` int(11) NOT NULL DEFAULT '0',
  `comment_approved` varchar(20) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '1',
  `comment_agent` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `comment_type` varchar(20) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `comment_parent` bigint(20) UNSIGNED NOT NULL DEFAULT '0',
  `user_id` bigint(20) UNSIGNED NOT NULL DEFAULT '0',
  `comment_title` varchar(400) COLLATE utf8mb4_unicode_ci NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `wp_comments`
--

INSERT INTO `wp_comments` (`comment_ID`, `comment_post_ID`, `comment_author`, `comment_author_email`, `comment_author_url`, `comment_author_IP`, `comment_date`, `comment_date_gmt`, `comment_content`, `comment_karma`, `comment_approved`, `comment_agent`, `comment_type`, `comment_parent`, `user_id`, `comment_title`) VALUES
(1, 2, 'Admiv', '', '', '', '0000-00-00 00:00:00', '0000-00-00 00:00:00', 'asasas aasasas aasasas aasasas aasasas aasasas aasasas aasasas aasasas aasasas aasasas aasasas aasasas aasasas aasasas aasasas aasasas aasasas aasasas aasasas aasasas aasasas aasasas aasasas a', 0, '1', '', 'hotels', 0, 1, 'excelant'),
(2, 2, 'user', 'm.rabiul09@gmail.com', '', '', '0000-00-00 00:00:00', '0000-00-00 00:00:00', 'asasas aasasas aasasas aasasas aasasas aasasas aasasas aasasas aasasas aasasas aasasas aasasas aasasas aasasas aasasas aasasas aasasas aasasas aasasas aasasas aasasas aasasas aasasas aasasas aasasas aasasas aasasas aasasas aasasas aasasas aasasas aasasas a', 0, '1', '', 'hotels', 0, 1, 'good'),
(3, 4, '', '', '', '', '0000-00-00 00:00:00', '0000-00-00 00:00:00', '', 0, '1', '', 'transports', 0, 0, ''),
(4, 4, '', '', '', '', '0000-00-00 00:00:00', '0000-00-00 00:00:00', '', 0, '1', '', 'transports', 0, 0, ''),
(5, 4, '', '', '', '', '0000-00-00 00:00:00', '0000-00-00 00:00:00', '', 0, '1', '', 'transports', 0, 0, ''),
(6, 4, '', '', '', '', '0000-00-00 00:00:00', '0000-00-00 00:00:00', '', 0, '1', '', 'transports', 0, 0, ''),
(7, 4, '', '', '', '', '0000-00-00 00:00:00', '0000-00-00 00:00:00', '', 0, '1', '', 'transports', 0, 0, ''),
(8, 4, '', '', '', '', '0000-00-00 00:00:00', '0000-00-00 00:00:00', '', 0, '1', '', 'transports', 0, 0, ''),
(9, 4, '', '', '', '', '0000-00-00 00:00:00', '0000-00-00 00:00:00', 'ewewe', 0, '1', '', 'transports', 0, 0, ''),
(10, 4, '', '', '', '', '0000-00-00 00:00:00', '0000-00-00 00:00:00', 'ewewe', 0, '1', '', 'transports', 0, 0, ''),
(11, 4, '', 'asasas', '', '', '0000-00-00 00:00:00', '0000-00-00 00:00:00', 'asas', 0, '1', '', 'transports', 0, 0, 'asasas');

-- --------------------------------------------------------

--
-- Table structure for table `wp_galcategory`
--

CREATE TABLE `wp_galcategory` (
  `catid` int(11) NOT NULL,
  `categorynm` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `catimage` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `date` date NOT NULL,
  `publish` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `wp_galimage`
--

CREATE TABLE `wp_galimage` (
  `imgid` int(11) NOT NULL,
  `catid` int(11) NOT NULL,
  `imagenm` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `imagecrop` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `publish` int(11) NOT NULL,
  `catpub` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `wp_gdgallerygalleries`
--

CREATE TABLE `wp_gdgallerygalleries` (
  `id_gallery` int(11) UNSIGNED NOT NULL,
  `name` varchar(255) DEFAULT NULL,
  `description` text,
  `ordering` int(11) NOT NULL DEFAULT '0',
  `order_by` int(1) NOT NULL DEFAULT '0',
  `sort_by` int(1) NOT NULL DEFAULT '0',
  `show_title` int(1) NOT NULL DEFAULT '0',
  `display_type` int(1) NOT NULL DEFAULT '0',
  `view_type` int(1) NOT NULL DEFAULT '0',
  `position` enum('center','left','right') DEFAULT 'center',
  `hover_effect` int(1) NOT NULL DEFAULT '0',
  `items_per_page` int(3) NOT NULL DEFAULT '5',
  `custom_css` text,
  `ctime` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `wp_gdgallerygalleries`
--

INSERT INTO `wp_gdgallerygalleries` (`id_gallery`, `name`, `description`, `ordering`, `order_by`, `sort_by`, `show_title`, `display_type`, `view_type`, `position`, `hover_effect`, `items_per_page`, `custom_css`, `ctime`) VALUES
(1, 'My First Gallery', NULL, 0, 0, 0, 0, 0, 0, 'center', 0, 5, '#gdgallery_container_1{}', '2019-05-25 19:17:32');

-- --------------------------------------------------------

--
-- Table structure for table `wp_gdgalleryimages`
--

CREATE TABLE `wp_gdgalleryimages` (
  `id_image` int(11) UNSIGNED NOT NULL,
  `id_gallery` int(11) UNSIGNED NOT NULL,
  `id_post` int(11) UNSIGNED DEFAULT '0',
  `name` varchar(255) DEFAULT NULL,
  `description` text,
  `ordering` int(11) NOT NULL DEFAULT '0',
  `link` varchar(255) DEFAULT NULL,
  `url` varchar(255) NOT NULL,
  `target` enum('_blank','_self','_top','_parent') DEFAULT '_blank',
  `type` enum('image','youtube','vimeo') DEFAULT 'image',
  `ctime` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `video_id` varchar(50) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `wp_gdgalleryimages`
--

INSERT INTO `wp_gdgalleryimages` (`id_image`, `id_gallery`, `id_post`, `name`, `description`, `ordering`, `link`, `url`, `target`, `type`, `ctime`, `video_id`) VALUES
(1, 1, 604, '1', NULL, 1, NULL, 'https://technovicinity.com/development/wordpress/milon/travel/wp-content/plugins/photo-gallery-image/resources/assets/images/project/1.jpg', '_blank', 'image', '2019-05-25 19:17:32', NULL),
(2, 1, 603, '2', NULL, 2, NULL, 'https://technovicinity.com/development/wordpress/milon/travel/wp-content/plugins/photo-gallery-image/resources/assets/images/project/2.jpg', '_blank', 'image', '2019-05-25 19:17:32', NULL),
(3, 1, 377, '3', NULL, 3, NULL, 'https://technovicinity.com/development/wordpress/milon/travel/wp-content/plugins/photo-gallery-image/resources/assets/images/project/3.jpg', '_blank', 'image', '2019-05-25 19:17:32', NULL),
(4, 1, 351, '4', NULL, 4, NULL, 'https://technovicinity.com/development/wordpress/milon/travel/wp-content/plugins/photo-gallery-image/resources/assets/images/project/4.jpg', '_blank', 'image', '2019-05-25 19:17:32', NULL),
(5, 1, 348, '5', NULL, 5, NULL, 'https://technovicinity.com/development/wordpress/milon/travel/wp-content/plugins/photo-gallery-image/resources/assets/images/project/5.jpg', '_blank', 'image', '2019-05-25 19:17:32', NULL),
(6, 1, 347, '6', NULL, 6, NULL, 'https://technovicinity.com/development/wordpress/milon/travel/wp-content/plugins/photo-gallery-image/resources/assets/images/project/6.jpg', '_blank', 'image', '2019-05-25 19:17:32', NULL),
(7, 1, 345, '7', NULL, 7, NULL, 'https://technovicinity.com/development/wordpress/milon/travel/wp-content/plugins/photo-gallery-image/resources/assets/images/project/7.jpg', '_blank', 'image', '2019-05-25 19:17:32', NULL),
(8, 1, 177, '8', NULL, 8, NULL, 'https://technovicinity.com/development/wordpress/milon/travel/wp-content/plugins/photo-gallery-image/resources/assets/images/project/8.jpg', '_blank', 'image', '2019-05-25 19:17:32', NULL),
(9, 1, 176, '9', NULL, 9, NULL, 'https://technovicinity.com/development/wordpress/milon/travel/wp-content/plugins/photo-gallery-image/resources/assets/images/project/9.jpg', '_blank', 'image', '2019-05-25 19:17:32', NULL),
(10, 1, 604, 'o-RUSSIA-VIRTUALPRIDE-facebook-263x197', NULL, 0, NULL, 'http://localhost/lipan/wordpress/milonvi/wp-content/uploads/2019/04/o-RUSSIA-VIRTUALPRIDE-facebook-263x197.jpg', '_blank', 'image', '2019-06-14 15:30:24', NULL);

-- --------------------------------------------------------

--
-- Table structure for table `wp_gdgallerysettings`
--

CREATE TABLE `wp_gdgallerysettings` (
  `id` int(11) UNSIGNED NOT NULL,
  `option_key` varchar(200) NOT NULL,
  `option_value` text
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

--
-- Dumping data for table `wp_gdgallerysettings`
--

INSERT INTO `wp_gdgallerysettings` (`id`, `option_key`, `option_value`) VALUES
(1, 'RemoveTablesUninstall', 'off'),
(2, 'lightbox_type_justified', 'wide'),
(3, 'show_title_justified', '0'),
(4, 'title_position_justified', 'center'),
(5, 'title_vertical_position_justified', 'inside_bottom'),
(6, 'title_appear_type_justified', 'slide'),
(7, 'title_size_justified', '16'),
(8, 'title_color_justified', 'FFFFFF'),
(9, 'title_background_color_justified', '333333'),
(10, 'title_background_opacity_justified', '70'),
(11, 'margin_justified', '10'),
(12, 'border_width_justified', '0'),
(13, 'border_color_justified', '333333'),
(14, 'border_radius_justified', '0'),
(15, 'on_hover_overlay_justified', 'b:1;'),
(16, 'show_icons_justified', 'b:1;'),
(17, 'show_link_icon_justified', 'b:1;'),
(18, 'item_as_link_justified', 'b:0;'),
(19, 'link_new_tab_justified', 'b:1;'),
(20, 'image_hover_effect_justified', 'blur'),
(21, 'image_hover_effect_reverse_justified', 'b:0;'),
(22, 'shadow_justified', 'b:0;'),
(23, 'load_more_text_justified', 'Load More'),
(24, 'load_more_position_justified', 'center'),
(25, 'load_more_font_size_justified', '15'),
(26, 'load_more_vertical_padding_justified', '8'),
(27, 'load_more_horisontal_padding_justified', '13'),
(28, 'load_more_border_width_justified', '1'),
(29, 'load_more_border_radius_justified', '0'),
(30, 'load_more_color_justified', 'FFFFFF'),
(31, 'load_more_background_color_justified', '333333'),
(32, 'load_more_border_color_justified', '333333'),
(33, 'load_more_font_family_justified', 'monospace'),
(34, 'load_more_hover_color_justified', '333333'),
(35, 'load_more_hover_background_color_justified', 'FFFFFF'),
(36, 'load_more_hover_border_color_justified', '333333'),
(37, 'load_more_loader_justified', 'b:1;'),
(38, 'load_more_loader_color_justified', '333333'),
(39, 'pagination_position_justified', 'center'),
(40, 'pagination_font_size_justified', '15'),
(41, 'pagination_vertical_padding_justified', '8'),
(42, 'pagination_horisontal_padding_justified', '13'),
(43, 'pagination_margin_justified', '3'),
(44, 'pagination_border_width_justified', '1'),
(45, 'pagination_border_radius_justified', '0'),
(46, 'pagination_border_color_justified', '333333'),
(47, 'pagination_color_justified', '333333'),
(48, 'pagination_background_color_justified', 'FFFFFF'),
(49, 'pagination_font_family_justified', 'monospace'),
(50, 'pagination_hover_border_color_justified', '333333'),
(51, 'pagination_hover_color_justified', 'FFFFFF'),
(52, 'pagination_hover_background_color_justified', '333333'),
(53, 'pagination_nav_type_justified', '0'),
(54, 'pagination_nav_text_justified', 'first,prev,next,last'),
(55, 'pagination_nearby_pages_justified', '2'),
(56, 'lightbox_type_tiles', 'wide'),
(57, 'show_title_tiles', '0'),
(58, 'title_position_tiles', 'center'),
(59, 'title_vertical_position_tiles', 'inside_bottom'),
(60, 'title_appear_type_tiles', 'slide'),
(61, 'title_size_tiles', '16'),
(62, 'title_color_tiles', 'FFFFFF'),
(63, 'title_background_color_tiles', 'f00'),
(64, 'title_background_opacity_tiles', '70'),
(65, 'margin_tiles', '10'),
(66, 'col_width_tiles', '250'),
(67, 'min_col_tiles', '2'),
(68, 'border_width_tiles', '0'),
(69, 'border_color_tiles', '333333'),
(70, 'border_radius_tiles', '0'),
(71, 'on_hover_overlay_tiles', 'b:1;'),
(72, 'show_icons_tiles', 'b:1;'),
(73, 'show_link_icon_tiles', 'b:1;'),
(74, 'item_as_link_tiles', 'b:0;'),
(75, 'link_new_tab_tiles', 'b:1;'),
(76, 'image_hover_effect_tiles', 'blur'),
(77, 'image_hover_effect_reverse_tiles', 'b:0;'),
(78, 'shadow_tiles', 'b:0;'),
(79, 'load_more_text_tiles', 'Load More'),
(80, 'load_more_position_tiles', 'center'),
(81, 'load_more_font_size_tiles', '15'),
(82, 'load_more_vertical_padding_tiles', '8'),
(83, 'load_more_horisontal_padding_tiles', '13'),
(84, 'load_more_border_width_tiles', '1'),
(85, 'load_more_border_radius_tiles', '0'),
(86, 'load_more_color_tiles', 'FFFFFF'),
(87, 'load_more_background_color_tiles', '333333'),
(88, 'load_more_border_color_tiles', '333333'),
(89, 'load_more_font_family_tiles', 'monospace'),
(90, 'load_more_hover_color_tiles', '333333'),
(91, 'load_more_hover_background_color_tiles', 'FFFFFF'),
(92, 'load_more_hover_border_color_tiles', '333333'),
(93, 'load_more_loader_tiles', 'b:1;'),
(94, 'load_more_loader_color_tiles', '333333'),
(95, 'pagination_position_tiles', 'center'),
(96, 'pagination_font_size_tiles', '15'),
(97, 'pagination_vertical_padding_tiles', '8'),
(98, 'pagination_horisontal_padding_tiles', '13'),
(99, 'pagination_margin_tiles', '3'),
(100, 'pagination_border_width_tiles', '1'),
(101, 'pagination_border_radius_tiles', '0'),
(102, 'pagination_border_color_tiles', '333333'),
(103, 'pagination_color_tiles', '333333'),
(104, 'pagination_background_color_tiles', 'FFFFFF'),
(105, 'pagination_font_family_tiles', 'monospace'),
(106, 'pagination_hover_border_color_tiles', '333333'),
(107, 'pagination_hover_color_tiles', 'FFFFFF'),
(108, 'pagination_hover_background_color_tiles', '333333'),
(109, 'pagination_nav_type_tiles', '0'),
(110, 'pagination_nav_text_tiles', 'first,prev,next,last'),
(111, 'pagination_nearby_pages_tiles', '2'),
(112, 'lightbox_type_carousel', 'wide'),
(113, 'show_title_carousel', '0'),
(114, 'title_position_carousel', 'center'),
(115, 'title_vertical_position_carousel', 'inside_bottom'),
(116, 'title_appear_type_carousel', 'slide'),
(117, 'title_size_carousel', '16'),
(118, 'title_color_carousel', 'FFFFFF'),
(119, 'title_background_color_carousel', '333333'),
(120, 'title_background_opacity_carousel', '70'),
(121, 'width_carousel', '200'),
(122, 'height_carousel', '200'),
(123, 'margin_carousel', '10'),
(124, 'position_carousel', 'center'),
(125, 'show_background_carousel', 'b:0;'),
(126, 'background_color_carousel', 'FFFFFF'),
(127, 'border_width_carousel', '0'),
(128, 'border_color_carousel', '333333'),
(129, 'border_radius_carousel', '0'),
(130, 'on_hover_overlay_carousel', 'b:1;'),
(131, 'show_icons_carousel', 'b:1;'),
(132, 'show_link_icon_carousel', 'b:1;'),
(133, 'item_as_link_carousel', 'b:0;'),
(134, 'link_new_tab_carousel', 'b:1;'),
(135, 'image_hover_effect_carousel', 'blur'),
(136, 'image_hover_effect_reverse_carousel', 'b:0;'),
(137, 'shadow_carousel', 'b:0;'),
(138, 'nav_num_carousel', '1'),
(139, 'scroll_duration_carousel', '500'),
(140, 'autoplay_carousel', 'b:1;'),
(141, 'autoplay_timeout_carousel', '3000'),
(142, 'autoplay_direction_carousel', 'right'),
(143, 'autoplay_pause_hover_carousel', 'b:1;'),
(144, 'enable_nav_carousel', 'b:1;'),
(145, 'nav_vertical_position_carousel', 'bottom'),
(146, 'nav_horisontal_position_carousel', 'center'),
(147, 'play_icon_carousel', 'b:1;'),
(148, 'icon_space_carousel', '20'),
(149, 'lightbox_type_grid', 'wide'),
(150, 'width_grid', '200'),
(151, 'height_grid', '200'),
(152, 'space_cols_grid', '20'),
(153, 'space_rows_grid', '20'),
(154, 'gallery_width_grid', '100'),
(155, 'gallery_bg_grid', 'b:1;'),
(156, 'gallery_bg_color_grid', 'FFFFFF'),
(157, 'num_rows_grid', '3'),
(158, 'show_title_grid', '1'),
(159, 'title_position_grid', 'left'),
(160, 'title_vertical_position_grid', 'bottom'),
(161, 'title_appear_type_grid', 'slide'),
(162, 'title_size_grid', '16'),
(163, 'title_color_grid', 'FFFFFF'),
(164, 'title_background_color_grid', '333333'),
(165, 'title_background_opacity_grid', '70'),
(166, 'border_width_grid', '1'),
(167, 'border_color_grid', '333333'),
(168, 'border_radius_grid', '3'),
(169, 'on_hover_overlay_grid', 'b:1;'),
(170, 'show_icons_grid', 'b:1;'),
(171, 'show_link_icon_grid', 'b:1;'),
(172, 'item_as_link_grid', 'b:0;'),
(173, 'link_new_tab_grid', 'b:1;'),
(174, 'image_hover_effect_grid', 'blur'),
(175, 'image_hover_effect_reverse_grid', 'b:0;'),
(176, 'shadow_grid', 'b:1;'),
(177, 'nav_type_grid', 'bullets'),
(178, 'bullets_margin_grid', '50'),
(179, 'bullets_color_grid', 'gray'),
(180, 'bullets_space_between_grid', '15'),
(181, 'arrows_margin_grid', '50'),
(182, 'arrows_space_between_grid', '20'),
(183, 'nav_position_grid', 'center'),
(184, 'nav_offset_grid', '0'),
(185, 'width_slider', '900'),
(186, 'height_slider', '500'),
(187, 'autoplay_slider', 'b:1;'),
(188, 'play_interval_slider', '5000'),
(189, 'pause_on_hover_slider', 'b:1;'),
(190, 'scale_mode_slider', 'fill'),
(191, 'transition_slider', 'slide'),
(192, 'transition_speed_slider', '1500'),
(193, 'zoom_slider', 'b:1;'),
(194, 'loader_type_slider', '1'),
(195, 'loader_color_slider', 'white'),
(196, 'bullets_slider', 'b:1;'),
(197, 'bullets_horisontal_position_slider', 'center'),
(198, 'bullets_vertical_position_slider', 'bottom'),
(199, 'arrows_slider', 'b:1;'),
(200, 'progress_indicator_slider', 'b:1;'),
(201, 'progress_indicator_type_slider', 'pie'),
(202, 'progress_indicator_horisontal_position_slider', 'right'),
(203, 'progress_indicator_vertical_position_slider', 'top'),
(204, 'play_slider', 'b:0;'),
(205, 'play_horizontal_position_slider', 'left'),
(206, 'play_vertical_position_slider', 'top'),
(207, 'fullscreen_slider', 'b:0;'),
(208, 'fullscreen_horisontal_position_slider', 'left'),
(209, 'fullscreen_vertical_position_slider', 'top'),
(210, 'zoom_panel_slider', 'b:0;'),
(211, 'zoom_horisontal_panel_position_slider', 'left'),
(212, 'zoom_vertical_panel_position_slider', 'top'),
(213, 'controls_always_on_slider', 'b:0;'),
(214, 'video_play_type_slider', 'round'),
(215, 'text_panel_slider', 'b:1;'),
(216, 'text_panel_always_on_slider', 'b:0;'),
(217, 'text_title_slider', 'b:1;'),
(218, 'text_description_slider', 'b:1;'),
(219, 'text_panel_bg_slider', 'b:1;'),
(220, 'carousel_slider', 'b:1;'),
(221, 'text_panel_bg_color_slider', '000000'),
(222, 'text_panel_bg_opacity_slider', '70'),
(223, 'text_panel_title_size_slider', '17'),
(224, 'text_panel_title_color_slider', 'FFFFFF'),
(225, 'text_panel_desc_size_slider', '14'),
(226, 'text_panel_desc_color_slider', 'FFFFFF'),
(227, 'playlist_slider', 'b:0;'),
(228, 'thumb_width_slider', '88'),
(229, 'thumb_height_slider', '50'),
(230, 'playlist_bg_slider', '000000'),
(231, 'arrows_offset_wide', '0'),
(232, 'overlay_color_wide', '000000'),
(233, 'overlay_opacity_wide', '100'),
(234, 'top_panel_bg_color_wide', '000000'),
(235, 'top_panel_opacity_wide', '100'),
(236, 'show_numbers_wide', 'b:1;'),
(237, 'number_size_wide', '15'),
(238, 'number_color_wide', 'FFFFFF'),
(239, 'image_border_width_wide', '0'),
(240, 'image_border_color_wide', 'FFFFFF'),
(241, 'image_border_radius_wide', '0'),
(242, 'image_shadow_wide', 'b:1;'),
(243, 'swipe_control_wide', 'b:1;'),
(244, 'zoom_control_wide', 'b:1;'),
(245, 'show_text_panel_wide', 'b:1;'),
(246, 'enable_title_wide', 'b:1;'),
(247, 'enable_desc_wide', 'b:0;'),
(248, 'texpanel_paddind_vert_wide', '5'),
(249, 'texpanel_paddind_hor_wide', '5'),
(250, 'text_position_wide', 'center'),
(251, 'title_color_wide', 'FFFFFF'),
(252, 'title_font_size_wide', '16'),
(253, 'desc_color_wide', 'FFFFFF'),
(254, 'desc_font_size_wide', '14'),
(255, 'arrows_offset_compact', '0'),
(256, 'overlay_color_compact', '000000'),
(257, 'overlay_opacity_compact', '50'),
(258, 'show_numbers_compact', 'b:1;'),
(259, 'number_size_compact', '15'),
(260, 'number_color_compact', 'FFFFFF'),
(261, 'image_border_width_compact', '0'),
(262, 'image_border_color_compact', 'FFFFFF'),
(263, 'image_border_radius_compact', '0'),
(264, 'image_shadow_compact', 'b:1;'),
(265, 'swipe_control_compact', 'b:1;'),
(266, 'zoom_control_compact', 'b:1;'),
(267, 'show_text_panel_compact', 'b:1;'),
(268, 'enable_title_compact', 'b:1;'),
(269, 'enable_desc_compact', 'b:0;'),
(270, 'texpanel_paddind_vert_compact', '5'),
(271, 'texpanel_paddind_hor_compact', '5'),
(272, 'text_position_compact', 'left'),
(273, 'title_color_compact', '333333'),
(274, 'title_font_size_compact', '16'),
(275, 'desc_color_compact', '333333'),
(276, 'desc_font_size_compact', '14');

-- --------------------------------------------------------

--
-- Table structure for table `wp_hotel_booking_order_itemmeta`
--

CREATE TABLE `wp_hotel_booking_order_itemmeta` (
  `meta_id` bigint(20) UNSIGNED NOT NULL,
  `hotel_booking_order_item_id` bigint(20) UNSIGNED NOT NULL,
  `meta_key` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `meta_value` longtext COLLATE utf8mb4_unicode_ci
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `wp_hotel_booking_order_items`
--

CREATE TABLE `wp_hotel_booking_order_items` (
  `order_item_id` bigint(20) UNSIGNED NOT NULL,
  `order_item_name` longtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `order_item_type` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `order_item_parent` bigint(20) DEFAULT NULL,
  `order_id` bigint(20) UNSIGNED NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `wp_hotel_booking_plans`
--

CREATE TABLE `wp_hotel_booking_plans` (
  `plan_id` bigint(20) UNSIGNED NOT NULL,
  `room_id` bigint(20) UNSIGNED NOT NULL,
  `start_time` timestamp NULL DEFAULT NULL,
  `end_time` timestamp NULL DEFAULT NULL,
  `pricing` longtext COLLATE utf8mb4_unicode_ci
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `wp_hotel_booking_plans`
--

INSERT INTO `wp_hotel_booking_plans` (`plan_id`, `room_id`, `start_time`, `end_time`, `pricing`) VALUES
(1, 417, NULL, NULL, 'a:7:{i:1;s:3:\"300\";i:2;s:3:\"200\";i:3;s:3:\"200\";i:4;s:3:\"200\";i:5;s:3:\"200\";i:6;s:3:\"250\";i:0;s:3:\"300\";}'),
(2, 416, NULL, NULL, 'a:7:{i:1;s:3:\"300\";i:2;s:3:\"200\";i:3;s:3:\"200\";i:4;s:3:\"200\";i:5;s:3:\"200\";i:6;s:3:\"250\";i:0;s:3:\"300\";}');

-- --------------------------------------------------------

--
-- Table structure for table `wp_links`
--

CREATE TABLE `wp_links` (
  `link_id` bigint(20) UNSIGNED NOT NULL,
  `link_url` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `link_name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `link_image` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `link_target` varchar(25) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `link_description` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `link_visible` varchar(20) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'Y',
  `link_owner` bigint(20) UNSIGNED NOT NULL DEFAULT '1',
  `link_rating` int(11) NOT NULL DEFAULT '0',
  `link_updated` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `link_rel` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `link_notes` mediumtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `link_rss` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT ''
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `wp_mphb_sync_logs`
--

CREATE TABLE `wp_mphb_sync_logs` (
  `log_id` int(11) NOT NULL,
  `queue_id` int(11) NOT NULL,
  `log_status` varchar(30) NOT NULL,
  `log_message` text NOT NULL,
  `log_context` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Table structure for table `wp_mphb_sync_queue`
--

CREATE TABLE `wp_mphb_sync_queue` (
  `queue_id` int(11) NOT NULL,
  `queue_name` tinytext NOT NULL,
  `queue_status` varchar(30) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Table structure for table `wp_mphb_sync_stats`
--

CREATE TABLE `wp_mphb_sync_stats` (
  `stat_id` int(11) NOT NULL,
  `queue_id` int(11) NOT NULL,
  `stat_total` int(11) NOT NULL,
  `stat_succeed` int(11) NOT NULL,
  `stat_skipped` int(11) NOT NULL,
  `stat_failed` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Table structure for table `wp_options`
--

CREATE TABLE `wp_options` (
  `option_id` bigint(20) UNSIGNED NOT NULL,
  `option_name` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `option_value` longtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `autoload` varchar(20) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'yes'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `wp_options`
--

INSERT INTO `wp_options` (`option_id`, `option_name`, `option_value`, `autoload`) VALUES
(1, 'siteurl', 'http://localhost/lipan/wordpress/milonvi/', 'yes'),
(2, 'home', 'http://localhost/lipan/wordpress/milonvi/', 'yes'),
(3, 'blogname', 'projct new development', 'yes'),
(4, 'blogdescription', 'Just another WordPress site', 'yes'),
(5, 'users_can_register', '0', 'yes'),
(6, 'admin_email', 'admin@gmail.com', 'yes'),
(7, 'start_of_week', '1', 'yes'),
(8, 'use_balanceTags', '0', 'yes'),
(9, 'use_smilies', '1', 'yes'),
(10, 'require_name_email', '1', 'yes'),
(11, 'comments_notify', '1', 'yes'),
(12, 'posts_per_rss', '10', 'yes'),
(13, 'rss_use_excerpt', '0', 'yes'),
(14, 'mailserver_url', 'mail.example.com', 'yes'),
(15, 'mailserver_login', 'login@example.com', 'yes'),
(16, 'mailserver_pass', 'password', 'yes'),
(17, 'mailserver_port', '110', 'yes'),
(18, 'default_category', '1', 'yes'),
(19, 'default_comment_status', 'open', 'yes'),
(20, 'default_ping_status', 'open', 'yes'),
(21, 'default_pingback_flag', '0', 'yes'),
(22, 'posts_per_page', '10', 'yes'),
(23, 'date_format', 'F j, Y', 'yes'),
(24, 'time_format', 'g:i a', 'yes'),
(25, 'links_updated_date_format', 'F j, Y g:i a', 'yes'),
(26, 'comment_moderation', '0', 'yes'),
(27, 'moderation_notify', '1', 'yes'),
(28, 'permalink_structure', '/%postname%/', 'yes'),
(30, 'hack_file', '0', 'yes'),
(31, 'blog_charset', 'UTF-8', 'yes'),
(32, 'moderation_keys', '', 'no'),
(33, 'active_plugins', 'a:10:{i:0;s:30:\"advanced-custom-fields/acf.php\";i:1;s:19:\"akismet/akismet.php\";i:2;s:28:\"categorized-gallery/init.php\";i:3;s:33:\"duplicate-post/duplicate-post.php\";i:4;s:29:\"photo-gallery-image/index.php\";i:5;s:25:\"profile-builder/index.php\";i:6;s:29:\"site-reviews/site-reviews.php\";i:7;s:14:\"types/wpcf.php\";i:8;s:37:\"user-role-editor/user-role-editor.php\";i:9;s:44:\"wp-custom-taxonomy-meta/wp-texonomy-meta.php\";}', 'yes'),
(34, 'category_base', '/taxonomy', 'yes'),
(35, 'ping_sites', 'http://rpc.pingomatic.com/', 'yes'),
(36, 'comment_max_links', '2', 'yes'),
(37, 'gmt_offset', '0', 'yes'),
(38, 'default_email_category', '1', 'yes'),
(39, 'recently_edited', 'a:5:{i:0;s:124:\"/home/techvqgu/public_html/development/wordpress/milon/travel/wp-content/themes/hazproject/admin-page/form_ahagencyleads.php\";i:2;s:100:\"/home/techvqgu/public_html/development/wordpress/milon/travel/wp-content/themes/hazproject/style.css\";i:3;s:104:\"/home/techvqgu/public_html/development/wordpress/milon/travel/wp-content/themes/hazproject/functions.php\";i:4;s:109:\"/home/techvqgu/public_html/development/wordpress/milon/travel/wp-content/themes/hazproject/inc/pages_link.php\";i:5;s:112:\"/home/techvqgu/public_html/development/wordpress/milon/travel/wp-content/themes/hazproject/all_page/book-now.php\";}', 'no'),
(40, 'template', 'hazproject', 'yes'),
(41, 'stylesheet', 'hazproject', 'yes'),
(42, 'comment_whitelist', '1', 'yes'),
(43, 'blacklist_keys', '', 'no'),
(44, 'comment_registration', '0', 'yes'),
(45, 'html_type', 'text/html', 'yes'),
(46, 'use_trackback', '0', 'yes'),
(47, 'default_role', 'taibur', 'yes'),
(48, 'db_version', '43764', 'yes'),
(49, 'uploads_use_yearmonth_folders', '1', 'yes'),
(50, 'upload_path', '', 'yes'),
(51, 'blog_public', '0', 'yes'),
(52, 'default_link_category', '0', 'yes'),
(53, 'show_on_front', 'page', 'yes'),
(54, 'tag_base', '', 'yes'),
(55, 'show_avatars', '1', 'yes'),
(56, 'avatar_rating', 'G', 'yes'),
(57, 'upload_url_path', '', 'yes'),
(58, 'thumbnail_size_w', '150', 'yes'),
(59, 'thumbnail_size_h', '150', 'yes'),
(60, 'thumbnail_crop', '1', 'yes'),
(61, 'medium_size_w', '300', 'yes'),
(62, 'medium_size_h', '300', 'yes'),
(63, 'avatar_default', 'mystery', 'yes'),
(64, 'large_size_w', '1024', 'yes'),
(65, 'large_size_h', '1024', 'yes'),
(66, 'image_default_link_type', 'none', 'yes'),
(67, 'image_default_size', '', 'yes'),
(68, 'image_default_align', '', 'yes'),
(69, 'close_comments_for_old_posts', '0', 'yes'),
(70, 'close_comments_days_old', '14', 'yes'),
(71, 'thread_comments', '1', 'yes'),
(72, 'thread_comments_depth', '5', 'yes'),
(73, 'page_comments', '0', 'yes'),
(74, 'comments_per_page', '50', 'yes'),
(75, 'default_comments_page', 'newest', 'yes'),
(76, 'comment_order', 'asc', 'yes'),
(77, 'sticky_posts', 'a:0:{}', 'yes'),
(78, 'widget_categories', 'a:2:{i:2;a:4:{s:5:\"title\";s:8:\"Category\";s:5:\"count\";i:0;s:12:\"hierarchical\";i:0;s:8:\"dropdown\";i:0;}s:12:\"_multiwidget\";i:1;}', 'yes'),
(79, 'widget_text', 'a:2:{i:1;a:0:{}s:12:\"_multiwidget\";i:1;}', 'yes'),
(80, 'widget_rss', 'a:2:{i:1;a:0:{}s:12:\"_multiwidget\";i:1;}', 'yes'),
(81, 'uninstall_plugins', 'a:1:{s:44:\"wp-custom-taxonomy-meta/wp-texonomy-meta.php\";s:15:\"wpaft_uninstall\";}', 'no'),
(82, 'timezone_string', '', 'yes'),
(83, 'page_for_posts', '582', 'yes'),
(84, 'page_on_front', '9', 'yes'),
(85, 'default_post_format', '0', 'yes'),
(86, 'link_manager_enabled', '0', 'yes'),
(87, 'finished_splitting_shared_terms', '1', 'yes'),
(88, 'site_icon', '0', 'yes'),
(89, 'medium_large_size_w', '768', 'yes'),
(90, 'medium_large_size_h', '0', 'yes'),
(91, 'wp_page_for_privacy_policy', '363', 'yes'),
(92, 'show_comments_cookies_opt_in', '0', 'yes'),
(93, 'initial_db_version', '43764', 'yes'),
(94, 'wp_user_roles', 'a:21:{s:13:\"administrator\";a:2:{s:4:\"name\";s:13:\"Administrator\";s:12:\"capabilities\";a:104:{s:13:\"switch_themes\";b:1;s:11:\"edit_themes\";b:1;s:16:\"activate_plugins\";b:1;s:12:\"edit_plugins\";b:1;s:10:\"edit_users\";b:1;s:10:\"edit_files\";b:1;s:14:\"manage_options\";b:1;s:17:\"moderate_comments\";b:1;s:17:\"manage_categories\";b:1;s:12:\"manage_links\";b:1;s:12:\"upload_files\";b:1;s:6:\"import\";b:1;s:15:\"unfiltered_html\";b:1;s:10:\"edit_posts\";b:1;s:17:\"edit_others_posts\";b:1;s:20:\"edit_published_posts\";b:1;s:13:\"publish_posts\";b:1;s:10:\"edit_pages\";b:1;s:4:\"read\";b:1;s:8:\"level_10\";b:1;s:7:\"level_9\";b:1;s:7:\"level_8\";b:1;s:7:\"level_7\";b:1;s:7:\"level_6\";b:1;s:7:\"level_5\";b:1;s:7:\"level_4\";b:1;s:7:\"level_3\";b:1;s:7:\"level_2\";b:1;s:7:\"level_1\";b:1;s:7:\"level_0\";b:1;s:17:\"edit_others_pages\";b:1;s:20:\"edit_published_pages\";b:1;s:13:\"publish_pages\";b:1;s:12:\"delete_pages\";b:1;s:19:\"delete_others_pages\";b:1;s:22:\"delete_published_pages\";b:1;s:12:\"delete_posts\";b:1;s:19:\"delete_others_posts\";b:1;s:22:\"delete_published_posts\";b:1;s:20:\"delete_private_posts\";b:1;s:18:\"edit_private_posts\";b:1;s:18:\"read_private_posts\";b:1;s:20:\"delete_private_pages\";b:1;s:18:\"edit_private_pages\";b:1;s:18:\"read_private_pages\";b:1;s:12:\"delete_users\";b:1;s:12:\"create_users\";b:1;s:17:\"unfiltered_upload\";b:1;s:14:\"edit_dashboard\";b:1;s:14:\"update_plugins\";b:1;s:14:\"delete_plugins\";b:1;s:15:\"install_plugins\";b:1;s:13:\"update_themes\";b:1;s:14:\"install_themes\";b:1;s:11:\"update_core\";b:1;s:10:\"list_users\";b:1;s:12:\"remove_users\";b:1;s:13:\"promote_users\";b:1;s:18:\"edit_theme_options\";b:1;s:13:\"delete_themes\";b:1;s:6:\"export\";b:1;s:16:\"edit_attachments\";b:1;s:18:\"delete_attachments\";b:1;s:23:\"read_others_attachments\";b:1;s:23:\"edit_others_attachments\";b:1;s:25:\"delete_others_attachments\";b:1;s:23:\"edit_users_higher_level\";b:1;s:25:\"delete_users_higher_level\";b:1;s:26:\"promote_users_higher_level\";b:1;s:29:\"promote_users_to_higher_level\";b:1;s:9:\"add_users\";b:1;s:10:\"list_roles\";b:1;s:12:\"create_roles\";b:1;s:10:\"edit_roles\";b:1;s:12:\"delete_roles\";b:1;s:15:\"edit_role_menus\";b:1;s:27:\"edit_posts_role_permissions\";b:1;s:27:\"edit_pages_role_permissions\";b:1;s:25:\"edit_nav_menu_permissions\";b:1;s:23:\"edit_content_shortcodes\";b:1;s:25:\"delete_content_shortcodes\";b:1;s:20:\"edit_login_redirects\";b:1;s:22:\"delete_login_redirects\";b:1;s:15:\"bulk_edit_roles\";b:1;s:23:\"edit_widget_permissions\";b:1;s:14:\"ure_edit_roles\";b:1;s:16:\"ure_create_roles\";b:1;s:16:\"ure_delete_roles\";b:1;s:23:\"ure_create_capabilities\";b:1;s:23:\"ure_delete_capabilities\";b:1;s:18:\"ure_manage_options\";b:1;s:15:\"ure_reset_roles\";b:1;s:26:\"wpcf_custom_post_type_view\";b:1;s:26:\"wpcf_custom_post_type_edit\";b:1;s:33:\"wpcf_custom_post_type_edit_others\";b:1;s:25:\"wpcf_custom_taxonomy_view\";b:1;s:25:\"wpcf_custom_taxonomy_edit\";b:1;s:32:\"wpcf_custom_taxonomy_edit_others\";b:1;s:22:\"wpcf_custom_field_view\";b:1;s:22:\"wpcf_custom_field_edit\";b:1;s:29:\"wpcf_custom_field_edit_others\";b:1;s:25:\"wpcf_user_meta_field_view\";b:1;s:25:\"wpcf_user_meta_field_edit\";b:1;s:32:\"wpcf_user_meta_field_edit_others\";b:1;}}s:6:\"author\";a:2:{s:4:\"name\";s:6:\"Author\";s:12:\"capabilities\";a:80:{s:16:\"activate_plugins\";b:1;s:12:\"create_users\";b:1;s:19:\"delete_others_pages\";b:1;s:19:\"delete_others_posts\";b:1;s:12:\"delete_pages\";b:1;s:14:\"delete_plugins\";b:1;s:12:\"delete_posts\";b:1;s:20:\"delete_private_pages\";b:1;s:20:\"delete_private_posts\";b:1;s:22:\"delete_published_pages\";b:1;s:22:\"delete_published_posts\";b:1;s:13:\"delete_themes\";b:1;s:12:\"delete_users\";b:1;s:14:\"edit_dashboard\";b:1;s:17:\"edit_others_pages\";b:1;s:17:\"edit_others_posts\";b:1;s:10:\"edit_pages\";b:1;s:12:\"edit_plugins\";b:1;s:10:\"edit_posts\";b:1;s:18:\"edit_private_pages\";b:1;s:18:\"edit_private_posts\";b:1;s:20:\"edit_published_pages\";b:1;s:20:\"edit_published_posts\";b:1;s:18:\"edit_theme_options\";b:1;s:11:\"edit_themes\";b:1;s:10:\"edit_users\";b:1;s:6:\"export\";b:1;s:6:\"import\";b:1;s:15:\"install_plugins\";b:1;s:14:\"install_themes\";b:1;s:7:\"level_0\";b:1;s:7:\"level_1\";b:1;s:7:\"level_2\";b:1;s:10:\"list_users\";b:1;s:17:\"manage_categories\";b:1;s:12:\"manage_links\";b:1;s:14:\"manage_options\";b:1;s:17:\"moderate_comments\";b:1;s:13:\"promote_users\";b:1;s:13:\"publish_pages\";b:1;s:13:\"publish_posts\";b:1;s:4:\"read\";b:1;s:18:\"read_private_pages\";b:1;s:18:\"read_private_posts\";b:1;s:12:\"remove_users\";b:1;s:13:\"switch_themes\";b:1;s:15:\"unfiltered_html\";b:1;s:17:\"unfiltered_upload\";b:1;s:11:\"update_core\";b:1;s:14:\"update_plugins\";b:1;s:13:\"update_themes\";b:1;s:12:\"upload_files\";b:1;s:23:\"ure_create_capabilities\";b:1;s:16:\"ure_create_roles\";b:1;s:23:\"ure_delete_capabilities\";b:1;s:16:\"ure_delete_roles\";b:1;s:14:\"ure_edit_roles\";b:1;s:18:\"ure_manage_options\";b:1;s:15:\"ure_reset_roles\";b:1;s:16:\"edit_attachments\";b:1;s:18:\"delete_attachments\";b:1;s:23:\"read_others_attachments\";b:1;s:23:\"edit_others_attachments\";b:1;s:25:\"delete_others_attachments\";b:1;s:23:\"edit_users_higher_level\";b:1;s:25:\"delete_users_higher_level\";b:1;s:26:\"promote_users_higher_level\";b:1;s:29:\"promote_users_to_higher_level\";b:1;s:26:\"wpcf_custom_post_type_view\";b:1;s:26:\"wpcf_custom_post_type_edit\";b:1;s:33:\"wpcf_custom_post_type_edit_others\";b:1;s:25:\"wpcf_custom_taxonomy_view\";b:1;s:25:\"wpcf_custom_taxonomy_edit\";b:1;s:32:\"wpcf_custom_taxonomy_edit_others\";b:1;s:22:\"wpcf_custom_field_view\";b:1;s:22:\"wpcf_custom_field_edit\";b:1;s:29:\"wpcf_custom_field_edit_others\";b:1;s:25:\"wpcf_user_meta_field_view\";b:1;s:25:\"wpcf_user_meta_field_edit\";b:1;s:32:\"wpcf_user_meta_field_edit_others\";b:1;}}s:11:\"bbp_blocked\";a:2:{s:4:\"name\";s:7:\"Blocked\";s:12:\"capabilities\";a:0:{}}s:19:\"wphb_booking_editor\";a:2:{s:4:\"name\";s:14:\"Booking Editor\";s:12:\"capabilities\";a:26:{s:4:\"read\";b:1;s:10:\"edit_posts\";b:1;s:16:\"publish_hb_rooms\";b:1;s:15:\"delete_hb_rooms\";b:1;s:25:\"delete_published_hb_rooms\";b:1;s:23:\"delete_private_hb_rooms\";b:1;s:22:\"delete_others_hb_rooms\";b:1;s:20:\"edit_others_hb_rooms\";b:1;s:13:\"edit_hb_rooms\";b:1;s:23:\"edit_published_hb_rooms\";b:1;s:21:\"edit_private_hb_rooms\";b:1;s:19:\"publish_hb_bookings\";b:1;s:18:\"delete_hb_bookings\";b:1;s:28:\"delete_published_hb_bookings\";b:1;s:26:\"delete_private_hb_bookings\";b:1;s:25:\"delete_others_hb_bookings\";b:1;s:23:\"edit_others_hb_bookings\";b:1;s:16:\"edit_hb_bookings\";b:1;s:26:\"edit_published_hb_bookings\";b:1;s:24:\"edit_private_hb_bookings\";b:1;s:12:\"upload_files\";b:1;s:16:\"edit_attachments\";b:1;s:18:\"delete_attachments\";b:1;s:23:\"read_others_attachments\";b:1;s:23:\"edit_others_attachments\";b:1;s:25:\"delete_others_attachments\";b:1;}}s:22:\"booking_package_member\";a:2:{s:4:\"name\";s:15:\"Booking Package\";s:12:\"capabilities\";a:3:{s:4:\"read\";b:1;s:7:\"level_0\";b:1;s:15:\"booking_package\";b:1;}}s:11:\"contributor\";a:2:{s:4:\"name\";s:11:\"Contributor\";s:12:\"capabilities\";a:5:{s:10:\"edit_posts\";b:1;s:4:\"read\";b:1;s:7:\"level_1\";b:1;s:7:\"level_0\";b:1;s:12:\"delete_posts\";b:1;}}s:8:\"customer\";a:2:{s:4:\"name\";s:8:\"Customer\";s:12:\"capabilities\";a:1:{s:4:\"read\";b:1;}}s:6:\"editor\";a:2:{s:4:\"name\";s:6:\"Editor\";s:12:\"capabilities\";a:20:{s:19:\"delete_others_posts\";b:1;s:12:\"delete_posts\";b:1;s:20:\"delete_private_posts\";b:1;s:22:\"delete_published_posts\";b:1;s:17:\"edit_others_posts\";b:1;s:10:\"edit_posts\";b:1;s:18:\"edit_private_posts\";b:1;s:20:\"edit_published_posts\";b:1;s:7:\"level_0\";b:1;s:7:\"level_1\";b:1;s:7:\"level_2\";b:1;s:7:\"level_3\";b:1;s:7:\"level_4\";b:1;s:7:\"level_5\";b:1;s:7:\"level_6\";b:1;s:7:\"level_7\";b:1;s:17:\"manage_categories\";b:1;s:17:\"moderate_comments\";b:1;s:13:\"publish_posts\";b:1;s:18:\"read_private_posts\";b:1;}}s:19:\"awebooking_customer\";a:2:{s:4:\"name\";s:14:\"Hotel Customer\";s:12:\"capabilities\";a:1:{s:4:\"read\";b:1;}}s:18:\"wphb_hotel_manager\";a:2:{s:4:\"name\";s:13:\"Hotel Manager\";s:12:\"capabilities\";a:27:{s:4:\"read\";b:1;s:10:\"edit_posts\";b:1;s:15:\"delete_hb_rooms\";b:1;s:16:\"publish_hb_rooms\";b:1;s:25:\"delete_published_hb_rooms\";b:1;s:23:\"delete_private_hb_rooms\";b:1;s:22:\"delete_others_hb_rooms\";b:1;s:20:\"edit_others_hb_rooms\";b:1;s:13:\"edit_hb_rooms\";b:1;s:23:\"edit_published_hb_rooms\";b:1;s:21:\"edit_private_hb_rooms\";b:1;s:19:\"publish_hb_bookings\";b:1;s:18:\"delete_hb_bookings\";b:1;s:28:\"delete_published_hb_bookings\";b:1;s:26:\"delete_private_hb_bookings\";b:1;s:25:\"delete_others_hb_bookings\";b:1;s:23:\"edit_others_hb_bookings\";b:1;s:16:\"edit_hb_bookings\";b:1;s:26:\"edit_published_hb_bookings\";b:1;s:24:\"edit_private_hb_bookings\";b:1;s:12:\"upload_files\";b:1;s:17:\"manage_hb_booking\";b:1;s:16:\"edit_attachments\";b:1;s:18:\"delete_attachments\";b:1;s:23:\"read_others_attachments\";b:1;s:23:\"edit_others_attachments\";b:1;s:25:\"delete_others_attachments\";b:1;}}s:18:\"awebooking_manager\";a:2:{s:4:\"name\";s:13:\"Hotel Manager\";s:12:\"capabilities\";a:115:{s:7:\"level_9\";b:1;s:7:\"level_8\";b:1;s:7:\"level_7\";b:1;s:7:\"level_6\";b:1;s:7:\"level_5\";b:1;s:7:\"level_4\";b:1;s:7:\"level_3\";b:1;s:7:\"level_2\";b:1;s:7:\"level_1\";b:1;s:7:\"level_0\";b:1;s:4:\"read\";b:1;s:18:\"read_private_pages\";b:1;s:18:\"read_private_posts\";b:1;s:10:\"edit_users\";b:1;s:10:\"edit_posts\";b:1;s:10:\"edit_pages\";b:1;s:20:\"edit_published_posts\";b:1;s:20:\"edit_published_pages\";b:1;s:18:\"edit_private_pages\";b:1;s:18:\"edit_private_posts\";b:1;s:17:\"edit_others_posts\";b:1;s:17:\"edit_others_pages\";b:1;s:13:\"publish_posts\";b:1;s:13:\"publish_pages\";b:1;s:12:\"delete_posts\";b:1;s:12:\"delete_pages\";b:1;s:20:\"delete_private_pages\";b:1;s:20:\"delete_private_posts\";b:1;s:22:\"delete_published_pages\";b:1;s:22:\"delete_published_posts\";b:1;s:19:\"delete_others_posts\";b:1;s:19:\"delete_others_pages\";b:1;s:17:\"manage_categories\";b:1;s:12:\"manage_links\";b:1;s:17:\"moderate_comments\";b:1;s:12:\"upload_files\";b:1;s:6:\"export\";b:1;s:6:\"import\";b:1;s:10:\"list_users\";b:1;s:17:\"manage_awebooking\";b:1;s:26:\"manage_awebooking_settings\";b:1;s:15:\"edit_awebooking\";b:1;s:15:\"read_awebooking\";b:1;s:17:\"delete_awebooking\";b:1;s:16:\"edit_awebookings\";b:1;s:23:\"edit_others_awebookings\";b:1;s:19:\"publish_awebookings\";b:1;s:24:\"read_private_awebookings\";b:1;s:18:\"delete_awebookings\";b:1;s:26:\"delete_private_awebookings\";b:1;s:28:\"delete_published_awebookings\";b:1;s:25:\"delete_others_awebookings\";b:1;s:24:\"edit_private_awebookings\";b:1;s:26:\"edit_published_awebookings\";b:1;s:23:\"manage_awebooking_terms\";b:1;s:21:\"edit_awebooking_terms\";b:1;s:23:\"delete_awebooking_terms\";b:1;s:23:\"assign_awebooking_terms\";b:1;s:14:\"edit_room_type\";b:1;s:14:\"read_room_type\";b:1;s:16:\"delete_room_type\";b:1;s:15:\"edit_room_types\";b:1;s:22:\"edit_others_room_types\";b:1;s:18:\"publish_room_types\";b:1;s:23:\"read_private_room_types\";b:1;s:17:\"delete_room_types\";b:1;s:25:\"delete_private_room_types\";b:1;s:27:\"delete_published_room_types\";b:1;s:24:\"delete_others_room_types\";b:1;s:23:\"edit_private_room_types\";b:1;s:25:\"edit_published_room_types\";b:1;s:22:\"manage_room_type_terms\";b:1;s:20:\"edit_room_type_terms\";b:1;s:22:\"delete_room_type_terms\";b:1;s:22:\"assign_room_type_terms\";b:1;s:18:\"edit_hotel_service\";b:1;s:18:\"read_hotel_service\";b:1;s:20:\"delete_hotel_service\";b:1;s:19:\"edit_hotel_services\";b:1;s:26:\"edit_others_hotel_services\";b:1;s:22:\"publish_hotel_services\";b:1;s:27:\"read_private_hotel_services\";b:1;s:21:\"delete_hotel_services\";b:1;s:29:\"delete_private_hotel_services\";b:1;s:31:\"delete_published_hotel_services\";b:1;s:28:\"delete_others_hotel_services\";b:1;s:27:\"edit_private_hotel_services\";b:1;s:29:\"edit_published_hotel_services\";b:1;s:26:\"manage_hotel_service_terms\";b:1;s:24:\"edit_hotel_service_terms\";b:1;s:26:\"delete_hotel_service_terms\";b:1;s:26:\"assign_hotel_service_terms\";b:1;s:19:\"edit_hotel_location\";b:1;s:19:\"read_hotel_location\";b:1;s:21:\"delete_hotel_location\";b:1;s:20:\"edit_hotel_locations\";b:1;s:27:\"edit_others_hotel_locations\";b:1;s:23:\"publish_hotel_locations\";b:1;s:28:\"read_private_hotel_locations\";b:1;s:22:\"delete_hotel_locations\";b:1;s:30:\"delete_private_hotel_locations\";b:1;s:32:\"delete_published_hotel_locations\";b:1;s:29:\"delete_others_hotel_locations\";b:1;s:28:\"edit_private_hotel_locations\";b:1;s:30:\"edit_published_hotel_locations\";b:1;s:27:\"manage_hotel_location_terms\";b:1;s:25:\"edit_hotel_location_terms\";b:1;s:27:\"delete_hotel_location_terms\";b:1;s:27:\"assign_hotel_location_terms\";b:1;s:16:\"edit_attachments\";b:1;s:18:\"delete_attachments\";b:1;s:23:\"read_others_attachments\";b:1;s:23:\"edit_others_attachments\";b:1;s:25:\"delete_others_attachments\";b:1;s:23:\"edit_users_higher_level\";b:1;}}s:23:\"awebooking_receptionist\";a:2:{s:4:\"name\";s:18:\"Hotel Receptionist\";s:12:\"capabilities\";a:88:{s:7:\"level_9\";b:1;s:7:\"level_8\";b:1;s:7:\"level_7\";b:1;s:7:\"level_6\";b:1;s:7:\"level_5\";b:1;s:7:\"level_4\";b:1;s:7:\"level_3\";b:1;s:7:\"level_2\";b:1;s:7:\"level_1\";b:1;s:7:\"level_0\";b:1;s:4:\"read\";b:1;s:18:\"read_private_pages\";b:1;s:18:\"read_private_posts\";b:1;s:10:\"edit_posts\";b:1;s:10:\"edit_pages\";b:1;s:13:\"publish_posts\";b:1;s:13:\"publish_pages\";b:1;s:12:\"manage_links\";b:1;s:17:\"moderate_comments\";b:1;s:17:\"manage_awebooking\";b:1;s:15:\"edit_awebooking\";b:1;s:15:\"read_awebooking\";b:1;s:17:\"delete_awebooking\";b:1;s:16:\"edit_awebookings\";b:1;s:23:\"edit_others_awebookings\";b:1;s:19:\"publish_awebookings\";b:1;s:24:\"read_private_awebookings\";b:1;s:18:\"delete_awebookings\";b:1;s:26:\"delete_private_awebookings\";b:1;s:28:\"delete_published_awebookings\";b:1;s:25:\"delete_others_awebookings\";b:1;s:24:\"edit_private_awebookings\";b:1;s:26:\"edit_published_awebookings\";b:1;s:23:\"manage_awebooking_terms\";b:1;s:21:\"edit_awebooking_terms\";b:1;s:23:\"delete_awebooking_terms\";b:1;s:23:\"assign_awebooking_terms\";b:1;s:14:\"edit_room_type\";b:1;s:14:\"read_room_type\";b:1;s:16:\"delete_room_type\";b:1;s:15:\"edit_room_types\";b:1;s:22:\"edit_others_room_types\";b:1;s:18:\"publish_room_types\";b:1;s:23:\"read_private_room_types\";b:1;s:17:\"delete_room_types\";b:1;s:25:\"delete_private_room_types\";b:1;s:27:\"delete_published_room_types\";b:1;s:24:\"delete_others_room_types\";b:1;s:23:\"edit_private_room_types\";b:1;s:25:\"edit_published_room_types\";b:1;s:22:\"manage_room_type_terms\";b:1;s:20:\"edit_room_type_terms\";b:1;s:22:\"delete_room_type_terms\";b:1;s:22:\"assign_room_type_terms\";b:1;s:18:\"edit_hotel_service\";b:1;s:18:\"read_hotel_service\";b:1;s:20:\"delete_hotel_service\";b:1;s:19:\"edit_hotel_services\";b:1;s:26:\"edit_others_hotel_services\";b:1;s:22:\"publish_hotel_services\";b:1;s:27:\"read_private_hotel_services\";b:1;s:21:\"delete_hotel_services\";b:1;s:29:\"delete_private_hotel_services\";b:1;s:31:\"delete_published_hotel_services\";b:1;s:28:\"delete_others_hotel_services\";b:1;s:27:\"edit_private_hotel_services\";b:1;s:29:\"edit_published_hotel_services\";b:1;s:26:\"manage_hotel_service_terms\";b:1;s:24:\"edit_hotel_service_terms\";b:1;s:26:\"delete_hotel_service_terms\";b:1;s:26:\"assign_hotel_service_terms\";b:1;s:19:\"edit_hotel_location\";b:1;s:19:\"read_hotel_location\";b:1;s:21:\"delete_hotel_location\";b:1;s:20:\"edit_hotel_locations\";b:1;s:27:\"edit_others_hotel_locations\";b:1;s:23:\"publish_hotel_locations\";b:1;s:28:\"read_private_hotel_locations\";b:1;s:22:\"delete_hotel_locations\";b:1;s:30:\"delete_private_hotel_locations\";b:1;s:32:\"delete_published_hotel_locations\";b:1;s:29:\"delete_others_hotel_locations\";b:1;s:28:\"edit_private_hotel_locations\";b:1;s:30:\"edit_published_hotel_locations\";b:1;s:27:\"manage_hotel_location_terms\";b:1;s:25:\"edit_hotel_location_terms\";b:1;s:27:\"delete_hotel_location_terms\";b:1;s:27:\"assign_hotel_location_terms\";b:1;}}s:13:\"bbp_keymaster\";a:2:{s:4:\"name\";s:9:\"Keymaster\";s:12:\"capabilities\";a:0:{}}s:13:\"bbp_moderator\";a:2:{s:4:\"name\";s:9:\"Moderator\";s:12:\"capabilities\";a:0:{}}s:15:\"bbp_participant\";a:2:{s:4:\"name\";s:11:\"Participant\";s:12:\"capabilities\";a:0:{}}s:12:\"shop_manager\";a:2:{s:4:\"name\";s:12:\"Shop manager\";s:12:\"capabilities\";a:97:{s:7:\"level_9\";b:1;s:7:\"level_8\";b:1;s:7:\"level_7\";b:1;s:7:\"level_6\";b:1;s:7:\"level_5\";b:1;s:7:\"level_4\";b:1;s:7:\"level_3\";b:1;s:7:\"level_2\";b:1;s:7:\"level_1\";b:1;s:7:\"level_0\";b:1;s:4:\"read\";b:1;s:18:\"read_private_pages\";b:1;s:18:\"read_private_posts\";b:1;s:10:\"edit_posts\";b:1;s:10:\"edit_pages\";b:1;s:20:\"edit_published_posts\";b:1;s:20:\"edit_published_pages\";b:1;s:18:\"edit_private_pages\";b:1;s:18:\"edit_private_posts\";b:1;s:17:\"edit_others_posts\";b:1;s:17:\"edit_others_pages\";b:1;s:13:\"publish_posts\";b:1;s:13:\"publish_pages\";b:1;s:12:\"delete_posts\";b:1;s:12:\"delete_pages\";b:1;s:20:\"delete_private_pages\";b:1;s:20:\"delete_private_posts\";b:1;s:22:\"delete_published_pages\";b:1;s:22:\"delete_published_posts\";b:1;s:19:\"delete_others_posts\";b:1;s:19:\"delete_others_pages\";b:1;s:17:\"manage_categories\";b:1;s:12:\"manage_links\";b:1;s:17:\"moderate_comments\";b:1;s:12:\"upload_files\";b:1;s:6:\"export\";b:1;s:6:\"import\";b:1;s:10:\"list_users\";b:1;s:18:\"edit_theme_options\";b:1;s:18:\"manage_woocommerce\";b:1;s:24:\"view_woocommerce_reports\";b:1;s:12:\"edit_product\";b:1;s:12:\"read_product\";b:1;s:14:\"delete_product\";b:1;s:13:\"edit_products\";b:1;s:20:\"edit_others_products\";b:1;s:16:\"publish_products\";b:1;s:21:\"read_private_products\";b:1;s:15:\"delete_products\";b:1;s:23:\"delete_private_products\";b:1;s:25:\"delete_published_products\";b:1;s:22:\"delete_others_products\";b:1;s:21:\"edit_private_products\";b:1;s:23:\"edit_published_products\";b:1;s:20:\"manage_product_terms\";b:1;s:18:\"edit_product_terms\";b:1;s:20:\"delete_product_terms\";b:1;s:20:\"assign_product_terms\";b:1;s:15:\"edit_shop_order\";b:1;s:15:\"read_shop_order\";b:1;s:17:\"delete_shop_order\";b:1;s:16:\"edit_shop_orders\";b:1;s:23:\"edit_others_shop_orders\";b:1;s:19:\"publish_shop_orders\";b:1;s:24:\"read_private_shop_orders\";b:1;s:18:\"delete_shop_orders\";b:1;s:26:\"delete_private_shop_orders\";b:1;s:28:\"delete_published_shop_orders\";b:1;s:25:\"delete_others_shop_orders\";b:1;s:24:\"edit_private_shop_orders\";b:1;s:26:\"edit_published_shop_orders\";b:1;s:23:\"manage_shop_order_terms\";b:1;s:21:\"edit_shop_order_terms\";b:1;s:23:\"delete_shop_order_terms\";b:1;s:23:\"assign_shop_order_terms\";b:1;s:16:\"edit_shop_coupon\";b:1;s:16:\"read_shop_coupon\";b:1;s:18:\"delete_shop_coupon\";b:1;s:17:\"edit_shop_coupons\";b:1;s:24:\"edit_others_shop_coupons\";b:1;s:20:\"publish_shop_coupons\";b:1;s:25:\"read_private_shop_coupons\";b:1;s:19:\"delete_shop_coupons\";b:1;s:27:\"delete_private_shop_coupons\";b:1;s:29:\"delete_published_shop_coupons\";b:1;s:26:\"delete_others_shop_coupons\";b:1;s:25:\"edit_private_shop_coupons\";b:1;s:27:\"edit_published_shop_coupons\";b:1;s:24:\"manage_shop_coupon_terms\";b:1;s:22:\"edit_shop_coupon_terms\";b:1;s:24:\"delete_shop_coupon_terms\";b:1;s:24:\"assign_shop_coupon_terms\";b:1;s:16:\"edit_attachments\";b:1;s:18:\"delete_attachments\";b:1;s:23:\"read_others_attachments\";b:1;s:23:\"edit_others_attachments\";b:1;s:25:\"delete_others_attachments\";b:1;}}s:13:\"bbp_spectator\";a:2:{s:4:\"name\";s:9:\"Spectator\";s:12:\"capabilities\";a:0:{}}s:10:\"subscriber\";a:2:{s:4:\"name\";s:10:\"Subscriber\";s:12:\"capabilities\";a:2:{s:4:\"read\";b:1;s:7:\"level_0\";b:1;}}s:18:\"wp-travel-customer\";a:2:{s:4:\"name\";s:18:\"WP Travel Customer\";s:12:\"capabilities\";a:1:{s:4:\"read\";b:1;}}s:5:\"milon\";a:2:{s:4:\"name\";s:5:\"milon\";s:12:\"capabilities\";a:18:{s:12:\"create_posts\";b:1;s:19:\"delete_others_posts\";b:1;s:12:\"delete_posts\";b:1;s:20:\"delete_private_posts\";b:1;s:22:\"delete_published_posts\";b:1;s:17:\"edit_others_posts\";b:1;s:10:\"edit_posts\";b:1;s:18:\"edit_private_posts\";b:1;s:20:\"edit_published_posts\";b:1;s:13:\"publish_posts\";b:1;s:4:\"read\";b:1;s:18:\"read_private_posts\";b:1;s:12:\"upload_files\";b:1;s:16:\"edit_attachments\";b:1;s:18:\"delete_attachments\";b:1;s:23:\"read_others_attachments\";b:1;s:23:\"edit_others_attachments\";b:1;s:25:\"delete_others_attachments\";b:1;}}s:6:\"taibur\";a:2:{s:4:\"name\";s:6:\"taibur\";s:12:\"capabilities\";a:71:{s:12:\"create_posts\";b:1;s:19:\"delete_others_posts\";b:1;s:12:\"delete_posts\";b:1;s:20:\"delete_private_posts\";b:1;s:22:\"delete_published_posts\";b:1;s:25:\"delete_published_products\";b:1;s:27:\"delete_published_room_types\";b:1;s:29:\"delete_published_shop_coupons\";b:1;s:28:\"delete_published_shop_orders\";b:1;s:12:\"delete_roles\";b:1;s:16:\"delete_room_type\";b:1;s:22:\"delete_room_type_terms\";b:1;s:17:\"delete_room_types\";b:1;s:18:\"delete_shop_coupon\";b:1;s:24:\"delete_shop_coupon_terms\";b:1;s:19:\"delete_shop_coupons\";b:1;s:17:\"delete_shop_order\";b:1;s:23:\"delete_shop_order_terms\";b:1;s:18:\"delete_shop_orders\";b:1;s:13:\"delete_themes\";b:1;s:12:\"delete_users\";b:1;s:25:\"delete_users_higher_level\";b:1;s:16:\"edit_attachments\";b:1;s:15:\"edit_awebooking\";b:1;s:21:\"edit_awebooking_terms\";b:1;s:16:\"edit_awebookings\";b:1;s:23:\"edit_content_shortcodes\";b:1;s:14:\"edit_dashboard\";b:1;s:16:\"edit_hb_bookings\";b:1;s:13:\"edit_hb_rooms\";b:1;s:19:\"edit_hotel_location\";b:1;s:25:\"edit_hotel_location_terms\";b:1;s:20:\"edit_hotel_locations\";b:1;s:18:\"edit_hotel_service\";b:1;s:24:\"edit_hotel_service_terms\";b:1;s:19:\"edit_hotel_services\";b:1;s:20:\"edit_login_redirects\";b:1;s:25:\"edit_nav_menu_permissions\";b:1;s:23:\"edit_others_attachments\";b:1;s:23:\"edit_others_awebookings\";b:1;s:23:\"edit_others_hb_bookings\";b:1;s:20:\"edit_others_hb_rooms\";b:1;s:27:\"edit_others_hotel_locations\";b:1;s:26:\"edit_others_hotel_services\";b:1;s:17:\"edit_others_pages\";b:1;s:17:\"edit_others_posts\";b:1;s:20:\"edit_others_products\";b:1;s:22:\"edit_others_room_types\";b:1;s:24:\"edit_others_shop_coupons\";b:1;s:23:\"edit_others_shop_orders\";b:1;s:10:\"edit_pages\";b:1;s:27:\"edit_pages_role_permissions\";b:1;s:12:\"edit_plugins\";b:1;s:10:\"edit_posts\";b:1;s:27:\"edit_posts_role_permissions\";b:1;s:24:\"edit_private_awebookings\";b:1;s:24:\"edit_private_hb_bookings\";b:1;s:21:\"edit_private_hb_rooms\";b:1;s:28:\"edit_private_hotel_locations\";b:1;s:27:\"edit_private_hotel_services\";b:1;s:18:\"edit_private_pages\";b:1;s:18:\"edit_private_posts\";b:1;s:21:\"edit_private_products\";b:1;s:23:\"edit_private_room_types\";b:1;s:25:\"edit_private_shop_coupons\";b:1;s:24:\"edit_private_shop_orders\";b:1;s:20:\"edit_published_posts\";b:1;s:13:\"publish_posts\";b:1;s:18:\"read_private_posts\";b:1;s:12:\"upload_files\";b:1;s:14:\"ure_edit_roles\";b:1;}}}', 'yes'),
(95, 'fresh_site', '0', 'yes'),
(96, 'widget_search', 'a:2:{i:2;a:1:{s:5:\"title\";s:0:\"\";}s:12:\"_multiwidget\";i:1;}', 'yes'),
(97, 'widget_recent-posts', 'a:2:{i:2;a:2:{s:5:\"title\";s:0:\"\";s:6:\"number\";i:5;}s:12:\"_multiwidget\";i:1;}', 'yes'),
(98, 'widget_recent-comments', 'a:2:{i:2;a:2:{s:5:\"title\";s:0:\"\";s:6:\"number\";i:5;}s:12:\"_multiwidget\";i:1;}', 'yes'),
(99, 'widget_archives', 'a:2:{i:2;a:3:{s:5:\"title\";s:0:\"\";s:5:\"count\";i:0;s:8:\"dropdown\";i:0;}s:12:\"_multiwidget\";i:1;}', 'yes'),
(100, 'widget_meta', 'a:2:{i:2;a:1:{s:5:\"title\";s:0:\"\";}s:12:\"_multiwidget\";i:1;}', 'yes'),
(101, 'sidebars_widgets', 'a:9:{s:19:\"wp_inactive_widgets\";a:0:{}s:9:\"sidebar-1\";a:5:{i:0;s:8:\"search-2\";i:1;s:14:\"recent-posts-2\";i:2;s:17:\"recent-comments-2\";i:3;s:10:\"archives-2\";i:4;s:6:\"meta-2\";}s:7:\"footer1\";a:0:{}s:7:\"footer2\";a:0:{}s:7:\"footer3\";a:0:{}s:7:\"footer4\";a:1:{i:0;s:12:\"categories-2\";}s:18:\"footerbottom-right\";a:0:{}s:12:\"page_sidebar\";a:0:{}s:13:\"array_version\";i:3;}', 'yes'),
(102, 'widget_pages', 'a:1:{s:12:\"_multiwidget\";i:1;}', 'yes'),
(103, 'widget_calendar', 'a:1:{s:12:\"_multiwidget\";i:1;}', 'yes'),
(104, 'widget_media_audio', 'a:1:{s:12:\"_multiwidget\";i:1;}', 'yes'),
(105, 'widget_media_image', 'a:1:{s:12:\"_multiwidget\";i:1;}', 'yes'),
(106, 'widget_media_gallery', 'a:1:{s:12:\"_multiwidget\";i:1;}', 'yes'),
(107, 'widget_media_video', 'a:1:{s:12:\"_multiwidget\";i:1;}', 'yes'),
(108, 'widget_tag_cloud', 'a:1:{s:12:\"_multiwidget\";i:1;}', 'yes'),
(109, 'widget_nav_menu', 'a:1:{s:12:\"_multiwidget\";i:1;}', 'yes'),
(110, 'widget_custom_html', 'a:1:{s:12:\"_multiwidget\";i:1;}', 'yes'),
(111, 'cron', 'a:13:{i:1570209561;a:1:{s:28:\"woocommerce_cleanup_sessions\";a:1:{s:32:\"40cd750bba9870f18aada2478b24840a\";a:3:{s:8:\"schedule\";s:10:\"twicedaily\";s:4:\"args\";a:0:{}s:8:\"interval\";i:43200;}}}i:1570210651;a:3:{s:16:\"wp_version_check\";a:1:{s:32:\"40cd750bba9870f18aada2478b24840a\";a:3:{s:8:\"schedule\";s:10:\"twicedaily\";s:4:\"args\";a:0:{}s:8:\"interval\";i:43200;}}s:17:\"wp_update_plugins\";a:1:{s:32:\"40cd750bba9870f18aada2478b24840a\";a:3:{s:8:\"schedule\";s:10:\"twicedaily\";s:4:\"args\";a:0:{}s:8:\"interval\";i:43200;}}s:16:\"wp_update_themes\";a:1:{s:32:\"40cd750bba9870f18aada2478b24840a\";a:3:{s:8:\"schedule\";s:10:\"twicedaily\";s:4:\"args\";a:0:{}s:8:\"interval\";i:43200;}}}i:1570211086;a:1:{s:29:\"wp_session_garbage_collection\";a:1:{s:32:\"40cd750bba9870f18aada2478b24840a\";a:3:{s:8:\"schedule\";s:6:\"hourly\";s:4:\"args\";a:0:{}s:8:\"interval\";i:3600;}}}i:1570211200;a:1:{s:34:\"wp_privacy_delete_old_export_files\";a:1:{s:32:\"40cd750bba9870f18aada2478b24840a\";a:3:{s:8:\"schedule\";s:6:\"hourly\";s:4:\"args\";a:0:{}s:8:\"interval\";i:3600;}}}i:1570215434;a:1:{s:24:\"akismet_scheduled_delete\";a:1:{s:32:\"40cd750bba9870f18aada2478b24840a\";a:3:{s:8:\"schedule\";s:5:\"daily\";s:4:\"args\";a:0:{}s:8:\"interval\";i:86400;}}}i:1570233600;a:1:{s:27:\"woocommerce_scheduled_sales\";a:1:{s:32:\"40cd750bba9870f18aada2478b24840a\";a:3:{s:8:\"schedule\";s:5:\"daily\";s:4:\"args\";a:0:{}s:8:\"interval\";i:86400;}}}i:1570248086;a:1:{s:35:\"site-reviews/schedule/session/purge\";a:1:{s:32:\"40cd750bba9870f18aada2478b24840a\";a:3:{s:8:\"schedule\";s:10:\"twicedaily\";s:4:\"args\";a:0:{}s:8:\"interval\";i:43200;}}}i:1570253921;a:2:{s:19:\"wp_scheduled_delete\";a:1:{s:32:\"40cd750bba9870f18aada2478b24840a\";a:3:{s:8:\"schedule\";s:5:\"daily\";s:4:\"args\";a:0:{}s:8:\"interval\";i:86400;}}s:25:\"delete_expired_transients\";a:1:{s:32:\"40cd750bba9870f18aada2478b24840a\";a:3:{s:8:\"schedule\";s:5:\"daily\";s:4:\"args\";a:0:{}s:8:\"interval\";i:86400;}}}i:1570254399;a:1:{s:30:\"wp_scheduled_auto_draft_delete\";a:1:{s:32:\"40cd750bba9870f18aada2478b24840a\";a:3:{s:8:\"schedule\";s:5:\"daily\";s:4:\"args\";a:0:{}s:8:\"interval\";i:86400;}}}i:1570274361;a:1:{s:33:\"woocommerce_cleanup_personal_data\";a:1:{s:32:\"40cd750bba9870f18aada2478b24840a\";a:3:{s:8:\"schedule\";s:5:\"daily\";s:4:\"args\";a:0:{}s:8:\"interval\";i:86400;}}}i:1570285161;a:1:{s:24:\"woocommerce_cleanup_logs\";a:1:{s:32:\"40cd750bba9870f18aada2478b24840a\";a:3:{s:8:\"schedule\";s:5:\"daily\";s:4:\"args\";a:0:{}s:8:\"interval\";i:86400;}}}i:1572199339;a:1:{s:25:\"otgs_send_components_data\";a:1:{s:32:\"40cd750bba9870f18aada2478b24840a\";a:2:{s:8:\"schedule\";b:0;s:4:\"args\";a:0:{}}}}s:7:\"version\";i:2;}', 'yes'),
(112, 'theme_mods_twentynineteen', 'a:2:{s:18:\"custom_css_post_id\";i:-1;s:16:\"sidebars_widgets\";a:2:{s:4:\"time\";i:1550564502;s:4:\"data\";a:2:{s:19:\"wp_inactive_widgets\";a:0:{}s:9:\"sidebar-1\";a:6:{i:0;s:8:\"search-2\";i:1;s:14:\"recent-posts-2\";i:2;s:17:\"recent-comments-2\";i:3;s:10:\"archives-2\";i:4;s:12:\"categories-2\";i:5;s:6:\"meta-2\";}}}}', 'yes'),
(123, 'can_compress_scripts', '1', 'no'),
(144, 'current_theme', 'venox', 'yes'),
(145, 'theme_mods_twentyseventeen', 'a:4:{i:0;b:0;s:18:\"nav_menu_locations\";a:1:{s:3:\"top\";i:2;}s:18:\"custom_css_post_id\";i:-1;s:16:\"sidebars_widgets\";a:2:{s:4:\"time\";i:1557979090;s:4:\"data\";a:5:{s:19:\"wp_inactive_widgets\";a:0:{}s:25:\"wp-travel-archive-sidebar\";a:0:{}s:9:\"sidebar-1\";a:6:{i:0;s:8:\"search-2\";i:1;s:14:\"recent-posts-2\";i:2;s:17:\"recent-comments-2\";i:3;s:10:\"archives-2\";i:4;s:12:\"categories-2\";i:5;s:6:\"meta-2\";}s:9:\"sidebar-2\";a:0:{}s:9:\"sidebar-3\";a:0:{}}}}', 'yes'),
(146, 'theme_switched', '', 'yes'),
(149, 'theme_mods_twentysixteen', 'a:4:{i:0;b:0;s:18:\"nav_menu_locations\";a:1:{s:7:\"primary\";i:2;}s:16:\"sidebars_widgets\";a:2:{s:4:\"time\";i:1559503883;s:4:\"data\";a:4:{s:19:\"wp_inactive_widgets\";a:0:{}s:9:\"sidebar-1\";a:6:{i:0;s:8:\"search-2\";i:1;s:14:\"recent-posts-2\";i:2;s:17:\"recent-comments-2\";i:3;s:10:\"archives-2\";i:4;s:12:\"categories-2\";i:5;s:6:\"meta-2\";}s:9:\"sidebar-2\";a:0:{}s:9:\"sidebar-3\";a:0:{}}}s:18:\"custom_css_post_id\";i:-1;}', 'yes'),
(151, 'theme_mods_hazproject', 'a:4:{i:0;b:0;s:18:\"nav_menu_locations\";a:3:{s:9:\"main_menu\";i:2;s:6:\"menu-1\";i:2;s:11:\"footer_menu\";i:204;}s:18:\"custom_css_post_id\";i:-1;s:16:\"sidebars_widgets\";a:2:{s:4:\"time\";i:1560702394;s:4:\"data\";a:8:{s:19:\"wp_inactive_widgets\";a:0:{}s:9:\"sidebar-1\";a:5:{i:0;s:8:\"search-2\";i:1;s:14:\"recent-posts-2\";i:2;s:17:\"recent-comments-2\";i:3;s:10:\"archives-2\";i:4;s:6:\"meta-2\";}s:7:\"footer1\";a:0:{}s:7:\"footer2\";a:0:{}s:7:\"footer3\";a:0:{}s:7:\"footer4\";a:1:{i:0;s:12:\"categories-2\";}s:18:\"footerbottom-right\";a:0:{}s:12:\"page_sidebar\";a:0:{}}}}', 'yes'),
(153, 'redux_version_upgraded_from', '3.6.5', 'yes'),
(157, 'r_notice_data', '{\"type\":\"redux-message\",\"title\":\"<strong>Redux v4 Beta:  We Need Your Help!<\\/strong><br\\/>\\r\\n\\r\\n\",\"message\":\"The long in-development Redux v4 Beta is nearing completion and we could really use your help!  To learn how to do so, please read our latest blog post: <a href=\\\"https:\\/\\/reduxframework.com\\/2018\\/11\\/redux-4-0-we-need-your-help\\/\\\">Redux 4.0 - We Need Your Help!<\\/a>\",\"color\":\"rgba(0,162,227,1)\"}\n', 'yes'),
(158, 'redux_blast', '1550567399', 'yes'),
(159, 'acf_version', '4.4.12', 'yes'),
(160, 'redux_demo', 'a:16:{s:8:\"last_tab\";s:1:\"1\";s:4:\"logo\";a:5:{s:3:\"url\";s:82:\"http://localhost/lipan/wordpress/milonvi/wp-content/uploads/2019/02/logo-white.png\";s:2:\"id\";s:2:\"37\";s:6:\"height\";s:2:\"20\";s:5:\"width\";s:2:\"95\";s:9:\"thumbnail\";s:82:\"http://localhost/lipan/wordpress/milonvi/wp-content/uploads/2019/02/logo-white.png\";}s:5:\"phone\";s:20:\"(000) 999 - 656 -888\";s:5:\"email\";s:18:\"contact@domain.com\";s:8:\"facebook\";s:1:\"#\";s:7:\"twitter\";s:1:\"#\";s:8:\"linkedin\";s:1:\"#\";s:10:\"googleplus\";s:1:\"#\";s:23:\"best_travel_agent_title\";s:17:\"Best Travel Agent\";s:25:\"best_travel_agent_content\";s:90:\"Morbi semper fames lobortis ac hac penatibus quisque massa scelerisque proin dignissim est\";s:18:\"trust_safety_title\";s:14:\"Trust & Safety\";s:20:\"trust_safety_content\";s:98:\"Viverra magna gravida accumsan enim integer faucibus velit leo laoreet platea senectus ullamcorper\";s:26:\"best_price_guarantee_title\";s:20:\"Best Price Guarantee\";s:28:\"best_price_guarantee_content\";s:83:\"At nec sit magnis enim nascetur platea molestie lobortis purus nunc tempor placerat\";s:7:\"aboutus\";s:105:\"Booking, reviews and advices on hotels, resorts, flights, vacation rentals, Hajj packages, and lots more!\";s:20:\"trust_have_questions\";s:312:\"  <div class=\"wpb-wrapper4 wpb-wrapper\">\r\n                        <h4>Have Questions?</h4>\r\n                        <h4 class=\"text-color\">+1-202-555-0173</h4>\r\n                        <a href=\"#\">support@domain.com</a>\r\n                        <p>24/7 Dedicated Customer Support</p>\r\n                    </div> \";}', 'yes'),
(161, 'redux_demo-transients', 'a:2:{s:14:\"changed_values\";a:0:{}s:9:\"last_save\";i:1560702942;}', 'yes'),
(162, 'nav_menu_options', 'a:2:{i:0;b:0;s:8:\"auto_add\";a:0:{}}', 'yes'),
(259, 'Airline company_children', 'a:0:{}', 'yes'),
(278, 'Room Type_children', 'a:0:{}', 'yes'),
(283, 'recently_activated', 'a:1:{s:43:\"custom-post-type-ui/custom-post-type-ui.php\";i:1560696499;}', 'yes'),
(306, 'Expert Rating_children', 'a:0:{}', 'yes'),
(310, 'Room Facilities_children', 'a:0:{}', 'yes'),
(314, 'Promotions_children', 'a:0:{}', 'yes'),
(339, 'Package Class_children', 'a:0:{}', 'yes'),
(431, 'RoomType_children', 'a:0:{}', 'yes'),
(439, 'Location_children', 'a:0:{}', 'yes'),
(442, 'Hotel Name_children', 'a:0:{}', 'yes'),
(445, 'Price Range_children', 'a:0:{}', 'yes'),
(449, 'No of Days_children', 'a:0:{}', 'yes'),
(503, 'HotelName_children', 'a:0:{}', 'yes'),
(506, 'PriceRange_children', 'a:0:{}', 'yes'),
(508, 'RoomFacilities_children', 'a:0:{}', 'yes'),
(513, 'NoofDays_children', 'a:0:{}', 'yes'),
(518, 'PackageClass_children', 'a:0:{}', 'yes'),
(575, 'woocommerce_store_address', 'Mirpur', 'yes'),
(576, 'woocommerce_store_address_2', 'Kalshi road', 'yes'),
(577, 'woocommerce_store_city', 'Dhaka', 'yes'),
(578, 'woocommerce_default_country', 'AX', 'yes'),
(579, 'woocommerce_store_postcode', '1216', 'yes'),
(580, 'woocommerce_allowed_countries', 'all', 'yes'),
(581, 'woocommerce_all_except_countries', 'a:0:{}', 'yes'),
(582, 'woocommerce_specific_allowed_countries', 'a:0:{}', 'yes'),
(583, 'woocommerce_ship_to_countries', '', 'yes'),
(584, 'woocommerce_specific_ship_to_countries', 'a:0:{}', 'yes'),
(585, 'woocommerce_default_customer_address', 'geolocation', 'yes'),
(586, 'woocommerce_calc_taxes', 'no', 'yes'),
(587, 'woocommerce_currency', 'BDT', 'yes'),
(588, 'woocommerce_currency_pos', 'left', 'yes'),
(589, 'woocommerce_price_thousand_sep', ',', 'yes'),
(590, 'woocommerce_price_decimal_sep', '.', 'yes'),
(591, 'woocommerce_price_num_decimals', '2', 'yes'),
(592, 'woocommerce_shop_page_id', '197', 'yes'),
(593, 'woocommerce_cart_redirect_after_add', 'yes', 'yes'),
(594, 'woocommerce_enable_ajax_add_to_cart', 'yes', 'yes'),
(595, 'woocommerce_weight_unit', 'kg', 'yes'),
(596, 'woocommerce_dimension_unit', 'in', 'yes'),
(597, 'woocommerce_enable_reviews', 'yes', 'yes'),
(598, 'woocommerce_review_rating_verification_label', 'yes', 'no'),
(599, 'woocommerce_review_rating_verification_required', 'no', 'no'),
(600, 'woocommerce_enable_review_rating', 'yes', 'yes'),
(601, 'woocommerce_review_rating_required', 'yes', 'no'),
(602, 'woocommerce_manage_stock', 'yes', 'yes'),
(603, 'woocommerce_hold_stock_minutes', '60', 'no'),
(604, 'woocommerce_notify_low_stock', 'yes', 'no'),
(605, 'woocommerce_notify_no_stock', 'yes', 'no'),
(606, 'woocommerce_stock_email_recipient', 'admin@gmail.com', 'no'),
(607, 'woocommerce_notify_low_stock_amount', '2', 'no'),
(608, 'woocommerce_notify_no_stock_amount', '0', 'yes'),
(609, 'woocommerce_hide_out_of_stock_items', 'no', 'yes'),
(610, 'woocommerce_stock_format', '', 'yes'),
(611, 'woocommerce_file_download_method', 'xsendfile', 'no'),
(612, 'woocommerce_downloads_require_login', 'no', 'no'),
(613, 'woocommerce_downloads_grant_access_after_payment', 'yes', 'no'),
(614, 'woocommerce_prices_include_tax', 'no', 'yes'),
(615, 'woocommerce_tax_based_on', 'shipping', 'yes'),
(616, 'woocommerce_shipping_tax_class', 'inherit', 'yes'),
(617, 'woocommerce_tax_round_at_subtotal', 'no', 'yes'),
(618, 'woocommerce_tax_classes', 'Reduced rate\r\nZero rate', 'yes'),
(619, 'woocommerce_tax_display_shop', 'excl', 'yes'),
(620, 'woocommerce_tax_display_cart', 'excl', 'no'),
(621, 'woocommerce_price_display_suffix', '', 'yes'),
(622, 'woocommerce_tax_total_display', 'itemized', 'no'),
(623, 'woocommerce_enable_shipping_calc', 'yes', 'no'),
(624, 'woocommerce_shipping_cost_requires_address', 'no', 'no'),
(625, 'woocommerce_ship_to_destination', 'billing', 'no'),
(626, 'woocommerce_shipping_debug_mode', 'no', 'no'),
(627, 'woocommerce_enable_coupons', 'yes', 'yes'),
(628, 'woocommerce_calc_discounts_sequentially', 'no', 'no'),
(629, 'woocommerce_enable_guest_checkout', 'yes', 'no'),
(630, 'woocommerce_force_ssl_checkout', 'no', 'yes'),
(631, 'woocommerce_unforce_ssl_checkout', 'yes', 'yes'),
(632, 'woocommerce_cart_page_id', '198', 'yes'),
(633, 'woocommerce_checkout_page_id', '290', 'yes'),
(634, 'woocommerce_terms_page_id', '198', 'no'),
(635, 'woocommerce_checkout_pay_endpoint', 'order-pay', 'yes'),
(636, 'woocommerce_checkout_order_received_endpoint', 'order-received', 'yes'),
(637, 'woocommerce_myaccount_add_payment_method_endpoint', 'add-payment-method', 'yes'),
(638, 'woocommerce_myaccount_delete_payment_method_endpoint', 'delete-payment-method', 'yes'),
(639, 'woocommerce_myaccount_set_default_payment_method_endpoint', 'set-default-payment-method', 'yes'),
(640, 'woocommerce_myaccount_page_id', '197', 'yes'),
(641, 'woocommerce_enable_signup_and_login_from_checkout', 'no', 'no'),
(642, 'woocommerce_enable_myaccount_registration', 'yes', 'no'),
(643, 'woocommerce_enable_checkout_login_reminder', 'yes', 'no'),
(644, 'woocommerce_registration_generate_username', 'yes', 'no'),
(645, 'woocommerce_registration_generate_password', 'yes', 'no'),
(646, 'woocommerce_myaccount_orders_endpoint', 'orders', 'yes'),
(647, 'woocommerce_myaccount_view_order_endpoint', 'view-order', 'yes'),
(648, 'woocommerce_myaccount_downloads_endpoint', 'downloads', 'yes'),
(649, 'woocommerce_myaccount_edit_account_endpoint', 'edit-account', 'yes'),
(650, 'woocommerce_myaccount_edit_address_endpoint', 'edit-address', 'yes'),
(651, 'woocommerce_myaccount_payment_methods_endpoint', 'payment-methods', 'yes'),
(652, 'woocommerce_myaccount_lost_password_endpoint', 'lost-password', 'yes'),
(653, 'woocommerce_logout_endpoint', 'customer-logout', 'yes'),
(654, 'woocommerce_email_from_name', 'projct new development', 'no'),
(655, 'woocommerce_email_from_address', 'admin@gmail.com', 'no'),
(656, 'woocommerce_email_header_image', '', 'no'),
(657, 'woocommerce_email_footer_text', '{site_title}', 'no'),
(658, 'woocommerce_email_base_color', '#96588a', 'no'),
(659, 'woocommerce_email_background_color', '#f7f7f7', 'no'),
(660, 'woocommerce_email_body_background_color', '#ffffff', 'no'),
(661, 'woocommerce_email_text_color', '#3c3c3c', 'no'),
(662, 'woocommerce_api_enabled', 'yes', 'yes'),
(663, 'woocommerce_permalinks', 'a:5:{s:12:\"product_base\";s:7:\"product\";s:13:\"category_base\";s:16:\"product-category\";s:8:\"tag_base\";s:11:\"product-tag\";s:14:\"attribute_base\";s:0:\"\";s:22:\"use_verbose_page_rules\";b:0;}', 'yes'),
(664, 'current_theme_supports_woocommerce', 'yes', 'yes'),
(665, 'woocommerce_queue_flush_rewrite_rules', 'no', 'yes'),
(668, 'default_product_cat', '73', 'yes'),
(673, 'woocommerce_admin_notices', 'a:1:{i:0;s:20:\"no_secure_connection\";}', 'yes'),
(674, '_transient_woocommerce_webhook_ids', 'a:0:{}', 'yes'),
(675, 'widget_woocommerce_widget_cart', 'a:1:{s:12:\"_multiwidget\";i:1;}', 'yes'),
(676, 'widget_woocommerce_layered_nav_filters', 'a:1:{s:12:\"_multiwidget\";i:1;}', 'yes'),
(677, 'widget_woocommerce_layered_nav', 'a:1:{s:12:\"_multiwidget\";i:1;}', 'yes'),
(678, 'widget_woocommerce_price_filter', 'a:1:{s:12:\"_multiwidget\";i:1;}', 'yes'),
(679, 'widget_woocommerce_product_categories', 'a:1:{s:12:\"_multiwidget\";i:1;}', 'yes'),
(680, 'widget_woocommerce_product_search', 'a:1:{s:12:\"_multiwidget\";i:1;}', 'yes'),
(681, 'widget_woocommerce_product_tag_cloud', 'a:1:{s:12:\"_multiwidget\";i:1;}', 'yes'),
(682, 'widget_woocommerce_products', 'a:1:{s:12:\"_multiwidget\";i:1;}', 'yes'),
(683, 'widget_woocommerce_recently_viewed_products', 'a:1:{s:12:\"_multiwidget\";i:1;}', 'yes'),
(684, 'widget_woocommerce_top_rated_products', 'a:1:{s:12:\"_multiwidget\";i:1;}', 'yes'),
(685, 'widget_woocommerce_recent_reviews', 'a:1:{s:12:\"_multiwidget\";i:1;}', 'yes'),
(686, 'widget_woocommerce_rating_filter', 'a:1:{s:12:\"_multiwidget\";i:1;}', 'yes'),
(689, 'woocommerce_meta_box_errors', 'a:0:{}', 'yes'),
(690, 'woocommerce_product_type', 'both', 'yes'),
(691, 'woocommerce_allow_tracking', 'yes', 'yes'),
(692, 'woocommerce_tracker_last_send', '1554204060', 'yes'),
(693, 'woocommerce_ppec_paypal_settings', 'a:2:{s:16:\"reroute_requests\";b:0;s:5:\"email\";b:0;}', 'yes'),
(694, 'woocommerce_cheque_settings', 'a:4:{s:7:\"enabled\";s:3:\"yes\";s:5:\"title\";s:14:\"Check payments\";s:11:\"description\";s:98:\"Please send a check to Store Name, Store Street, Store Town, Store State / County, Store Postcode.\";s:12:\"instructions\";s:0:\"\";}', 'yes'),
(695, 'woocommerce_bacs_settings', 'a:1:{s:7:\"enabled\";s:3:\"yes\";}', 'yes'),
(696, 'woocommerce_cod_settings', 'a:1:{s:7:\"enabled\";s:3:\"yes\";}', 'yes'),
(698, '_transient_shipping-transient-version', '1551549411', 'yes'),
(705, 'theme_mods_storefront', 'a:4:{i:0;b:0;s:18:\"nav_menu_locations\";a:2:{s:7:\"primary\";i:2;s:9:\"secondary\";i:204;}s:18:\"custom_css_post_id\";i:-1;s:16:\"sidebars_widgets\";a:2:{s:4:\"time\";i:1559503859;s:4:\"data\";a:7:{s:19:\"wp_inactive_widgets\";a:0:{}s:9:\"sidebar-1\";a:6:{i:0;s:8:\"search-2\";i:1;s:14:\"recent-posts-2\";i:2;s:17:\"recent-comments-2\";i:3;s:10:\"archives-2\";i:4;s:12:\"categories-2\";i:5;s:6:\"meta-2\";}s:8:\"header-1\";a:0:{}s:8:\"footer-1\";a:0:{}s:8:\"footer-2\";a:0:{}s:8:\"footer-3\";a:0:{}s:8:\"footer-4\";a:0:{}}}}', 'yes'),
(706, 'storefront_nux_fresh_site', '0', 'yes'),
(707, 'woocommerce_catalog_rows', '3', 'yes'),
(708, 'woocommerce_catalog_columns', '4', 'yes'),
(709, 'woocommerce_maybe_regenerate_images_hash', 'f261099d5ac7c38b838790cc120ec5ff', 'yes'),
(725, '_transient_product_query-transient-version', '1554372095', 'yes'),
(730, 'storefront_nux_dismissed', '1', 'yes'),
(731, 'storefront_nux_guided_tour', '1', 'yes'),
(739, '_transient_product-transient-version', '1554372095', 'yes'),
(815, '_transient_orders-transient-version', '1551470204', 'yes'),
(820, 'woocommerce_tracker_ua', 'a:9:{i:0;s:77:\"mozilla/5.0 (windows nt 6.1; win64; x64; rv:65.0) gecko/20100101 firefox/65.0\";i:1;s:73:\"Mozilla/5.0 (Windows NT 10.0; WOW64; rv:66.0) Gecko/20100101 Firefox/66.0\";i:2;s:77:\"Mozilla/5.0 (Windows NT 6.1; Win64; x64; rv:65.0) Gecko/20100101 Firefox/65.0\";i:3;s:114:\"Mozilla/5.0 (Windows NT 6.1; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/72.0.3626.119 Safari/537.36\";i:4;s:73:\"Mozilla/5.0 (Windows NT 10.0; WOW64; rv:67.0) Gecko/20100101 Firefox/67.0\";i:5;s:77:\"Mozilla/5.0 (Windows NT 6.1; Win64; x64; rv:66.0) Gecko/20100101 Firefox/66.0\";i:6;s:114:\"Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/73.0.3683.86 Safari/537.36\";i:7;s:113:\"Mozilla/5.0 (Windows NT 6.1; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/73.0.3683.86 Safari/537.36\";i:8;s:114:\"Mozilla/5.0 (Windows NT 6.1; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/74.0.3729.131 Safari/537.36\";}', 'yes'),
(844, '_transient_wc_attribute_taxonomies', 'a:1:{i:0;O:8:\"stdClass\":6:{s:12:\"attribute_id\";s:1:\"1\";s:14:\"attribute_name\";s:6:\"gfdgfd\";s:15:\"attribute_label\";s:6:\"gdfgfd\";s:14:\"attribute_type\";s:6:\"select\";s:17:\"attribute_orderby\";s:10:\"menu_order\";s:16:\"attribute_public\";s:1:\"0\";}}', 'yes'),
(856, 'product_cat_children', 'a:0:{}', 'yes'),
(901, 'bbpress_shortcodes', 'a:1:{s:24:\"bbpress_shortcodes_posts\";a:9:{s:4:\"post\";s:4:\"post\";s:4:\"page\";s:4:\"page\";s:10:\"attachment\";s:10:\"attachment\";s:7:\"product\";s:7:\"product\";s:5:\"umrah\";s:5:\"umrah\";s:4:\"cars\";s:4:\"cars\";s:5:\"tours\";s:5:\"tours\";s:6:\"rental\";s:6:\"rental\";s:7:\"flights\";s:7:\"flights\";}}', 'yes'),
(902, 'wpcf7', 'a:2:{s:7:\"version\";s:5:\"5.0.1\";s:13:\"bulk_validate\";a:4:{s:9:\"timestamp\";i:1551523045;s:7:\"version\";s:5:\"5.0.1\";s:11:\"count_valid\";i:1;s:13:\"count_invalid\";i:0;}}', 'yes'),
(905, 'user_role_editor', 'a:8:{s:11:\"ure_version\";s:6:\"4.50.2\";s:19:\"ure_hide_pro_banner\";i:1;s:15:\"show_admin_role\";i:0;s:17:\"ure_caps_readable\";i:0;s:24:\"ure_show_deprecated_caps\";i:0;s:23:\"ure_confirm_role_update\";s:1:\"1\";s:14:\"edit_user_caps\";s:1:\"1\";s:18:\"caps_columns_quant\";i:1;}', 'yes');
INSERT INTO `wp_options` (`option_id`, `option_name`, `option_value`, `autoload`) VALUES
(906, 'wp_backup_user_roles', 'a:12:{s:13:\"administrator\";a:2:{s:4:\"name\";s:13:\"Administrator\";s:12:\"capabilities\";a:114:{s:13:\"switch_themes\";b:1;s:11:\"edit_themes\";b:1;s:16:\"activate_plugins\";b:1;s:12:\"edit_plugins\";b:1;s:10:\"edit_users\";b:1;s:10:\"edit_files\";b:1;s:14:\"manage_options\";b:1;s:17:\"moderate_comments\";b:1;s:17:\"manage_categories\";b:1;s:12:\"manage_links\";b:1;s:12:\"upload_files\";b:1;s:6:\"import\";b:1;s:15:\"unfiltered_html\";b:1;s:10:\"edit_posts\";b:1;s:17:\"edit_others_posts\";b:1;s:20:\"edit_published_posts\";b:1;s:13:\"publish_posts\";b:1;s:10:\"edit_pages\";b:1;s:4:\"read\";b:1;s:8:\"level_10\";b:1;s:7:\"level_9\";b:1;s:7:\"level_8\";b:1;s:7:\"level_7\";b:1;s:7:\"level_6\";b:1;s:7:\"level_5\";b:1;s:7:\"level_4\";b:1;s:7:\"level_3\";b:1;s:7:\"level_2\";b:1;s:7:\"level_1\";b:1;s:7:\"level_0\";b:1;s:17:\"edit_others_pages\";b:1;s:20:\"edit_published_pages\";b:1;s:13:\"publish_pages\";b:1;s:12:\"delete_pages\";b:1;s:19:\"delete_others_pages\";b:1;s:22:\"delete_published_pages\";b:1;s:12:\"delete_posts\";b:1;s:19:\"delete_others_posts\";b:1;s:22:\"delete_published_posts\";b:1;s:20:\"delete_private_posts\";b:1;s:18:\"edit_private_posts\";b:1;s:18:\"read_private_posts\";b:1;s:20:\"delete_private_pages\";b:1;s:18:\"edit_private_pages\";b:1;s:18:\"read_private_pages\";b:1;s:12:\"delete_users\";b:1;s:12:\"create_users\";b:1;s:17:\"unfiltered_upload\";b:1;s:14:\"edit_dashboard\";b:1;s:14:\"update_plugins\";b:1;s:14:\"delete_plugins\";b:1;s:15:\"install_plugins\";b:1;s:13:\"update_themes\";b:1;s:14:\"install_themes\";b:1;s:11:\"update_core\";b:1;s:10:\"list_users\";b:1;s:12:\"remove_users\";b:1;s:13:\"promote_users\";b:1;s:18:\"edit_theme_options\";b:1;s:13:\"delete_themes\";b:1;s:6:\"export\";b:1;s:18:\"manage_woocommerce\";b:1;s:24:\"view_woocommerce_reports\";b:1;s:12:\"edit_product\";b:1;s:12:\"read_product\";b:1;s:14:\"delete_product\";b:1;s:13:\"edit_products\";b:1;s:20:\"edit_others_products\";b:1;s:16:\"publish_products\";b:1;s:21:\"read_private_products\";b:1;s:15:\"delete_products\";b:1;s:23:\"delete_private_products\";b:1;s:25:\"delete_published_products\";b:1;s:22:\"delete_others_products\";b:1;s:21:\"edit_private_products\";b:1;s:23:\"edit_published_products\";b:1;s:20:\"manage_product_terms\";b:1;s:18:\"edit_product_terms\";b:1;s:20:\"delete_product_terms\";b:1;s:20:\"assign_product_terms\";b:1;s:15:\"edit_shop_order\";b:1;s:15:\"read_shop_order\";b:1;s:17:\"delete_shop_order\";b:1;s:16:\"edit_shop_orders\";b:1;s:23:\"edit_others_shop_orders\";b:1;s:19:\"publish_shop_orders\";b:1;s:24:\"read_private_shop_orders\";b:1;s:18:\"delete_shop_orders\";b:1;s:26:\"delete_private_shop_orders\";b:1;s:28:\"delete_published_shop_orders\";b:1;s:25:\"delete_others_shop_orders\";b:1;s:24:\"edit_private_shop_orders\";b:1;s:26:\"edit_published_shop_orders\";b:1;s:23:\"manage_shop_order_terms\";b:1;s:21:\"edit_shop_order_terms\";b:1;s:23:\"delete_shop_order_terms\";b:1;s:23:\"assign_shop_order_terms\";b:1;s:16:\"edit_shop_coupon\";b:1;s:16:\"read_shop_coupon\";b:1;s:18:\"delete_shop_coupon\";b:1;s:17:\"edit_shop_coupons\";b:1;s:24:\"edit_others_shop_coupons\";b:1;s:20:\"publish_shop_coupons\";b:1;s:25:\"read_private_shop_coupons\";b:1;s:19:\"delete_shop_coupons\";b:1;s:27:\"delete_private_shop_coupons\";b:1;s:29:\"delete_published_shop_coupons\";b:1;s:26:\"delete_others_shop_coupons\";b:1;s:25:\"edit_private_shop_coupons\";b:1;s:27:\"edit_published_shop_coupons\";b:1;s:24:\"manage_shop_coupon_terms\";b:1;s:22:\"edit_shop_coupon_terms\";b:1;s:24:\"delete_shop_coupon_terms\";b:1;s:24:\"assign_shop_coupon_terms\";b:1;}}s:6:\"editor\";a:2:{s:4:\"name\";s:6:\"Editor\";s:12:\"capabilities\";a:34:{s:17:\"moderate_comments\";b:1;s:17:\"manage_categories\";b:1;s:12:\"manage_links\";b:1;s:12:\"upload_files\";b:1;s:15:\"unfiltered_html\";b:1;s:10:\"edit_posts\";b:1;s:17:\"edit_others_posts\";b:1;s:20:\"edit_published_posts\";b:1;s:13:\"publish_posts\";b:1;s:10:\"edit_pages\";b:1;s:4:\"read\";b:1;s:7:\"level_7\";b:1;s:7:\"level_6\";b:1;s:7:\"level_5\";b:1;s:7:\"level_4\";b:1;s:7:\"level_3\";b:1;s:7:\"level_2\";b:1;s:7:\"level_1\";b:1;s:7:\"level_0\";b:1;s:17:\"edit_others_pages\";b:1;s:20:\"edit_published_pages\";b:1;s:13:\"publish_pages\";b:1;s:12:\"delete_pages\";b:1;s:19:\"delete_others_pages\";b:1;s:22:\"delete_published_pages\";b:1;s:12:\"delete_posts\";b:1;s:19:\"delete_others_posts\";b:1;s:22:\"delete_published_posts\";b:1;s:20:\"delete_private_posts\";b:1;s:18:\"edit_private_posts\";b:1;s:18:\"read_private_posts\";b:1;s:20:\"delete_private_pages\";b:1;s:18:\"edit_private_pages\";b:1;s:18:\"read_private_pages\";b:1;}}s:6:\"author\";a:2:{s:4:\"name\";s:6:\"Author\";s:12:\"capabilities\";a:10:{s:12:\"upload_files\";b:1;s:10:\"edit_posts\";b:1;s:20:\"edit_published_posts\";b:1;s:13:\"publish_posts\";b:1;s:4:\"read\";b:1;s:7:\"level_2\";b:1;s:7:\"level_1\";b:1;s:7:\"level_0\";b:1;s:12:\"delete_posts\";b:1;s:22:\"delete_published_posts\";b:1;}}s:11:\"contributor\";a:2:{s:4:\"name\";s:11:\"Contributor\";s:12:\"capabilities\";a:5:{s:10:\"edit_posts\";b:1;s:4:\"read\";b:1;s:7:\"level_1\";b:1;s:7:\"level_0\";b:1;s:12:\"delete_posts\";b:1;}}s:10:\"subscriber\";a:2:{s:4:\"name\";s:10:\"Subscriber\";s:12:\"capabilities\";a:2:{s:4:\"read\";b:1;s:7:\"level_0\";b:1;}}s:8:\"customer\";a:2:{s:4:\"name\";s:8:\"Customer\";s:12:\"capabilities\";a:1:{s:4:\"read\";b:1;}}s:12:\"shop_manager\";a:2:{s:4:\"name\";s:12:\"Shop manager\";s:12:\"capabilities\";a:92:{s:7:\"level_9\";b:1;s:7:\"level_8\";b:1;s:7:\"level_7\";b:1;s:7:\"level_6\";b:1;s:7:\"level_5\";b:1;s:7:\"level_4\";b:1;s:7:\"level_3\";b:1;s:7:\"level_2\";b:1;s:7:\"level_1\";b:1;s:7:\"level_0\";b:1;s:4:\"read\";b:1;s:18:\"read_private_pages\";b:1;s:18:\"read_private_posts\";b:1;s:10:\"edit_users\";b:1;s:10:\"edit_posts\";b:1;s:10:\"edit_pages\";b:1;s:20:\"edit_published_posts\";b:1;s:20:\"edit_published_pages\";b:1;s:18:\"edit_private_pages\";b:1;s:18:\"edit_private_posts\";b:1;s:17:\"edit_others_posts\";b:1;s:17:\"edit_others_pages\";b:1;s:13:\"publish_posts\";b:1;s:13:\"publish_pages\";b:1;s:12:\"delete_posts\";b:1;s:12:\"delete_pages\";b:1;s:20:\"delete_private_pages\";b:1;s:20:\"delete_private_posts\";b:1;s:22:\"delete_published_pages\";b:1;s:22:\"delete_published_posts\";b:1;s:19:\"delete_others_posts\";b:1;s:19:\"delete_others_pages\";b:1;s:17:\"manage_categories\";b:1;s:12:\"manage_links\";b:1;s:17:\"moderate_comments\";b:1;s:12:\"upload_files\";b:1;s:6:\"export\";b:1;s:6:\"import\";b:1;s:10:\"list_users\";b:1;s:18:\"manage_woocommerce\";b:1;s:24:\"view_woocommerce_reports\";b:1;s:12:\"edit_product\";b:1;s:12:\"read_product\";b:1;s:14:\"delete_product\";b:1;s:13:\"edit_products\";b:1;s:20:\"edit_others_products\";b:1;s:16:\"publish_products\";b:1;s:21:\"read_private_products\";b:1;s:15:\"delete_products\";b:1;s:23:\"delete_private_products\";b:1;s:25:\"delete_published_products\";b:1;s:22:\"delete_others_products\";b:1;s:21:\"edit_private_products\";b:1;s:23:\"edit_published_products\";b:1;s:20:\"manage_product_terms\";b:1;s:18:\"edit_product_terms\";b:1;s:20:\"delete_product_terms\";b:1;s:20:\"assign_product_terms\";b:1;s:15:\"edit_shop_order\";b:1;s:15:\"read_shop_order\";b:1;s:17:\"delete_shop_order\";b:1;s:16:\"edit_shop_orders\";b:1;s:23:\"edit_others_shop_orders\";b:1;s:19:\"publish_shop_orders\";b:1;s:24:\"read_private_shop_orders\";b:1;s:18:\"delete_shop_orders\";b:1;s:26:\"delete_private_shop_orders\";b:1;s:28:\"delete_published_shop_orders\";b:1;s:25:\"delete_others_shop_orders\";b:1;s:24:\"edit_private_shop_orders\";b:1;s:26:\"edit_published_shop_orders\";b:1;s:23:\"manage_shop_order_terms\";b:1;s:21:\"edit_shop_order_terms\";b:1;s:23:\"delete_shop_order_terms\";b:1;s:23:\"assign_shop_order_terms\";b:1;s:16:\"edit_shop_coupon\";b:1;s:16:\"read_shop_coupon\";b:1;s:18:\"delete_shop_coupon\";b:1;s:17:\"edit_shop_coupons\";b:1;s:24:\"edit_others_shop_coupons\";b:1;s:20:\"publish_shop_coupons\";b:1;s:25:\"read_private_shop_coupons\";b:1;s:19:\"delete_shop_coupons\";b:1;s:27:\"delete_private_shop_coupons\";b:1;s:29:\"delete_published_shop_coupons\";b:1;s:26:\"delete_others_shop_coupons\";b:1;s:25:\"edit_private_shop_coupons\";b:1;s:27:\"edit_published_shop_coupons\";b:1;s:24:\"manage_shop_coupon_terms\";b:1;s:22:\"edit_shop_coupon_terms\";b:1;s:24:\"delete_shop_coupon_terms\";b:1;s:24:\"assign_shop_coupon_terms\";b:1;}}s:13:\"bbp_keymaster\";a:2:{s:4:\"name\";s:9:\"Keymaster\";s:12:\"capabilities\";a:29:{s:9:\"keep_gate\";b:1;s:8:\"spectate\";b:1;s:11:\"participate\";b:1;s:8:\"moderate\";b:1;s:8:\"throttle\";b:1;s:10:\"view_trash\";b:1;s:14:\"publish_forums\";b:1;s:11:\"edit_forums\";b:1;s:18:\"edit_others_forums\";b:1;s:13:\"delete_forums\";b:1;s:20:\"delete_others_forums\";b:1;s:19:\"read_private_forums\";b:1;s:18:\"read_hidden_forums\";b:1;s:14:\"publish_topics\";b:1;s:11:\"edit_topics\";b:1;s:18:\"edit_others_topics\";b:1;s:13:\"delete_topics\";b:1;s:20:\"delete_others_topics\";b:1;s:19:\"read_private_topics\";b:1;s:15:\"publish_replies\";b:1;s:12:\"edit_replies\";b:1;s:19:\"edit_others_replies\";b:1;s:14:\"delete_replies\";b:1;s:21:\"delete_others_replies\";b:1;s:20:\"read_private_replies\";b:1;s:17:\"manage_topic_tags\";b:1;s:15:\"edit_topic_tags\";b:1;s:17:\"delete_topic_tags\";b:1;s:17:\"assign_topic_tags\";b:1;}}s:13:\"bbp_moderator\";a:2:{s:4:\"name\";s:9:\"Moderator\";s:12:\"capabilities\";a:25:{s:8:\"spectate\";b:1;s:11:\"participate\";b:1;s:8:\"moderate\";b:1;s:8:\"throttle\";b:1;s:10:\"view_trash\";b:1;s:14:\"publish_forums\";b:1;s:11:\"edit_forums\";b:1;s:19:\"read_private_forums\";b:1;s:18:\"read_hidden_forums\";b:1;s:14:\"publish_topics\";b:1;s:11:\"edit_topics\";b:1;s:18:\"edit_others_topics\";b:1;s:13:\"delete_topics\";b:1;s:20:\"delete_others_topics\";b:1;s:19:\"read_private_topics\";b:1;s:15:\"publish_replies\";b:1;s:12:\"edit_replies\";b:1;s:19:\"edit_others_replies\";b:1;s:14:\"delete_replies\";b:1;s:21:\"delete_others_replies\";b:1;s:20:\"read_private_replies\";b:1;s:17:\"manage_topic_tags\";b:1;s:15:\"edit_topic_tags\";b:1;s:17:\"delete_topic_tags\";b:1;s:17:\"assign_topic_tags\";b:1;}}s:15:\"bbp_participant\";a:2:{s:4:\"name\";s:11:\"Participant\";s:12:\"capabilities\";a:8:{s:8:\"spectate\";b:1;s:11:\"participate\";b:1;s:19:\"read_private_forums\";b:1;s:14:\"publish_topics\";b:1;s:11:\"edit_topics\";b:1;s:15:\"publish_replies\";b:1;s:12:\"edit_replies\";b:1;s:17:\"assign_topic_tags\";b:1;}}s:13:\"bbp_spectator\";a:2:{s:4:\"name\";s:9:\"Spectator\";s:12:\"capabilities\";a:1:{s:8:\"spectate\";b:1;}}s:11:\"bbp_blocked\";a:2:{s:4:\"name\";s:7:\"Blocked\";s:12:\"capabilities\";a:28:{s:8:\"spectate\";b:0;s:11:\"participate\";b:0;s:8:\"moderate\";b:0;s:8:\"throttle\";b:0;s:10:\"view_trash\";b:0;s:14:\"publish_forums\";b:0;s:11:\"edit_forums\";b:0;s:18:\"edit_others_forums\";b:0;s:13:\"delete_forums\";b:0;s:20:\"delete_others_forums\";b:0;s:19:\"read_private_forums\";b:0;s:18:\"read_hidden_forums\";b:0;s:14:\"publish_topics\";b:0;s:11:\"edit_topics\";b:0;s:18:\"edit_others_topics\";b:0;s:13:\"delete_topics\";b:0;s:20:\"delete_others_topics\";b:0;s:19:\"read_private_topics\";b:0;s:15:\"publish_replies\";b:0;s:12:\"edit_replies\";b:0;s:19:\"edit_others_replies\";b:0;s:14:\"delete_replies\";b:0;s:21:\"delete_others_replies\";b:0;s:20:\"read_private_replies\";b:0;s:17:\"manage_topic_tags\";b:0;s:15:\"edit_topic_tags\";b:0;s:17:\"delete_topic_tags\";b:0;s:17:\"assign_topic_tags\";b:0;}}}', 'no'),
(907, 'ure_tasks_queue', 'a:0:{}', 'yes'),
(908, 'wsl_settings_welcome_panel_enabled', '1', 'yes'),
(909, 'wsl_settings_redirect_url', 'http://localhost/project', 'yes'),
(910, 'wsl_settings_force_redirect_url', '2', 'yes'),
(911, 'wsl_settings_connect_with_label', 'Connect with:', 'yes'),
(912, 'wsl_settings_users_avatars', '1', 'yes'),
(913, 'wsl_settings_use_popup', '2', 'yes'),
(914, 'wsl_settings_widget_display', '1', 'yes'),
(915, 'wsl_settings_authentication_widget_css', '.wp-social-login-connect-with {}\n.wp-social-login-provider-list {}\n.wp-social-login-provider-list a {}\n.wp-social-login-provider-list img {}\n.wsl_connect_with_provider {}', 'yes'),
(916, 'wsl_settings_bouncer_registration_enabled', '1', 'yes'),
(917, 'wsl_settings_bouncer_authentication_enabled', '1', 'yes'),
(918, 'wsl_settings_bouncer_accounts_linking_enabled', '1', 'yes'),
(919, 'wsl_settings_bouncer_profile_completion_require_email', '2', 'yes'),
(920, 'wsl_settings_bouncer_profile_completion_change_username', '2', 'yes'),
(921, 'wsl_settings_bouncer_profile_completion_hook_extra_fields', '2', 'yes'),
(922, 'wsl_settings_bouncer_new_users_moderation_level', '1', 'yes'),
(923, 'wsl_settings_bouncer_new_users_membership_default_role', 'default', 'yes'),
(924, 'wsl_settings_bouncer_new_users_restrict_domain_enabled', '2', 'yes'),
(925, 'wsl_settings_bouncer_new_users_restrict_domain_text_bounce', '<strong>This website is restricted to invited readers only.</strong><p>It doesn\'t look like you have been invited to access this site. If you think this is a mistake, you might want to contact the website owner and request an invitation.<p>', 'yes'),
(926, 'wsl_settings_bouncer_new_users_restrict_email_enabled', '2', 'yes'),
(927, 'wsl_settings_bouncer_new_users_restrict_email_text_bounce', '<strong>This website is restricted to invited readers only.</strong><p>It doesn\'t look like you have been invited to access this site. If you think this is a mistake, you might want to contact the website owner and request an invitation.<p>', 'yes'),
(928, 'wsl_settings_bouncer_new_users_restrict_profile_enabled', '2', 'yes'),
(929, 'wsl_settings_bouncer_new_users_restrict_profile_text_bounce', '<strong>This website is restricted to invited readers only.</strong><p>It doesn\'t look like you have been invited to access this site. If you think this is a mistake, you might want to contact the website owner and request an invitation.<p>', 'yes'),
(930, 'wsl_settings_contacts_import_facebook', '2', 'yes'),
(931, 'wsl_settings_contacts_import_google', '2', 'yes'),
(932, 'wsl_settings_contacts_import_twitter', '2', 'yes'),
(933, 'wsl_settings_contacts_import_live', '2', 'yes'),
(934, 'wsl_settings_contacts_import_linkedin', '2', 'yes'),
(935, 'wsl_settings_buddypress_enable_mapping', '2', 'yes'),
(936, 'wsl_settings_buddypress_xprofile_map', '', 'yes'),
(937, 'wsl_settings_Facebook_enabled', '1', 'yes'),
(938, 'wsl_settings_Google_enabled', '1', 'yes'),
(939, 'wsl_settings_Twitter_enabled', '1', 'yes'),
(940, 'wsl_components_core_enabled', '1', 'yes'),
(941, 'wsl_components_networks_enabled', '1', 'yes'),
(942, 'wsl_components_login-widget_enabled', '1', 'yes'),
(943, 'wsl_components_bouncer_enabled', '1', 'yes'),
(944, 'wplc_db_version', '8.0.07', 'yes'),
(945, 'WPLC_SETTINGS', 'a:46:{s:19:\"wplc_settings_align\";s:1:\"2\";s:21:\"wplc_settings_enabled\";s:1:\"1\";s:20:\"wplc_powered_by_link\";s:1:\"0\";s:18:\"wplc_settings_fill\";s:6:\"ed832f\";s:18:\"wplc_settings_font\";s:6:\"FFFFFF\";s:20:\"wplc_settings_color1\";s:6:\"ED832F\";s:20:\"wplc_settings_color2\";s:6:\"FFFFFF\";s:20:\"wplc_settings_color3\";s:6:\"EEEEEE\";s:20:\"wplc_settings_color4\";s:6:\"666666\";s:10:\"wplc_theme\";s:13:\"theme-default\";s:13:\"wplc_newtheme\";s:7:\"theme-2\";s:22:\"wplc_require_user_info\";s:1:\"1\";s:23:\"wplc_loggedin_user_info\";s:1:\"1\";s:26:\"wplc_user_alternative_text\";s:60:\"Please click \\\'Start Chat\\\' to initiate a chat with an agent\";s:30:\"wplc_user_default_visitor_name\";s:5:\"Guest\";s:22:\"wplc_enabled_on_mobile\";s:1:\"1\";s:17:\"wplc_display_name\";s:1:\"1\";s:22:\"wplc_record_ip_address\";s:1:\"1\";s:27:\"wplc_pro_chat_email_address\";s:15:\"admin@gmail.com\";s:13:\"wplc_pro_fst1\";s:10:\"Questions?\";s:13:\"wplc_pro_fst2\";s:12:\"Chat with us\";s:13:\"wplc_pro_fst3\";s:15:\"Start live chat\";s:13:\"wplc_pro_sst1\";s:10:\"Start Chat\";s:20:\"wplc_pro_sst1_survey\";s:23:\"Or chat to an agent now\";s:21:\"wplc_pro_sst1e_survey\";s:10:\"Chat ended\";s:13:\"wplc_pro_sst2\";s:32:\"Connecting. Please be patient...\";s:13:\"wplc_pro_tst1\";s:34:\"Reactivating your previous chat...\";s:11:\"wplc_pro_na\";s:29:\"Chat offline. Leave a message\";s:14:\"wplc_pro_intro\";s:56:\"Hello. Please input your details so that I may help you.\";s:17:\"wplc_pro_offline1\";s:83:\"We are currently offline. Please leave a message and we\'ll get back to you shortly.\";s:17:\"wplc_pro_offline2\";s:18:\"Sending message...\";s:17:\"wplc_pro_offline3\";s:55:\"Thank you for your message. We will be in contact soon.\";s:20:\"wplc_pro_offline_btn\";s:15:\"Leave a message\";s:25:\"wplc_pro_offline_btn_send\";s:12:\"Send message\";s:15:\"wplc_user_enter\";s:32:\"Press ENTER to send your message\";s:20:\"wplc_text_chat_ended\";s:40:\"The chat has been ended by the operator.\";s:19:\"wplc_close_btn_text\";s:5:\"close\";s:22:\"wplc_user_welcome_chat\";s:28:\"Welcome. How may I help you?\";s:16:\"wplc_welcome_msg\";s:84:\"Please standby for an agent. While you wait for the agent you may type your message.\";s:20:\"wplc_use_node_server\";i:1;s:27:\"wplc_preferred_gif_provider\";i:1;s:18:\"wplc_giphy_api_key\";s:0:\"\";s:18:\"wplc_tenor_api_key\";s:0:\"\";s:21:\"wplc_enable_msg_sound\";s:1:\"1\";s:24:\"wplc_enable_font_awesome\";s:1:\"1\";s:30:\"wplc_using_localization_plugin\";i:0;}', 'yes'),
(946, 'WPLC_HIDE_CHAT', 'true', 'yes'),
(947, 'wplc_api_secret_token', '77cc6f8f99fef0defadaae7decebbaa8', 'yes'),
(948, 'wplc_node_server_secret_token', '00b415b34f1464d577954ed94ddc5b1f', 'yes'),
(949, 'wpuf_installed', '1551523053', 'yes'),
(953, 'wpuf_version', '2.8.7', 'yes'),
(956, 'widget_akismet_widget', 'a:1:{s:12:\"_multiwidget\";i:1;}', 'yes'),
(957, 'widget_bbp_login_widget', 'a:1:{s:12:\"_multiwidget\";i:1;}', 'yes'),
(958, 'widget_bbp_views_widget', 'a:1:{s:12:\"_multiwidget\";i:1;}', 'yes'),
(959, 'widget_bbp_search_widget', 'a:1:{s:12:\"_multiwidget\";i:1;}', 'yes'),
(960, 'widget_bbp_forums_widget', 'a:1:{s:12:\"_multiwidget\";i:1;}', 'yes'),
(961, 'widget_bbp_topics_widget', 'a:1:{s:12:\"_multiwidget\";i:1;}', 'yes'),
(962, 'widget_bbp_replies_widget', 'a:1:{s:12:\"_multiwidget\";i:1;}', 'yes'),
(963, 'widget_bbp_stats_widget', 'a:1:{s:12:\"_multiwidget\";i:1;}', 'yes'),
(964, 'widget_wpuf_login_widget', 'a:1:{s:12:\"_multiwidget\";i:1;}', 'yes'),
(965, 'widget_mc4wp_form_widget', 'a:1:{s:12:\"_multiwidget\";i:1;}', 'yes'),
(966, 'vc_version', '5.4.7', 'yes'),
(968, 'WPLC_V8_FIRST_TIME', '1', 'yes'),
(969, 'wplc_current_version', '8.0.07', 'yes'),
(970, 'WPLC_ET_SETTINGS', 'a:6:{s:23:\"wplc_enable_transcripts\";i:1;s:24:\"wplc_send_transcripts_to\";s:4:\"user\";s:36:\"wplc_send_transcripts_when_chat_ends\";i:0;s:18:\"wplc_et_email_body\";s:2090:\"\n<!DOCTYPE HTML PUBLIC \\\"-//W3C//DTD HTML 4.01 Transitional//EN\\\" \\\"http://www.w3.org/TR/html4/loose.dtd\\\">		\n	<html>\n	\n	<body>\n\n\n\n		<table id=\"\" border=\"0\" cellpadding=\"0\" cellspacing=\"0\" width=\"100%\" style=\"background-color: #ec822c;\">\n	    <tbody>\n	      <tr>\n	        <td width=\"100%\" style=\"padding: 30px 20px 100px 20px;\">\n	          <table align=\"center\" cellpadding=\"0\" cellspacing=\"0\" class=\"\" width=\"100%\" style=\"border-collapse: separate; max-width:600px;\">\n	            <tbody>\n	              <tr>\n	                <td style=\"text-align: center; padding-bottom: 20px;\">\n	                  \n	                  <p>[wplc_et_transcript_header_text]</p>\n	                </td>\n	              </tr>\n	            </tbody>\n	          </table>\n\n	          <table id=\"\" align=\"center\" cellpadding=\"0\" cellspacing=\"0\" class=\"\" width=\"100%\" style=\"border-collapse: separate; max-width: 600px; font-family: Georgia, serif; font-size: 12px; color: rgb(51, 62, 72); border: 0px solid rgb(255, 255, 255); border-radius: 10px; background-color: rgb(255, 255, 255);\">\n	          <tbody>\n	              <tr>\n	                <td class=\"sortable-list ui-sortable\" style=\"padding:20px;\">\n	                    [wplc_et_transcript]\n	                </td>\n	              </tr>\n	            </tbody>\n	          </table>\n\n	          <table align=\"center\" cellpadding=\"0\" cellspacing=\"0\" class=\"\" width=\"100%\" style=\"border-collapse: separate; max-width:100%;\">\n	            <tbody>\n	              <tr>\n	                <td style=\"padding:20px;\">\n	                  <table border=\"0\" cellpadding=\"0\" cellspacing=\"0\" class=\"\" width=\"100%\">\n	                    <tbody>\n	                      <tr>\n	                        <td id=\"\" align=\"center\">\n	                         <p>[wplc_et_transcript_footer_text]</p>\n	                        </td>\n	                      </tr>\n	                    </tbody>\n	                  </table>\n	                </td>\n	              </tr>\n	            </tbody>\n	          </table>\n	        </td>\n	      </tr>\n	    </tbody>\n	  </table>\n\n\n		\n		</div>\n	</body>\n</html>\n			\";s:20:\"wplc_et_email_header\";s:220:\"<a title=\"projct new development\" href=\"http://localhost/project\" style=\"font-family: Arial, Helvetica, sans-serif; font-size: 13px; color: #FFF; font-weight: bold; text-decoration: underline;\">projct new development</a>\";s:20:\"wplc_et_email_footer\";s:372:\"<span style=\'font-family: Arial, Helvetica, sans-serif; font-size: 13px; color: #FFF; font-weight: normal;\'>Thank you for chatting with us. If you have any questions, please <a href=\"mailto:admin@gmail.com\" target=\"_blank\" style=\"font-family: Arial, Helvetica, sans-serif; font-size: 13px; color: #FFF; font-weight: bold; text-decoration: underline;\">contact us</a></span>\";}', 'yes'),
(971, 'WPLC_ET_FIRST_RUN', '1', 'yes'),
(973, 'wpuf_expiry_posts_last_cleaned', 'May 22, 2019 6:05 am', 'yes'),
(974, 'option_tree_settings', 'a:2:{s:8:\"sections\";a:1:{i:0;a:2:{s:2:\"id\";s:7:\"general\";s:5:\"title\";s:7:\"General\";}}s:8:\"settings\";a:1:{i:0;a:10:{s:2:\"id\";s:11:\"sample_text\";s:5:\"label\";s:23:\"Sample Text Field Label\";s:4:\"desc\";s:38:\"Description for the sample text field.\";s:7:\"section\";s:7:\"general\";s:4:\"type\";s:4:\"text\";s:3:\"std\";s:0:\"\";s:5:\"class\";s:0:\"\";s:4:\"rows\";s:0:\"\";s:9:\"post_type\";s:0:\"\";s:7:\"choices\";a:0:{}}}}', 'yes'),
(975, '_bbp_private_forums', 'a:0:{}', 'yes'),
(976, '_bbp_hidden_forums', 'a:0:{}', 'yes'),
(977, '_bbp_db_version', '250', 'yes'),
(978, 'duplicate_post_copytitle', '1', 'yes'),
(979, 'duplicate_post_copydate', '0', 'yes'),
(980, 'duplicate_post_copystatus', '0', 'yes'),
(981, 'duplicate_post_copyslug', '0', 'yes'),
(982, 'duplicate_post_copyexcerpt', '1', 'yes'),
(983, 'duplicate_post_copycontent', '1', 'yes'),
(984, 'duplicate_post_copythumbnail', '1', 'yes'),
(985, 'duplicate_post_copytemplate', '1', 'yes'),
(986, 'duplicate_post_copyformat', '1', 'yes'),
(987, 'duplicate_post_copyauthor', '0', 'yes'),
(988, 'duplicate_post_copypassword', '0', 'yes'),
(989, 'duplicate_post_copyattachments', '0', 'yes'),
(990, 'duplicate_post_copychildren', '0', 'yes'),
(991, 'duplicate_post_copycomments', '0', 'yes'),
(992, 'duplicate_post_copymenuorder', '1', 'yes'),
(993, 'duplicate_post_taxonomies_blacklist', 'a:0:{}', 'yes'),
(994, 'duplicate_post_blacklist', '', 'yes'),
(995, 'duplicate_post_types_enabled', 'a:2:{i:0;s:4:\"post\";i:1;s:4:\"page\";}', 'yes'),
(996, 'duplicate_post_show_row', '1', 'yes'),
(997, 'duplicate_post_show_adminbar', '1', 'yes'),
(998, 'duplicate_post_show_submitbox', '1', 'yes'),
(999, 'duplicate_post_show_bulkactions', '1', 'yes'),
(1000, 'duplicate_post_version', '3.2.2', 'yes'),
(1001, 'duplicate_post_show_notice', '0', 'no'),
(1002, 'mc4wp_version', '4.2.1', 'yes'),
(1003, 'wpuf_general', 'a:9:{s:14:\"show_admin_bar\";a:1:{i:0;s:6:\"taibur\";}s:12:\"admin_access\";s:4:\"read\";s:17:\"override_editlink\";s:2:\"no\";s:22:\"wpuf_compatibility_acf\";s:2:\"no\";s:11:\"load_script\";s:2:\"on\";s:16:\"recaptcha_public\";s:0:\"\";s:17:\"recaptcha_private\";s:0:\"\";s:10:\"custom_css\";s:0:\"\";s:18:\"install_wpuf_pages\";s:2:\"on\";}', 'yes'),
(1004, 'wpuf_frontend_posting', 'a:2:{s:12:\"edit_page_id\";i:523;s:17:\"default_post_form\";i:525;}', 'yes'),
(1005, 'wpuf_dashboard', 'a:9:{s:16:\"enable_post_edit\";s:3:\"yes\";s:15:\"enable_post_del\";s:3:\"yes\";s:20:\"disable_pending_edit\";s:2:\"on\";s:8:\"per_page\";s:2:\"10\";s:13:\"show_user_bio\";s:2:\"on\";s:15:\"show_post_count\";s:2:\"on\";s:13:\"show_ft_image\";s:2:\"on\";s:11:\"ft_img_size\";s:9:\"thumbnail\";s:11:\"un_auth_msg\";s:0:\"\";}', 'yes'),
(1006, 'wpuf_my_account', 'a:3:{s:12:\"account_page\";s:3:\"511\";s:18:\"show_subscriptions\";s:2:\"on\";s:20:\"show_billing_address\";s:2:\"on\";}', 'yes'),
(1007, 'wpuf_profile', 'a:7:{s:28:\"autologin_after_registration\";s:2:\"on\";s:22:\"register_link_override\";s:2:\"on\";s:17:\"reg_override_page\";s:3:\"535\";s:10:\"login_page\";s:3:\"524\";s:25:\"redirect_after_login_page\";s:3:\"522\";s:25:\"wp_default_login_redirect\";s:2:\"on\";s:5:\"roles\";a:21:{s:13:\"administrator\";s:0:\"\";s:6:\"author\";s:0:\"\";s:11:\"bbp_blocked\";s:0:\"\";s:19:\"wphb_booking_editor\";s:0:\"\";s:22:\"booking_package_member\";s:0:\"\";s:11:\"contributor\";s:0:\"\";s:8:\"customer\";s:0:\"\";s:6:\"editor\";s:0:\"\";s:19:\"awebooking_customer\";s:0:\"\";s:18:\"wphb_hotel_manager\";s:0:\"\";s:18:\"awebooking_manager\";s:0:\"\";s:23:\"awebooking_receptionist\";s:0:\"\";s:13:\"bbp_keymaster\";s:0:\"\";s:13:\"bbp_moderator\";s:0:\"\";s:15:\"bbp_participant\";s:0:\"\";s:12:\"shop_manager\";s:0:\"\";s:13:\"bbp_spectator\";s:0:\"\";s:10:\"subscriber\";s:0:\"\";s:18:\"wp-travel-customer\";s:0:\"\";s:5:\"milon\";s:3:\"532\";s:6:\"taibur\";s:0:\"\";}}', 'yes'),
(1008, 'wpuf_payment', 'a:4:{s:17:\"subscription_page\";i:528;s:12:\"payment_page\";i:529;s:15:\"payment_success\";i:530;s:12:\"bank_success\";i:531;}', 'yes'),
(1009, 'wpuf_mails', '', 'yes'),
(1010, 'wpuf_payment_invoices', '', 'yes'),
(1011, 'wsl_settings_Facebook_app_scope', 'email, public_profile, user_friends', 'yes'),
(1012, 'wsl_settings_Google_app_scope', 'profile https://www.googleapis.com/auth/plus.profile.emails.read', 'yes'),
(1013, 'wsl_settings_GitHub_app_scope', 'user:email', 'yes'),
(1014, 'option_tree', 'a:1:{s:11:\"sample_text\";s:0:\"\";}', 'yes'),
(1015, 'ot_media_post_ID', '252', 'yes'),
(1016, 'mc4wp_flash_messages', 'a:0:{}', 'no'),
(1040, 'woocommerce_placeholder_image', '', 'yes'),
(1041, 'woocommerce_erasure_request_removes_order_data', 'no', 'no'),
(1042, 'woocommerce_erasure_request_removes_download_data', 'no', 'no'),
(1043, 'woocommerce_registration_privacy_policy_text', 'Your personal data will be used to support your experience throughout this website, to manage access to your account, and for other purposes described in our [privacy_policy].', 'yes'),
(1044, 'woocommerce_checkout_privacy_policy_text', 'Your personal data will be used to process your order, support your experience throughout this website, and for other purposes described in our [privacy_policy].', 'yes'),
(1045, 'woocommerce_delete_inactive_accounts', 'a:2:{s:6:\"number\";s:0:\"\";s:4:\"unit\";s:6:\"months\";}', 'no'),
(1046, 'woocommerce_trash_pending_orders', 'a:2:{s:6:\"number\";s:0:\"\";s:4:\"unit\";s:4:\"days\";}', 'no'),
(1047, 'woocommerce_trash_failed_orders', 'a:2:{s:6:\"number\";s:0:\"\";s:4:\"unit\";s:4:\"days\";}', 'no'),
(1048, 'woocommerce_trash_cancelled_orders', 'a:2:{s:6:\"number\";s:0:\"\";s:4:\"unit\";s:4:\"days\";}', 'no'),
(1049, 'woocommerce_anonymize_completed_orders', 'a:2:{s:6:\"number\";s:0:\"\";s:4:\"unit\";s:6:\"months\";}', 'no'),
(1050, 'woocommerce_single_image_width', '600', 'yes'),
(1051, 'woocommerce_thumbnail_image_width', '300', 'yes'),
(1052, 'woocommerce_checkout_highlight_required_fields', 'yes', 'yes'),
(1053, 'woocommerce_demo_store', 'no', 'no'),
(1054, 'woocommerce_version', '3.5.5', 'yes');
INSERT INTO `wp_options` (`option_id`, `option_name`, `option_value`, `autoload`) VALUES
(1059, 'rewrite_rules', 'a:386:{s:12:\"hotelhajj/?$\";s:29:\"index.php?post_type=hotelhajj\";s:42:\"hotelhajj/feed/(feed|rdf|rss|rss2|atom)/?$\";s:46:\"index.php?post_type=hotelhajj&feed=$matches[1]\";s:37:\"hotelhajj/(feed|rdf|rss|rss2|atom)/?$\";s:46:\"index.php?post_type=hotelhajj&feed=$matches[1]\";s:29:\"hotelhajj/page/([0-9]{1,})/?$\";s:47:\"index.php?post_type=hotelhajj&paged=$matches[1]\";s:10:\"flights/?$\";s:27:\"index.php?post_type=flights\";s:40:\"flights/feed/(feed|rdf|rss|rss2|atom)/?$\";s:44:\"index.php?post_type=flights&feed=$matches[1]\";s:35:\"flights/(feed|rdf|rss|rss2|atom)/?$\";s:44:\"index.php?post_type=flights&feed=$matches[1]\";s:27:\"flights/page/([0-9]{1,})/?$\";s:45:\"index.php?post_type=flights&paged=$matches[1]\";s:7:\"hajj/?$\";s:24:\"index.php?post_type=hajj\";s:37:\"hajj/feed/(feed|rdf|rss|rss2|atom)/?$\";s:41:\"index.php?post_type=hajj&feed=$matches[1]\";s:32:\"hajj/(feed|rdf|rss|rss2|atom)/?$\";s:41:\"index.php?post_type=hajj&feed=$matches[1]\";s:24:\"hajj/page/([0-9]{1,})/?$\";s:42:\"index.php?post_type=hajj&paged=$matches[1]\";s:11:\"^wp-json/?$\";s:22:\"index.php?rest_route=/\";s:14:\"^wp-json/(.*)?\";s:33:\"index.php?rest_route=/$matches[1]\";s:21:\"^index.php/wp-json/?$\";s:22:\"index.php?rest_route=/\";s:24:\"^index.php/wp-json/(.*)?\";s:33:\"index.php?rest_route=/$matches[1]\";s:8:\"umrah/?$\";s:25:\"index.php?post_type=umrah\";s:38:\"umrah/feed/(feed|rdf|rss|rss2|atom)/?$\";s:42:\"index.php?post_type=umrah&feed=$matches[1]\";s:33:\"umrah/(feed|rdf|rss|rss2|atom)/?$\";s:42:\"index.php?post_type=umrah&feed=$matches[1]\";s:25:\"umrah/page/([0-9]{1,})/?$\";s:43:\"index.php?post_type=umrah&paged=$matches[1]\";s:13:\"restaurant/?$\";s:30:\"index.php?post_type=restaurant\";s:43:\"restaurant/feed/(feed|rdf|rss|rss2|atom)/?$\";s:47:\"index.php?post_type=restaurant&feed=$matches[1]\";s:38:\"restaurant/(feed|rdf|rss|rss2|atom)/?$\";s:47:\"index.php?post_type=restaurant&feed=$matches[1]\";s:30:\"restaurant/page/([0-9]{1,})/?$\";s:48:\"index.php?post_type=restaurant&paged=$matches[1]\";s:12:\"transport/?$\";s:29:\"index.php?post_type=transport\";s:42:\"transport/feed/(feed|rdf|rss|rss2|atom)/?$\";s:46:\"index.php?post_type=transport&feed=$matches[1]\";s:37:\"transport/(feed|rdf|rss|rss2|atom)/?$\";s:46:\"index.php?post_type=transport&feed=$matches[1]\";s:29:\"transport/page/([0-9]{1,})/?$\";s:47:\"index.php?post_type=transport&paged=$matches[1]\";s:8:\"tours/?$\";s:25:\"index.php?post_type=tours\";s:38:\"tours/feed/(feed|rdf|rss|rss2|atom)/?$\";s:42:\"index.php?post_type=tours&feed=$matches[1]\";s:33:\"tours/(feed|rdf|rss|rss2|atom)/?$\";s:42:\"index.php?post_type=tours&feed=$matches[1]\";s:25:\"tours/page/([0-9]{1,})/?$\";s:43:\"index.php?post_type=tours&paged=$matches[1]\";s:18:\"available-rooms/?$\";s:35:\"index.php?post_type=available-rooms\";s:48:\"available-rooms/feed/(feed|rdf|rss|rss2|atom)/?$\";s:52:\"index.php?post_type=available-rooms&feed=$matches[1]\";s:43:\"available-rooms/(feed|rdf|rss|rss2|atom)/?$\";s:52:\"index.php?post_type=available-rooms&feed=$matches[1]\";s:35:\"available-rooms/page/([0-9]{1,})/?$\";s:53:\"index.php?post_type=available-rooms&paged=$matches[1]\";s:35:\"hotelhajj/.+?/attachment/([^/]+)/?$\";s:32:\"index.php?attachment=$matches[1]\";s:45:\"hotelhajj/.+?/attachment/([^/]+)/trackback/?$\";s:37:\"index.php?attachment=$matches[1]&tb=1\";s:65:\"hotelhajj/.+?/attachment/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$\";s:49:\"index.php?attachment=$matches[1]&feed=$matches[2]\";s:60:\"hotelhajj/.+?/attachment/([^/]+)/(feed|rdf|rss|rss2|atom)/?$\";s:49:\"index.php?attachment=$matches[1]&feed=$matches[2]\";s:60:\"hotelhajj/.+?/attachment/([^/]+)/comment-page-([0-9]{1,})/?$\";s:50:\"index.php?attachment=$matches[1]&cpage=$matches[2]\";s:41:\"hotelhajj/.+?/attachment/([^/]+)/embed/?$\";s:43:\"index.php?attachment=$matches[1]&embed=true\";s:24:\"hotelhajj/(.+?)/embed/?$\";s:42:\"index.php?hotelhajj=$matches[1]&embed=true\";s:28:\"hotelhajj/(.+?)/trackback/?$\";s:36:\"index.php?hotelhajj=$matches[1]&tb=1\";s:48:\"hotelhajj/(.+?)/feed/(feed|rdf|rss|rss2|atom)/?$\";s:48:\"index.php?hotelhajj=$matches[1]&feed=$matches[2]\";s:43:\"hotelhajj/(.+?)/(feed|rdf|rss|rss2|atom)/?$\";s:48:\"index.php?hotelhajj=$matches[1]&feed=$matches[2]\";s:36:\"hotelhajj/(.+?)/page/?([0-9]{1,})/?$\";s:49:\"index.php?hotelhajj=$matches[1]&paged=$matches[2]\";s:43:\"hotelhajj/(.+?)/comment-page-([0-9]{1,})/?$\";s:49:\"index.php?hotelhajj=$matches[1]&cpage=$matches[2]\";s:32:\"hotelhajj/(.+?)(?:/([0-9]+))?/?$\";s:48:\"index.php?hotelhajj=$matches[1]&page=$matches[2]\";s:46:\"genre/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$\";s:52:\"index.php?departuretime=$matches[1]&feed=$matches[2]\";s:41:\"genre/([^/]+)/(feed|rdf|rss|rss2|atom)/?$\";s:52:\"index.php?departuretime=$matches[1]&feed=$matches[2]\";s:22:\"genre/([^/]+)/embed/?$\";s:46:\"index.php?departuretime=$matches[1]&embed=true\";s:34:\"genre/([^/]+)/page/?([0-9]{1,})/?$\";s:53:\"index.php?departuretime=$matches[1]&paged=$matches[2]\";s:16:\"genre/([^/]+)/?$\";s:35:\"index.php?departuretime=$matches[1]\";s:33:\"flights/.+?/attachment/([^/]+)/?$\";s:32:\"index.php?attachment=$matches[1]\";s:43:\"flights/.+?/attachment/([^/]+)/trackback/?$\";s:37:\"index.php?attachment=$matches[1]&tb=1\";s:63:\"flights/.+?/attachment/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$\";s:49:\"index.php?attachment=$matches[1]&feed=$matches[2]\";s:58:\"flights/.+?/attachment/([^/]+)/(feed|rdf|rss|rss2|atom)/?$\";s:49:\"index.php?attachment=$matches[1]&feed=$matches[2]\";s:58:\"flights/.+?/attachment/([^/]+)/comment-page-([0-9]{1,})/?$\";s:50:\"index.php?attachment=$matches[1]&cpage=$matches[2]\";s:39:\"flights/.+?/attachment/([^/]+)/embed/?$\";s:43:\"index.php?attachment=$matches[1]&embed=true\";s:22:\"flights/(.+?)/embed/?$\";s:40:\"index.php?flights=$matches[1]&embed=true\";s:26:\"flights/(.+?)/trackback/?$\";s:34:\"index.php?flights=$matches[1]&tb=1\";s:46:\"flights/(.+?)/feed/(feed|rdf|rss|rss2|atom)/?$\";s:46:\"index.php?flights=$matches[1]&feed=$matches[2]\";s:41:\"flights/(.+?)/(feed|rdf|rss|rss2|atom)/?$\";s:46:\"index.php?flights=$matches[1]&feed=$matches[2]\";s:34:\"flights/(.+?)/page/?([0-9]{1,})/?$\";s:47:\"index.php?flights=$matches[1]&paged=$matches[2]\";s:41:\"flights/(.+?)/comment-page-([0-9]{1,})/?$\";s:47:\"index.php?flights=$matches[1]&cpage=$matches[2]\";s:30:\"flights/(.+?)(?:/([0-9]+))?/?$\";s:46:\"index.php?flights=$matches[1]&page=$matches[2]\";s:49:\"airports/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$\";s:47:\"index.php?airports=$matches[1]&feed=$matches[2]\";s:44:\"airports/([^/]+)/(feed|rdf|rss|rss2|atom)/?$\";s:47:\"index.php?airports=$matches[1]&feed=$matches[2]\";s:25:\"airports/([^/]+)/embed/?$\";s:41:\"index.php?airports=$matches[1]&embed=true\";s:37:\"airports/([^/]+)/page/?([0-9]{1,})/?$\";s:48:\"index.php?airports=$matches[1]&paged=$matches[2]\";s:19:\"airports/([^/]+)/?$\";s:30:\"index.php?airports=$matches[1]\";s:56:\"airline-company/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$\";s:54:\"index.php?airline-company=$matches[1]&feed=$matches[2]\";s:51:\"airline-company/([^/]+)/(feed|rdf|rss|rss2|atom)/?$\";s:54:\"index.php?airline-company=$matches[1]&feed=$matches[2]\";s:32:\"airline-company/([^/]+)/embed/?$\";s:48:\"index.php?airline-company=$matches[1]&embed=true\";s:44:\"airline-company/([^/]+)/page/?([0-9]{1,})/?$\";s:55:\"index.php?airline-company=$matches[1]&paged=$matches[2]\";s:26:\"airline-company/([^/]+)/?$\";s:37:\"index.php?airline-company=$matches[1]\";s:30:\"hajj/.+?/attachment/([^/]+)/?$\";s:32:\"index.php?attachment=$matches[1]\";s:40:\"hajj/.+?/attachment/([^/]+)/trackback/?$\";s:37:\"index.php?attachment=$matches[1]&tb=1\";s:60:\"hajj/.+?/attachment/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$\";s:49:\"index.php?attachment=$matches[1]&feed=$matches[2]\";s:55:\"hajj/.+?/attachment/([^/]+)/(feed|rdf|rss|rss2|atom)/?$\";s:49:\"index.php?attachment=$matches[1]&feed=$matches[2]\";s:55:\"hajj/.+?/attachment/([^/]+)/comment-page-([0-9]{1,})/?$\";s:50:\"index.php?attachment=$matches[1]&cpage=$matches[2]\";s:36:\"hajj/.+?/attachment/([^/]+)/embed/?$\";s:43:\"index.php?attachment=$matches[1]&embed=true\";s:19:\"hajj/(.+?)/embed/?$\";s:37:\"index.php?hajj=$matches[1]&embed=true\";s:23:\"hajj/(.+?)/trackback/?$\";s:31:\"index.php?hajj=$matches[1]&tb=1\";s:43:\"hajj/(.+?)/feed/(feed|rdf|rss|rss2|atom)/?$\";s:43:\"index.php?hajj=$matches[1]&feed=$matches[2]\";s:38:\"hajj/(.+?)/(feed|rdf|rss|rss2|atom)/?$\";s:43:\"index.php?hajj=$matches[1]&feed=$matches[2]\";s:31:\"hajj/(.+?)/page/?([0-9]{1,})/?$\";s:44:\"index.php?hajj=$matches[1]&paged=$matches[2]\";s:38:\"hajj/(.+?)/comment-page-([0-9]{1,})/?$\";s:44:\"index.php?hajj=$matches[1]&cpage=$matches[2]\";s:27:\"hajj/(.+?)(?:/([0-9]+))?/?$\";s:43:\"index.php?hajj=$matches[1]&page=$matches[2]\";s:47:\"taxonomy/(.+?)/feed/(feed|rdf|rss|rss2|atom)/?$\";s:52:\"index.php?category_name=$matches[1]&feed=$matches[2]\";s:42:\"taxonomy/(.+?)/(feed|rdf|rss|rss2|atom)/?$\";s:52:\"index.php?category_name=$matches[1]&feed=$matches[2]\";s:23:\"taxonomy/(.+?)/embed/?$\";s:46:\"index.php?category_name=$matches[1]&embed=true\";s:35:\"taxonomy/(.+?)/page/?([0-9]{1,})/?$\";s:53:\"index.php?category_name=$matches[1]&paged=$matches[2]\";s:17:\"taxonomy/(.+?)/?$\";s:35:\"index.php?category_name=$matches[1]\";s:44:\"tag/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$\";s:42:\"index.php?tag=$matches[1]&feed=$matches[2]\";s:39:\"tag/([^/]+)/(feed|rdf|rss|rss2|atom)/?$\";s:42:\"index.php?tag=$matches[1]&feed=$matches[2]\";s:20:\"tag/([^/]+)/embed/?$\";s:36:\"index.php?tag=$matches[1]&embed=true\";s:32:\"tag/([^/]+)/page/?([0-9]{1,})/?$\";s:43:\"index.php?tag=$matches[1]&paged=$matches[2]\";s:14:\"tag/([^/]+)/?$\";s:25:\"index.php?tag=$matches[1]\";s:45:\"type/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$\";s:50:\"index.php?post_format=$matches[1]&feed=$matches[2]\";s:40:\"type/([^/]+)/(feed|rdf|rss|rss2|atom)/?$\";s:50:\"index.php?post_format=$matches[1]&feed=$matches[2]\";s:21:\"type/([^/]+)/embed/?$\";s:44:\"index.php?post_format=$matches[1]&embed=true\";s:33:\"type/([^/]+)/page/?([0-9]{1,})/?$\";s:51:\"index.php?post_format=$matches[1]&paged=$matches[2]\";s:15:\"type/([^/]+)/?$\";s:33:\"index.php?post_format=$matches[1]\";s:47:\"hotels/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$\";s:45:\"index.php?hotels=$matches[1]&feed=$matches[2]\";s:42:\"hotels/([^/]+)/(feed|rdf|rss|rss2|atom)/?$\";s:45:\"index.php?hotels=$matches[1]&feed=$matches[2]\";s:23:\"hotels/([^/]+)/embed/?$\";s:39:\"index.php?hotels=$matches[1]&embed=true\";s:35:\"hotels/([^/]+)/page/?([0-9]{1,})/?$\";s:46:\"index.php?hotels=$matches[1]&paged=$matches[2]\";s:17:\"hotels/([^/]+)/?$\";s:28:\"index.php?hotels=$matches[1]\";s:42:\"wp-types-group/[^/]+/attachment/([^/]+)/?$\";s:32:\"index.php?attachment=$matches[1]\";s:52:\"wp-types-group/[^/]+/attachment/([^/]+)/trackback/?$\";s:37:\"index.php?attachment=$matches[1]&tb=1\";s:72:\"wp-types-group/[^/]+/attachment/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$\";s:49:\"index.php?attachment=$matches[1]&feed=$matches[2]\";s:67:\"wp-types-group/[^/]+/attachment/([^/]+)/(feed|rdf|rss|rss2|atom)/?$\";s:49:\"index.php?attachment=$matches[1]&feed=$matches[2]\";s:67:\"wp-types-group/[^/]+/attachment/([^/]+)/comment-page-([0-9]{1,})/?$\";s:50:\"index.php?attachment=$matches[1]&cpage=$matches[2]\";s:48:\"wp-types-group/[^/]+/attachment/([^/]+)/embed/?$\";s:43:\"index.php?attachment=$matches[1]&embed=true\";s:31:\"wp-types-group/([^/]+)/embed/?$\";s:47:\"index.php?wp-types-group=$matches[1]&embed=true\";s:35:\"wp-types-group/([^/]+)/trackback/?$\";s:41:\"index.php?wp-types-group=$matches[1]&tb=1\";s:43:\"wp-types-group/([^/]+)/page/?([0-9]{1,})/?$\";s:54:\"index.php?wp-types-group=$matches[1]&paged=$matches[2]\";s:50:\"wp-types-group/([^/]+)/comment-page-([0-9]{1,})/?$\";s:54:\"index.php?wp-types-group=$matches[1]&cpage=$matches[2]\";s:39:\"wp-types-group/([^/]+)(?:/([0-9]+))?/?$\";s:53:\"index.php?wp-types-group=$matches[1]&page=$matches[2]\";s:31:\"wp-types-group/[^/]+/([^/]+)/?$\";s:32:\"index.php?attachment=$matches[1]\";s:41:\"wp-types-group/[^/]+/([^/]+)/trackback/?$\";s:37:\"index.php?attachment=$matches[1]&tb=1\";s:61:\"wp-types-group/[^/]+/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$\";s:49:\"index.php?attachment=$matches[1]&feed=$matches[2]\";s:56:\"wp-types-group/[^/]+/([^/]+)/(feed|rdf|rss|rss2|atom)/?$\";s:49:\"index.php?attachment=$matches[1]&feed=$matches[2]\";s:56:\"wp-types-group/[^/]+/([^/]+)/comment-page-([0-9]{1,})/?$\";s:50:\"index.php?attachment=$matches[1]&cpage=$matches[2]\";s:37:\"wp-types-group/[^/]+/([^/]+)/embed/?$\";s:43:\"index.php?attachment=$matches[1]&embed=true\";s:47:\"wp-types-user-group/[^/]+/attachment/([^/]+)/?$\";s:32:\"index.php?attachment=$matches[1]\";s:57:\"wp-types-user-group/[^/]+/attachment/([^/]+)/trackback/?$\";s:37:\"index.php?attachment=$matches[1]&tb=1\";s:77:\"wp-types-user-group/[^/]+/attachment/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$\";s:49:\"index.php?attachment=$matches[1]&feed=$matches[2]\";s:72:\"wp-types-user-group/[^/]+/attachment/([^/]+)/(feed|rdf|rss|rss2|atom)/?$\";s:49:\"index.php?attachment=$matches[1]&feed=$matches[2]\";s:72:\"wp-types-user-group/[^/]+/attachment/([^/]+)/comment-page-([0-9]{1,})/?$\";s:50:\"index.php?attachment=$matches[1]&cpage=$matches[2]\";s:53:\"wp-types-user-group/[^/]+/attachment/([^/]+)/embed/?$\";s:43:\"index.php?attachment=$matches[1]&embed=true\";s:36:\"wp-types-user-group/([^/]+)/embed/?$\";s:52:\"index.php?wp-types-user-group=$matches[1]&embed=true\";s:40:\"wp-types-user-group/([^/]+)/trackback/?$\";s:46:\"index.php?wp-types-user-group=$matches[1]&tb=1\";s:48:\"wp-types-user-group/([^/]+)/page/?([0-9]{1,})/?$\";s:59:\"index.php?wp-types-user-group=$matches[1]&paged=$matches[2]\";s:55:\"wp-types-user-group/([^/]+)/comment-page-([0-9]{1,})/?$\";s:59:\"index.php?wp-types-user-group=$matches[1]&cpage=$matches[2]\";s:44:\"wp-types-user-group/([^/]+)(?:/([0-9]+))?/?$\";s:58:\"index.php?wp-types-user-group=$matches[1]&page=$matches[2]\";s:36:\"wp-types-user-group/[^/]+/([^/]+)/?$\";s:32:\"index.php?attachment=$matches[1]\";s:46:\"wp-types-user-group/[^/]+/([^/]+)/trackback/?$\";s:37:\"index.php?attachment=$matches[1]&tb=1\";s:66:\"wp-types-user-group/[^/]+/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$\";s:49:\"index.php?attachment=$matches[1]&feed=$matches[2]\";s:61:\"wp-types-user-group/[^/]+/([^/]+)/(feed|rdf|rss|rss2|atom)/?$\";s:49:\"index.php?attachment=$matches[1]&feed=$matches[2]\";s:61:\"wp-types-user-group/[^/]+/([^/]+)/comment-page-([0-9]{1,})/?$\";s:50:\"index.php?attachment=$matches[1]&cpage=$matches[2]\";s:42:\"wp-types-user-group/[^/]+/([^/]+)/embed/?$\";s:43:\"index.php?attachment=$matches[1]&embed=true\";s:47:\"wp-types-term-group/[^/]+/attachment/([^/]+)/?$\";s:32:\"index.php?attachment=$matches[1]\";s:57:\"wp-types-term-group/[^/]+/attachment/([^/]+)/trackback/?$\";s:37:\"index.php?attachment=$matches[1]&tb=1\";s:77:\"wp-types-term-group/[^/]+/attachment/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$\";s:49:\"index.php?attachment=$matches[1]&feed=$matches[2]\";s:72:\"wp-types-term-group/[^/]+/attachment/([^/]+)/(feed|rdf|rss|rss2|atom)/?$\";s:49:\"index.php?attachment=$matches[1]&feed=$matches[2]\";s:72:\"wp-types-term-group/[^/]+/attachment/([^/]+)/comment-page-([0-9]{1,})/?$\";s:50:\"index.php?attachment=$matches[1]&cpage=$matches[2]\";s:53:\"wp-types-term-group/[^/]+/attachment/([^/]+)/embed/?$\";s:43:\"index.php?attachment=$matches[1]&embed=true\";s:36:\"wp-types-term-group/([^/]+)/embed/?$\";s:52:\"index.php?wp-types-term-group=$matches[1]&embed=true\";s:40:\"wp-types-term-group/([^/]+)/trackback/?$\";s:46:\"index.php?wp-types-term-group=$matches[1]&tb=1\";s:48:\"wp-types-term-group/([^/]+)/page/?([0-9]{1,})/?$\";s:59:\"index.php?wp-types-term-group=$matches[1]&paged=$matches[2]\";s:55:\"wp-types-term-group/([^/]+)/comment-page-([0-9]{1,})/?$\";s:59:\"index.php?wp-types-term-group=$matches[1]&cpage=$matches[2]\";s:44:\"wp-types-term-group/([^/]+)(?:/([0-9]+))?/?$\";s:58:\"index.php?wp-types-term-group=$matches[1]&page=$matches[2]\";s:36:\"wp-types-term-group/[^/]+/([^/]+)/?$\";s:32:\"index.php?attachment=$matches[1]\";s:46:\"wp-types-term-group/[^/]+/([^/]+)/trackback/?$\";s:37:\"index.php?attachment=$matches[1]&tb=1\";s:66:\"wp-types-term-group/[^/]+/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$\";s:49:\"index.php?attachment=$matches[1]&feed=$matches[2]\";s:61:\"wp-types-term-group/[^/]+/([^/]+)/(feed|rdf|rss|rss2|atom)/?$\";s:49:\"index.php?attachment=$matches[1]&feed=$matches[2]\";s:61:\"wp-types-term-group/[^/]+/([^/]+)/comment-page-([0-9]{1,})/?$\";s:50:\"index.php?attachment=$matches[1]&cpage=$matches[2]\";s:42:\"wp-types-term-group/[^/]+/([^/]+)/embed/?$\";s:43:\"index.php?attachment=$matches[1]&embed=true\";s:39:\"site-review/[^/]+/attachment/([^/]+)/?$\";s:32:\"index.php?attachment=$matches[1]\";s:49:\"site-review/[^/]+/attachment/([^/]+)/trackback/?$\";s:37:\"index.php?attachment=$matches[1]&tb=1\";s:69:\"site-review/[^/]+/attachment/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$\";s:49:\"index.php?attachment=$matches[1]&feed=$matches[2]\";s:64:\"site-review/[^/]+/attachment/([^/]+)/(feed|rdf|rss|rss2|atom)/?$\";s:49:\"index.php?attachment=$matches[1]&feed=$matches[2]\";s:64:\"site-review/[^/]+/attachment/([^/]+)/comment-page-([0-9]{1,})/?$\";s:50:\"index.php?attachment=$matches[1]&cpage=$matches[2]\";s:45:\"site-review/[^/]+/attachment/([^/]+)/embed/?$\";s:43:\"index.php?attachment=$matches[1]&embed=true\";s:28:\"site-review/([^/]+)/embed/?$\";s:44:\"index.php?site-review=$matches[1]&embed=true\";s:32:\"site-review/([^/]+)/trackback/?$\";s:38:\"index.php?site-review=$matches[1]&tb=1\";s:40:\"site-review/([^/]+)/page/?([0-9]{1,})/?$\";s:51:\"index.php?site-review=$matches[1]&paged=$matches[2]\";s:47:\"site-review/([^/]+)/comment-page-([0-9]{1,})/?$\";s:51:\"index.php?site-review=$matches[1]&cpage=$matches[2]\";s:36:\"site-review/([^/]+)(?:/([0-9]+))?/?$\";s:50:\"index.php?site-review=$matches[1]&page=$matches[2]\";s:28:\"site-review/[^/]+/([^/]+)/?$\";s:32:\"index.php?attachment=$matches[1]\";s:38:\"site-review/[^/]+/([^/]+)/trackback/?$\";s:37:\"index.php?attachment=$matches[1]&tb=1\";s:58:\"site-review/[^/]+/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$\";s:49:\"index.php?attachment=$matches[1]&feed=$matches[2]\";s:53:\"site-review/[^/]+/([^/]+)/(feed|rdf|rss|rss2|atom)/?$\";s:49:\"index.php?attachment=$matches[1]&feed=$matches[2]\";s:53:\"site-review/[^/]+/([^/]+)/comment-page-([0-9]{1,})/?$\";s:50:\"index.php?attachment=$matches[1]&cpage=$matches[2]\";s:34:\"site-review/[^/]+/([^/]+)/embed/?$\";s:43:\"index.php?attachment=$matches[1]&embed=true\";s:61:\"site-review-category/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$\";s:59:\"index.php?site-review-category=$matches[1]&feed=$matches[2]\";s:56:\"site-review-category/([^/]+)/(feed|rdf|rss|rss2|atom)/?$\";s:59:\"index.php?site-review-category=$matches[1]&feed=$matches[2]\";s:37:\"site-review-category/([^/]+)/embed/?$\";s:53:\"index.php?site-review-category=$matches[1]&embed=true\";s:49:\"site-review-category/([^/]+)/page/?([0-9]{1,})/?$\";s:60:\"index.php?site-review-category=$matches[1]&paged=$matches[2]\";s:31:\"site-review-category/([^/]+)/?$\";s:42:\"index.php?site-review-category=$matches[1]\";s:45:\"wppb-roles-editor/[^/]+/attachment/([^/]+)/?$\";s:32:\"index.php?attachment=$matches[1]\";s:55:\"wppb-roles-editor/[^/]+/attachment/([^/]+)/trackback/?$\";s:37:\"index.php?attachment=$matches[1]&tb=1\";s:75:\"wppb-roles-editor/[^/]+/attachment/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$\";s:49:\"index.php?attachment=$matches[1]&feed=$matches[2]\";s:70:\"wppb-roles-editor/[^/]+/attachment/([^/]+)/(feed|rdf|rss|rss2|atom)/?$\";s:49:\"index.php?attachment=$matches[1]&feed=$matches[2]\";s:70:\"wppb-roles-editor/[^/]+/attachment/([^/]+)/comment-page-([0-9]{1,})/?$\";s:50:\"index.php?attachment=$matches[1]&cpage=$matches[2]\";s:51:\"wppb-roles-editor/[^/]+/attachment/([^/]+)/embed/?$\";s:43:\"index.php?attachment=$matches[1]&embed=true\";s:34:\"wppb-roles-editor/([^/]+)/embed/?$\";s:50:\"index.php?wppb-roles-editor=$matches[1]&embed=true\";s:38:\"wppb-roles-editor/([^/]+)/trackback/?$\";s:44:\"index.php?wppb-roles-editor=$matches[1]&tb=1\";s:46:\"wppb-roles-editor/([^/]+)/page/?([0-9]{1,})/?$\";s:57:\"index.php?wppb-roles-editor=$matches[1]&paged=$matches[2]\";s:53:\"wppb-roles-editor/([^/]+)/comment-page-([0-9]{1,})/?$\";s:57:\"index.php?wppb-roles-editor=$matches[1]&cpage=$matches[2]\";s:42:\"wppb-roles-editor/([^/]+)(?:/([0-9]+))?/?$\";s:56:\"index.php?wppb-roles-editor=$matches[1]&page=$matches[2]\";s:34:\"wppb-roles-editor/[^/]+/([^/]+)/?$\";s:32:\"index.php?attachment=$matches[1]\";s:44:\"wppb-roles-editor/[^/]+/([^/]+)/trackback/?$\";s:37:\"index.php?attachment=$matches[1]&tb=1\";s:64:\"wppb-roles-editor/[^/]+/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$\";s:49:\"index.php?attachment=$matches[1]&feed=$matches[2]\";s:59:\"wppb-roles-editor/[^/]+/([^/]+)/(feed|rdf|rss|rss2|atom)/?$\";s:49:\"index.php?attachment=$matches[1]&feed=$matches[2]\";s:59:\"wppb-roles-editor/[^/]+/([^/]+)/comment-page-([0-9]{1,})/?$\";s:50:\"index.php?attachment=$matches[1]&cpage=$matches[2]\";s:40:\"wppb-roles-editor/[^/]+/([^/]+)/embed/?$\";s:43:\"index.php?attachment=$matches[1]&embed=true\";s:31:\"umrah/.+?/attachment/([^/]+)/?$\";s:32:\"index.php?attachment=$matches[1]\";s:41:\"umrah/.+?/attachment/([^/]+)/trackback/?$\";s:37:\"index.php?attachment=$matches[1]&tb=1\";s:61:\"umrah/.+?/attachment/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$\";s:49:\"index.php?attachment=$matches[1]&feed=$matches[2]\";s:56:\"umrah/.+?/attachment/([^/]+)/(feed|rdf|rss|rss2|atom)/?$\";s:49:\"index.php?attachment=$matches[1]&feed=$matches[2]\";s:56:\"umrah/.+?/attachment/([^/]+)/comment-page-([0-9]{1,})/?$\";s:50:\"index.php?attachment=$matches[1]&cpage=$matches[2]\";s:37:\"umrah/.+?/attachment/([^/]+)/embed/?$\";s:43:\"index.php?attachment=$matches[1]&embed=true\";s:20:\"umrah/(.+?)/embed/?$\";s:38:\"index.php?umrah=$matches[1]&embed=true\";s:24:\"umrah/(.+?)/trackback/?$\";s:32:\"index.php?umrah=$matches[1]&tb=1\";s:44:\"umrah/(.+?)/feed/(feed|rdf|rss|rss2|atom)/?$\";s:44:\"index.php?umrah=$matches[1]&feed=$matches[2]\";s:39:\"umrah/(.+?)/(feed|rdf|rss|rss2|atom)/?$\";s:44:\"index.php?umrah=$matches[1]&feed=$matches[2]\";s:32:\"umrah/(.+?)/page/?([0-9]{1,})/?$\";s:45:\"index.php?umrah=$matches[1]&paged=$matches[2]\";s:39:\"umrah/(.+?)/comment-page-([0-9]{1,})/?$\";s:45:\"index.php?umrah=$matches[1]&cpage=$matches[2]\";s:28:\"umrah/(.+?)(?:/([0-9]+))?/?$\";s:44:\"index.php?umrah=$matches[1]&page=$matches[2]\";s:36:\"restaurant/.+?/attachment/([^/]+)/?$\";s:32:\"index.php?attachment=$matches[1]\";s:46:\"restaurant/.+?/attachment/([^/]+)/trackback/?$\";s:37:\"index.php?attachment=$matches[1]&tb=1\";s:66:\"restaurant/.+?/attachment/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$\";s:49:\"index.php?attachment=$matches[1]&feed=$matches[2]\";s:61:\"restaurant/.+?/attachment/([^/]+)/(feed|rdf|rss|rss2|atom)/?$\";s:49:\"index.php?attachment=$matches[1]&feed=$matches[2]\";s:61:\"restaurant/.+?/attachment/([^/]+)/comment-page-([0-9]{1,})/?$\";s:50:\"index.php?attachment=$matches[1]&cpage=$matches[2]\";s:42:\"restaurant/.+?/attachment/([^/]+)/embed/?$\";s:43:\"index.php?attachment=$matches[1]&embed=true\";s:25:\"restaurant/(.+?)/embed/?$\";s:43:\"index.php?restaurant=$matches[1]&embed=true\";s:29:\"restaurant/(.+?)/trackback/?$\";s:37:\"index.php?restaurant=$matches[1]&tb=1\";s:49:\"restaurant/(.+?)/feed/(feed|rdf|rss|rss2|atom)/?$\";s:49:\"index.php?restaurant=$matches[1]&feed=$matches[2]\";s:44:\"restaurant/(.+?)/(feed|rdf|rss|rss2|atom)/?$\";s:49:\"index.php?restaurant=$matches[1]&feed=$matches[2]\";s:37:\"restaurant/(.+?)/page/?([0-9]{1,})/?$\";s:50:\"index.php?restaurant=$matches[1]&paged=$matches[2]\";s:44:\"restaurant/(.+?)/comment-page-([0-9]{1,})/?$\";s:50:\"index.php?restaurant=$matches[1]&cpage=$matches[2]\";s:33:\"restaurant/(.+?)(?:/([0-9]+))?/?$\";s:49:\"index.php?restaurant=$matches[1]&page=$matches[2]\";s:35:\"transport/.+?/attachment/([^/]+)/?$\";s:32:\"index.php?attachment=$matches[1]\";s:45:\"transport/.+?/attachment/([^/]+)/trackback/?$\";s:37:\"index.php?attachment=$matches[1]&tb=1\";s:65:\"transport/.+?/attachment/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$\";s:49:\"index.php?attachment=$matches[1]&feed=$matches[2]\";s:60:\"transport/.+?/attachment/([^/]+)/(feed|rdf|rss|rss2|atom)/?$\";s:49:\"index.php?attachment=$matches[1]&feed=$matches[2]\";s:60:\"transport/.+?/attachment/([^/]+)/comment-page-([0-9]{1,})/?$\";s:50:\"index.php?attachment=$matches[1]&cpage=$matches[2]\";s:41:\"transport/.+?/attachment/([^/]+)/embed/?$\";s:43:\"index.php?attachment=$matches[1]&embed=true\";s:24:\"transport/(.+?)/embed/?$\";s:42:\"index.php?transport=$matches[1]&embed=true\";s:28:\"transport/(.+?)/trackback/?$\";s:36:\"index.php?transport=$matches[1]&tb=1\";s:48:\"transport/(.+?)/feed/(feed|rdf|rss|rss2|atom)/?$\";s:48:\"index.php?transport=$matches[1]&feed=$matches[2]\";s:43:\"transport/(.+?)/(feed|rdf|rss|rss2|atom)/?$\";s:48:\"index.php?transport=$matches[1]&feed=$matches[2]\";s:36:\"transport/(.+?)/page/?([0-9]{1,})/?$\";s:49:\"index.php?transport=$matches[1]&paged=$matches[2]\";s:43:\"transport/(.+?)/comment-page-([0-9]{1,})/?$\";s:49:\"index.php?transport=$matches[1]&cpage=$matches[2]\";s:32:\"transport/(.+?)(?:/([0-9]+))?/?$\";s:48:\"index.php?transport=$matches[1]&page=$matches[2]\";s:31:\"tours/.+?/attachment/([^/]+)/?$\";s:32:\"index.php?attachment=$matches[1]\";s:41:\"tours/.+?/attachment/([^/]+)/trackback/?$\";s:37:\"index.php?attachment=$matches[1]&tb=1\";s:61:\"tours/.+?/attachment/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$\";s:49:\"index.php?attachment=$matches[1]&feed=$matches[2]\";s:56:\"tours/.+?/attachment/([^/]+)/(feed|rdf|rss|rss2|atom)/?$\";s:49:\"index.php?attachment=$matches[1]&feed=$matches[2]\";s:56:\"tours/.+?/attachment/([^/]+)/comment-page-([0-9]{1,})/?$\";s:50:\"index.php?attachment=$matches[1]&cpage=$matches[2]\";s:37:\"tours/.+?/attachment/([^/]+)/embed/?$\";s:43:\"index.php?attachment=$matches[1]&embed=true\";s:20:\"tours/(.+?)/embed/?$\";s:38:\"index.php?tours=$matches[1]&embed=true\";s:24:\"tours/(.+?)/trackback/?$\";s:32:\"index.php?tours=$matches[1]&tb=1\";s:44:\"tours/(.+?)/feed/(feed|rdf|rss|rss2|atom)/?$\";s:44:\"index.php?tours=$matches[1]&feed=$matches[2]\";s:39:\"tours/(.+?)/(feed|rdf|rss|rss2|atom)/?$\";s:44:\"index.php?tours=$matches[1]&feed=$matches[2]\";s:32:\"tours/(.+?)/page/?([0-9]{1,})/?$\";s:45:\"index.php?tours=$matches[1]&paged=$matches[2]\";s:39:\"tours/(.+?)/comment-page-([0-9]{1,})/?$\";s:45:\"index.php?tours=$matches[1]&cpage=$matches[2]\";s:28:\"tours/(.+?)(?:/([0-9]+))?/?$\";s:44:\"index.php?tours=$matches[1]&page=$matches[2]\";s:32:\"cars/[^/]+/attachment/([^/]+)/?$\";s:32:\"index.php?attachment=$matches[1]\";s:42:\"cars/[^/]+/attachment/([^/]+)/trackback/?$\";s:37:\"index.php?attachment=$matches[1]&tb=1\";s:62:\"cars/[^/]+/attachment/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$\";s:49:\"index.php?attachment=$matches[1]&feed=$matches[2]\";s:57:\"cars/[^/]+/attachment/([^/]+)/(feed|rdf|rss|rss2|atom)/?$\";s:49:\"index.php?attachment=$matches[1]&feed=$matches[2]\";s:57:\"cars/[^/]+/attachment/([^/]+)/comment-page-([0-9]{1,})/?$\";s:50:\"index.php?attachment=$matches[1]&cpage=$matches[2]\";s:38:\"cars/[^/]+/attachment/([^/]+)/embed/?$\";s:43:\"index.php?attachment=$matches[1]&embed=true\";s:21:\"cars/([^/]+)/embed/?$\";s:37:\"index.php?cars=$matches[1]&embed=true\";s:25:\"cars/([^/]+)/trackback/?$\";s:31:\"index.php?cars=$matches[1]&tb=1\";s:33:\"cars/([^/]+)/page/?([0-9]{1,})/?$\";s:44:\"index.php?cars=$matches[1]&paged=$matches[2]\";s:40:\"cars/([^/]+)/comment-page-([0-9]{1,})/?$\";s:44:\"index.php?cars=$matches[1]&cpage=$matches[2]\";s:29:\"cars/([^/]+)(?:/([0-9]+))?/?$\";s:43:\"index.php?cars=$matches[1]&page=$matches[2]\";s:21:\"cars/[^/]+/([^/]+)/?$\";s:32:\"index.php?attachment=$matches[1]\";s:31:\"cars/[^/]+/([^/]+)/trackback/?$\";s:37:\"index.php?attachment=$matches[1]&tb=1\";s:51:\"cars/[^/]+/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$\";s:49:\"index.php?attachment=$matches[1]&feed=$matches[2]\";s:46:\"cars/[^/]+/([^/]+)/(feed|rdf|rss|rss2|atom)/?$\";s:49:\"index.php?attachment=$matches[1]&feed=$matches[2]\";s:46:\"cars/[^/]+/([^/]+)/comment-page-([0-9]{1,})/?$\";s:50:\"index.php?attachment=$matches[1]&cpage=$matches[2]\";s:27:\"cars/[^/]+/([^/]+)/embed/?$\";s:43:\"index.php?attachment=$matches[1]&embed=true\";s:49:\"carsname/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$\";s:47:\"index.php?carsname=$matches[1]&feed=$matches[2]\";s:44:\"carsname/([^/]+)/(feed|rdf|rss|rss2|atom)/?$\";s:47:\"index.php?carsname=$matches[1]&feed=$matches[2]\";s:25:\"carsname/([^/]+)/embed/?$\";s:41:\"index.php?carsname=$matches[1]&embed=true\";s:37:\"carsname/([^/]+)/page/?([0-9]{1,})/?$\";s:48:\"index.php?carsname=$matches[1]&paged=$matches[2]\";s:19:\"carsname/([^/]+)/?$\";s:30:\"index.php?carsname=$matches[1]\";s:53:\"carsfeatures/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$\";s:51:\"index.php?carsfeatures=$matches[1]&feed=$matches[2]\";s:48:\"carsfeatures/([^/]+)/(feed|rdf|rss|rss2|atom)/?$\";s:51:\"index.php?carsfeatures=$matches[1]&feed=$matches[2]\";s:29:\"carsfeatures/([^/]+)/embed/?$\";s:45:\"index.php?carsfeatures=$matches[1]&embed=true\";s:41:\"carsfeatures/([^/]+)/page/?([0-9]{1,})/?$\";s:52:\"index.php?carsfeatures=$matches[1]&paged=$matches[2]\";s:23:\"carsfeatures/([^/]+)/?$\";s:34:\"index.php?carsfeatures=$matches[1]\";s:53:\"carslocation/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$\";s:51:\"index.php?carslocation=$matches[1]&feed=$matches[2]\";s:48:\"carslocation/([^/]+)/(feed|rdf|rss|rss2|atom)/?$\";s:51:\"index.php?carslocation=$matches[1]&feed=$matches[2]\";s:29:\"carslocation/([^/]+)/embed/?$\";s:45:\"index.php?carslocation=$matches[1]&embed=true\";s:41:\"carslocation/([^/]+)/page/?([0-9]{1,})/?$\";s:52:\"index.php?carslocation=$matches[1]&paged=$matches[2]\";s:23:\"carslocation/([^/]+)/?$\";s:34:\"index.php?carslocation=$matches[1]\";s:57:\"defaultequipment/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$\";s:55:\"index.php?defaultequipment=$matches[1]&feed=$matches[2]\";s:52:\"defaultequipment/([^/]+)/(feed|rdf|rss|rss2|atom)/?$\";s:55:\"index.php?defaultequipment=$matches[1]&feed=$matches[2]\";s:33:\"defaultequipment/([^/]+)/embed/?$\";s:49:\"index.php?defaultequipment=$matches[1]&embed=true\";s:45:\"defaultequipment/([^/]+)/page/?([0-9]{1,})/?$\";s:56:\"index.php?defaultequipment=$matches[1]&paged=$matches[2]\";s:27:\"defaultequipment/([^/]+)/?$\";s:38:\"index.php?defaultequipment=$matches[1]\";s:49:\"destinos/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$\";s:46:\"index.php?destino=$matches[1]&feed=$matches[2]\";s:44:\"destinos/([^/]+)/(feed|rdf|rss|rss2|atom)/?$\";s:46:\"index.php?destino=$matches[1]&feed=$matches[2]\";s:25:\"destinos/([^/]+)/embed/?$\";s:40:\"index.php?destino=$matches[1]&embed=true\";s:37:\"destinos/([^/]+)/page/?([0-9]{1,})/?$\";s:47:\"index.php?destino=$matches[1]&paged=$matches[2]\";s:19:\"destinos/([^/]+)/?$\";s:29:\"index.php?destino=$matches[1]\";s:62:\"main_hotel_informations/(.+?)/feed/(feed|rdf|rss|rss2|atom)/?$\";s:62:\"index.php?main_hotel_informations=$matches[1]&feed=$matches[2]\";s:57:\"main_hotel_informations/(.+?)/(feed|rdf|rss|rss2|atom)/?$\";s:62:\"index.php?main_hotel_informations=$matches[1]&feed=$matches[2]\";s:38:\"main_hotel_informations/(.+?)/embed/?$\";s:56:\"index.php?main_hotel_informations=$matches[1]&embed=true\";s:50:\"main_hotel_informations/(.+?)/page/?([0-9]{1,})/?$\";s:63:\"index.php?main_hotel_informations=$matches[1]&paged=$matches[2]\";s:32:\"main_hotel_informations/(.+?)/?$\";s:45:\"index.php?main_hotel_informations=$matches[1]\";s:43:\"available-rooms/[^/]+/attachment/([^/]+)/?$\";s:32:\"index.php?attachment=$matches[1]\";s:53:\"available-rooms/[^/]+/attachment/([^/]+)/trackback/?$\";s:37:\"index.php?attachment=$matches[1]&tb=1\";s:73:\"available-rooms/[^/]+/attachment/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$\";s:49:\"index.php?attachment=$matches[1]&feed=$matches[2]\";s:68:\"available-rooms/[^/]+/attachment/([^/]+)/(feed|rdf|rss|rss2|atom)/?$\";s:49:\"index.php?attachment=$matches[1]&feed=$matches[2]\";s:68:\"available-rooms/[^/]+/attachment/([^/]+)/comment-page-([0-9]{1,})/?$\";s:50:\"index.php?attachment=$matches[1]&cpage=$matches[2]\";s:49:\"available-rooms/[^/]+/attachment/([^/]+)/embed/?$\";s:43:\"index.php?attachment=$matches[1]&embed=true\";s:32:\"available-rooms/([^/]+)/embed/?$\";s:48:\"index.php?available-rooms=$matches[1]&embed=true\";s:36:\"available-rooms/([^/]+)/trackback/?$\";s:42:\"index.php?available-rooms=$matches[1]&tb=1\";s:56:\"available-rooms/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$\";s:54:\"index.php?available-rooms=$matches[1]&feed=$matches[2]\";s:51:\"available-rooms/([^/]+)/(feed|rdf|rss|rss2|atom)/?$\";s:54:\"index.php?available-rooms=$matches[1]&feed=$matches[2]\";s:44:\"available-rooms/([^/]+)/page/?([0-9]{1,})/?$\";s:55:\"index.php?available-rooms=$matches[1]&paged=$matches[2]\";s:51:\"available-rooms/([^/]+)/comment-page-([0-9]{1,})/?$\";s:55:\"index.php?available-rooms=$matches[1]&cpage=$matches[2]\";s:40:\"available-rooms/([^/]+)(?:/([0-9]+))?/?$\";s:54:\"index.php?available-rooms=$matches[1]&page=$matches[2]\";s:32:\"available-rooms/[^/]+/([^/]+)/?$\";s:32:\"index.php?attachment=$matches[1]\";s:42:\"available-rooms/[^/]+/([^/]+)/trackback/?$\";s:37:\"index.php?attachment=$matches[1]&tb=1\";s:62:\"available-rooms/[^/]+/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$\";s:49:\"index.php?attachment=$matches[1]&feed=$matches[2]\";s:57:\"available-rooms/[^/]+/([^/]+)/(feed|rdf|rss|rss2|atom)/?$\";s:49:\"index.php?attachment=$matches[1]&feed=$matches[2]\";s:57:\"available-rooms/[^/]+/([^/]+)/comment-page-([0-9]{1,})/?$\";s:50:\"index.php?attachment=$matches[1]&cpage=$matches[2]\";s:38:\"available-rooms/[^/]+/([^/]+)/embed/?$\";s:43:\"index.php?attachment=$matches[1]&embed=true\";s:48:\".*wp-(atom|rdf|rss|rss2|feed|commentsrss2)\\.php$\";s:18:\"index.php?feed=old\";s:20:\".*wp-app\\.php(/.*)?$\";s:19:\"index.php?error=403\";s:18:\".*wp-register.php$\";s:23:\"index.php?register=true\";s:32:\"feed/(feed|rdf|rss|rss2|atom)/?$\";s:27:\"index.php?&feed=$matches[1]\";s:27:\"(feed|rdf|rss|rss2|atom)/?$\";s:27:\"index.php?&feed=$matches[1]\";s:8:\"embed/?$\";s:21:\"index.php?&embed=true\";s:20:\"page/?([0-9]{1,})/?$\";s:28:\"index.php?&paged=$matches[1]\";s:27:\"comment-page-([0-9]{1,})/?$\";s:38:\"index.php?&page_id=9&cpage=$matches[1]\";s:41:\"comments/feed/(feed|rdf|rss|rss2|atom)/?$\";s:42:\"index.php?&feed=$matches[1]&withcomments=1\";s:36:\"comments/(feed|rdf|rss|rss2|atom)/?$\";s:42:\"index.php?&feed=$matches[1]&withcomments=1\";s:17:\"comments/embed/?$\";s:21:\"index.php?&embed=true\";s:44:\"search/(.+)/feed/(feed|rdf|rss|rss2|atom)/?$\";s:40:\"index.php?s=$matches[1]&feed=$matches[2]\";s:39:\"search/(.+)/(feed|rdf|rss|rss2|atom)/?$\";s:40:\"index.php?s=$matches[1]&feed=$matches[2]\";s:20:\"search/(.+)/embed/?$\";s:34:\"index.php?s=$matches[1]&embed=true\";s:32:\"search/(.+)/page/?([0-9]{1,})/?$\";s:41:\"index.php?s=$matches[1]&paged=$matches[2]\";s:14:\"search/(.+)/?$\";s:23:\"index.php?s=$matches[1]\";s:47:\"author/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$\";s:50:\"index.php?author_name=$matches[1]&feed=$matches[2]\";s:42:\"author/([^/]+)/(feed|rdf|rss|rss2|atom)/?$\";s:50:\"index.php?author_name=$matches[1]&feed=$matches[2]\";s:23:\"author/([^/]+)/embed/?$\";s:44:\"index.php?author_name=$matches[1]&embed=true\";s:35:\"author/([^/]+)/page/?([0-9]{1,})/?$\";s:51:\"index.php?author_name=$matches[1]&paged=$matches[2]\";s:17:\"author/([^/]+)/?$\";s:33:\"index.php?author_name=$matches[1]\";s:69:\"([0-9]{4})/([0-9]{1,2})/([0-9]{1,2})/feed/(feed|rdf|rss|rss2|atom)/?$\";s:80:\"index.php?year=$matches[1]&monthnum=$matches[2]&day=$matches[3]&feed=$matches[4]\";s:64:\"([0-9]{4})/([0-9]{1,2})/([0-9]{1,2})/(feed|rdf|rss|rss2|atom)/?$\";s:80:\"index.php?year=$matches[1]&monthnum=$matches[2]&day=$matches[3]&feed=$matches[4]\";s:45:\"([0-9]{4})/([0-9]{1,2})/([0-9]{1,2})/embed/?$\";s:74:\"index.php?year=$matches[1]&monthnum=$matches[2]&day=$matches[3]&embed=true\";s:57:\"([0-9]{4})/([0-9]{1,2})/([0-9]{1,2})/page/?([0-9]{1,})/?$\";s:81:\"index.php?year=$matches[1]&monthnum=$matches[2]&day=$matches[3]&paged=$matches[4]\";s:39:\"([0-9]{4})/([0-9]{1,2})/([0-9]{1,2})/?$\";s:63:\"index.php?year=$matches[1]&monthnum=$matches[2]&day=$matches[3]\";s:56:\"([0-9]{4})/([0-9]{1,2})/feed/(feed|rdf|rss|rss2|atom)/?$\";s:64:\"index.php?year=$matches[1]&monthnum=$matches[2]&feed=$matches[3]\";s:51:\"([0-9]{4})/([0-9]{1,2})/(feed|rdf|rss|rss2|atom)/?$\";s:64:\"index.php?year=$matches[1]&monthnum=$matches[2]&feed=$matches[3]\";s:32:\"([0-9]{4})/([0-9]{1,2})/embed/?$\";s:58:\"index.php?year=$matches[1]&monthnum=$matches[2]&embed=true\";s:44:\"([0-9]{4})/([0-9]{1,2})/page/?([0-9]{1,})/?$\";s:65:\"index.php?year=$matches[1]&monthnum=$matches[2]&paged=$matches[3]\";s:26:\"([0-9]{4})/([0-9]{1,2})/?$\";s:47:\"index.php?year=$matches[1]&monthnum=$matches[2]\";s:43:\"([0-9]{4})/feed/(feed|rdf|rss|rss2|atom)/?$\";s:43:\"index.php?year=$matches[1]&feed=$matches[2]\";s:38:\"([0-9]{4})/(feed|rdf|rss|rss2|atom)/?$\";s:43:\"index.php?year=$matches[1]&feed=$matches[2]\";s:19:\"([0-9]{4})/embed/?$\";s:37:\"index.php?year=$matches[1]&embed=true\";s:31:\"([0-9]{4})/page/?([0-9]{1,})/?$\";s:44:\"index.php?year=$matches[1]&paged=$matches[2]\";s:13:\"([0-9]{4})/?$\";s:26:\"index.php?year=$matches[1]\";s:27:\".?.+?/attachment/([^/]+)/?$\";s:32:\"index.php?attachment=$matches[1]\";s:37:\".?.+?/attachment/([^/]+)/trackback/?$\";s:37:\"index.php?attachment=$matches[1]&tb=1\";s:57:\".?.+?/attachment/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$\";s:49:\"index.php?attachment=$matches[1]&feed=$matches[2]\";s:52:\".?.+?/attachment/([^/]+)/(feed|rdf|rss|rss2|atom)/?$\";s:49:\"index.php?attachment=$matches[1]&feed=$matches[2]\";s:52:\".?.+?/attachment/([^/]+)/comment-page-([0-9]{1,})/?$\";s:50:\"index.php?attachment=$matches[1]&cpage=$matches[2]\";s:33:\".?.+?/attachment/([^/]+)/embed/?$\";s:43:\"index.php?attachment=$matches[1]&embed=true\";s:16:\"(.?.+?)/embed/?$\";s:41:\"index.php?pagename=$matches[1]&embed=true\";s:20:\"(.?.+?)/trackback/?$\";s:35:\"index.php?pagename=$matches[1]&tb=1\";s:40:\"(.?.+?)/feed/(feed|rdf|rss|rss2|atom)/?$\";s:47:\"index.php?pagename=$matches[1]&feed=$matches[2]\";s:35:\"(.?.+?)/(feed|rdf|rss|rss2|atom)/?$\";s:47:\"index.php?pagename=$matches[1]&feed=$matches[2]\";s:28:\"(.?.+?)/page/?([0-9]{1,})/?$\";s:48:\"index.php?pagename=$matches[1]&paged=$matches[2]\";s:35:\"(.?.+?)/comment-page-([0-9]{1,})/?$\";s:48:\"index.php?pagename=$matches[1]&cpage=$matches[2]\";s:24:\"(.?.+?)(?:/([0-9]+))?/?$\";s:47:\"index.php?pagename=$matches[1]&page=$matches[2]\";s:27:\"[^/]+/attachment/([^/]+)/?$\";s:32:\"index.php?attachment=$matches[1]\";s:37:\"[^/]+/attachment/([^/]+)/trackback/?$\";s:37:\"index.php?attachment=$matches[1]&tb=1\";s:57:\"[^/]+/attachment/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$\";s:49:\"index.php?attachment=$matches[1]&feed=$matches[2]\";s:52:\"[^/]+/attachment/([^/]+)/(feed|rdf|rss|rss2|atom)/?$\";s:49:\"index.php?attachment=$matches[1]&feed=$matches[2]\";s:52:\"[^/]+/attachment/([^/]+)/comment-page-([0-9]{1,})/?$\";s:50:\"index.php?attachment=$matches[1]&cpage=$matches[2]\";s:33:\"[^/]+/attachment/([^/]+)/embed/?$\";s:43:\"index.php?attachment=$matches[1]&embed=true\";s:16:\"([^/]+)/embed/?$\";s:37:\"index.php?name=$matches[1]&embed=true\";s:20:\"([^/]+)/trackback/?$\";s:31:\"index.php?name=$matches[1]&tb=1\";s:40:\"([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$\";s:43:\"index.php?name=$matches[1]&feed=$matches[2]\";s:35:\"([^/]+)/(feed|rdf|rss|rss2|atom)/?$\";s:43:\"index.php?name=$matches[1]&feed=$matches[2]\";s:28:\"([^/]+)/page/?([0-9]{1,})/?$\";s:44:\"index.php?name=$matches[1]&paged=$matches[2]\";s:35:\"([^/]+)/comment-page-([0-9]{1,})/?$\";s:44:\"index.php?name=$matches[1]&cpage=$matches[2]\";s:24:\"([^/]+)(?:/([0-9]+))?/?$\";s:43:\"index.php?name=$matches[1]&page=$matches[2]\";s:16:\"[^/]+/([^/]+)/?$\";s:32:\"index.php?attachment=$matches[1]\";s:26:\"[^/]+/([^/]+)/trackback/?$\";s:37:\"index.php?attachment=$matches[1]&tb=1\";s:46:\"[^/]+/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$\";s:49:\"index.php?attachment=$matches[1]&feed=$matches[2]\";s:41:\"[^/]+/([^/]+)/(feed|rdf|rss|rss2|atom)/?$\";s:49:\"index.php?attachment=$matches[1]&feed=$matches[2]\";s:41:\"[^/]+/([^/]+)/comment-page-([0-9]{1,})/?$\";s:50:\"index.php?attachment=$matches[1]&cpage=$matches[2]\";s:22:\"[^/]+/([^/]+)/embed/?$\";s:43:\"index.php?attachment=$matches[1]&embed=true\";}', 'yes'),
(1104, 'package_city_children', 'a:0:{}', 'yes'),
(1110, 'package_class_children', 'a:0:{}', 'yes'),
(1118, 'no_of_days_children', 'a:0:{}', 'yes'),
(1120, 'price_range_children', 'a:0:{}', 'yes'),
(1171, 'woocommerce_db_version', '3.5.5', 'yes'),
(1193, 'woocommerce_free_shipping_1_settings', 'a:3:{s:5:\"title\";s:13:\"Free shipping\";s:8:\"requires\";s:6:\"coupon\";s:10:\"min_amount\";s:1:\"0\";}', 'yes'),
(1194, 'woocommerce_flat_rate_2_settings', 'a:3:{s:5:\"title\";s:9:\"Flat rate\";s:10:\"tax_status\";s:7:\"taxable\";s:4:\"cost\";s:3:\"100\";}', 'yes'),
(1201, 'woocommerce_paypal_settings', 'a:23:{s:7:\"enabled\";s:3:\"yes\";s:5:\"title\";s:6:\"PayPal\";s:11:\"description\";s:85:\"Pay via PayPal; you can pay with your credit card if you don\'t have a PayPal account.\";s:5:\"email\";s:15:\"admin@gmail.com\";s:8:\"advanced\";s:0:\"\";s:8:\"testmode\";s:2:\"no\";s:5:\"debug\";s:2:\"no\";s:16:\"ipn_notification\";s:3:\"yes\";s:14:\"receiver_email\";s:15:\"admin@gmail.com\";s:14:\"identity_token\";s:0:\"\";s:14:\"invoice_prefix\";s:3:\"WC-\";s:13:\"send_shipping\";s:3:\"yes\";s:16:\"address_override\";s:2:\"no\";s:13:\"paymentaction\";s:4:\"sale\";s:10:\"page_style\";s:0:\"\";s:9:\"image_url\";s:0:\"\";s:11:\"api_details\";s:0:\"\";s:12:\"api_username\";s:0:\"\";s:12:\"api_password\";s:0:\"\";s:13:\"api_signature\";s:0:\"\";s:20:\"sandbox_api_username\";s:0:\"\";s:20:\"sandbox_api_password\";s:0:\"\";s:21:\"sandbox_api_signature\";s:0:\"\";}', 'yes'),
(1202, 'woocommerce_gateway_order', 'a:4:{s:4:\"bacs\";i:0;s:6:\"cheque\";i:1;s:3:\"cod\";i:2;s:6:\"paypal\";i:3;}', 'yes'),
(1621, 'Car Category_children', 'a:0:{}', 'yes'),
(1655, 'wpbs_db_version', '1.0', 'yes'),
(1656, 'wpbs-languages', '{\"en\":\"English\"}', 'yes'),
(1657, 'wpbs-options', '{\"selectedColor\":\"#3399cc\",\"selectedBorder\":\"#336699\",\"historyColor\":\"#e823e8\",\"dateFormat\":\"j F Y\"}', 'yes'),
(1658, 'wpbs-default-legend', '{\"default\":{\"name\":{\"default\":\"Available\",\"hr\":\"Slobodno\",\"cs\":\"Volno\",\"da\":\"Ledigt\",\"nl\":\"Vrij\",\"en\":\"Available\",\"fr\":\"Libre\",\"de\":\"Frei\",\"hu\":\"Szabad\",\"it\":\"Libero\",\"ro\":\"Disponobil\",\"ru\":\"\\u0414\\u043e\\u0441\\u0442\\u0443\\u043f\\u043d\\u043e\",\"sk\":\"Vo\\u013en\\u00fd\",\"es\":\"Libre\",\"sv\":\"Ledigt\",\"uk\":\"B\\u0456\\u043b\\u044c\\u043d\\u043e\",\"no\":\"\"},\"color\":\"#DDFFCC\",\"splitColor\":false,\"bookable\":\"yes\"},\"1\":{\"name\":{\"default\":\"Booked\",\"hr\":\"Zauzeto\",\"cs\":\"Obsazeno\",\"da\":\"Booket\",\"nl\":\"Bezet\",\"en\":\"Booked\",\"fr\":\"Occup\\u00e9\",\"de\":\"Belegt\",\"hu\":\"Foglalt\",\"it\":\"Prenotato\",\"ro\":\"Rezervat\",\"ru\":\"\\u0417\\u0430\\u043d\\u044f\\u0442\\u043e\",\"sk\":\"Obsaden\\u00fd\",\"es\":\"Reservado\",\"sv\":\"Bokat\",\"uk\":\"\\u0417\\u0430\\u0439\\u043d\\u044f\\u0442\\u043e\",\"no\":\"\"},\"color\":\"#FFC0BD\",\"splitColor\":false,\"bookable\":false}}', 'yes'),
(1659, 'widget_wpbs_widget', 'a:1:{s:12:\"_multiwidget\";i:1;}', 'yes'),
(2011, 'CarsName_children', 'a:0:{}', 'yes'),
(2015, 'CarsFeatures_children', 'a:0:{}', 'yes'),
(2019, 'CarsLocation_children', 'a:0:{}', 'yes'),
(2058, 'DefaultEquipment_children', 'a:0:{}', 'yes'),
(2349, 'tour_categories_children', 'a:0:{}', 'yes'),
(2665, 'hotel_name_children', 'a:0:{}', 'yes'),
(2752, 'wp_travel_wp-travel-cart_page_id', '354', 'yes'),
(2753, 'wp_travel_wp-travel-checkout_page_id', '355', 'yes'),
(2754, 'wp_travel_wp-travel-dashboard_page_id', '356', 'yes'),
(2755, 'wp_travel_version', '1.8.9', 'yes'),
(2758, 'widget_wp_travel_search', 'a:1:{s:12:\"_multiwidget\";i:1;}', 'yes'),
(2759, 'widget_wp_travel_featured', 'a:1:{s:12:\"_multiwidget\";i:1;}', 'yes'),
(2760, 'widget_wp_travel_location', 'a:1:{s:12:\"_multiwidget\";i:1;}', 'yes'),
(2761, 'widget_wp_travel_trip_type', 'a:1:{s:12:\"_multiwidget\";i:1;}', 'yes'),
(2762, 'widget_wp_travel_sale_itineraries', 'a:1:{s:12:\"_multiwidget\";i:1;}', 'yes'),
(2763, 'widget_wp_travel_trip_enquiry_form_widget', 'a:1:{s:12:\"_multiwidget\";i:1;}', 'yes'),
(2764, 'widget_wp_travel_filter_search_widget', 'a:1:{s:12:\"_multiwidget\";i:1;}', 'yes');
INSERT INTO `wp_options` (`option_id`, `option_name`, `option_value`, `autoload`) VALUES
(2786, 'wp_travel_settings', 'a:38:{s:17:\"myaccount_page_id\";s:0:\"\";s:37:\"enable_checkout_customer_registration\";s:3:\"yes\";s:39:\"enable_my_account_customer_registration\";s:3:\"yes\";s:28:\"generate_username_from_email\";s:3:\"yes\";s:22:\"generate_user_password\";s:3:\"yes\";s:8:\"currency\";s:3:\"USD\";s:13:\"wp_travel_map\";s:10:\"google-map\";s:18:\"google_map_api_key\";s:0:\"\";s:21:\"google_map_zoom_level\";s:2:\"15\";s:22:\"hide_related_itinerary\";s:3:\"yes\";s:26:\"enable_multiple_travellers\";s:3:\"yes\";s:27:\"trip_pricing_options_layout\";s:17:\"by-pricing-option\";s:27:\"send_booking_email_to_admin\";s:3:\"yes\";s:31:\"booking_admin_template_settings\";a:4:{s:13:\"admin_subject\";s:11:\"New Booking\";s:11:\"admin_title\";s:11:\"New Booking\";s:18:\"admin_header_color\";s:7:\"#dd3333\";s:13:\"email_content\";s:6013:\"&nbsp;\r\n<table class=\"wp-travel-wrapper\" style=\"color: #5d5d5d; font-family: Roboto, sans-serif; margin: auto;\" width=\"100%\" cellspacing=\"0\" cellpadding=\"0\">\r\n<tbody>\r\n<tr class=\"wp-travel-content\" style=\"background: #fff;\">\r\n<td class=\"wp-travel-content-top\" style=\"background: #fff; box-sizing: border-box; margin: 0; padding: 20px 25px;\" colspan=\"2\" align=\"left\">\r\n<p style=\"line-height: 1.55; font-size: 14px;\">Hello {sitename} Admin,</p>\r\n<p style=\"line-height: 1.55; font-size: 14px;\">You have received bookings from {customer_name}:</p>\r\n<p style=\"line-height: 1.55; font-size: 14px;\"><b>Booking ID: <a style=\"color: #5a418b; text-decoration: none;\" href=\"{booking_edit_link}\" target=\"_blank\" rel=\"noopener\">#{booking_id}</a> ({booking_arrival_date})</b></p>\r\n</td>\r\n</tr>\r\n<tr class=\"wp-travel-content\" style=\"background: #fff;\">\r\n<td class=\"wp-travel-content-title\" style=\"background: #fff; box-sizing: border-box; margin: 0; padding: 0px 0px 8px 25px;\" colspan=\"2\" align=\"left\">\r\n<h3 style=\"font-size: 16px; line-height: 1; margin: 0; margin-top: 30px;\"><b>Booking Details:</b></h3>\r\n</td>\r\n</tr>\r\n<tr class=\"wp-travel-content\" style=\"background: #fff;\">\r\n<td style=\"font-size: 14px; background: #fff; box-sizing: border-box; margin: 0; padding: 0px 0px 8px 25px;\" align=\"left\"><b>Itinerary</b></td>\r\n<td style=\"font-size: 14px; background: #fff; box-sizing: border-box; margin: 0; padding: 0px 0px 8px 25px;\" align=\"left\"><a style=\"color: #5a418b; text-decoration: none;\" href=\"{itinerary_link}\" target=\"_blank\" rel=\"noopener\">{itinerary_title}</a></td>\r\n</tr>\r\n<tr class=\"wp-travel-content\" style=\"background: #fff;\">\r\n<td style=\"font-size: 14px; background: #fff; box-sizing: border-box; margin: 0; padding: 0px 0px 8px 25px;\" align=\"left\"><b>Pax</b></td>\r\n<td style=\"font-size: 14px; background: #fff; box-sizing: border-box; margin: 0; padding: 0px 0px 8px 25px;\" align=\"left\">{booking_no_of_pax}</td>\r\n</tr>\r\n<tr class=\"wp-travel-content\" style=\"background: #fff;\">\r\n<td style=\"font-size: 14px; background: #fff; box-sizing: border-box; margin: 0; padding: 0px 0px 8px 25px;\" align=\"left\"><b>Scheduled Date</b></td>\r\n<td style=\"font-size: 14px; background: #fff; box-sizing: border-box; margin: 0; padding: 0px 0px 8px 25px;\" align=\"left\">{booking_scheduled_date}</td>\r\n</tr>\r\n<tr class=\"wp-travel-content\" style=\"background: #fff;\">\r\n<td style=\"font-size: 14px; background: #fff; box-sizing: border-box; margin: 0; padding: 0px 0px 8px 25px;\" align=\"left\"><b>Arrival Date</b></td>\r\n<td style=\"font-size: 14px; background: #fff; box-sizing: border-box; margin: 0; padding: 0px 0px 8px 25px;\" align=\"left\">{booking_arrival_date}</td>\r\n</tr>\r\n<tr class=\"wp-travel-content\" style=\"background: #fff;\">\r\n<td style=\"font-size: 14px; background: #fff; box-sizing: border-box; margin: 0; padding: 0px 0px 8px 25px;\" align=\"left\"><b>Departure Date</b></td>\r\n<td style=\"font-size: 14px; background: #fff; box-sizing: border-box; margin: 0; padding: 0px 0px 8px 25px;\" align=\"left\">{booking_departure_date}</td>\r\n</tr>\r\n<tr class=\"wp-travel-content\" style=\"background: #fff;\">\r\n<td class=\"wp-travel-content-title\" style=\"background: #fff; box-sizing: border-box; margin: 0; padding: 0px 0px 8px 25px;\" colspan=\"2\" align=\"left\">\r\n<h3 style=\"font-size: 16px; line-height: 1; margin: 0; margin-top: 30px;\"><b>Customer Details:</b></h3>\r\n</td>\r\n</tr>\r\n<tr class=\"wp-travel-content\" style=\"background: #fff;\">\r\n<td style=\"font-size: 14px; background: #fff; box-sizing: border-box; margin: 0; padding: 0px 0px 8px 25px;\" align=\"left\"><b>Name</b></td>\r\n<td style=\"font-size: 14px; background: #fff; box-sizing: border-box; margin: 0; padding: 0px 0px 8px 25px;\" align=\"left\">{customer_name}</td>\r\n</tr>\r\n<tr class=\"wp-travel-content\" style=\"background: #fff;\">\r\n<td style=\"font-size: 14px; background: #fff; box-sizing: border-box; margin: 0; padding: 0px 0px 8px 25px;\" align=\"left\"><b>Country</b></td>\r\n<td style=\"font-size: 14px; background: #fff; box-sizing: border-box; margin: 0; padding: 0px 0px 8px 25px;\" align=\"left\">{customer_country}</td>\r\n</tr>\r\n<tr class=\"wp-travel-content\" style=\"background: #fff;\">\r\n<td style=\"font-size: 14px; background: #fff; box-sizing: border-box; margin: 0; padding: 0px 0px 8px 25px;\" align=\"left\"><b>Address</b></td>\r\n<td style=\"font-size: 14px; background: #fff; box-sizing: border-box; margin: 0; padding: 0px 0px 8px 25px;\" align=\"left\">{customer_address}</td>\r\n</tr>\r\n<tr class=\"wp-travel-content\" style=\"background: #fff;\">\r\n<td style=\"font-size: 14px; background: #fff; box-sizing: border-box; margin: 0; padding: 0px 0px 8px 25px;\" align=\"left\"><b>Phone</b></td>\r\n<td style=\"font-size: 14px; background: #fff; box-sizing: border-box; margin: 0; padding: 0px 0px 8px 25px;\" align=\"left\">{customer_phone}</td>\r\n</tr>\r\n<tr class=\"wp-travel-content\" style=\"background: #fff;\">\r\n<td style=\"font-size: 14px; background: #fff; box-sizing: border-box; margin: 0; padding: 0px 0px 8px 25px;\" align=\"left\"><b>Email</b></td>\r\n<td style=\"font-size: 14px; background: #fff; box-sizing: border-box; margin: 0; padding: 0px 0px 8px 25px;\" align=\"left\">{customer_email}</td>\r\n</tr>\r\n<tr class=\"wp-travel-content\" style=\"background: #fff;\">\r\n<td style=\"font-size: 14px; background: #fff; box-sizing: border-box; margin: 0; padding: 0px 0px 8px 25px;\" colspan=\"2\" align=\"left\"><b>Note</b></td>\r\n</tr>\r\n<tr class=\"wp-travel-content\" style=\"background: #fff;\">\r\n<td style=\"font-size: 14px; background: #fff; box-sizing: border-box; margin: 0; padding: 0px 0px 8px 25px;\" colspan=\"2\" align=\"left\">{customer_note}</td>\r\n</tr>\r\n<tr class=\"wp-travel-content\" style=\"background: #fff;\">\r\n<td colspan=\"2\" align=\"center\"><a class=\"wp-travel-veiw-more\" style=\"color: #fcfffd; text-decoration: none; background: #dd402e; border-radius: 3px; display: block; font-size: 14px; margin: 20px auto; padding: 10px 20px; text-align: center; height: 30px; line-height: 30px; width: 200px;\" href=\"{booking_edit_link}\" target=\"_blank\" rel=\"noopener\">View details on site</a></td>\r\n</tr>\r\n</tbody>\r\n</table>\";}s:31:\"payment_admin_template_settings\";a:4:{s:13:\"admin_subject\";s:11:\"New Booking\";s:11:\"admin_title\";s:11:\"New Booking\";s:18:\"admin_header_color\";s:0:\"\";s:13:\"email_content\";s:7803:\"&nbsp;\r\n<table class=\"wp-travel-wrapper\" style=\"color: #5d5d5d; font-family: Roboto, sans-serif; margin: auto;\" width=\"100%\" cellspacing=\"0\" cellpadding=\"0\">\r\n<tbody>\r\n<tr class=\"wp-travel-content\" style=\"background: #fff;\">\r\n<td class=\"wp-travel-content-top\" style=\"background: #fff; box-sizing: border-box; margin: 0; padding: 20px 25px;\" colspan=\"2\" align=\"left\">\r\n<p style=\"line-height: 1.55; font-size: 14px;\">Hello {sitename} Admin,</p>\r\n<p style=\"line-height: 1.55; font-size: 14px;\">You have received payment from {customer_name}:</p>\r\n<p style=\"line-height: 1.55; font-size: 14px;\"><b>Booking ID: <a style=\"color: #5a418b; text-decoration: none;\" href=\"{booking_edit_link}\" target=\"_blank\" rel=\"noopener\">#{booking_id}</a> ({booking_arrival_date})</b></p>\r\n</td>\r\n</tr>\r\n<tr class=\"wp-travel-content\" style=\"background: #fff;\">\r\n<td class=\"wp-travel-content-title\" style=\"background: #fff; box-sizing: border-box; margin: 0; padding: 0px 0px 8px 25px;\" colspan=\"2\" align=\"left\">\r\n<h3 style=\"font-size: 16px; line-height: 1; margin: 0; margin-top: 30px;\"><b>Booking Details:</b></h3>\r\n</td>\r\n</tr>\r\n<tr class=\"wp-travel-content\" style=\"background: #fff;\">\r\n<td style=\"font-size: 14px; background: #fff; box-sizing: border-box; margin: 0; padding: 0px 0px 8px 25px;\" align=\"left\"><b>Itinerary</b></td>\r\n<td style=\"font-size: 14px; background: #fff; box-sizing: border-box; margin: 0; padding: 0px 0px 8px 25px;\" align=\"left\"><a style=\"color: #5a418b; text-decoration: none;\" href=\"{itinerary_link}\" target=\"_blank\" rel=\"noopener\">{itinerary_title}</a></td>\r\n</tr>\r\n<tr class=\"wp-travel-content\" style=\"background: #fff;\">\r\n<td style=\"font-size: 14px; background: #fff; box-sizing: border-box; margin: 0; padding: 0px 0px 8px 25px;\" align=\"left\"><b>Pax</b></td>\r\n<td style=\"font-size: 14px; background: #fff; box-sizing: border-box; margin: 0; padding: 0px 0px 8px 25px;\" align=\"left\">{booking_no_of_pax}</td>\r\n</tr>\r\n<tr class=\"wp-travel-content\" style=\"background: #fff;\">\r\n<td style=\"font-size: 14px; background: #fff; box-sizing: border-box; margin: 0; padding: 0px 0px 8px 25px;\" align=\"left\"><b>Scheduled Date</b></td>\r\n<td style=\"font-size: 14px; background: #fff; box-sizing: border-box; margin: 0; padding: 0px 0px 8px 25px;\" align=\"left\">{booking_scheduled_date}</td>\r\n</tr>\r\n<tr class=\"wp-travel-content\" style=\"background: #fff;\">\r\n<td style=\"font-size: 14px; background: #fff; box-sizing: border-box; margin: 0; padding: 0px 0px 8px 25px;\" align=\"left\"><b>Arrival Date</b></td>\r\n<td style=\"font-size: 14px; background: #fff; box-sizing: border-box; margin: 0; padding: 0px 0px 8px 25px;\" align=\"left\">{booking_arrival_date}</td>\r\n</tr>\r\n<tr class=\"wp-travel-content\" style=\"background: #fff;\">\r\n<td style=\"font-size: 14px; background: #fff; box-sizing: border-box; margin: 0; padding: 0px 0px 8px 25px;\" align=\"left\"><b>Departure Date</b></td>\r\n<td style=\"font-size: 14px; background: #fff; box-sizing: border-box; margin: 0; padding: 0px 0px 8px 25px;\" align=\"left\">{booking_departure_date}</td>\r\n</tr>\r\n<tr class=\"wp-travel-content\" style=\"background: #fff;\">\r\n<td class=\"wp-travel-content-title\" style=\"background: #fff; box-sizing: border-box; margin: 0; padding: 0px 0px 8px 25px;\" colspan=\"2\" align=\"left\">\r\n<h3 style=\"font-size: 16px; line-height: 1; margin: 0; margin-top: 30px;\"><b>Customer Details:</b></h3>\r\n</td>\r\n</tr>\r\n<tr class=\"wp-travel-content\" style=\"background: #fff;\">\r\n<td style=\"font-size: 14px; background: #fff; box-sizing: border-box; margin: 0; padding: 0px 0px 8px 25px;\" align=\"left\"><b>Name</b></td>\r\n<td style=\"font-size: 14px; background: #fff; box-sizing: border-box; margin: 0; padding: 0px 0px 8px 25px;\" align=\"left\">{customer_name}</td>\r\n</tr>\r\n<tr class=\"wp-travel-content\" style=\"background: #fff;\">\r\n<td style=\"font-size: 14px; background: #fff; box-sizing: border-box; margin: 0; padding: 0px 0px 8px 25px;\" align=\"left\"><b>Country</b></td>\r\n<td style=\"font-size: 14px; background: #fff; box-sizing: border-box; margin: 0; padding: 0px 0px 8px 25px;\" align=\"left\">{customer_country}</td>\r\n</tr>\r\n<tr class=\"wp-travel-content\" style=\"background: #fff;\">\r\n<td style=\"font-size: 14px; background: #fff; box-sizing: border-box; margin: 0; padding: 0px 0px 8px 25px;\" align=\"left\"><b>Address</b></td>\r\n<td style=\"font-size: 14px; background: #fff; box-sizing: border-box; margin: 0; padding: 0px 0px 8px 25px;\" align=\"left\">{customer_address}</td>\r\n</tr>\r\n<tr class=\"wp-travel-content\" style=\"background: #fff;\">\r\n<td style=\"font-size: 14px; background: #fff; box-sizing: border-box; margin: 0; padding: 0px 0px 8px 25px;\" align=\"left\"><b>Phone</b></td>\r\n<td style=\"font-size: 14px; background: #fff; box-sizing: border-box; margin: 0; padding: 0px 0px 8px 25px;\" align=\"left\">{customer_phone}</td>\r\n</tr>\r\n<tr class=\"wp-travel-content\" style=\"background: #fff;\">\r\n<td style=\"font-size: 14px; background: #fff; box-sizing: border-box; margin: 0; padding: 0px 0px 8px 25px;\" align=\"left\"><b>Email</b></td>\r\n<td style=\"font-size: 14px; background: #fff; box-sizing: border-box; margin: 0; padding: 0px 0px 8px 25px;\" align=\"left\">{customer_email}</td>\r\n</tr>\r\n<tr class=\"wp-travel-content\" style=\"background: #fff;\">\r\n<td style=\"font-size: 14px; background: #fff; box-sizing: border-box; margin: 0; padding: 0px 0px 8px 25px;\" colspan=\"2\" align=\"left\"><b>Note</b></td>\r\n</tr>\r\n<tr class=\"wp-travel-content\" style=\"background: #fff;\">\r\n<td style=\"font-size: 14px; background: #fff; box-sizing: border-box; margin: 0; padding: 0px 0px 8px 25px;\" colspan=\"2\" align=\"left\">{customer_note}</td>\r\n</tr>\r\n<tr class=\"wp-travel-content\" style=\"background: #fff;\">\r\n<td class=\"wp-travel-content-title\" style=\"background: #fff; box-sizing: border-box; margin: 0; padding: 0px 0px 8px 25px;\" colspan=\"2\" align=\"left\">\r\n<h3 style=\"font-size: 16px; line-height: 1; margin: 0; margin-top: 30px;\"><b>Payment Details:</b></h3>\r\n</td>\r\n</tr>\r\n<tr class=\"wp-travel-content\" style=\"background: #fff;\">\r\n<td style=\"font-size: 14px; background: #fff; box-sizing: border-box; margin: 0; padding: 0px 0px 8px 25px;\" align=\"left\"><b>Payment Status</b></td>\r\n<td style=\"font-size: 14px; background: #fff; box-sizing: border-box; margin: 0; padding: 0px 0px 8px 25px;\" align=\"left\">{payment_status}</td>\r\n</tr>\r\n<tr class=\"wp-travel-content\" style=\"background: #fff;\">\r\n<td style=\"font-size: 14px; background: #fff; box-sizing: border-box; margin: 0; padding: 0px 0px 8px 25px;\" align=\"left\"><b>Payment Mode</b></td>\r\n<td style=\"font-size: 14px; background: #fff; box-sizing: border-box; margin: 0; padding: 0px 0px 8px 25px;\" align=\"left\">{payment_mode}</td>\r\n</tr>\r\n<tr class=\"wp-travel-content\" style=\"background: #fff;\">\r\n<td style=\"font-size: 14px; background: #fff; box-sizing: border-box; margin: 0; padding: 0px 0px 8px 25px;\" align=\"left\"><b>Trip Price</b></td>\r\n<td style=\"font-size: 14px; background: #fff; box-sizing: border-box; margin: 0; padding: 0px 0px 8px 25px;\" align=\"left\">{currency_symbol} {trip_price}</td>\r\n</tr>\r\n<tr class=\"wp-travel-content\" style=\"background: #fff;\">\r\n<td style=\"font-size: 14px; background: #fff; box-sizing: border-box; margin: 0; padding: 0px 0px 8px 25px;\" align=\"left\"><b>Payment Amount</b></td>\r\n<td style=\"font-size: 14px; background: #fff; box-sizing: border-box; margin: 0; padding: 0px 0px 8px 25px;\" align=\"left\">{currency_symbol} {payment_amount}</td>\r\n</tr>\r\n<tr class=\"wp-travel-content\" style=\"background: #fff;\">\r\n<td colspan=\"2\" align=\"center\"><a class=\"wp-travel-veiw-more\" style=\"color: #fcfffd; text-decoration: none; background: #dd402e; border-radius: 3px; display: block; font-size: 14px; margin: 20px auto; padding: 10px 20px; text-align: center; height: 30px; line-height: 30px; width: 200px;\" href=\"{booking_edit_link}\" target=\"_blank\" rel=\"noopener\">View details on site</a></td>\r\n</tr>\r\n</tbody>\r\n</table>\";}s:31:\"enquiry_admin_template_settings\";a:4:{s:13:\"admin_subject\";s:11:\"New Enquiry\";s:11:\"admin_title\";s:11:\"New Enquiry\";s:18:\"admin_header_color\";s:0:\"\";s:13:\"email_content\";s:2878:\"&nbsp;\r\n<table class=\"wp-travel-wrapper\" style=\"color: #5d5d5d; font-family: Roboto, sans-serif; margin: auto;\" width=\"100%\" cellspacing=\"0\" cellpadding=\"0\">\r\n<tbody>\r\n<tr class=\"wp-travel-content\" style=\"background: #fff;\">\r\n<td class=\"wp-travel-content-top\" style=\"background: #fff; box-sizing: border-box; margin: 0; padding: 20px 25px;\" colspan=\"2\" align=\"left\">\r\n<p style=\"line-height: 1.55; font-size: 14px;\">Hello {sitename} Admin,</p>\r\n<p style=\"line-height: 1.55; font-size: 14px;\">You have received trip enquiry from {customer_name}:</p>\r\n</td>\r\n</tr>\r\n<tr class=\"wp-travel-content\" style=\"background: #fff;\">\r\n<td class=\"wp-travel-content-title\" style=\"background: #fff; box-sizing: border-box; margin: 0; padding: 0px 0px 8px 25px;\" colspan=\"2\" align=\"left\">\r\n<h3 style=\"font-size: 16px; line-height: 1; margin: 0; margin-top: 30px;\"><b>Enquiry Details:</b></h3>\r\n</td>\r\n</tr>\r\n<tr class=\"wp-travel-content\" style=\"background: #fff;\">\r\n<td style=\"font-size: 14px; background: #fff; box-sizing: border-box; margin: 0; padding: 0px 0px 8px 25px;\" align=\"left\"><b>Itinerary</b></td>\r\n<td style=\"font-size: 14px; background: #fff; box-sizing: border-box; margin: 0; padding: 0px 0px 8px 25px;\" align=\"left\"><a style=\"color: #5a418b; text-decoration: none;\" href=\"{itinerary_link}\" target=\"_blank\" rel=\"noopener\">{itinerary_title}</a></td>\r\n</tr>\r\n<tr class=\"wp-travel-content\" style=\"background: #fff;\">\r\n<td style=\"font-size: 14px; background: #fff; box-sizing: border-box; margin: 0; padding: 0px 0px 8px 25px;\" align=\"left\"><b>Name</b></td>\r\n<td style=\"font-size: 14px; background: #fff; box-sizing: border-box; margin: 0; padding: 0px 0px 8px 25px;\" align=\"left\">{customer_name}</td>\r\n</tr>\r\n<tr class=\"wp-travel-content\" style=\"background: #fff;\">\r\n<td style=\"font-size: 14px; background: #fff; box-sizing: border-box; margin: 0; padding: 0px 0px 8px 25px;\" align=\"left\"><b>E-mail</b></td>\r\n<td style=\"font-size: 14px; background: #fff; box-sizing: border-box; margin: 0; padding: 0px 0px 8px 25px;\" align=\"left\">{customer_email}</td>\r\n</tr>\r\n<tr class=\"wp-travel-content\" style=\"background: #fff;\">\r\n<td style=\"font-size: 14px; background: #fff; box-sizing: border-box; margin: 0; padding: 0px 0px 8px 25px;\" align=\"left\"><b>Enquiry Message</b></td>\r\n<td style=\"font-size: 14px; background: #fff; box-sizing: border-box; margin: 0; padding: 0px 0px 8px 25px;\" align=\"left\">{customer_note}</td>\r\n</tr>\r\n<tr class=\"wp-travel-content\" style=\"background: #fff;\">\r\n<td colspan=\"2\" align=\"center\"><a class=\"wp-travel-veiw-more\" style=\"color: #fcfffd; text-decoration: none; background: #dd402e; border-radius: 3px; display: block; font-size: 14px; margin: 20px auto; padding: 10px 20px; text-align: center; height: 30px; line-height: 30px; width: 200px;\" href=\"{enquery_edit_link}\" target=\"_blank\" rel=\"noopener\">View details on site </a></td>\r\n</tr>\r\n</tbody>\r\n</table>\";}s:32:\"booking_client_template_settings\";a:4:{s:14:\"client_subject\";s:16:\"Booking Recieved\";s:12:\"client_title\";s:16:\"Booking Recieved\";s:19:\"client_header_color\";s:7:\"#81d742\";s:13:\"email_content\";s:5630:\"&nbsp;\r\n<table class=\"wp-travel-wrapper\" style=\"color: #5d5d5d; font-family: Roboto, sans-serif; margin: auto;\" width=\"100%\" cellspacing=\"0\" cellpadding=\"0\">\r\n<tbody>\r\n<tr class=\"wp-travel-content\" style=\"background: #fff;\">\r\n<td class=\"wp-travel-content-top\" style=\"background: #fff; box-sizing: border-box; margin: 0; padding: 20px 25px;\" colspan=\"2\" align=\"left\">\r\n<p style=\"line-height: 1.55; font-size: 14px;\">Hello {customer_name},</p>\r\n<p style=\"line-height: 1.55; font-size: 14px;\">Your booking has been received and is now being processed. Your order details are shown below for your reference:</p>\r\n<p style=\"line-height: 1.55; font-size: 14px;\"><b>Booking ID: <a style=\"color: #5a418b; text-decoration: none;\" href=\"{booking_edit_link}\" target=\"_blank\" rel=\"noopener\">#{booking_id}</a> ({booking_arrival_date})</b></p>\r\n</td>\r\n</tr>\r\n<tr class=\"wp-travel-content\" style=\"background: #fff;\">\r\n<td class=\"wp-travel-content-title\" style=\"background: #fff; box-sizing: border-box; margin: 0; padding: 0px 0px 8px 25px;\" colspan=\"2\" align=\"left\">\r\n<h3 style=\"font-size: 16px; line-height: 1; margin: 0; margin-top: 30px;\"><b>Booking Details:</b></h3>\r\n</td>\r\n</tr>\r\n<tr class=\"wp-travel-content\" style=\"background: #fff;\">\r\n<td style=\"font-size: 14px; background: #fff; box-sizing: border-box; margin: 0; padding: 0px 0px 8px 25px;\" align=\"left\"><b>Itinerary</b></td>\r\n<td style=\"font-size: 14px; background: #fff; box-sizing: border-box; margin: 0; padding: 0px 0px 8px 25px;\" align=\"left\"><a style=\"color: #5a418b; text-decoration: none;\" href=\"{itinerary_link}\" target=\"_blank\" rel=\"noopener\">{itinerary_title}</a></td>\r\n</tr>\r\n<tr class=\"wp-travel-content\" style=\"background: #fff;\">\r\n<td style=\"font-size: 14px; background: #fff; box-sizing: border-box; margin: 0; padding: 0px 0px 8px 25px;\" align=\"left\"><b>Pax</b></td>\r\n<td style=\"font-size: 14px; background: #fff; box-sizing: border-box; margin: 0; padding: 0px 0px 8px 25px;\" align=\"left\">{booking_no_of_pax}</td>\r\n</tr>\r\n<tr class=\"wp-travel-content\" style=\"background: #fff;\">\r\n<td style=\"font-size: 14px; background: #fff; box-sizing: border-box; margin: 0; padding: 0px 0px 8px 25px;\" align=\"left\"><b>Scheduled Date</b></td>\r\n<td style=\"font-size: 14px; background: #fff; box-sizing: border-box; margin: 0; padding: 0px 0px 8px 25px;\" align=\"left\">{booking_scheduled_date}</td>\r\n</tr>\r\n<tr class=\"wp-travel-content\" style=\"background: #fff;\">\r\n<td style=\"font-size: 14px; background: #fff; box-sizing: border-box; margin: 0; padding: 0px 0px 8px 25px;\" align=\"left\"><b>Arrival Date</b></td>\r\n<td style=\"font-size: 14px; background: #fff; box-sizing: border-box; margin: 0; padding: 0px 0px 8px 25px;\" align=\"left\">{booking_arrival_date}</td>\r\n</tr>\r\n<tr class=\"wp-travel-content\" style=\"background: #fff;\">\r\n<td style=\"font-size: 14px; background: #fff; box-sizing: border-box; margin: 0; padding: 0px 0px 8px 25px;\" align=\"left\"><b>Departure Date</b></td>\r\n<td style=\"font-size: 14px; background: #fff; box-sizing: border-box; margin: 0; padding: 0px 0px 8px 25px;\" align=\"left\">{booking_departure_date}</td>\r\n</tr>\r\n<tr class=\"wp-travel-content\" style=\"background: #fff;\">\r\n<td class=\"wp-travel-content-title\" style=\"background: #fff; box-sizing: border-box; margin: 0; padding: 0px 0px 8px 25px;\" colspan=\"2\" align=\"left\">\r\n<h3 style=\"font-size: 16px; line-height: 1; margin: 0; margin-top: 30px;\"><b>Your Details:</b></h3>\r\n</td>\r\n</tr>\r\n<tr class=\"wp-travel-content\" style=\"background: #fff;\">\r\n<td style=\"font-size: 14px; background: #fff; box-sizing: border-box; margin: 0; padding: 0px 0px 8px 25px;\" align=\"left\"><b>Name</b></td>\r\n<td style=\"font-size: 14px; background: #fff; box-sizing: border-box; margin: 0; padding: 0px 0px 8px 25px;\" align=\"left\">{customer_name}</td>\r\n</tr>\r\n<tr class=\"wp-travel-content\" style=\"background: #fff;\">\r\n<td style=\"font-size: 14px; background: #fff; box-sizing: border-box; margin: 0; padding: 0px 0px 8px 25px;\" align=\"left\"><b>Country</b></td>\r\n<td style=\"font-size: 14px; background: #fff; box-sizing: border-box; margin: 0; padding: 0px 0px 8px 25px;\" align=\"left\">{customer_country}</td>\r\n</tr>\r\n<tr class=\"wp-travel-content\" style=\"background: #fff;\">\r\n<td style=\"font-size: 14px; background: #fff; box-sizing: border-box; margin: 0; padding: 0px 0px 8px 25px;\" align=\"left\"><b>Address</b></td>\r\n<td style=\"font-size: 14px; background: #fff; box-sizing: border-box; margin: 0; padding: 0px 0px 8px 25px;\" align=\"left\">{customer_address}</td>\r\n</tr>\r\n<tr class=\"wp-travel-content\" style=\"background: #fff;\">\r\n<td style=\"font-size: 14px; background: #fff; box-sizing: border-box; margin: 0; padding: 0px 0px 8px 25px;\" align=\"left\"><b>Phone</b></td>\r\n<td style=\"font-size: 14px; background: #fff; box-sizing: border-box; margin: 0; padding: 0px 0px 8px 25px;\" align=\"left\">{customer_phone}</td>\r\n</tr>\r\n<tr class=\"wp-travel-content\" style=\"background: #fff;\">\r\n<td style=\"font-size: 14px; background: #fff; box-sizing: border-box; margin: 0; padding: 0px 0px 8px 25px;\" align=\"left\"><b>Email</b></td>\r\n<td style=\"font-size: 14px; background: #fff; box-sizing: border-box; margin: 0; padding: 0px 0px 8px 25px;\" align=\"left\">{customer_email}</td>\r\n</tr>\r\n<tr class=\"wp-travel-content\" style=\"background: #fff;\">\r\n<td style=\"font-size: 14px; background: #fff; box-sizing: border-box; margin: 0; padding: 0px 0px 8px 25px;\" colspan=\"2\" align=\"left\"><b>Note</b></td>\r\n</tr>\r\n<tr class=\"wp-travel-content\" style=\"background: #fff;\">\r\n<td style=\"font-size: 14px; background: #fff; box-sizing: border-box; margin: 0; padding: 0px 0px 8px 25px;\" colspan=\"2\" align=\"left\">{customer_note}</td>\r\n</tr>\r\n</tbody>\r\n</table>\";}s:32:\"payment_client_template_settings\";a:4:{s:14:\"client_subject\";s:16:\"Payment Recieved\";s:12:\"client_title\";s:16:\"Payment Recieved\";s:19:\"client_header_color\";s:0:\"\";s:13:\"email_content\";s:2572:\"&nbsp;\r\n<table class=\"wp-travel-wrapper\" style=\"color: #5d5d5d; font-family: Roboto, sans-serif; margin: auto;\" width=\"100%\" cellspacing=\"0\" cellpadding=\"0\">\r\n<tbody>\r\n<tr class=\"wp-travel-content\" style=\"background: #fff;\">\r\n<td class=\"wp-travel-content-top\" style=\"background: #fff; box-sizing: border-box; margin: 0; padding: 20px 25px;\" colspan=\"2\" align=\"left\">\r\n<p style=\"line-height: 1.55; font-size: 14px;\">Hello {customer_name},</p>\r\n<p style=\"line-height: 1.55; font-size: 14px;\">Your payment has been received.</p>\r\n<p style=\"line-height: 1.55; font-size: 14px;\"><b>Booking ID: <a style=\"color: #5a418b; text-decoration: none;\" href=\"{booking_edit_link}\" target=\"_blank\" rel=\"noopener\">#{booking_id}</a> ({booking_arrival_date})</b></p>\r\n</td>\r\n</tr>\r\n<tr class=\"wp-travel-content\" style=\"background: #fff;\">\r\n<td class=\"wp-travel-content-title\" style=\"background: #fff; box-sizing: border-box; margin: 0; padding: 0px 0px 8px 25px;\" colspan=\"2\" align=\"left\">\r\n<h3 style=\"font-size: 16px; line-height: 1; margin: 0; margin-top: 30px;\"><b>Payment Details:</b></h3>\r\n</td>\r\n</tr>\r\n<tr class=\"wp-travel-content\" style=\"background: #fff;\">\r\n<td style=\"font-size: 14px; background: #fff; box-sizing: border-box; margin: 0; padding: 0px 0px 8px 25px;\" align=\"left\"><b>Payment Status</b></td>\r\n<td style=\"font-size: 14px; background: #fff; box-sizing: border-box; margin: 0; padding: 0px 0px 8px 25px;\" align=\"left\">{payment_status}</td>\r\n</tr>\r\n<tr class=\"wp-travel-content\" style=\"background: #fff;\">\r\n<td style=\"font-size: 14px; background: #fff; box-sizing: border-box; margin: 0; padding: 0px 0px 8px 25px;\" align=\"left\"><b>Payment Mode</b></td>\r\n<td style=\"font-size: 14px; background: #fff; box-sizing: border-box; margin: 0; padding: 0px 0px 8px 25px;\" align=\"left\">{payment_mode}</td>\r\n</tr>\r\n<tr class=\"wp-travel-content\" style=\"background: #fff;\">\r\n<td style=\"font-size: 14px; background: #fff; box-sizing: border-box; margin: 0; padding: 0px 0px 8px 25px;\" align=\"left\"><b>Trip Price</b></td>\r\n<td style=\"font-size: 14px; background: #fff; box-sizing: border-box; margin: 0; padding: 0px 0px 8px 25px;\" align=\"left\">{currency_symbol} {trip_price}</td>\r\n</tr>\r\n<tr class=\"wp-travel-content\" style=\"background: #fff;\">\r\n<td style=\"font-size: 14px; background: #fff; box-sizing: border-box; margin: 0; padding: 0px 0px 8px 25px;\" align=\"left\"><b>Payment Amount</b></td>\r\n<td style=\"font-size: 14px; background: #fff; box-sizing: border-box; margin: 0; padding: 0px 0px 8px 25px;\" align=\"left\">{currency_symbol} {payment_amount}</td>\r\n</tr>\r\n</tbody>\r\n</table>\";}s:19:\"global_tab_settings\";a:8:{s:8:\"overview\";a:2:{s:5:\"label\";s:8:\"Overview\";s:12:\"show_in_menu\";s:3:\"yes\";}s:12:\"trip_outline\";a:2:{s:5:\"label\";s:12:\"Trip Outline\";s:12:\"show_in_menu\";s:3:\"yes\";}s:13:\"trip_includes\";a:2:{s:5:\"label\";s:13:\"Trip Includes\";s:12:\"show_in_menu\";s:3:\"yes\";}s:13:\"trip_excludes\";a:2:{s:5:\"label\";s:13:\"Trip Excludes\";s:12:\"show_in_menu\";s:3:\"yes\";}s:7:\"gallery\";a:2:{s:5:\"label\";s:7:\"Gallery\";s:12:\"show_in_menu\";s:3:\"yes\";}s:7:\"reviews\";a:2:{s:5:\"label\";s:7:\"Reviews\";s:12:\"show_in_menu\";s:3:\"yes\";}s:7:\"booking\";a:2:{s:5:\"label\";s:7:\"Booking\";s:12:\"show_in_menu\";s:3:\"yes\";}s:3:\"faq\";a:2:{s:5:\"label\";s:3:\"FAQ\";s:12:\"show_in_menu\";s:3:\"yes\";}}s:26:\"enable_trip_enquiry_option\";s:3:\"yes\";s:14:\"enable_og_tags\";s:3:\"yes\";s:12:\"wt_test_mode\";s:3:\"yes\";s:13:\"wt_test_email\";s:0:\"\";s:15:\"partial_payment\";s:3:\"yes\";s:22:\"minimum_partial_payout\";s:4:\"24.6\";s:15:\"trip_tax_enable\";s:0:\"\";s:19:\"trip_tax_percentage\";s:0:\"\";s:24:\"trip_tax_price_inclusive\";s:3:\"yes\";s:12:\"paypal_email\";s:0:\"\";s:21:\"payment_option_paypal\";s:3:\"yes\";s:27:\"wp_travel_trip_facts_enable\";s:3:\"yes\";s:29:\"wp_travel_trip_facts_settings\";a:1:{i:736107;a:4:{s:4:\"name\";s:4:\"test\";s:4:\"type\";s:8:\"multiple\";s:7:\"options\";s:0:\"\";s:4:\"icon\";s:0:\"\";}}s:12:\"cart_page_id\";s:3:\"354\";s:16:\"checkout_page_id\";s:3:\"355\";s:17:\"dashboard_page_id\";s:3:\"356\";s:22:\"wp_travel_gdpr_message\";s:35:\"By contacting us, you agree to our \";s:20:\"open_gdpr_in_new_tab\";s:3:\"yes\";s:20:\"wp_travel_from_email\";s:15:\"admin@gmail.com\";}', 'yes');
INSERT INTO `wp_options` (`option_id`, `option_name`, `option_value`, `autoload`) VALUES
(2805, '_transient_wp_travel_marketplace_addons_list', '{\n    \"products\": [\n        {\n            \"info\": {\n                \"id\": 12512,\n                \"slug\": \"wp-travel-mailchimp\",\n                \"title\": \"WP Travel MailChimp\",\n                \"create_date\": \"2019-03-25 11:53:59\",\n                \"modified_date\": \"2019-03-29 07:45:50\",\n                \"status\": \"publish\",\n                \"link\": \"https:\\/\\/wptravel.io\\/?post_type=download&p=12512\",\n                \"content\": \"<img class=\\\"alignright size-full wp-image-12643\\\" src=\\\"http:\\/\\/wptravel.io\\/wp-content\\/uploads\\/edd\\/2019\\/03\\/mail-chimp-main-banner-1.jpg\\\" alt=\\\"\\\" width=\\\"1497\\\" height=\\\"614\\\" \\/>\\r\\n\\r\\nLooking for easy-to-install and use MailChimp WordPress Plugin for your travel website? Install WP Travel MailChimp addon on your travel site today &amp; launch your email campaign in minutes.\\r\\n\\r\\nThe WP Travel WordPress MailChimp Plugin add on integrates a site\\u2019s signup with MailChimp and lets travel and tour operator websites to launch effective email campaigns.\\r\\n\\r\\nSend occasional newsletters to your subscribers informing them about your seasonal and special offers. Let them know about your new launches and all your events in which they might be interested. Such periodic and targeted email campaigns help you build a good rapport with the users and increase increasing sales. MailChimp is one of the best email tools that helps you send such emails to 2000 users for free. And that is why we created this plugin.\\r\\n\\r\\nTo launch your email campaign using this plugin follow here is a quick summary of steps:\\r\\n<ul>\\r\\n \\t<li>Create a MailChimp account, if you haven\'t one already - it\'s free for a start<\\/li>\\r\\n \\t<li>Install the WP Travel MailChimp WordPress plugin on your website - make sure you already have a WP Travel Plugin installed.<\\/li>\\r\\n \\t<li>Integrate the MailChimp WordPress plugin with your MailChimp Addon<\\/li>\\r\\n \\t<li>Style the opt-in forms, subscribe forms and signup forms and place them on the sections of your website where you think your users are likely to subscribe.<\\/li>\\r\\n \\t<li>Setup additional settings for users that book your tours or could contact you using forms on your contact us and other pages.<\\/li>\\r\\n<\\/ul>\\r\\n<strong>NOTE:<\\/strong>\\r\\n\\r\\nThis is NOT a standalone plugin. It works ONLY in conjunction with its parent plugin - WP Travel, the best tour operator plugin on WordPress. The WP Travel Plugin is made exclusively to serve travel and tour websites\\u2019 needs and requirements.\\r\\n\\r\\nHere are some cool features of this WP Travel MailChimp Plugin:\\r\\n\\r\\n<strong>1. Seamless Integration<\\/strong>\\r\\n\\r\\nThis add on can be configured to sync all your inquiries and booking emails to your MailChimp account. In your MailChimp account, you can create focused email listings that correspond to sign up forms. The MailChimp lists are an easy way for you to classify signups and interest groups to prepare customized email marketing templates each of these listings.\\r\\n\\r\\n<strong>2. Compliant with Anti Spam Requirements<\\/strong>\\r\\n\\r\\nTo comply with email marketing norms and making your email campaign compliant with anti-spam initiatives comes with the opt-in or opt-out feature. Enabling this feature will let you verify the validity of the email and also powers your user to confirm if they want to receive periodic newsletters from you or not.\\r\\n\\r\\n<strong>3. Sync MailChimp Email List to your Travel site<\\/strong>\\r\\n\\r\\nAnother robust feature of this plugin is the ability that it provides to the website owner to assign specific forms to specific MailChimp email campaign listings from their own website\\u2019s backend. Once connected with the MailChimp account, the plugin syncs all the email listings created in MailChimp.\",\n                \"excerpt\": \"\",\n                \"thumbnail\": \"https:\\/\\/wptravel.io\\/wp-content\\/uploads\\/edd\\/2019\\/03\\/mail-chimp-thumbnail.jpg\",\n                \"category\": [\n                    {\n                        \"term_id\": 2017,\n                        \"name\": \"Miscellaneous\",\n                        \"slug\": \"miscellaneous\",\n                        \"term_group\": 0,\n                        \"term_taxonomy_id\": 2017,\n                        \"taxonomy\": \"download_category\",\n                        \"description\": \"\",\n                        \"parent\": 0,\n                        \"count\": 5,\n                        \"filter\": \"raw\"\n                    }\n                ],\n                \"tags\": false\n            },\n            \"pricing\": {\n                \"amount\": \"15.99\"\n            }\n        },\n        {\n            \"info\": {\n                \"id\": 6673,\n                \"slug\": \"wp-travel-utilities\",\n                \"title\": \"WP Travel Utilities\",\n                \"create_date\": \"2018-05-21 04:02:21\",\n                \"modified_date\": \"2019-03-08 08:57:08\",\n                \"status\": \"publish\",\n                \"link\": \"http:\\/\\/wptravel.io\\/?post_type=download&p=6673\",\n                \"content\": \"WP Travel utilities is a bundle of basic features which enhances the WP travel plugin. The plugin basically addresses the minimal but important feature that is not available in the free version of WP Travel plugin. It lets you define your own custom trip code, enable\\/disable WP Travel \\\"Powered By Branding\\\" text or define your custom text. Likewise, it also has an option to send an email related to Trip Booking, Trip Payments and Trip Enquiry to your multiple recipients and more <a href=\\\"http:\\/\\/wptravel.io\\/downloads\\/wp-travel-utilities\\/#features\\\">features<\\/a>. WP Travel plugin must be installed and activated to use this addon. After you activate the plugin, a Utilities Option field will be added in the settings section of WP Travel plugin.\",\n                \"excerpt\": \"\",\n                \"thumbnail\": \"https:\\/\\/wptravel.io\\/wp-content\\/uploads\\/edd\\/2018\\/05\\/wp-travel-utilities-thumbnail.png\",\n                \"category\": false,\n                \"tags\": false\n            },\n            \"pricing\": {\n                \"amount\": \"22.99\"\n            }\n        },\n        {\n            \"info\": {\n                \"id\": 8351,\n                \"slug\": \"wp-travel-tour-extras\",\n                \"title\": \"WP Travel Tour Extras\",\n                \"create_date\": \"2018-10-30 07:51:33\",\n                \"modified_date\": \"2019-03-19 06:52:18\",\n                \"status\": \"publish\",\n                \"link\": \"http:\\/\\/wptravel.io\\/?post_type=download&p=8351\",\n                \"content\": \"<img class=\\\"size-full wp-image-12348 aligncenter\\\" src=\\\"http:\\/\\/wptravel.io\\/wp-content\\/uploads\\/edd\\/2019\\/03\\/ws-travel-tour-extras_2.jpg\\\" alt=\\\"\\\" width=\\\"1920\\\" height=\\\"800\\\" \\/>\\r\\n\\r\\nIf you are thinking of adding the additional services to your trips then you can go for WP Travel Tour Extras. It is an exciting plugin now available as an add-on for the WP Travel plugin. You can add any services like flight, vehicle service, insurance or any other custom you want. You can add paid or free service that user can select.\\u00a0 Additionally, you can add a gallery for the service, description and sale price.\\r\\n\\r\\nYou can download and use the plugin from the <a href=\\\"https:\\/\\/themepalace.com\\/downloads\\/wp-travel-tour-extras\\/\\\">Theme Place<\\/a> with our WP Travel plugin in one-click installation.\\r\\n\\r\\nIf you spot any issue then please post them directly in our official support forum.\\r\\n\\r\\n&nbsp;\\r\\n<p style=\\\"text-align: center;\\\">[wp_travel_site_get_purchase_button]<\\/p>\\r\\n&nbsp;\\r\\n<h2>Features of add-ons:<\\/h2>\\r\\n&nbsp;\\r\\n<h4>CREATE ADDITIONAL SERVICES FOR TRIPS:<\\/h4>\\r\\n<img class=\\\"size-full wp-image-12349 aligncenter\\\" src=\\\"http:\\/\\/wptravel.io\\/wp-content\\/uploads\\/edd\\/2019\\/03\\/easily-add-extra-products-services-to-a-trip.jpg\\\" alt=\\\"\\\" width=\\\"880\\\" height=\\\"330\\\" \\/>\\r\\n\\r\\nCreate additional services for trips. You can add any services like flight, vehicle service, insurance or any other custom you want. You can add paid or free service that user can select.\\u00a0\\u00a0Additionally you can add gallery for the service, description and sale price.\\r\\n<h4>SALE PRICES FOR EXTRA PRODUCT OR SERVICES:<\\/h4>\\r\\n<img class=\\\"size-full wp-image-12352 aligncenter\\\" src=\\\"http:\\/\\/wptravel.io\\/wp-content\\/uploads\\/edd\\/2019\\/03\\/sale-prices-for-extra-products-services.jpg\\\" alt=\\\"\\\" width=\\\"880\\\" height=\\\"330\\\" \\/>\\r\\n\\r\\nYou can specify the price of extra services and products that a trip packages offers.\\r\\n<h4>INTUITIVE AND EASY FRONT-END UI:<\\/h4>\\r\\n<img class=\\\"size-full wp-image-12353 aligncenter\\\" src=\\\"http:\\/\\/wptravel.io\\/wp-content\\/uploads\\/edd\\/2019\\/03\\/intuitive-and-easy-front-end-UI.jpg\\\" alt=\\\"\\\" width=\\\"880\\\" height=\\\"330\\\" \\/>\\r\\n\\r\\nWP Travel Tour Extras is designed to be intuitive and easy to use, while keeping your WordPress site healthy. The interface is made appealing, easy and efficient so that it does not get in between you and your work.\\r\\n<h4>EXTRAS GALLERY:<\\/h4>\\r\\n<img class=\\\"size-full wp-image-12350 aligncenter\\\" src=\\\"http:\\/\\/wptravel.io\\/wp-content\\/uploads\\/edd\\/2019\\/03\\/extras-gallery.jpg\\\" alt=\\\"\\\" width=\\\"880\\\" height=\\\"330\\\" \\/>\\r\\n\\r\\nYou can show off different images and stuffs related to the specific product, service or whatever in elegant gallery format.\\r\\n<h4>REGULAR PRICE AND SALE PRICE:<\\/h4>\\r\\n<img class=\\\"size-full wp-image-12355 aligncenter\\\" src=\\\"http:\\/\\/wptravel.io\\/wp-content\\/uploads\\/edd\\/2019\\/03\\/regular-price-and-sale-price.jpg\\\" alt=\\\"\\\" width=\\\"880\\\" height=\\\"330\\\" \\/>\\r\\n\\r\\nYou can input both regular price and sale price for the extra service or product that you offer along with the trips.\",\n                \"excerpt\": \"\",\n                \"thumbnail\": \"https:\\/\\/wptravel.io\\/wp-content\\/uploads\\/edd\\/2018\\/10\\/wp-travel-tour-extras-thumbnail-1.jpg\",\n                \"category\": [\n                    {\n                        \"term_id\": 2017,\n                        \"name\": \"Miscellaneous\",\n                        \"slug\": \"miscellaneous\",\n                        \"term_group\": 0,\n                        \"term_taxonomy_id\": 2017,\n                        \"taxonomy\": \"download_category\",\n                        \"description\": \"\",\n                        \"parent\": 0,\n                        \"count\": 5,\n                        \"filter\": \"raw\"\n                    }\n                ],\n                \"tags\": false\n            },\n            \"pricing\": {\n                \"amount\": \"15.99\"\n            }\n        },\n        {\n            \"info\": {\n                \"id\": 5353,\n                \"slug\": \"wp-travel-stripe-checkout\",\n                \"title\": \"WP Travel Stripe Checkout\",\n                \"create_date\": \"2018-02-28 10:04:21\",\n                \"modified_date\": \"2019-03-28 06:54:39\",\n                \"status\": \"publish\",\n                \"link\": \"http:\\/\\/wptravel.io\\/?post_type=download&p=5353\",\n                \"content\": \"<img class=\\\"alignright size-full wp-image-12711\\\" src=\\\"http:\\/\\/wptravel.io\\/wp-content\\/uploads\\/edd\\/2019\\/03\\/stripe-banner.jpg\\\" alt=\\\"\\\" width=\\\"1500\\\" height=\\\"700\\\" \\/>\\r\\n\\r\\n<span style=\\\"font-weight: 400;\\\">WP Travel Stripe WordPress Plugin add on is a payment plugin that helps you receive payments on WordPress travel site through Stripe. As one of the largest payment companies in the world, Stripe is a convenient way to accept online payments. It provides better user payment experience on every device including mobile, tablet and desktop. All the transactions are done on-site, and it allows you to provide one-time payment as well as recurring payment options for your customers. So, you don\\u2019t need to worry about losing a customer in an external page.<\\/span>\\r\\n\\r\\n<span style=\\\"font-weight: 400;\\\">Running an online travel business can be an uphill battle if you have not integrated online payment modules like Stripe that work with a wide range of credit cards. Creating a strategic plan, engineering the best site that satisfies your customer needs and delivering them with a wide range of options to pay for the tour and trip bookings, can be very costly for your programmer to custom code it. So, we created this simple but powerful Stripe payment plugin for your travel site. When coupled with its parent travel plugin, WP Travel, this addon will further boost the growth of your travel business.<\\/span>\\r\\n\\r\\n<span style=\\\"font-weight: 400;\\\">Stripe Checkout add-on is very easy to set up. You don\\u2019t need programming skills to integrate it on your site. Once you have merchant account on Stripe (which is also very easy), it requires very less time to integrate your website with your Stripe account. We have made the integration process very simple, saving your time with working with stripe php codes and all. It involves some drag and drops and some toggling with buttons to integrate. With this add-on, you can focus more on making better products and let it handle the payment part.<\\/span>\\r\\n\\r\\n<span style=\\\"font-weight: 400;\\\">\\u00a0<\\/span>\\r\\n\\r\\n<b>Why Stripe Checkout WordPress plugin?<\\/b>\\r\\n\\r\\n<span style=\\\"font-weight: 400;\\\">\\u00a0<\\/span>\\r\\n\\r\\n<span style=\\\"font-weight: 400;\\\">WP Travel Stripe Payment Plugin is renowned for its safety features and ease of use for both customers and merchants. Stripe payment is famous as \\u201cPayment form done right\\u201d because of its seamless transaction experience to the customer all around the world.<\\/span>\\r\\n\\r\\n<span style=\\\"font-weight: 400;\\\">As an owner of a travel business, you can<\\/span><a href=\\\"https:\\/\\/dashboard.stripe.com\\/register\\\"><span style=\\\"font-weight: 400;\\\"> set up a Stripe merchant account<\\/span><\\/a><span style=\\\"font-weight: 400;\\\"> in just a few minutes. It has no setup fees, no monthly fees, and no hidden costs. It accepts all major debit and credit cards across the world, giving your would-be customers a wide array of choices to make the payment through.<\\/span>\\r\\n\\r\\n<span style=\\\"font-weight: 400;\\\">Stripe Checkout is fully optimized for all sizes of mobile screens and the best site it works on your site \\u2013 without the user ever leaving it. The customer can pay instantly without being redirected away to payment gateway site. As such this provides you with the opportunity to upsell more products to these customers.<\\/span>\\r\\n\\r\\n<b>What do you need to install the WP Travel Stripe Payment plugin?<\\/b>\\r\\n\\r\\n<span style=\\\"font-weight: 400;\\\">\\u00a0<\\/span>\\r\\n\\r\\n<span style=\\\"font-weight: 400;\\\">Before installing the WP Travel Stripe Payment plugin on your site, you should create a Stripe merchant account. This is relevantly easy. In addition to that, you should install WP Travel plugin on the site as the Stripe payment plugin works ONLY with it. With these basics done, install the stripe payment plugin and follow onscreen instructions or i<\\/span><a href=\\\"http:\\/\\/wptravel.io\\/documentations\\/wp-travel-stripe-checkout\\/\\\"><span style=\\\"font-weight: 400;\\\">nstructions given here.<\\/span><\\/a>\\r\\n\\r\\n<b>NOTE:<\\/b>\\r\\n<ul>\\r\\n \\t<li style=\\\"font-weight: 400;\\\"><span style=\\\"font-weight: 400;\\\">The WP Travel Payment plugin only works if the WP Travel plugin is installed.<\\/span><\\/li>\\r\\n \\t<li style=\\\"font-weight: 400;\\\"><span style=\\\"font-weight: 400;\\\">WP Travel is a plugin exclusively made for travel and tour agency WordPress websites.<\\/span><\\/li>\\r\\n \\t<li style=\\\"font-weight: 400;\\\"><span style=\\\"font-weight: 400;\\\">Stripe works only pages with HTTPs connection.<\\/span><\\/li>\\r\\n<\\/ul>\\r\\n<span style=\\\"font-weight: 400;\\\">\\u00a0<\\/span>\\r\\n\\r\\n<b>WP Travel Stripe Payment Plugin Features:<\\/b><span style=\\\"font-weight: 400;\\\">\\u00a0<\\/span>\\r\\n\\r\\n<b>Frictionless Onsite Checkout:<\\/b>\\r\\n\\r\\n<span style=\\\"font-weight: 400;\\\">WP Travel Stripe Payment plugin add-on offers the ability to have single page checkout for your customers. Nothing is frustrating than going to multiple pages to pay. Users simply hate this, as we do. With this option, visitors can quickly click on the stripe payment button and make the payment without leaving your site. As such it helps to decrease the shopping cart abandonment rates and increase the volume of trip bookings.<\\/span>\\r\\n\\r\\n<b>Highly Secured <\\/b>\\r\\n\\r\\n<span style=\\\"font-weight: 400;\\\">This Stripe payment plugin uses the Stripe API that provides a highly secure environment for the users to make the transaction. It comes loaded with Stripe Radar, fraud protection tools along with other security features. It helps in detecting and preventing fraud along with counterfeit transactions. Stripe uses advanced machine learning infrastructure that allows it to identify shifting fraud patterns and control them constantly.<\\/span>\\r\\n\\r\\n<b>Wide range of debit and credit card options<\\/b>\\r\\n\\r\\n<span style=\\\"font-weight: 400;\\\">The Stripe Payment plugin allows your users to pay for your trips and tour bookings using Stripe account or their debit and credit cards. This add-on accepts most of the debit and credit card. You can easily prompt them to enter the credit card number. It provides real-time feedback. So your visitor can easily identify error while filling stripe forms.<\\/span>\\r\\n\\r\\n<b>Highly customizable settings<\\/b>\\r\\n\\r\\n<span style=\\\"font-weight: 400;\\\">The WP Travel Stripe Payment plugin is engineered to allow customization to checkout form and add custom fields. As such, no matter what your website\\u2019s design or color scheme is, you can adapt Stripe checkout forms to it. This helps to maintain consistent branding on your website. The UI toolkit provided by Stripe gives collective experience for the front end and design. You can easily access the setting page from your WordPress site.<\\/span>\\r\\n\\r\\n<b>Built-in mobile support (Responsive)<\\/b>\\r\\n\\r\\n<span style=\\\"font-weight: 400;\\\">Our Stripe Checkout WordPress plugin has built-in mobile support. It automatically adapts to mobile devices. This checkout lets your customers save their time by providing easy navigation in mobile devices. It adjusts to the different screen sizes of the mobile, tablet and desktop.<\\/span>\\r\\n\\r\\n<span style=\\\"font-weight: 400;\\\">Power your tour and travel agency website with the all-in-one solution, WP Travel, and boost your abilities to receive online payment through Stripe today. Download it now.<\\/span>\\r\\n\\r\\n<span style=\\\"font-weight: 400;\\\">\\u00a0<\\/span>\",\n                \"excerpt\": \"\",\n                \"thumbnail\": \"https:\\/\\/wptravel.io\\/wp-content\\/uploads\\/2018\\/05\\/stripe-checkout.png\",\n                \"category\": [\n                    {\n                        \"term_id\": 166,\n                        \"name\": \"Payment\",\n                        \"slug\": \"payment\",\n                        \"term_group\": 0,\n                        \"term_taxonomy_id\": 166,\n                        \"taxonomy\": \"download_category\",\n                        \"description\": \"\",\n                        \"parent\": 0,\n                        \"count\": 8,\n                        \"filter\": \"raw\"\n                    }\n                ],\n                \"tags\": false\n            },\n            \"pricing\": {\n                \"amount\": \"19.99\"\n            }\n        },\n        {\n            \"info\": {\n                \"id\": 5042,\n                \"slug\": \"wp-travel-paypal-express-checkout\",\n                \"title\": \"WP Travel PayPal Express Checkout\",\n                \"create_date\": \"2018-02-21 07:14:20\",\n                \"modified_date\": \"2019-03-28 06:52:26\",\n                \"status\": \"publish\",\n                \"link\": \"http:\\/\\/wptravel.io\\/?post_type=download&p=5042\",\n                \"content\": \"<img class=\\\"alignright size-full wp-image-12709\\\" src=\\\"http:\\/\\/wptravel.io\\/wp-content\\/uploads\\/edd\\/2019\\/03\\/paypal-banner.jpg\\\" alt=\\\"\\\" width=\\\"1500\\\" height=\\\"700\\\" \\/>\\r\\n\\r\\n<span style=\\\"font-weight: 400;\\\">Install the best PayPal Checkout WordPress plugin addon for WP Travel plugin on your travel and tour website and increase your sales. This PayPal Checkout plugin helps your users to book any trek and tour packages on your site and pay for it without going through loads of forms and signups. <\\/span>\\r\\n\\r\\n<span style=\\\"font-weight: 400;\\\">Powered by PayPal and integrated with WP Travel, the<\\/span><a href=\\\"http:\\/\\/wptravel.io\\/\\\"><span style=\\\"font-weight: 400;\\\"> best plugin for tour and travel websites<\\/span><\\/a><span style=\\\"font-weight: 400;\\\">, this add-on provides better user experience and secure environment for your website users to make a transaction. With increasing security issues on the internet to create an online purchase, PayPal\\u2019s express checkout plugin add on for WordPress provides an optimum on-site environment and helps in building trust with your brand. This additional trust dramatically increases their probability of booking a travel and tour packages online.<\\/span>\\r\\n\\r\\n<span style=\\\"font-weight: 400;\\\">If you are a developer who wants to integrate PayPal Express Checkout on your client\\u2019s travel agency site built on WordPress, then you have come to the right place. Instead of working for hours on studying the PayPal API integration documentation, programming and fixing bugs, buy and install this plugin and invest your time in other productive activities.<\\/span>\\r\\n\\r\\n<b>NOTE: <\\/b>\\r\\n\\r\\n<span style=\\\"font-weight: 400;\\\">The PayPal Checkout WordPress Plugin for WP Travel works ONLY with WP Travel plugin.<\\/span>\\r\\n\\r\\n<span style=\\\"font-weight: 400;\\\">The WP Travel plugin is FREE &amp; made for travel and tour websites ONLY.<\\/span>\\r\\n\\r\\n<b>Why should you have PayPal Express Checkout on your travel site? <\\/b>\\r\\n\\r\\n<b>Maximizing Sales:<\\/b>\\r\\n\\r\\n<span style=\\\"font-weight: 400;\\\">Many studies, including <\\/span><a href=\\\"https:\\/\\/www.braintreepayments.com\\/blog\\/a-new-study-shows-paypal-helps-improve-checkout-conversion\\/\\\"><span style=\\\"font-weight: 400;\\\">this one<\\/span><\\/a><span style=\\\"font-weight: 400;\\\">, have pointed that having PayPal on checkout helps increase checkout conversions significantly. PayPal Express Checkout eliminates one of the significant causes of checkout abandonment by giving buyers seamless experience and avoiding them to add your products in cart page. With a single click on PayPal button, buyers can provide their detail in a go, thereby speeding the checkout experience.\\u00a0<\\/span>\\r\\n\\r\\n<b>On-Site Checkout:<\\/b>\\r\\n\\r\\n<span style=\\\"font-weight: 400;\\\">On-Site checkout means single-page checkout. It guarantees that the user does not have to go through a lot of form fillups. When the user clicks on the payment option of PayPal Express at your checkout page, it redirects to a standard PayPal login form. Where they can finish the transactions swiftly.<\\/span>\\r\\n\\r\\n<b>UpSell Additional Products<\\/b>\\r\\n\\r\\n<span style=\\\"font-weight: 400;\\\">After finishing the payment, the customer is redirected to your page where they can engage in other activities.\\u00a0 This opens the possibilities to up-sell additional products along with reducing the risk of abandonment of shopping cart.<\\/span>\\r\\n\\r\\n<b>Highly Secured<\\/b>\\r\\n\\r\\n<span style=\\\"font-weight: 400;\\\">Our PayPal Express Checkout plugin provides a highly secure environment and customizable security options for a site owner to configure. Any information exchanged is secured and encrypted. Powered by the PayPal API, users sensitive information like credit card, billing address or bank number transmitted through secure channels. This way, user don\\u2019t have to worry about paying from your site. <\\/span>\\r\\n\\r\\n&nbsp;\\r\\n\\r\\n<b>Credit Card Options<\\/b>\\r\\n\\r\\n<span style=\\\"font-weight: 400;\\\">While the PayPal standard payment service does not allow users to sign out using their credit card, the PayPal Express Checkout provides it. With the Express Checkout, a user can make the payment with their credit card, without ever logging into their PayPal account.\\u00a0 This feature has proven to increase conversion rates as well as payment options at your travel site. As it can be your main payment options at all times.<\\/span>\\r\\n\\r\\n&nbsp;\\r\\n\\r\\n<b>Partial Payment <\\/b>\\r\\n\\r\\n<span style=\\\"font-weight: 400;\\\">This PayPal Express Checkout plugin provides the option of making a partial payment to your users. Under this option, your client can opt to pay for all the booking charges or to pay only a partial amount. This is an excellent feature for potential customers as it helps them to book the tour by paying partially.<\\/span>\\r\\n\\r\\n<span style=\\\"font-weight: 400;\\\">Running a travel agency business can be a daunting task, but we have made making a travel site and accepting international payments from the customer easy. Install our PayPal Express Checkout Plugin on your travel website today. <\\/span>\",\n                \"excerpt\": \"\",\n                \"thumbnail\": \"https:\\/\\/wptravel.io\\/wp-content\\/uploads\\/2018\\/05\\/paypal-checkout.png\",\n                \"category\": [\n                    {\n                        \"term_id\": 166,\n                        \"name\": \"Payment\",\n                        \"slug\": \"payment\",\n                        \"term_group\": 0,\n                        \"term_taxonomy_id\": 166,\n                        \"taxonomy\": \"download_category\",\n                        \"description\": \"\",\n                        \"parent\": 0,\n                        \"count\": 8,\n                        \"filter\": \"raw\"\n                    }\n                ],\n                \"tags\": [\n                    {\n                        \"term_id\": 168,\n                        \"name\": \"PayPal\",\n                        \"slug\": \"paypal\",\n                        \"term_group\": 0,\n                        \"term_taxonomy_id\": 168,\n                        \"taxonomy\": \"download_tag\",\n                        \"description\": \"\",\n                        \"parent\": 0,\n                        \"count\": 1,\n                        \"filter\": \"raw\"\n                    }\n                ]\n            },\n            \"pricing\": {\n                \"amount\": \"19.99\"\n            }\n        },\n        {\n            \"info\": {\n                \"id\": 12008,\n                \"slug\": \"wp-travel-custom-filter\",\n                \"title\": \"WP Travel Custom Filter\",\n                \"create_date\": \"2019-03-25 11:20:43\",\n                \"modified_date\": \"2019-03-29 06:49:23\",\n                \"status\": \"publish\",\n                \"link\": \"https:\\/\\/wptravel.io\\/?post_type=download&p=12008\",\n                \"content\": \"<img class=\\\"size-full wp-image-12582 aligncenter\\\" src=\\\"http:\\/\\/wptravel.io\\/wp-content\\/uploads\\/edd\\/2019\\/03\\/custom-filter.png\\\" alt=\\\"\\\" width=\\\"1497\\\" height=\\\"614\\\" \\/>\\r\\n\\r\\nCustom Filter is easy\\u00a0 way to provide your visitors with filtering for your post types. With this you get a complete solution for adding filtering based on custom taxonomy.\\r\\n\\r\\nWith the added filters, user can categorize the trips more conveniently with the filter label that they want.\\r\\n\\r\\n&nbsp;\\r\\n<h2>Features of add-ons:<\\/h2>\\r\\n<h4>Flexibility in adding multiple filters:<\\/h4>\\r\\nWith a single click, user can add the filters which makes the grouping of the created trips super easy and fast!\\r\\n<h4>Easy Classification of trips through clean categorization:<\\/h4>\\r\\nWith the added filters, user can categorize the trips more conveniently with the filter label that they want.\\r\\n<h4>User Friendly experience to enhance site through additional filters:<\\/h4>\\r\\n\\u2018Single Click\\u2019 and the filter is there with full functionality of the manually created filters.\\r\\nCollapse\",\n                \"excerpt\": \"\",\n                \"thumbnail\": false,\n                \"category\": [\n                    {\n                        \"term_id\": 2017,\n                        \"name\": \"Miscellaneous\",\n                        \"slug\": \"miscellaneous\",\n                        \"term_group\": 0,\n                        \"term_taxonomy_id\": 2017,\n                        \"taxonomy\": \"download_category\",\n                        \"description\": \"\",\n                        \"parent\": 0,\n                        \"count\": 5,\n                        \"filter\": \"raw\"\n                    }\n                ],\n                \"tags\": false\n            },\n            \"pricing\": {\n                \"amount\": \"19.00\"\n            }\n        },\n        {\n            \"info\": {\n                \"id\": 11488,\n                \"slug\": \"wp-travel-paystack-checkout\",\n                \"title\": \"WP Travel Paystack Checkout\",\n                \"create_date\": \"2019-03-08 07:56:36\",\n                \"modified_date\": \"2019-03-28 06:49:22\",\n                \"status\": \"publish\",\n                \"link\": \"https:\\/\\/wptravel.io\\/?post_type=download&p=11488\",\n                \"content\": \"<img class=\\\"alignright wp-image-12013 size-full\\\" src=\\\"http:\\/\\/wptravel.io\\/wp-content\\/uploads\\/edd\\/2019\\/03\\/banner.png\\\" alt=\\\"WP Travel Paystack Payment Plugin\\\" width=\\\"2910\\\" height=\\\"1162\\\" \\/>\\r\\n\\r\\nWP Travel Paystack Checkout is the fastest, simplest and safest Paystack WordPress plugin add-on for travel and tour websites. It is specially built to help travel and tour websites in Africa to accept online reservations and bookings from users across the world and receive online payments in their local Naira currency.\\r\\n\\r\\nThough Paystack provides extensive documentation on integrating its payment gateway, integrating it takes hours of work for developers. Our team worked together and came up with this little yet powerful Paystack plugin for WordPress to put an end to this repetitive task (and sometimes monotonous).\\u00a0 It integrates Paystack payment gateway to your travel website like a charm.\\r\\n\\r\\nAs part of our mission to make the life of WordPress developers and travel and tour sites entrepreneurs easy, we introduced this payment plugin. It offers a safe and convenient payment experience to local and international customers and site owners. With the plugin, travel operators will be able to accept an online reservation from their domestic and international clients, without having to bother about currency exchange or dollar accounts. All the site owners will need to have is a Paystack account and its integration details.\\r\\n<h2>What do you need to install?<strong>\\r\\n<\\/strong><\\/h2>\\r\\nApart from the Paystack account details, the other thing you will need is to install WP Travel plugin on your site, enable it and then install this addon. Once you install and set up all your account details in the backend of the WP Travel Paystack Payment, you are all set to local and international payments in Naira.\\r\\n\\r\\nThis simple and powerful plugin offers you the flexibility to configure transaction settings in the backend to tailor the user experience on checkout and assist you in your conversion rate optimization game. So up your game with Paystack payment plugin now and crush your competitors.\\r\\n\\r\\n&nbsp;\\r\\n<p style=\\\"text-align: center;\\\">[wp_travel_site_get_purchase_button]<\\/p>\\r\\n\\r\\n<h2>Points to be noted:<\\/h2>\\r\\n<ul>\\r\\n \\t<li>This payment gateway add-ons work only with Nigerian currency (Naira).<\\/li>\\r\\n \\t<li>This payment add-ons only work in conjunction with our parent plugin WP Travel plugin installed; it does not work as a stand-alone plugin. You can download <a href=\\\"http:\\/\\/wptravel.io\\\">WP Travel plugin<\\/a> for free.<\\/li>\\r\\n<\\/ul>\\r\\n<h2>Features of add-ons:<\\/h2>\\r\\n<h3>Highly Secure<strong>:<\\/strong><\\/h3>\\r\\n<img class=\\\"alignright size-full wp-image-12706\\\" src=\\\"http:\\/\\/wptravel.io\\/wp-content\\/uploads\\/edd\\/2019\\/03\\/secure-payment-paystack.jpg\\\" alt=\\\"\\\" width=\\\"1652\\\" height=\\\"661\\\" \\/>\\r\\n\\r\\n<img class=\\\"aligncenter wp-image-11797 size-full\\\" src=\\\"http:\\/\\/wptravelsite.local\\/wp-content\\/uploads\\/2019\\/03\\/secure-payment.jpg\\\" alt=\\\"\\\" width=\\\"1652\\\" height=\\\"661\\\" \\/>\\r\\n\\r\\nOur Paystack WordPress plugin provides a highly secure environment and customizable security options for site owners to configure. Powered by the secure Paystack API, this plugin comes with in-built automated, and manual fraud system saves your customers from the fraudulent transaction and associated chargeback claims.\\r\\n<h3>Multiple Payment Options<\\/h3>\\r\\n<img class=\\\"alignright size-full wp-image-12014\\\" src=\\\"http:\\/\\/wptravel.io\\/wp-content\\/uploads\\/edd\\/2019\\/03\\/E-banking-payment.jpg\\\" alt=\\\"\\\" width=\\\"1652\\\" height=\\\"661\\\" \\/>\\r\\n\\r\\nThis add-on provides multiple choices to make the payment including MasterCard, Visa card and direct bank transaction. It lets your customers pay you however they want. It automatically routes payments through the most optimal channels, ensuring the highest transaction success rates in the market. With this add-on, you can accept payment from international customers, wherever they are in the world and of course your local customers too in Nigeria!\\r\\n<h3>Single Page Checkout<\\/h3>\\r\\n&nbsp;\\r\\n\\r\\nThe Paystack add-on supports one-page-checkout function. As such it helps you make your checkout process seamless for your users and decrease cart abandonment rates. This payment plugin facilitates quick authentication of the transaction for the user without ever needing them to leave the checkout page. After paying customer is returned to your site. Enable the single page checkout experience for Paystack to provide customers with a better experience on your site.\\r\\n<h3>Why Paystack?<\\/h3>\\r\\nThe WP Travel Paystack Checkout is powered by <a href=\\\"https:\\/\\/paystack.com\\/\\\">Paystack<\\/a>, a well-trusted payment gateway. Paystack has one of the best transaction success rates in industry history. It helps millions of business in Nigeria to receive payment in local currencies from anywhere in the world. With transparent pricing and commission rates, it is must-have online payment gateway on your travel site. With this add-on customer easily book your tour and trekking packages using MasterCard, Visa, and Bank Account.\\r\\n\\r\\nUp your game, today, use the smartest Paystack payment plugin on WordPress for travel and tour sites and save loads of your programming hours.\",\n                \"excerpt\": \"\",\n                \"thumbnail\": \"https:\\/\\/wptravel.io\\/wp-content\\/uploads\\/edd\\/2019\\/03\\/thumbnail-with-header.png\",\n                \"category\": [\n                    {\n                        \"term_id\": 166,\n                        \"name\": \"Payment\",\n                        \"slug\": \"payment\",\n                        \"term_group\": 0,\n                        \"term_taxonomy_id\": 166,\n                        \"taxonomy\": \"download_category\",\n                        \"description\": \"\",\n                        \"parent\": 0,\n                        \"count\": 8,\n                        \"filter\": \"raw\"\n                    }\n                ],\n                \"tags\": false\n            },\n            \"pricing\": {\n                \"amount\": \"19.00\"\n            }\n        },\n        {\n            \"info\": {\n                \"id\": 11475,\n                \"slug\": \"wp-travel-partial-payment\",\n                \"title\": \"WP Travel Partial Payment\",\n                \"create_date\": \"2019-03-06 10:33:50\",\n                \"modified_date\": \"2019-03-10 03:03:20\",\n                \"status\": \"publish\",\n                \"link\": \"https:\\/\\/wptravel.io\\/?post_type=download&p=11475\",\n                \"content\": \"Customers might make a partial payment initially because of the uncertainty, insecurities or simply they just don\'t have enough to pay in full at a time. Now the question is \\\"How to make the remaining payment ?\\\".\\r\\n\\r\\nSo, we are very excited to announce the release of our much-awaited addon \\\"WP Travel Partial Payment\\\" which will let go off all our worries of finding the easy way to make the payment of the remaining amount.\\r\\n\\r\\nWP Travel Partial payment provides better control over how you collect payments by allowing your customers to make payments of remaining parts via the payment addon that they prefer.\",\n                \"excerpt\": \"\",\n                \"thumbnail\": \"https:\\/\\/wptravel.io\\/wp-content\\/uploads\\/edd\\/2019\\/03\\/partial_payment_thumbnail.jpg\",\n                \"category\": [\n                    {\n                        \"term_id\": 166,\n                        \"name\": \"Payment\",\n                        \"slug\": \"payment\",\n                        \"term_group\": 0,\n                        \"term_taxonomy_id\": 166,\n                        \"taxonomy\": \"download_category\",\n                        \"description\": \"\",\n                        \"parent\": 0,\n                        \"count\": 8,\n                        \"filter\": \"raw\"\n                    }\n                ],\n                \"tags\": false\n            },\n            \"pricing\": {\n                \"amount\": \"19.00\"\n            }\n        },\n        {\n            \"info\": {\n                \"id\": 9263,\n                \"slug\": \"wp-travel-khalti-checkout\",\n                \"title\": \"WP Travel Khalti Checkout\",\n                \"create_date\": \"2019-02-27 05:39:57\",\n                \"modified_date\": \"2019-03-28 06:42:09\",\n                \"status\": \"publish\",\n                \"link\": \"http:\\/\\/wptravel.io\\/?post_type=download&p=9263\",\n                \"content\": \"<img class=\\\"alignright size-full wp-image-12699\\\" src=\\\"http:\\/\\/wptravel.io\\/wp-content\\/uploads\\/edd\\/2019\\/03\\/wp-travel-khalti-checkout-banner.jpg\\\" alt=\\\"\\\" width=\\\"1920\\\" height=\\\"800\\\" \\/>\\r\\n\\r\\n<span style=\\\"font-weight: 400;\\\">WP Travel Khalti Payment plugin is made for Nepali travel and tour websites built on WordPress to accept local payments in Nepali rupees. All transactions are done on a single page checkout. The process is instant, secure and hassle-free. It gives multiple payment options which include debit cards of various Nepali banks, Khalti wallet, and e-banking payment.<\\/span>\\r\\n\\r\\n<span style=\\\"font-weight: 400;\\\">Nepal has always been one of the best tourist destinations for both foreign and local tourists. With the globalization of digital platform, people are also looking for comfortable and secure online payment gateway in Nepal. Online travel agencies and websites are expected to have their payment options for local users. So, the travel operator who has their site powered by WordPress has an excellent opportunity to convert a local visitor into paying customer by integrating our add-on.<\\/span>\\r\\n\\r\\n<b>Why Khalti Checkout?<\\/b>\\r\\n\\r\\n<span style=\\\"font-weight: 400;\\\">Our Khalti checkout plugin is powered by the Khalti payment gateway, one of the most widely used online wallets in Nepal. It is specially designed for Nepali currency. So, travel agencies can boost their ability to take bookings and payments from domestic tourists by providing the standard mode of payment for all Nepali customers. Khalti is associated with numbers of Banks. Therefore, loading the funds from a bank account using e-banks or mobile banking is comfortable and convenient for your website users to pay for the bookings.<\\/span>\\r\\n\\r\\n<span style=\\\"font-weight: 400;\\\">WP Travel, as one of the <\\/span><a href=\\\"http:\\/\\/wptravel.io\\/\\\"><span style=\\\"font-weight: 400;\\\">best WordPress plugin for travel and tour websites<\\/span><\\/a><span style=\\\"font-weight: 400;\\\">, powers many travel and tour websites in Nepal and across the globe. With the addition of WP Travel Khalti payment add-on to WP Travel plugin, now your Nepali clients can seamlessly pay for their travels and tours online through their Khalti account. This add-on is very easy to set up and can be integrated even if you are not well versed in coding and programming. With this add-on, you can focus more on your products and let the plugin handle the payment part.<\\/span>\\r\\n\\r\\n<b>Points to be noted:<\\/b>\\r\\n<ul>\\r\\n \\t<li style=\\\"font-weight: 400;\\\"><span style=\\\"font-weight: 400;\\\">This add-on works only in Nepal and with the Nepalese currency.<\\/span><\\/li>\\r\\n \\t<li style=\\\"font-weight: 400;\\\"><span style=\\\"font-weight: 400;\\\">This payment add on works on WordPress site and ONLY with <\\/span><a href=\\\"http:\\/\\/wptravel.io\\/\\\"><span style=\\\"font-weight: 400;\\\">WP Travel plugin.<\\/span><\\/a><span style=\\\"font-weight: 400;\\\">\\u00a0<\\/span><\\/li>\\r\\n<\\/ul>\\r\\n<b>Secure Payment Gateway:<\\/b>\\r\\n\\r\\n<img class=\\\"alignright size-full wp-image-12700\\\" src=\\\"http:\\/\\/wptravel.io\\/wp-content\\/uploads\\/edd\\/2019\\/03\\/secure-payment-gateway-1-1.jpg\\\" alt=\\\"\\\" width=\\\"880\\\" height=\\\"330\\\" \\/>\\r\\n\\r\\n<span style=\\\"font-weight: 400;\\\">WP Travel Khalti payment provides a highly secure environment with robust security options. All connections to Khalti through the website are encrypted. So, all of the transactions and personal card details are always safe and secure. They are not stored on the host website as the transaction is carried out using the Khalti Payment gateway.<\\/span>\\r\\n\\r\\n<b>Multiple payment options:<\\/b>\\r\\n\\r\\n<img class=\\\"alignright size-full wp-image-12701\\\" src=\\\"http:\\/\\/wptravel.io\\/wp-content\\/uploads\\/edd\\/2019\\/03\\/debit-card-wallet-and-e-banking-payment-1.jpg\\\" alt=\\\"\\\" width=\\\"880\\\" height=\\\"330\\\" \\/>\\r\\n\\r\\n<span style=\\\"font-weight: 400;\\\">The payment method in this add-on is highly flexible and efficient. The users can use their Debit (ATM) card as well as e-banking system to pay for their bookings. Also, the customer load funds from a bank account into their Khalti digital wallet and then pay from it for the tour and trekking packages.<\\/span>\\r\\n\\r\\n<b>On-Site Checkout:<\\/b>\\r\\n\\r\\n<img class=\\\"alignright size-full wp-image-12702\\\" src=\\\"http:\\/\\/wptravel.io\\/wp-content\\/uploads\\/edd\\/2019\\/03\\/seamless-and-on-site-checkout-1.jpg\\\" alt=\\\"\\\" width=\\\"880\\\" height=\\\"330\\\" \\/>\\r\\n\\r\\n<span style=\\\"font-weight: 400;\\\">This add-on provides a single page checkout facility enabling your customers to pay you without ever leaving your site. With the single click, the user can fill checkout form on-site. After finishing the transaction, the customer is left on your site which gives further opportunity to up-sell more products.<\\/span>\\r\\n\\r\\n<b>Highly Customizable Settings:<\\/b>\\r\\n\\r\\n<img class=\\\"alignright size-full wp-image-12703\\\" src=\\\"http:\\/\\/wptravel.io\\/wp-content\\/uploads\\/edd\\/2019\\/03\\/customizable-settings-1.jpg\\\" alt=\\\"\\\" width=\\\"880\\\" height=\\\"330\\\" \\/>\\r\\n\\r\\n<span style=\\\"font-weight: 400;\\\">This add-on provides highly customizable settings. It enables you to customize or make changes to checkout form according to the specific needs by configuring layout and system functionality. It allows you to show consistent branding by creating a custom layout concerning your site.<\\/span>\\r\\n\\r\\n<span style=\\\"font-weight: 400;\\\">Up your game today by installing WP Travel Khalti Checkout on your travel site and open the opportunity for your Nepali customers to pay you online using their Khalti digital wallet.<\\/span>\",\n                \"excerpt\": \"\",\n                \"thumbnail\": \"https:\\/\\/wptravel.io\\/wp-content\\/uploads\\/2019\\/02\\/wp-travel-khalti-checkout-thumbnail.jpg\",\n                \"category\": [\n                    {\n                        \"term_id\": 166,\n                        \"name\": \"Payment\",\n                        \"slug\": \"payment\",\n                        \"term_group\": 0,\n                        \"term_taxonomy_id\": 166,\n                        \"taxonomy\": \"download_category\",\n                        \"description\": \"\",\n                        \"parent\": 0,\n                        \"count\": 8,\n                        \"filter\": \"raw\"\n                    }\n                ],\n                \"tags\": false\n            },\n            \"pricing\": {\n                \"amount\": \"19.99\"\n            }\n        },\n        {\n            \"info\": {\n                \"id\": 10243,\n                \"slug\": \"wp-travel-field-editor\",\n                \"title\": \"WP Travel Field Editor\",\n                \"create_date\": \"2019-02-06 10:11:53\",\n                \"modified_date\": \"2019-03-08 09:57:18\",\n                \"status\": \"publish\",\n                \"link\": \"http:\\/\\/wptravel.io\\/?post_type=download&p=10243\",\n                \"content\": \"If you are wondering how to add a new fields in the forms of the WP Travel plugin then you are at right place. The WP Travel Field Editor provides an interface to add, edit and remove fields that are displayed in Trip Enquiry fields, Traveler info fields, and Billing fields.\\r\\n\\r\\nFields can be added, edited and removed from the billing and traveler info and trip\\u00a0enquiry form sections.\\r\\n\\r\\nNote:\\u00a0This plugin requires WP Travel plugin to be installed, activated.\",\n                \"excerpt\": \"\",\n                \"thumbnail\": \"https:\\/\\/wptravel.io\\/wp-content\\/uploads\\/edd\\/2019\\/02\\/wp-travel-field-editor-logo.png\",\n                \"category\": [\n                    {\n                        \"term_id\": 2018,\n                        \"name\": \"Forms\",\n                        \"slug\": \"forms\",\n                        \"term_group\": 0,\n                        \"term_taxonomy_id\": 2018,\n                        \"taxonomy\": \"download_category\",\n                        \"description\": \"\",\n                        \"parent\": 0,\n                        \"count\": 1,\n                        \"filter\": \"raw\"\n                    },\n                    {\n                        \"term_id\": 2017,\n                        \"name\": \"Miscellaneous\",\n                        \"slug\": \"miscellaneous\",\n                        \"term_group\": 0,\n                        \"term_taxonomy_id\": 2017,\n                        \"taxonomy\": \"download_category\",\n                        \"description\": \"\",\n                        \"parent\": 0,\n                        \"count\": 5,\n                        \"filter\": \"raw\"\n                    }\n                ],\n                \"tags\": false\n            },\n            \"pricing\": {\n                \"amount\": \"15.99\"\n            }\n        }\n    ],\n    \"request_speed\": 0.0072100162506103515625\n}', 'yes'),
(2849, '_site_transient__transient_wt_booking_count_360', '0', 'no'),
(3088, 'itinerary_types_children', 'a:0:{}', 'yes'),
(3112, 'activity_children', 'a:0:{}', 'yes'),
(3252, 'travel_locations_children', 'a:2:{i:120;a:1:{i:0;i:123;}i:123;a:1:{i:0;i:124;}}', 'yes'),
(3690, 'price_children', 'a:0:{}', 'yes'),
(3721, 'tourhotelname_children', 'a:0:{}', 'yes'),
(3731, 'facilities_children', 'a:0:{}', 'yes'),
(3738, 'departuretime_children', 'a:0:{}', 'yes'),
(4929, 'hotelfacilities_children', 'a:0:{}', 'yes'),
(5291, 'hotelrating_children', 'a:0:{}', 'yes'),
(6105, 'mphb_registered_attributes', 'a:0:{}', 'yes'),
(6106, 'widget_mphb_rooms_widget', 'a:1:{s:12:\"_multiwidget\";i:1;}', 'yes'),
(6107, 'widget_mphb_search_availability_widget', 'a:1:{s:12:\"_multiwidget\";i:1;}', 'yes'),
(6124, 'mphb_db_version', '3.2.0', 'yes'),
(6125, 'mphb_max_stay_length', 'a:1:{i:0;a:3:{s:15:\"max_stay_length\";i:15;s:13:\"room_type_ids\";a:1:{i:0;i:0;}s:10:\"season_ids\";a:1:{i:0;i:0;}}}', 'no'),
(6128, 'mphb_email_hotel_admin_email', 'milon@gmail.com', 'yes'),
(6129, 'mphb_email_from_email', 'test@gmail.com', 'yes'),
(6161, 'mphb_room_type_facility_children', 'a:0:{}', 'yes'),
(6164, 'mphb_search_results_page', '382', 'yes'),
(6165, 'mphb_checkout_page', '385', 'yes'),
(6166, 'mphb_booking_confirmation_page', '386', 'yes'),
(6167, 'mphb_user_cancel_redirect_page', '387', 'yes');
INSERT INTO `wp_options` (`option_id`, `option_name`, `option_value`, `autoload`) VALUES
(6168, 'mphb_payment_success_page', '388', 'yes'),
(6169, 'mphb_payment_failed_page', '389', 'yes'),
(6170, 'mphb_wizard_passed', '1', 'yes'),
(6256, 'mphb_terms_and_conditions_page', '382', 'yes'),
(6257, 'mphb_confirmation_mode', 'payment', 'yes'),
(6258, 'mphb_user_approval_time', '20', 'yes'),
(6259, 'mphb_require_country', '1', 'yes'),
(6260, 'mphb_require_full_address', '0', 'yes'),
(6261, 'mphb_default_country', 'BD', 'yes'),
(6262, 'mphb_unfold_price_breakdown', '1', 'yes'),
(6263, 'mphb_user_can_cancel_booking', '1', 'yes'),
(6264, 'mphb_search_max_adults', '30', 'yes'),
(6265, 'mphb_search_max_children', '10', 'yes'),
(6266, 'mphb_children_age', '3', 'yes'),
(6267, 'mphb_direct_booking', '0', 'yes'),
(6268, 'mphb_guest_management', 'allow-all', 'yes'),
(6269, 'mphb_hide_guests_on_search', '0', 'yes'),
(6270, 'mphb_square_unit', 'm2', 'yes'),
(6271, 'mphb_currency_symbol', 'USD', 'yes'),
(6272, 'mphb_currency_position', 'before', 'yes'),
(6273, 'mphb_datepicker_date_format', 'd/m/Y', 'yes'),
(6274, 'mphb_check_out_time', '10:00', 'yes'),
(6275, 'mphb_check_in_time', '11:00', 'yes'),
(6276, 'mphb_bed_types', 'a:0:{}', 'yes'),
(6277, 'mphb_average_price_period', '7', 'yes'),
(6278, 'mphb_enable_recommendation', '1', 'yes'),
(6279, 'mphb_enable_coupons', '0', 'yes'),
(6280, 'mphb_template_mode', 'theme', 'yes'),
(6281, 'mphb_checkout_text', '<p><strong>Lorem Ipsum</strong> is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry\'s standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book.</p>', 'yes'),
(6282, 'mphb_booking_disabled', '0', 'yes'),
(6283, 'mphb_disabled_booking_text', '<p><strong>Lorem Ipsum</strong> is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry\'s standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book.</p>', 'yes'),
(6284, 'mphb_single_room_type_gallery_use_magnific', '1', 'yes'),
(6285, 'mphb_datepicker_theme', '', 'yes'),
(6286, 'mphb_use_block_editor_for_room_types', '1', 'yes'),
(6287, 'mphb_use_block_editor_for_services', '1', 'yes'),
(6298, 'mphb_email_from_name', 'test', 'yes'),
(6299, 'mphb_email_logo', 'nh', 'yes'),
(6300, 'mphb_email_footer_text', '<p><a href=\"http://localhost/project\">projct new development</a></p>', 'yes'),
(6301, 'mphb_email_reserved_room_details', '<h4>Accommodation #%room_key%</h4>\r\n<p>Adults: %adults%<br />Children: %children%<br />Accommodation: <a href=\"%room_type_link%\">%room_type_title%</a><br />Accommodation Rate: %room_rate_title%<br />%room_rate_description% <br />Bed Type: %room_type_bed_type%</p>\r\n<h4>Additional Services</h4>\r\n<p>%services% </p>', 'yes'),
(6302, 'mphb_email_base_color', '#557da1', 'yes'),
(6303, 'mphb_email_bg_color', '#f5f5f5', 'yes'),
(6304, 'mphb_email_body_bg_color', '#fdfdfd', 'yes'),
(6305, 'mphb_email_body_text_color', '#505050', 'yes'),
(7028, '_mphb_wp_session_dc1847569bb318e8ca444217ffc1b0df', 'a:1:{s:22:\"mphb_search_parameters\";s:151:\"a:4:{s:11:\"mphb_adults\";s:1:\"1\";s:13:\"mphb_children\";s:1:\"0\";s:18:\"mphb_check_in_date\";s:10:\"2019-04-03\";s:19:\"mphb_check_out_date\";s:10:\"2019-04-17\";}\";}', 'no'),
(7055, '_mphb_wp_session_expires_dc1847569bb318e8ca444217ffc1b0df', '1554195892', 'no'),
(7075, 'tp_hotel_booking_single_purchase', '1', 'yes'),
(7076, 'tp_hotel_booking_currency', 'USD', 'yes'),
(7077, 'tp_hotel_booking_price_currency_position', 'left', 'yes'),
(7078, 'tp_hotel_booking_price_thousands_separator', ',', 'yes'),
(7079, 'tp_hotel_booking_price_decimals_separator', '.', 'yes'),
(7080, 'tp_hotel_booking_price_number_of_decimal', '1', 'yes'),
(7081, 'tp_hotel_booking_minimum_booking_day', '1', 'yes'),
(7082, 'tp_hotel_booking_tax', '10', 'yes'),
(7083, 'tp_hotel_booking_price_including_tax', '1', 'yes'),
(7084, 'tp_hotel_booking_price_display', 'min', 'yes'),
(7085, 'tp_hotel_booking_advance_payment', '50', 'yes'),
(7086, 'tp_hotel_booking_hotel_name', 'Hanoi Daewoo Hotel', 'yes'),
(7087, 'tp_hotel_booking_hotel_address', 'Ha Noi', 'yes'),
(7088, 'tp_hotel_booking_hotel_city', 'Ha Noi', 'yes'),
(7089, 'tp_hotel_booking_hotel_state', 'Hanoi Daewoo Hotel', 'yes'),
(7090, 'tp_hotel_booking_hotel_country', 'Vietnam', 'yes'),
(7091, 'tp_hotel_booking_hotel_zip_code', '10000', 'yes'),
(7092, 'tp_hotel_booking_hotel_phone_number', '', 'yes'),
(7093, 'tp_hotel_booking_hotel_fax_number', '', 'yes'),
(7094, 'tp_hotel_booking_hotel_email_address', '', 'yes'),
(7095, 'tp_hotel_booking_email_general_from_name', 'projct new development', 'yes'),
(7096, 'tp_hotel_booking_email_general_from_email', 'admin@gmail.com', 'yes'),
(7097, 'tp_hotel_booking_email_general_subject', 'Reservation', 'yes'),
(7098, 'tp_hotel_booking_cancel_payment', '12', 'yes'),
(7099, 'tp_hotel_booking_guest_checkout', '1', 'yes'),
(7100, 'tp_hotel_booking_catalog_number_column', '4', 'yes'),
(7101, 'tp_hotel_booking_posts_per_page', '8', 'yes'),
(7102, 'tp_hotel_booking_catalog_image', 'a:2:{s:5:\"width\";i:270;s:6:\"height\";i:270;}', 'yes'),
(7103, 'tp_hotel_booking_catalog_display_rating', '1', 'yes'),
(7104, 'tp_hotel_booking_room_image_gallery', 'a:2:{s:5:\"width\";i:270;s:6:\"height\";i:270;}', 'yes'),
(7105, 'tp_hotel_booking_room_thumbnail', 'a:2:{s:5:\"width\";i:150;s:6:\"height\";i:150;}', 'yes'),
(7106, 'tp_hotel_booking_display_pricing_plans', '1', 'yes'),
(7107, 'tp_hotel_booking_enable_review_rating', '1', 'yes'),
(7108, 'tp_hotel_booking_review_rating_required', '1', 'yes'),
(7109, 'tp_hotel_booking_enable_gallery_lightbox', '1', 'yes'),
(7110, 'hotel_booking_version', '1.9.8.7', 'yes'),
(7114, 'widget_hb_widget_search', 'a:1:{s:12:\"_multiwidget\";i:1;}', 'yes'),
(7115, 'widget_hb_widget_carousel', 'a:1:{s:12:\"_multiwidget\";i:1;}', 'yes'),
(7116, 'widget_hb_widget_best_reviews', 'a:1:{s:12:\"_multiwidget\";i:1;}', 'yes'),
(7117, 'widget_hb_widget_lastest_reviews', 'a:1:{s:12:\"_multiwidget\";i:1;}', 'yes'),
(7118, 'widget_hb_widget_cart', 'a:1:{s:12:\"_multiwidget\";i:1;}', 'yes'),
(7122, 'hotel_booking_rooms_page_id', '400', 'yes'),
(7123, 'tp_hotel_booking_rooms_page_id', '400', 'yes'),
(7124, 'hotel_booking_cart_page_id', '401', 'yes'),
(7125, 'tp_hotel_booking_cart_page_id', '401', 'yes'),
(7126, 'hotel_booking_checkout_page_id', '402', 'yes'),
(7127, 'tp_hotel_booking_checkout_page_id', '402', 'yes'),
(7128, 'hotel_booking_search_page_id', '403', 'yes'),
(7129, 'tp_hotel_booking_search_page_id', '403', 'yes'),
(7130, 'hotel_booking_account_page_id', '404', 'yes'),
(7131, 'tp_hotel_booking_account_page_id', '404', 'yes'),
(7132, 'hotel_booking_terms_page_id', '405', 'yes'),
(7133, 'tp_hotel_booking_terms_page_id', '405', 'yes'),
(7134, 'hotel_booking_thankyou_page_id', '406', 'yes'),
(7135, 'tp_hotel_booking_thankyou_page_id', '406', 'yes'),
(7390, '_mphb_wp_session_expires_53ae0c29b9f277521dce04b404cda5ee', '1554265342', 'no'),
(7449, 'mphb_room_type_category_children', 'a:0:{}', 'yes'),
(7545, '_mphb_wp_session_53ae0c29b9f277521dce04b404cda5ee', 'a:1:{s:22:\"mphb_search_parameters\";s:151:\"a:4:{s:11:\"mphb_adults\";s:1:\"2\";s:13:\"mphb_children\";s:1:\"3\";s:18:\"mphb_check_in_date\";s:10:\"2019-04-03\";s:19:\"mphb_check_out_date\";s:10:\"2019-04-04\";}\";}', 'no'),
(7594, 'tp_hotel_booking_custom_process', '1', 'yes'),
(7622, 'hb_room_type_children', 'a:0:{}', 'yes'),
(7718, 'tp_hotel_booking_catalog_image_width', '270', 'yes'),
(7719, 'tp_hotel_booking_catalog_image_height', '270', 'yes'),
(7720, 'tp_hotel_booking_room_image_gallery_width', '1000', 'yes'),
(7721, 'tp_hotel_booking_room_image_gallery_height', '1000', 'yes'),
(7722, 'tp_hotel_booking_room_thumbnail_width', '150', 'yes'),
(7723, 'tp_hotel_booking_room_thumbnail_height', '150', 'yes'),
(7982, '_transient_timeout__redux_activation_redirect', '1570208147', 'no'),
(7983, '_transient__redux_activation_redirect', '1', 'no'),
(8143, 'booking_activation_process', 'Off', 'yes'),
(8144, 'booking_admin_cal_count', '2', 'yes'),
(8145, 'booking_skin', '/css/skins/traditional.css', 'yes'),
(8146, 'booking_num_per_page', '10', 'yes'),
(8147, 'booking_sort_order', '', 'yes'),
(8148, 'booking_default_toolbar_tab', 'filter', 'yes'),
(8149, 'booking_listing_default_view_mode', 'vm_calendar', 'yes'),
(8150, 'booking_view_days_num', '90', 'yes'),
(8151, 'booking_max_monthes_in_calendar', '1y', 'yes'),
(8152, 'booking_client_cal_count', '1', 'yes'),
(8153, 'booking_start_day_weeek', '0', 'yes'),
(8154, 'booking_title_after_reservation', 'Thank you for your online booking.  We will send confirmation of your booking as soon as possible.', 'yes'),
(8155, 'booking_title_after_reservation_time', '7000', 'yes'),
(8156, 'booking_type_of_thank_you_message', 'message', 'yes'),
(8157, 'booking_thank_you_page_URL', '/thank-you', 'yes'),
(8158, 'booking_is_use_autofill_4_logged_user', 'Off', 'yes'),
(8159, 'booking_date_format', 'F j, Y', 'yes'),
(8160, 'booking_date_view_type', 'short', 'yes'),
(8161, 'booking_is_delete_if_deactive', 'Off', 'yes'),
(8162, 'booking_dif_colors_approval_pending', 'On', 'yes'),
(8163, 'booking_is_use_hints_at_admin_panel', 'On', 'yes'),
(8164, 'booking_is_not_load_bs_script_in_client', 'Off', 'yes'),
(8165, 'booking_is_not_load_bs_script_in_admin', 'Off', 'yes'),
(8166, 'booking_is_load_js_css_on_specific_pages', 'Off', 'yes'),
(8167, 'booking_is_show_system_debug_log', 'Off', 'yes'),
(8168, 'booking_pages_for_load_js_css', '', 'yes'),
(8169, 'booking_type_of_day_selections', 'multiple', 'yes'),
(8170, 'booking_timeslot_day_bg_as_available', 'On', 'yes'),
(8171, 'booking_form_is_using_bs_css', 'On', 'yes'),
(8172, 'booking_form_format_type', 'vertical', 'yes'),
(8173, 'booking_form_field_active1', 'On', 'yes'),
(8174, 'booking_form_field_required1', 'On', 'yes'),
(8175, 'booking_form_field_label1', 'First Name', 'yes'),
(8176, 'booking_form_field_active2', 'On', 'yes'),
(8177, 'booking_form_field_required2', 'On', 'yes'),
(8178, 'booking_form_field_label2', 'Last Name', 'yes'),
(8179, 'booking_form_field_active3', 'On', 'yes'),
(8180, 'booking_form_field_required3', 'On', 'yes'),
(8181, 'booking_form_field_label3', 'Email', 'yes'),
(8182, 'booking_form_field_active4', 'On', 'yes'),
(8183, 'booking_form_field_required4', 'Off', 'yes'),
(8184, 'booking_form_field_label4', 'Phone', 'yes'),
(8185, 'booking_form_field_active5', 'On', 'yes'),
(8186, 'booking_form_field_required5', 'Off', 'yes'),
(8187, 'booking_form_field_label5', 'Details', 'yes'),
(8188, 'booking_form_field_active6', 'Off', 'yes'),
(8189, 'booking_form_field_required6', 'Off', 'yes'),
(8190, 'booking_form_field_label6', 'Visitors', 'yes'),
(8191, 'booking_form_field_values6', '1\n2\n3\n4', 'yes'),
(8192, 'booking_is_days_always_available', 'Off', 'yes'),
(8193, 'booking_is_show_pending_days_as_available', 'Off', 'yes'),
(8194, 'booking_check_on_server_if_dates_free', 'Off', 'yes'),
(8195, 'booking_unavailable_days_num_from_today', '0', 'yes'),
(8196, 'booking_unavailable_day0', 'On', 'yes'),
(8197, 'booking_unavailable_day1', 'On', 'yes'),
(8198, 'booking_unavailable_day2', 'On', 'yes'),
(8199, 'booking_unavailable_day3', 'On', 'yes'),
(8200, 'booking_unavailable_day4', 'On', 'yes'),
(8201, 'booking_unavailable_day5', 'On', 'yes'),
(8202, 'booking_unavailable_day6', 'On', 'yes'),
(8203, 'booking_menu_position', 'top', 'yes'),
(8204, 'booking_user_role_booking', 'editor', 'yes'),
(8205, 'booking_user_role_addbooking', 'editor', 'yes'),
(8206, 'booking_user_role_resources', 'editor', 'yes'),
(8207, 'booking_user_role_settings', 'administrator', 'yes'),
(8208, 'booking_is_email_reservation_adress', 'On', 'yes'),
(8209, 'booking_email_reservation_adress', '&quot;Booking system&quot; &lt;admin@gmail.com&gt;', 'yes'),
(8210, 'booking_email_reservation_from_adress', '[visitoremail]', 'yes'),
(8211, 'booking_email_reservation_subject', 'New booking', 'yes'),
(8212, 'booking_email_reservation_content', 'You need to approve a new booking [bookingtype] for: [dates]&lt;br/&gt;&lt;br/&gt; Person detail information:&lt;br/&gt; [content]&lt;br/&gt;&lt;br/&gt; Currently a new booking is waiting for approval. Please visit the moderation panel [moderatelink]&lt;br/&gt;&lt;br/&gt;Thank you, projct new development&lt;br/&gt;[siteurl]', 'yes'),
(8213, 'booking_is_email_newbookingbyperson_adress', 'Off', 'yes'),
(8214, 'booking_email_newbookingbyperson_adress', '&quot;Booking system&quot; &lt;admin@gmail.com&gt;', 'yes'),
(8215, 'booking_email_newbookingbyperson_subject', 'New booking', 'yes'),
(8216, 'booking_email_newbookingbyperson_content', 'Your reservation [bookingtype] for: [dates] is processing now! We will send confirmation by email. &lt;br/&gt;&lt;br/&gt;[content]&lt;br/&gt;&lt;br/&gt; Thank you, projct new development&lt;br/&gt;[siteurl]', 'yes'),
(8217, 'booking_is_email_approval_adress', 'On', 'yes'),
(8218, 'booking_is_email_approval_send_copy_to_admin', 'Off', 'yes'),
(8219, 'booking_email_approval_adress', '&quot;Booking system&quot; &lt;admin@gmail.com&gt;', 'yes'),
(8220, 'booking_email_approval_subject', 'Your booking has been approved', 'yes'),
(8221, 'booking_email_approval_content', 'Your booking [bookingtype] for: [dates] has been approved.&lt;br/&gt;&lt;br/&gt;[content]&lt;br/&gt;&lt;br/&gt;Thank you, projct new development&lt;br/&gt;[siteurl]', 'yes'),
(8222, 'booking_is_email_deny_adress', 'On', 'yes'),
(8223, 'booking_is_email_deny_send_copy_to_admin', 'Off', 'yes'),
(8224, 'booking_email_deny_adress', '&quot;Booking system&quot; &lt;admin@gmail.com&gt;', 'yes'),
(8225, 'booking_email_deny_subject', 'Your booking has been declined', 'yes'),
(8226, 'booking_email_deny_content', 'Your booking [bookingtype] for: [dates] has been  canceled. &lt;br/&gt;[denyreason]&lt;br/&gt;&lt;br/&gt;[content]&lt;br/&gt;&lt;br/&gt;Thank you, projct new development&lt;br/&gt;[siteurl]', 'yes'),
(8227, 'booking_widget_title', 'Booking form', 'yes'),
(8228, 'booking_widget_show', 'booking_form', 'yes'),
(8229, 'booking_widget_type', '1', 'yes'),
(8230, 'booking_widget_calendar_count', '1', 'yes'),
(8231, 'booking_widget_last_field', '', 'yes'),
(8232, 'booking_wpdev_copyright_adminpanel', 'On', 'yes'),
(8233, 'booking_is_show_powered_by_notice', 'On', 'yes'),
(8234, 'booking_is_use_captcha', 'Off', 'yes'),
(8235, 'booking_is_show_legend', 'Off', 'yes'),
(8236, 'booking_legend_is_show_item_available', 'On', 'yes'),
(8237, 'booking_legend_text_for_item_available', 'Available', 'yes'),
(8238, 'booking_legend_is_show_item_pending', 'On', 'yes'),
(8239, 'booking_legend_text_for_item_pending', 'Pending', 'yes'),
(8240, 'booking_legend_is_show_item_approved', 'On', 'yes'),
(8241, 'booking_legend_text_for_item_approved', 'Booked', 'yes'),
(8242, 'booking_legend_is_show_numbers', 'Off', 'yes'),
(8243, 'booking_email_new_admin', 'a:15:{s:7:\"enabled\";s:2:\"On\";s:2:\"to\";s:15:\"admin@gmail.com\";s:7:\"to_name\";s:14:\"Booking system\";s:4:\"from\";s:15:\"admin@gmail.com\";s:9:\"from_name\";s:14:\"Booking system\";s:7:\"subject\";s:11:\"New booking\";s:7:\"content\";s:277:\"You need to approve a new booking [bookingtype] for: [dates]<br/><br/> Person detail information:<br/> [content]<br/><br/> Currently a new booking is waiting for approval. Please visit the moderation panel [moderatelink]<br/><br/>Thank you, projct new development<br/>[siteurl]\";s:14:\"header_content\";s:0:\"\";s:14:\"footer_content\";s:0:\"\";s:13:\"template_file\";s:5:\"plain\";s:10:\"base_color\";s:7:\"#557da1\";s:16:\"background_color\";s:7:\"#f5f5f5\";s:10:\"body_color\";s:7:\"#fdfdfd\";s:10:\"text_color\";s:7:\"#505050\";s:18:\"email_content_type\";s:4:\"html\";}', 'yes'),
(8244, 'booking_email_new_visitor', 'a:13:{s:7:\"enabled\";s:2:\"On\";s:4:\"from\";s:15:\"admin@gmail.com\";s:9:\"from_name\";s:14:\"Booking system\";s:7:\"subject\";s:11:\"New booking\";s:7:\"content\";s:176:\"Your reservation [bookingtype] for: [dates] is processing now! We will send confirmation by email. <br/><br/>[content]<br/><br/> Thank you, projct new development<br/>[siteurl]\";s:14:\"header_content\";s:0:\"\";s:14:\"footer_content\";s:0:\"\";s:13:\"template_file\";s:5:\"plain\";s:10:\"base_color\";s:7:\"#557da1\";s:16:\"background_color\";s:7:\"#f5f5f5\";s:10:\"body_color\";s:7:\"#fdfdfd\";s:10:\"text_color\";s:7:\"#505050\";s:18:\"email_content_type\";s:4:\"html\";}', 'yes'),
(8245, 'booking_email_approved', 'a:16:{s:7:\"enabled\";s:2:\"On\";s:13:\"copy_to_admin\";s:3:\"Off\";s:2:\"to\";s:15:\"admin@gmail.com\";s:7:\"to_name\";s:14:\"Booking system\";s:4:\"from\";s:15:\"admin@gmail.com\";s:9:\"from_name\";s:14:\"Booking system\";s:7:\"subject\";s:30:\"Your booking has been approved\";s:7:\"content\";s:134:\"Your booking [bookingtype] for: [dates] has been approved.<br/><br/>[content]<br/><br/>Thank you, projct new development<br/>[siteurl]\";s:14:\"header_content\";s:0:\"\";s:14:\"footer_content\";s:0:\"\";s:13:\"template_file\";s:5:\"plain\";s:10:\"base_color\";s:7:\"#557da1\";s:16:\"background_color\";s:7:\"#f5f5f5\";s:10:\"body_color\";s:7:\"#fdfdfd\";s:10:\"text_color\";s:7:\"#505050\";s:18:\"email_content_type\";s:4:\"html\";}', 'yes'),
(8246, 'booking_email_deleted', 'a:16:{s:7:\"enabled\";s:2:\"On\";s:13:\"copy_to_admin\";s:3:\"Off\";s:2:\"to\";s:15:\"admin@gmail.com\";s:7:\"to_name\";s:14:\"Booking system\";s:4:\"from\";s:15:\"admin@gmail.com\";s:9:\"from_name\";s:14:\"Booking system\";s:7:\"subject\";s:30:\"Your booking has been declined\";s:7:\"content\";s:153:\"Your booking [bookingtype] for: [dates] has been  canceled. <br/>[denyreason]<br/><br/>[content]<br/><br/>Thank you, projct new development<br/>[siteurl]\";s:14:\"header_content\";s:0:\"\";s:14:\"footer_content\";s:0:\"\";s:13:\"template_file\";s:5:\"plain\";s:10:\"base_color\";s:7:\"#557da1\";s:16:\"background_color\";s:7:\"#f5f5f5\";s:10:\"body_color\";s:7:\"#fdfdfd\";s:10:\"text_color\";s:7:\"#505050\";s:18:\"email_content_type\";s:4:\"html\";}', 'yes'),
(8247, 'booking_email_deny', 'a:16:{s:7:\"enabled\";s:2:\"On\";s:13:\"copy_to_admin\";s:3:\"Off\";s:2:\"to\";s:15:\"admin@gmail.com\";s:7:\"to_name\";s:14:\"Booking system\";s:4:\"from\";s:15:\"admin@gmail.com\";s:9:\"from_name\";s:14:\"Booking system\";s:7:\"subject\";s:30:\"Your booking has been declined\";s:7:\"content\";s:153:\"Your booking [bookingtype] for: [dates] has been  canceled. <br/>[denyreason]<br/><br/>[content]<br/><br/>Thank you, projct new development<br/>[siteurl]\";s:14:\"header_content\";s:0:\"\";s:14:\"footer_content\";s:0:\"\";s:13:\"template_file\";s:5:\"plain\";s:10:\"base_color\";s:7:\"#557da1\";s:16:\"background_color\";s:7:\"#f5f5f5\";s:10:\"body_color\";s:7:\"#fdfdfd\";s:10:\"text_color\";s:7:\"#505050\";s:18:\"email_content_type\";s:4:\"html\";}', 'yes'),
(8248, 'booking_email_trash', 'a:16:{s:7:\"enabled\";s:2:\"On\";s:13:\"copy_to_admin\";s:3:\"Off\";s:2:\"to\";s:15:\"admin@gmail.com\";s:7:\"to_name\";s:14:\"Booking system\";s:4:\"from\";s:15:\"admin@gmail.com\";s:9:\"from_name\";s:14:\"Booking system\";s:7:\"subject\";s:30:\"Your booking has been declined\";s:7:\"content\";s:153:\"Your booking [bookingtype] for: [dates] has been  canceled. <br/>[denyreason]<br/><br/>[content]<br/><br/>Thank you, projct new development<br/>[siteurl]\";s:14:\"header_content\";s:0:\"\";s:14:\"footer_content\";s:0:\"\";s:13:\"template_file\";s:5:\"plain\";s:10:\"base_color\";s:7:\"#557da1\";s:16:\"background_color\";s:7:\"#f5f5f5\";s:10:\"body_color\";s:7:\"#fdfdfd\";s:10:\"text_color\";s:7:\"#505050\";s:18:\"email_content_type\";s:4:\"html\";}', 'yes'),
(8249, 'booking_form_structure_type', 'vertical', 'yes'),
(8250, 'booking_menu_go_pro', 'show', 'yes'),
(8251, 'booking_form', '<div class=\"wpbc_booking_form_structure wpbc_vertical\">\n  <div class=\"wpbc_structure_calendar\">\n    [calendar]\n  </div>\n  <div class=\"wpbc_structure_form\">\n     <p>First Name*:<br />[text* name]</p>\n     <p>Last Name*:<br />[text* secondname]</p>\n     <p>Email*:<br />[email* email]</p>\n     <p>Phone:<br />[text phone]</p>\n     <p>Details:<br />[textarea details]</p>\n     <p>[captcha]</p>\n     <p>[submit class:btn \"Send\"]</p>\n  </div>\n</div>\n<div class=\"wpbc_booking_form_footer\"></div>', 'yes'),
(8252, 'booking_form_show', '<div style=\"text-align:left;word-wrap: break-word;\">\n  <strong>First Name</strong>: <span class=\"fieldvalue\">[name]</span><br/>\n  <strong>Last Name</strong>: <span class=\"fieldvalue\">[secondname]</span><br/>\n  <strong>Email</strong>: <span class=\"fieldvalue\">[email]</span><br/>\n  <strong>Phone</strong>: <span class=\"fieldvalue\">[phone]</span><br/>\n  <strong>Details</strong>: <span class=\"fieldvalue\">[details]</span><br/>\n</div>', 'yes'),
(8253, 'booking_form_visual', 'a:9:{i:0;a:2:{s:4:\"type\";s:8:\"calendar\";s:10:\"obligatory\";s:2:\"On\";}i:1;a:6:{s:4:\"type\";s:4:\"text\";s:4:\"name\";s:4:\"name\";s:10:\"obligatory\";s:3:\"Off\";s:6:\"active\";s:2:\"On\";s:8:\"required\";s:2:\"On\";s:5:\"label\";s:10:\"First Name\";}i:2;a:6:{s:4:\"type\";s:4:\"text\";s:4:\"name\";s:10:\"secondname\";s:10:\"obligatory\";s:3:\"Off\";s:6:\"active\";s:2:\"On\";s:8:\"required\";s:2:\"On\";s:5:\"label\";s:9:\"Last Name\";}i:3;a:6:{s:4:\"type\";s:5:\"email\";s:4:\"name\";s:5:\"email\";s:10:\"obligatory\";s:2:\"On\";s:6:\"active\";s:2:\"On\";s:8:\"required\";s:2:\"On\";s:5:\"label\";s:5:\"Email\";}i:4;a:7:{s:4:\"type\";s:6:\"select\";s:4:\"name\";s:8:\"visitors\";s:10:\"obligatory\";s:3:\"Off\";s:6:\"active\";s:3:\"Off\";s:8:\"required\";s:3:\"Off\";s:5:\"label\";s:8:\"Visitors\";s:5:\"value\";s:7:\"1\n2\n3\n4\";}i:5;a:6:{s:4:\"type\";s:4:\"text\";s:4:\"name\";s:5:\"phone\";s:10:\"obligatory\";s:3:\"Off\";s:6:\"active\";s:2:\"On\";s:8:\"required\";s:3:\"Off\";s:5:\"label\";s:5:\"Phone\";}i:6;a:6:{s:4:\"type\";s:8:\"textarea\";s:4:\"name\";s:7:\"details\";s:10:\"obligatory\";s:3:\"Off\";s:6:\"active\";s:2:\"On\";s:8:\"required\";s:3:\"Off\";s:5:\"label\";s:7:\"Details\";}i:7;a:6:{s:4:\"type\";s:7:\"captcha\";s:4:\"name\";s:7:\"captcha\";s:10:\"obligatory\";s:2:\"On\";s:6:\"active\";s:3:\"Off\";s:8:\"required\";s:2:\"On\";s:5:\"label\";s:0:\"\";}i:8;a:6:{s:4:\"type\";s:6:\"submit\";s:4:\"name\";s:6:\"submit\";s:10:\"obligatory\";s:2:\"On\";s:6:\"active\";s:2:\"On\";s:8:\"required\";s:2:\"On\";s:5:\"label\";s:4:\"Send\";}}', 'yes'),
(8254, 'booking_gcal_feed', '', 'yes'),
(8255, 'booking_gcal_events_from', 'month-start', 'yes'),
(8256, 'booking_gcal_events_from_offset', '', 'yes'),
(8257, 'booking_gcal_events_from_offset_type', '', 'yes'),
(8258, 'booking_gcal_events_until', 'any', 'yes'),
(8259, 'booking_gcal_events_until_offset', '', 'yes'),
(8260, 'booking_gcal_events_until_offset_type', '', 'yes'),
(8261, 'booking_gcal_events_max', '25', 'yes'),
(8262, 'booking_gcal_api_key', '', 'yes'),
(8263, 'booking_gcal_timezone', '', 'yes'),
(8264, 'booking_gcal_is_send_email', 'Off', 'yes'),
(8265, 'booking_gcal_auto_import_is_active', 'Off', 'yes'),
(8266, 'booking_gcal_auto_import_time', '24', 'yes'),
(8267, 'booking_gcal_events_form_fields', 's:101:\"a:3:{s:5:\"title\";s:9:\"text^name\";s:11:\"description\";s:16:\"textarea^details\";s:5:\"where\";s:5:\"text^\";}\";', 'yes'),
(8268, 'booking_version_num', '8.4.6', 'yes'),
(8272, 'widget_bookingwidget', 'a:1:{s:12:\"_multiwidget\";i:1;}', 'yes'),
(8276, 'booking_activation_redirect_for_version', '8.4.6', 'yes'),
(8404, 'widget_wpsimplebookingcalendar_widget', 'a:1:{s:12:\"_multiwidget\";i:1;}', 'yes'),
(8416, 'wp-simple-booking-calendar-options', 'a:1:{s:9:\"calendars\";a:1:{i:1;a:4:{s:12:\"calendarName\";s:13:\"Hotel Booking\";s:12:\"calendarJson\";s:113:\"{\"year2019\":{\"month4\":{\"day1\":\"booked\",\"day2\":\"booked\",\"day3\":\"booked\",\"day4\":\"changeover\",\"day5\":\"changeover\"}}}\";s:11:\"dateCreated\";i:1554275383;s:12:\"dateModified\";i:1554275500;}}}', 'yes'),
(8649, 'wpbooking_update_1_0_7', 'updated', 'yes'),
(8650, 'wpbooking_update_1_0_7_hotel_room_order', 'updated', 'yes'),
(8651, 'wpbooking_service_version', '1.2', 'yes'),
(8652, 'wpbooking_order_version', '1.0.5', 'yes'),
(8653, 'wpbooking_order_hotel_room_version', '1.3', 'yes'),
(8654, 'wpbooking_availability_version', '1.2', 'yes'),
(8655, 'wpbooking_payment_version', '1.0', 'yes'),
(8656, 'wpbooking_favorite_version', '1.0', 'yes'),
(8657, 'wpbooking_review_helpful_version', '1.0.1', 'yes'),
(8658, 'wpbooking_availability_tour_version', '1.3', 'yes'),
(8659, 'widget_wpbooking_widget_form_search', 'a:1:{s:12:\"_multiwidget\";i:1;}', 'yes'),
(8667, 'wpbooking_taxonomies', 'a:2:{s:13:\"wb_tax_1_star\";a:5:{s:5:\"label\";s:6:\"1 star\";s:4:\"name\";s:13:\"wb_tax_1_star\";s:12:\"hierarchical\";i:1;s:12:\"service_type\";a:2:{i:0;s:13:\"accommodation\";i:1;s:4:\"tour\";}s:4:\"slug\";s:6:\"1-star\";}s:13:\"wb_tax_2_star\";a:5:{s:5:\"label\";s:6:\"2 star\";s:4:\"name\";s:13:\"wb_tax_2_star\";s:12:\"hierarchical\";i:1;s:12:\"service_type\";b:0;s:4:\"slug\";s:6:\"2-star\";}}', 'yes'),
(8697, 'wb_tax_1_star_children', 'a:0:{}', 'yes'),
(8703, 'wb_hotel_room_type_children', 'a:0:{}', 'yes'),
(8704, 'tax_meta_156', 'a:1:{s:24:\"featured_image_room_type\";s:0:\"\";}', 'yes'),
(8709, 'wb_hotel_room_facilities_children', 'a:0:{}', 'yes'),
(8712, 'wb_tour_type_children', 'a:0:{}', 'yes'),
(8713, 'tax_meta_158', 'a:1:{s:24:\"featured_image_tour_type\";s:0:\"\";}', 'yes'),
(8719, 'wpbooking_amenity_children', 'a:0:{}', 'yes'),
(8725, 'wpbooking_extra_service_children', 'a:0:{}', 'yes'),
(8800, 'wpbooking_location_children', 'a:0:{}', 'yes'),
(8801, 'wb_tax_2_star_children', 'a:0:{}', 'yes'),
(8854, 'wpbooking_update_availability_tour', 'updated', 'no'),
(8855, 'wpbooking_update_availability_car', 'updated', 'no'),
(8856, 'wpbooking_update_base_price_tour', 'updated', 'no'),
(8857, 'wpbooking_update_status_order_hotel', 'updated', 'no'),
(8858, 'wpbooking_update_num_total_room', 'updated', 'no'),
(8859, 'wpbooking_update_num_total_room_in_hotel', 'updated', 'no'),
(8860, 'wpbooking_update_max_people_tour', 'updated', 'no'),
(9057, 'awebooking_version', '3.2.11', 'yes'),
(9058, 'awebooking_db_version', '3.2.11', 'yes'),
(9060, 'widget_awebooking_check_availability', 'a:1:{s:12:\"_multiwidget\";i:1;}', 'yes'),
(9064, 'awebooking_admin_notices', 'a:0:{}', 'yes'),
(9065, 'awebooking_settings', 'a:74:{s:10:\"hotel_name\";s:22:\"projct new development\";s:10:\"calc_taxes\";s:2:\"on\";s:14:\"tax_rate_model\";s:6:\"single\";s:18:\"prices_include_tax\";s:2:\"no\";s:30:\"gateway_direct_payment_enabled\";s:3:\"off\";s:28:\"gateway_direct_payment_title\";s:12:\"Pay at Hotel\";s:20:\"gateway_bacs_enabled\";s:2:\"on\";s:18:\"gateway_bacs_title\";s:20:\"Direct bank transfer\";s:24:\"gateway_bacs_description\";s:102:\"Make your payment directly into our bank account. Please use your Booking ID as the payment reference.\";s:25:\"gateway_bacs_instructions\";s:0:\"\";s:21:\"gateway_bacs_accounts\";s:0:\"\";s:29:\"display_search_form_on_search\";s:2:\"on\";s:19:\"display_filter_form\";s:2:\"on\";s:20:\"use_experiment_style\";s:3:\"off\";s:22:\"search_form_max_adults\";s:1:\"6\";s:24:\"search_form_max_children\";s:1:\"6\";s:23:\"search_form_max_infants\";s:1:\"6\";s:18:\"archive_image_size\";a:3:{s:5:\"width\";i:600;s:6:\"height\";i:400;s:4:\"crop\";s:2:\"on\";}s:17:\"single_image_size\";a:3:{s:5:\"width\";i:900;s:6:\"height\";i:600;s:4:\"crop\";s:2:\"on\";}s:20:\"thumbnail_image_size\";a:3:{s:5:\"width\";i:300;s:6:\"height\";i:300;s:4:\"crop\";s:2:\"on\";}s:24:\"email_invoice_email_type\";s:4:\"html\";s:23:\"email_invoice_recipient\";s:15:\"admin@gmail.com\";s:21:\"email_invoice_subject\";s:0:\"\";s:21:\"email_invoice_content\";s:0:\"\";s:25:\"email_new_booking_enabled\";s:2:\"on\";s:28:\"email_new_booking_email_type\";s:4:\"html\";s:27:\"email_new_booking_recipient\";s:15:\"admin@gmail.com\";s:25:\"email_new_booking_subject\";s:70:\"[{site_title}] New customer booking #{booking_number} - {booking_date}\";s:25:\"email_new_booking_content\";s:82:\"You have received a booking from {customer_first_name}. The booking is as follows:\";s:22:\"email_reserved_enabled\";s:2:\"on\";s:25:\"email_reserved_email_type\";s:4:\"html\";s:22:\"email_reserved_subject\";s:53:\"Your {site_title} booking receipt from {date_created}\";s:22:\"email_reserved_content\";s:125:\"Your booking is reserved until we confirm payment has been received. Your booking details are shown below for your reference:\";s:24:\"email_processing_enabled\";s:2:\"on\";s:27:\"email_processing_email_type\";s:4:\"html\";s:24:\"email_processing_subject\";s:53:\"Your {site_title} booking receipt from {date_created}\";s:24:\"email_processing_content\";s:115:\"Your booking has been received and is now being processed. Your booking details are shown below for your reference:\";s:23:\"email_completed_enabled\";s:2:\"on\";s:26:\"email_completed_email_type\";s:4:\"html\";s:23:\"email_completed_subject\";s:65:\"Your {site_title} booking receipt from {date_created} is complete\";s:23:\"email_completed_content\";s:122:\"Hi there. Your recent booking on {site_title} has been completed. Your booking details are shown below for your reference:\";s:23:\"email_cancelled_enabled\";s:2:\"on\";s:26:\"email_cancelled_email_type\";s:4:\"html\";s:23:\"email_cancelled_subject\";s:35:\"Cancelled booking #{booking_number}\";s:23:\"email_cancelled_content\";s:50:\"Your booking #{booking_number} has been cancelled!\";s:27:\"email_customer_note_enabled\";s:2:\"on\";s:30:\"email_customer_note_email_type\";s:4:\"html\";s:27:\"email_customer_note_subject\";s:39:\"Note added to your {site_title} booking\";s:27:\"email_customer_note_content\";s:67:\"Hello, a note has just been added to your booking:\n\n{customer_note}\";s:18:\"email_from_address\";s:15:\"admin@gmail.com\";s:16:\"email_base_color\";s:7:\"#2196f3\";s:21:\"email_body_text_color\";s:7:\"#74787E\";s:14:\"email_bg_color\";s:7:\"#ffffff\";s:19:\"email_body_bg_color\";s:7:\"#f7f7f7\";s:8:\"api_code\";s:0:\"\";s:15:\"enable_location\";s:2:\"on\";s:17:\"children_bookable\";s:2:\"on\";s:16:\"infants_bookable\";s:2:\"on\";s:16:\"reservation_mode\";s:13:\"multiple_room\";s:12:\"measure_unit\";s:2:\"m2\";s:23:\"page_check_availability\";i:382;s:13:\"page_checkout\";i:13;s:10:\"page_terms\";i:62;s:8:\"currency\";s:3:\"USD\";s:17:\"currency_position\";s:4:\"left\";s:24:\"price_thousand_separator\";s:1:\",\";s:23:\"price_decimal_separator\";s:1:\".\";s:21:\"price_number_decimals\";i:2;s:26:\"scheduler_display_duration\";i:30;s:28:\"display_datepicker_minnights\";i:1;s:28:\"display_datepicker_maxnights\";i:0;s:26:\"display_datepicker_mindate\";i:0;s:31:\"display_datepicker_disabledates\";s:0:\"\";s:30:\"display_datepicker_disabledays\";a:7:{i:0;i:0;i:1;i:1;i:2;i:2;i:3;i:3;i:4;i:4;i:5;i:5;i:6;i:6;}}', 'yes'),
(9068, '_wp_session_awebooking_356a192b7913b04c54574d18c28d46e6395428ab', 'a:2:{s:7:\"payload\";a:1:{s:6:\"_flash\";a:2:{s:3:\"old\";a:0:{}s:3:\"new\";a:0:{}}}s:13:\"last_activity\";i:1554285951;}', 'no'),
(9093, 'hotel_amenity_children', 'a:0:{}', 'yes'),
(9137, '_transient_as_comment_count', 'O:8:\"stdClass\":7:{s:8:\"approved\";s:1:\"4\";s:14:\"total_comments\";i:4;s:3:\"all\";i:4;s:9:\"moderated\";i:0;s:4:\"spam\";i:0;s:5:\"trash\";i:0;s:12:\"post-trashed\";i:0;}', 'yes'),
(9276, '_wp_session_awebooking_ZjRj56NEkxoKw1oif1gE2ljYBYtFtAeo3Xv5x2v4', 'a:2:{s:7:\"payload\";a:1:{s:6:\"_flash\";a:2:{s:3:\"old\";a:0:{}s:3:\"new\";a:0:{}}}s:13:\"last_activity\";i:1554285420;}', 'no'),
(9323, 'booking_package_timezone', 'UTC', 'yes'),
(9324, 'booking_package_javascriptSyntaxErrorNotification', '1', 'yes'),
(9325, 'booking_package_db_version', '0.4.4', 'yes'),
(9326, 'booking_package_activation_id', '0', 'yes'),
(9328, 'widget_booking_package_widget', 'a:1:{s:12:\"_multiwidget\";i:1;}', 'yes'),
(9331, 'booking_package_home_path', 'F:/xampp/htdocs/project/', 'yes'),
(9332, 'booking_package_version', '1.3.40', 'yes'),
(9340, 'booking_package_read_member_limit', '10', 'yes'),
(9341, 'booking_package_function_for_member', '0', 'yes'),
(9342, 'booking_package_reject_non_membder', '0', 'yes'),
(9343, 'booking_package_visitors_registration_for_member', '0', 'yes'),
(9344, 'booking_package_check_email_for_member', '0', 'yes'),
(9345, 'booking_package_accept_subscribers_as_users', '0', 'yes'),
(9346, 'booking_package_subject_email_for_member', '', 'yes'),
(9347, 'booking_package_body_email_for_member', '', 'yes'),
(9354, 'booking_package_ical_token', 'b1a2ce85e374f68632d64360c59619cf70247ab6', 'yes'),
(9355, '_booking-package_css_v', '1554286119', 'yes'),
(9357, 'booking_package_site_name', 'Site name', 'yes'),
(9358, 'booking_package_email_to', 'milon@gmail.com', 'yes'),
(9359, 'booking_package_email_title_to', 'milon@gmail.com', 'yes'),
(9360, 'booking_package_email_from', 'milon@gmail.com', 'yes'),
(9361, 'booking_package_email_title_from', 'milon@gmail.com', 'yes'),
(9362, 'booking_package_country', 'US', 'yes'),
(9363, 'booking_package_currency', 'usd', 'yes'),
(9364, 'booking_package_dateFormat', '0', 'yes'),
(9365, 'booking_package_positionOfWeek', 'before', 'yes'),
(9366, 'booking_package_automaticApprove', '1', 'yes'),
(9367, 'booking_package_headingPosition', '1', 'yes'),
(9368, 'booking_package_fontSize', '14px', 'yes'),
(9369, 'booking_package_backgroundColor', '#FFF', 'yes'),
(9370, 'booking_package_calendarBackgroundColorWithSchedule', '#FFF', 'yes'),
(9371, 'booking_package_calendarBackgroundColorWithNoSchedule', '#EEE', 'yes'),
(9372, 'booking_package_backgroundColorOfRegularHolidays', '#FFD5D5', 'yes'),
(9373, 'booking_package_scheduleAndServiceBackgroundColor', '#FFF', 'yes'),
(9374, 'booking_package_backgroundColorOfSelectedLabel', '#EAEDF3', 'yes'),
(9375, 'booking_package_mouseHover', '#EAEDF3', 'yes'),
(9376, 'booking_package_borderColor', '#ddd', 'yes'),
(9377, 'booking_package_paypal_active', '0', 'yes'),
(9378, 'booking_package_paypal_live', '0', 'yes'),
(9379, 'booking_package_paypal_client_id', '', 'yes'),
(9380, 'booking_package_paypal_secret_key', '', 'yes'),
(9462, 'booking_package_ical_active', '1', 'yes'),
(11302, '_transient_wc_count_comments', 'O:8:\"stdClass\":7:{s:14:\"total_comments\";i:4;s:3:\"all\";i:4;s:8:\"approved\";s:1:\"4\";s:9:\"moderated\";i:0;s:4:\"spam\";i:0;s:5:\"trash\";i:0;s:12:\"post-trashed\";i:0;}', 'yes'),
(11604, '_site_transient__transient_wt_booking_stat_data', 'a:0:{}', 'no'),
(11605, '_site_transient__transient_wt_booking_top_country', 'a:1:{i:0;O:8:\"stdClass\":2:{s:8:\"wt_total\";s:1:\"1\";s:7:\"country\";s:2:\"AF\";}}', 'no'),
(11606, '_site_transient__transient_wt_booking_top_itinerary', 'a:1:{i:0;O:8:\"stdClass\":2:{s:8:\"wt_total\";s:1:\"1\";s:12:\"itinerary_id\";s:1:\"0\";}}', 'no'),
(12770, 'locationto_children', 'a:0:{}', 'yes'),
(12785, 'locationform_children', 'a:0:{}', 'yes'),
(12836, 'passenger_children', 'a:0:{}', 'yes'),
(14638, 'airlines_children', 'a:0:{}', 'yes'),
(14640, 'stops_children', 'a:0:{}', 'yes'),
(15045, 'roundtrip_children', 'a:0:{}', 'yes'),
(17734, 'hotelprice_children', 'a:0:{}', 'yes'),
(17834, 'hotellocation_children', 'a:0:{}', 'yes'),
(18782, 'ure_role_additional_options_values', 'a:4:{s:6:\"taibur\";a:1:{s:14:\"hide_admin_bar\";i:1;}s:6:\"author\";a:0:{}s:6:\"editor\";a:0:{}s:5:\"milon\";a:0:{}}', 'yes'),
(20478, 'site_reviews_v3', 'a:5:{s:8:\"settings\";a:2:{s:7:\"general\";a:2:{s:20:\"notification_message\";s:173:\"<strong>A new {review_rating}-star review has been submitted:</strong>\n\n{review_title}\n\n{review_content}\n\n{review_author} &lt;{review_email}&gt; - {review_ip}\n\n{review_link}\";s:13:\"notifications\";a:0:{}}s:11:\"submissions\";a:1:{s:8:\"required\";a:0:{}}}s:7:\"version\";s:5:\"3.5.4\";s:21:\"version_upgraded_from\";s:5:\"0.0.0\";s:6:\"counts\";a:1:{s:5:\"local\";a:6:{i:0;i:0;i:1;i:0;i:2;i:3;i:3;i:3;i:4;i:5;i:5;i:1;}}s:17:\"last_review_count\";i:1558238488;}', 'yes'),
(20480, 'widget_site-reviews_site-reviews', 'a:1:{s:12:\"_multiwidget\";i:1;}', 'yes'),
(20481, 'widget_site-reviews_site-reviews-form', 'a:1:{s:12:\"_multiwidget\";i:1;}', 'yes'),
(20482, 'widget_site-reviews_site-reviews-summary', 'a:1:{s:12:\"_multiwidget\";i:1;}', 'yes'),
(22119, 'wp_travel_permalinks', 'a:4:{s:19:\"wp_travel_trip_base\";s:9:\"itinerary\";s:24:\"wp_travel_trip_type_base\";s:9:\"trip-type\";s:26:\"wp_travel_destination_base\";s:16:\"travel-locations\";s:23:\"wp_travel_activity_base\";s:8:\"activity\";}', 'yes'),
(22567, 'wp_user_disable_signup', '0', 'yes'),
(22568, 'wp_user_disable_admin_bar', '1', 'yes'),
(22569, 'wp_user_appearance_skin', 'horizontal', 'yes'),
(22570, 'wp_user_language', 'English', 'yes'),
(22571, 'wp_user_appearance_icon', '0', 'yes'),
(22572, 'wp_user_appearance_custom_css', '', 'yes'),
(22573, 'wp_user_login_limit_enable', '1', 'yes'),
(22574, 'wp_user_login_limit', '5', 'yes'),
(22575, 'wp_user_login_limit_time', '10', 'yes'),
(22576, 'wp_user_login_limit_admin_notify', '1', 'yes'),
(22577, 'wpuser_site_key', 'c8593704c0435a2642ecbb5b7edd3b6e23ce012c24d3d0e5c95e1ca7fc747c9d', 'yes'),
(22578, 'wpuser_api_key', '03300de3c975be0f78fc67764c381131', 'yes'),
(22579, 'wp_user_enable_rest_api', '0', 'yes'),
(22580, 'wp_user_enable_rest_api_key_auth', '0', 'yes'),
(22581, 'wp_user_login_limit_password_enable', '1', 'yes'),
(22582, 'wp_user_login_limit_password', '$\\S*(?=\\S{8,})(?=\\S*[a-z])(?=\\S*[A-Z])(?=\\S*[\\d])(?=\\S*[\\W])\\S*$', 'yes'),
(22583, 'wp_user_login_password_valid_message', 'Password containing at least one lowercase letter,uppercase letter,special character (non-word characters),one number and at least length 8', 'yes'),
(22584, 'wp_user_security_reCaptcha_enable', '0', 'yes'),
(22585, 'wp_user_security_reCaptcha_secretkey', '', 'yes'),
(22586, 'wp_user_email_name', 'projct new development', 'yes'),
(22587, 'wp_user_email_id', 'admin@gmail.com', 'yes'),
(22588, 'wp_user_email_admin_register_enable', '1', 'yes'),
(22589, 'wp_user_email_admin_register_subject', 'New User Registration', 'yes'),
(22590, 'wp_user_email_admin_register_content', 'Hi there,<br>\r\n{WPUSER_USERNAME} has just created a new account at {WPUSER_BLOGNAME}.', 'yes'),
(22591, 'wp_user_email_user_register_enable', '1', 'yes'),
(22592, 'wp_user_email_user_register_subject', 'Welcome', 'yes'),
(22593, 'wp_user_email_user_register_content', 'To login please visit the following URL:\r\n{WPUSER_LOGIN_URL}<br><br>\r\nYour account e-mail: {WPUSER_EMAIL}<br>\r\nYour account username: {WPUSER_USERNAME}<br><br>\r\nIf you have any problems, please contact us at {WPUSER_ADMIN_EMAIL}.<br><br>\r\nBest Regards!', 'yes'),
(22594, 'wp_user_email_user_forgot_subject', 'Your new password', 'yes'),
(22595, 'wp_user_email_user_forgot_content', 'Dear <strong style=\"font-family:Arial;margin:0px;padding:0px\"> {WPUSER_USERNAME}</strong>, <br><br>\r\n                <h3>Your password changed successfully. Details as follow</h3>\r\n                <br><br>\r\n                Login url :{WPUSER_LOGIN_URL}\r\n                <br> <br>\r\n                User Name : {WPUSER_USERNAME}\r\n                <br>\r\n                Your new password is: {WPUSER_NEW_PASSWORD}', 'yes'),
(22596, 'wp_user_truncate_login_entries', '0', 'yes'),
(22597, 'wp_user_default_status', '1', 'yes'),
(22598, 'wp_user_disable_user_sidebar', '1', 'yes'),
(22599, 'wp_user_tab_position_is_vertical', '0', 'yes'),
(22600, 'wp_user_page', '508', 'yes'),
(22602, 'widget_wpusersearchwidget', 'a:1:{s:12:\"_multiwidget\";i:1;}', 'yes'),
(22603, 'widget_wpuserwidget', 'a:1:{s:12:\"_multiwidget\";i:1;}', 'yes'),
(22769, '_wpuf_page_created', '1', 'yes'),
(22772, 'wpuf_whats_new', 'a:1:{s:5:\"2.8.7\";b:1;}', 'yes'),
(22961, 'weforms_settings', 'a:3:{s:13:\"email_gateway\";s:9:\"wordpress\";s:6:\"credit\";b:0;s:9:\"recaptcha\";a:2:{s:3:\"key\";s:0:\"\";s:6:\"secret\";s:0:\"\";}}', 'yes'),
(22962, 'weforms_installed', '1558505712', 'yes'),
(22967, 'weforms_version', '1.3.9', 'yes'),
(22969, 'widget_weforms_widget', 'a:1:{s:12:\"_multiwidget\";i:1;}', 'yes'),
(23156, 'widget_wppb-login-widget', 'a:1:{s:12:\"_multiwidget\";i:1;}', 'yes'),
(23157, 'wppb_version', '2.9.9', 'yes'),
(23158, 'wppb_manage_fields', 'a:13:{i:0;a:21:{s:2:\"id\";i:1;s:5:\"field\";s:24:\"Default - Name (Heading)\";s:9:\"meta-name\";s:0:\"\";s:11:\"field-title\";s:4:\"Name\";s:11:\"description\";s:0:\"\";s:8:\"required\";s:2:\"No\";s:18:\"overwrite-existing\";s:2:\"No\";s:9:\"row-count\";s:1:\"5\";s:24:\"allowed-image-extensions\";s:2:\".*\";s:25:\"allowed-upload-extensions\";s:2:\".*\";s:11:\"avatar-size\";s:3:\"100\";s:11:\"date-format\";s:8:\"mm/dd/yy\";s:18:\"terms-of-agreement\";s:0:\"\";s:7:\"options\";s:0:\"\";s:6:\"labels\";s:0:\"\";s:10:\"public-key\";s:0:\"\";s:11:\"private-key\";s:0:\"\";s:13:\"default-value\";s:0:\"\";s:14:\"default-option\";s:0:\"\";s:15:\"default-options\";s:0:\"\";s:15:\"default-content\";s:0:\"\";}i:1;a:21:{s:2:\"id\";i:2;s:5:\"field\";s:18:\"Default - Username\";s:9:\"meta-name\";s:0:\"\";s:11:\"field-title\";s:8:\"Username\";s:11:\"description\";s:0:\"\";s:8:\"required\";s:3:\"Yes\";s:18:\"overwrite-existing\";s:2:\"No\";s:9:\"row-count\";s:1:\"5\";s:24:\"allowed-image-extensions\";s:2:\".*\";s:25:\"allowed-upload-extensions\";s:2:\".*\";s:11:\"avatar-size\";s:3:\"100\";s:11:\"date-format\";s:8:\"mm/dd/yy\";s:18:\"terms-of-agreement\";s:0:\"\";s:7:\"options\";s:0:\"\";s:6:\"labels\";s:0:\"\";s:10:\"public-key\";s:0:\"\";s:11:\"private-key\";s:0:\"\";s:13:\"default-value\";s:0:\"\";s:14:\"default-option\";s:0:\"\";s:15:\"default-options\";s:0:\"\";s:15:\"default-content\";s:0:\"\";}i:2;a:21:{s:2:\"id\";i:3;s:5:\"field\";s:20:\"Default - First Name\";s:9:\"meta-name\";s:10:\"first_name\";s:11:\"field-title\";s:10:\"First Name\";s:11:\"description\";s:0:\"\";s:8:\"required\";s:2:\"No\";s:18:\"overwrite-existing\";s:2:\"No\";s:9:\"row-count\";s:1:\"5\";s:24:\"allowed-image-extensions\";s:2:\".*\";s:25:\"allowed-upload-extensions\";s:2:\".*\";s:11:\"avatar-size\";s:3:\"100\";s:11:\"date-format\";s:8:\"mm/dd/yy\";s:18:\"terms-of-agreement\";s:0:\"\";s:7:\"options\";s:0:\"\";s:6:\"labels\";s:0:\"\";s:10:\"public-key\";s:0:\"\";s:11:\"private-key\";s:0:\"\";s:13:\"default-value\";s:0:\"\";s:14:\"default-option\";s:0:\"\";s:15:\"default-options\";s:0:\"\";s:15:\"default-content\";s:0:\"\";}i:3;a:21:{s:2:\"id\";i:4;s:5:\"field\";s:19:\"Default - Last Name\";s:9:\"meta-name\";s:9:\"last_name\";s:11:\"field-title\";s:9:\"Last Name\";s:11:\"description\";s:0:\"\";s:8:\"required\";s:2:\"No\";s:18:\"overwrite-existing\";s:2:\"No\";s:9:\"row-count\";s:1:\"5\";s:24:\"allowed-image-extensions\";s:2:\".*\";s:25:\"allowed-upload-extensions\";s:2:\".*\";s:11:\"avatar-size\";s:3:\"100\";s:11:\"date-format\";s:8:\"mm/dd/yy\";s:18:\"terms-of-agreement\";s:0:\"\";s:7:\"options\";s:0:\"\";s:6:\"labels\";s:0:\"\";s:10:\"public-key\";s:0:\"\";s:11:\"private-key\";s:0:\"\";s:13:\"default-value\";s:0:\"\";s:14:\"default-option\";s:0:\"\";s:15:\"default-options\";s:0:\"\";s:15:\"default-content\";s:0:\"\";}i:4;a:21:{s:2:\"id\";i:5;s:5:\"field\";s:18:\"Default - Nickname\";s:9:\"meta-name\";s:8:\"nickname\";s:11:\"field-title\";s:8:\"Nickname\";s:11:\"description\";s:0:\"\";s:8:\"required\";s:2:\"No\";s:18:\"overwrite-existing\";s:2:\"No\";s:9:\"row-count\";s:1:\"5\";s:24:\"allowed-image-extensions\";s:2:\".*\";s:25:\"allowed-upload-extensions\";s:2:\".*\";s:11:\"avatar-size\";s:3:\"100\";s:11:\"date-format\";s:8:\"mm/dd/yy\";s:18:\"terms-of-agreement\";s:0:\"\";s:7:\"options\";s:0:\"\";s:6:\"labels\";s:0:\"\";s:10:\"public-key\";s:0:\"\";s:11:\"private-key\";s:0:\"\";s:13:\"default-value\";s:0:\"\";s:14:\"default-option\";s:0:\"\";s:15:\"default-options\";s:0:\"\";s:15:\"default-content\";s:0:\"\";}i:5;a:21:{s:2:\"id\";i:6;s:5:\"field\";s:34:\"Default - Display name publicly as\";s:9:\"meta-name\";s:0:\"\";s:11:\"field-title\";s:24:\"Display name publicly as\";s:11:\"description\";s:0:\"\";s:8:\"required\";s:2:\"No\";s:18:\"overwrite-existing\";s:2:\"No\";s:9:\"row-count\";s:1:\"5\";s:24:\"allowed-image-extensions\";s:2:\".*\";s:25:\"allowed-upload-extensions\";s:2:\".*\";s:11:\"avatar-size\";s:3:\"100\";s:11:\"date-format\";s:8:\"mm/dd/yy\";s:18:\"terms-of-agreement\";s:0:\"\";s:7:\"options\";s:0:\"\";s:6:\"labels\";s:0:\"\";s:10:\"public-key\";s:0:\"\";s:11:\"private-key\";s:0:\"\";s:13:\"default-value\";s:0:\"\";s:14:\"default-option\";s:0:\"\";s:15:\"default-options\";s:0:\"\";s:15:\"default-content\";s:0:\"\";}i:6;a:21:{s:2:\"id\";i:7;s:5:\"field\";s:32:\"Default - Contact Info (Heading)\";s:9:\"meta-name\";s:0:\"\";s:11:\"field-title\";s:12:\"Contact Info\";s:11:\"description\";s:0:\"\";s:8:\"required\";s:2:\"No\";s:18:\"overwrite-existing\";s:2:\"No\";s:9:\"row-count\";s:1:\"5\";s:24:\"allowed-image-extensions\";s:2:\".*\";s:25:\"allowed-upload-extensions\";s:2:\".*\";s:11:\"avatar-size\";s:3:\"100\";s:11:\"date-format\";s:8:\"mm/dd/yy\";s:18:\"terms-of-agreement\";s:0:\"\";s:7:\"options\";s:0:\"\";s:6:\"labels\";s:0:\"\";s:10:\"public-key\";s:0:\"\";s:11:\"private-key\";s:0:\"\";s:13:\"default-value\";s:0:\"\";s:14:\"default-option\";s:0:\"\";s:15:\"default-options\";s:0:\"\";s:15:\"default-content\";s:0:\"\";}i:7;a:21:{s:2:\"id\";i:8;s:5:\"field\";s:16:\"Default - E-mail\";s:9:\"meta-name\";s:0:\"\";s:11:\"field-title\";s:6:\"E-mail\";s:11:\"description\";s:0:\"\";s:8:\"required\";s:3:\"Yes\";s:18:\"overwrite-existing\";s:2:\"No\";s:9:\"row-count\";s:1:\"5\";s:24:\"allowed-image-extensions\";s:2:\".*\";s:25:\"allowed-upload-extensions\";s:2:\".*\";s:11:\"avatar-size\";s:3:\"100\";s:11:\"date-format\";s:8:\"mm/dd/yy\";s:18:\"terms-of-agreement\";s:0:\"\";s:7:\"options\";s:0:\"\";s:6:\"labels\";s:0:\"\";s:10:\"public-key\";s:0:\"\";s:11:\"private-key\";s:0:\"\";s:13:\"default-value\";s:0:\"\";s:14:\"default-option\";s:0:\"\";s:15:\"default-options\";s:0:\"\";s:15:\"default-content\";s:0:\"\";}i:8;a:21:{s:2:\"id\";i:9;s:5:\"field\";s:17:\"Default - Website\";s:9:\"meta-name\";s:0:\"\";s:11:\"field-title\";s:7:\"Website\";s:11:\"description\";s:0:\"\";s:8:\"required\";s:2:\"No\";s:18:\"overwrite-existing\";s:2:\"No\";s:9:\"row-count\";s:1:\"5\";s:24:\"allowed-image-extensions\";s:2:\".*\";s:25:\"allowed-upload-extensions\";s:2:\".*\";s:11:\"avatar-size\";s:3:\"100\";s:11:\"date-format\";s:8:\"mm/dd/yy\";s:18:\"terms-of-agreement\";s:0:\"\";s:7:\"options\";s:0:\"\";s:6:\"labels\";s:0:\"\";s:10:\"public-key\";s:0:\"\";s:11:\"private-key\";s:0:\"\";s:13:\"default-value\";s:0:\"\";s:14:\"default-option\";s:0:\"\";s:15:\"default-options\";s:0:\"\";s:15:\"default-content\";s:0:\"\";}i:9;a:21:{s:2:\"id\";i:10;s:5:\"field\";s:34:\"Default - About Yourself (Heading)\";s:9:\"meta-name\";s:0:\"\";s:11:\"field-title\";s:14:\"About Yourself\";s:11:\"description\";s:0:\"\";s:8:\"required\";s:2:\"No\";s:18:\"overwrite-existing\";s:2:\"No\";s:9:\"row-count\";s:1:\"5\";s:24:\"allowed-image-extensions\";s:2:\".*\";s:25:\"allowed-upload-extensions\";s:2:\".*\";s:11:\"avatar-size\";s:3:\"100\";s:11:\"date-format\";s:8:\"mm/dd/yy\";s:18:\"terms-of-agreement\";s:0:\"\";s:7:\"options\";s:0:\"\";s:6:\"labels\";s:0:\"\";s:10:\"public-key\";s:0:\"\";s:11:\"private-key\";s:0:\"\";s:13:\"default-value\";s:0:\"\";s:14:\"default-option\";s:0:\"\";s:15:\"default-options\";s:0:\"\";s:15:\"default-content\";s:0:\"\";}i:10;a:21:{s:2:\"id\";i:11;s:5:\"field\";s:27:\"Default - Biographical Info\";s:9:\"meta-name\";s:11:\"description\";s:11:\"field-title\";s:17:\"Biographical Info\";s:11:\"description\";s:0:\"\";s:8:\"required\";s:2:\"No\";s:18:\"overwrite-existing\";s:2:\"No\";s:9:\"row-count\";s:1:\"5\";s:24:\"allowed-image-extensions\";s:2:\".*\";s:25:\"allowed-upload-extensions\";s:2:\".*\";s:11:\"avatar-size\";s:3:\"100\";s:11:\"date-format\";s:8:\"mm/dd/yy\";s:18:\"terms-of-agreement\";s:0:\"\";s:7:\"options\";s:0:\"\";s:6:\"labels\";s:0:\"\";s:10:\"public-key\";s:0:\"\";s:11:\"private-key\";s:0:\"\";s:13:\"default-value\";s:0:\"\";s:14:\"default-option\";s:0:\"\";s:15:\"default-options\";s:0:\"\";s:15:\"default-content\";s:0:\"\";}i:11;a:21:{s:2:\"id\";i:12;s:5:\"field\";s:18:\"Default - Password\";s:9:\"meta-name\";s:0:\"\";s:11:\"field-title\";s:8:\"Password\";s:11:\"description\";s:0:\"\";s:8:\"required\";s:3:\"Yes\";s:18:\"overwrite-existing\";s:2:\"No\";s:9:\"row-count\";s:1:\"5\";s:24:\"allowed-image-extensions\";s:2:\".*\";s:25:\"allowed-upload-extensions\";s:2:\".*\";s:11:\"avatar-size\";s:3:\"100\";s:11:\"date-format\";s:8:\"mm/dd/yy\";s:18:\"terms-of-agreement\";s:0:\"\";s:7:\"options\";s:0:\"\";s:6:\"labels\";s:0:\"\";s:10:\"public-key\";s:0:\"\";s:11:\"private-key\";s:0:\"\";s:13:\"default-value\";s:0:\"\";s:14:\"default-option\";s:0:\"\";s:15:\"default-options\";s:0:\"\";s:15:\"default-content\";s:0:\"\";}i:12;a:21:{s:2:\"id\";i:13;s:5:\"field\";s:25:\"Default - Repeat Password\";s:9:\"meta-name\";s:0:\"\";s:11:\"field-title\";s:15:\"Repeat Password\";s:11:\"description\";s:0:\"\";s:8:\"required\";s:3:\"Yes\";s:18:\"overwrite-existing\";s:2:\"No\";s:9:\"row-count\";s:1:\"5\";s:24:\"allowed-image-extensions\";s:2:\".*\";s:25:\"allowed-upload-extensions\";s:2:\".*\";s:11:\"avatar-size\";s:3:\"100\";s:11:\"date-format\";s:8:\"mm/dd/yy\";s:18:\"terms-of-agreement\";s:0:\"\";s:7:\"options\";s:0:\"\";s:6:\"labels\";s:0:\"\";s:10:\"public-key\";s:0:\"\";s:11:\"private-key\";s:0:\"\";s:13:\"default-value\";s:0:\"\";s:14:\"default-option\";s:0:\"\";s:15:\"default-options\";s:0:\"\";s:15:\"default-content\";s:0:\"\";}}', 'yes'),
(23159, 'wppb_general_settings', 'a:7:{s:17:\"extraFieldsLayout\";s:7:\"default\";s:17:\"emailConfirmation\";s:2:\"no\";s:21:\"activationLandingPage\";s:0:\"\";s:11:\"rolesEditor\";s:3:\"yes\";s:9:\"loginWith\";s:13:\"usernameemail\";s:23:\"minimum_password_length\";s:0:\"\";s:25:\"minimum_password_strength\";s:0:\"\";}', 'yes'),
(23166, 'wppb_display_admin_settings', 'a:20:{s:13:\"Administrator\";s:7:\"default\";s:6:\"Author\";s:7:\"default\";s:7:\"Blocked\";s:7:\"default\";s:14:\"Booking Editor\";s:7:\"default\";s:15:\"Booking Package\";s:7:\"default\";s:11:\"Contributor\";s:7:\"default\";s:8:\"Customer\";s:7:\"default\";s:6:\"Editor\";s:7:\"default\";s:14:\"Hotel Customer\";s:7:\"default\";s:13:\"Hotel Manager\";s:7:\"default\";s:18:\"Hotel Receptionist\";s:7:\"default\";s:9:\"Keymaster\";s:7:\"default\";s:9:\"Moderator\";s:7:\"default\";s:11:\"Participant\";s:7:\"default\";s:12:\"Shop manager\";s:7:\"default\";s:9:\"Spectator\";s:7:\"default\";s:10:\"Subscriber\";s:7:\"default\";s:18:\"WP Travel Customer\";s:7:\"default\";s:5:\"milon\";s:7:\"default\";s:6:\"taibur\";s:4:\"show\";}', 'yes'),
(23176, 'wppb_content_restriction_settings', 'a:6:{s:13:\"restrict_type\";s:7:\"message\";s:12:\"redirect_url\";s:0:\"\";s:18:\"message_logged_out\";s:0:\"\";s:17:\"message_logged_in\";s:0:\"\";s:12:\"post_preview\";s:4:\"none\";s:19:\"post_preview_length\";s:2:\"20\";}', 'yes');
INSERT INTO `wp_options` (`option_id`, `option_name`, `option_value`, `autoload`) VALUES
(23178, 'wppb_private_website_settings', 'a:4:{s:15:\"private_website\";s:2:\"no\";s:11:\"redirect_to\";s:0:\"\";s:13:\"allowed_pages\";a:0:{}s:10:\"hide_menus\";s:2:\"no\";}', 'yes'),
(23181, 'wppb_pages_created', 'true', 'yes'),
(23261, 'wppb_roles_editor_capabilities', 'a:7:{s:7:\"general\";a:3:{s:5:\"label\";s:7:\"General\";s:4:\"icon\";s:19:\"dashicons-wordpress\";s:12:\"capabilities\";a:10:{i:0;s:14:\"edit_dashboard\";i:1;s:10:\"edit_files\";i:2;s:6:\"export\";i:3;s:6:\"import\";i:4;s:12:\"manage_links\";i:5;s:14:\"manage_options\";i:6;s:17:\"moderate_comments\";i:7;s:4:\"read\";i:8;s:15:\"unfiltered_html\";i:9;s:11:\"update_core\";}}s:10:\"post_types\";a:5:{s:4:\"post\";a:3:{s:5:\"label\";s:5:\"Posts\";s:4:\"icon\";s:20:\"dashicons-admin-post\";s:12:\"capabilities\";a:11:{i:0;s:10:\"edit_posts\";i:1;s:17:\"edit_others_posts\";i:2;s:13:\"publish_posts\";i:3;s:18:\"read_private_posts\";i:4;s:4:\"read\";i:5;s:12:\"delete_posts\";i:6;s:20:\"delete_private_posts\";i:7;s:22:\"delete_published_posts\";i:8;s:19:\"delete_others_posts\";i:9;s:18:\"edit_private_posts\";i:10;s:20:\"edit_published_posts\";}}s:4:\"page\";a:3:{s:5:\"label\";s:5:\"Pages\";s:4:\"icon\";s:20:\"dashicons-admin-page\";s:12:\"capabilities\";a:11:{i:0;s:10:\"edit_pages\";i:1;s:17:\"edit_others_pages\";i:2;s:13:\"publish_pages\";i:3;s:18:\"read_private_pages\";i:4;s:4:\"read\";i:5;s:12:\"delete_pages\";i:6;s:20:\"delete_private_pages\";i:7;s:22:\"delete_published_pages\";i:8;s:19:\"delete_others_pages\";i:9;s:18:\"edit_private_pages\";i:10;s:20:\"edit_published_pages\";}}s:10:\"attachment\";a:3:{s:5:\"label\";s:5:\"Media\";s:4:\"icon\";s:21:\"dashicons-admin-media\";s:12:\"capabilities\";a:2:{i:11;s:12:\"upload_files\";i:12;s:17:\"unfiltered_upload\";}}s:8:\"wp_block\";a:3:{s:5:\"label\";s:6:\"Blocks\";s:4:\"icon\";s:20:\"dashicons-admin-post\";s:12:\"capabilities\";a:6:{i:0;s:11:\"edit_blocks\";i:2;s:14:\"publish_blocks\";i:3;s:19:\"read_private_blocks\";i:5;s:13:\"delete_blocks\";i:6;s:21:\"delete_private_blocks\";i:9;s:19:\"edit_private_blocks\";}}s:11:\"site-review\";a:3:{s:5:\"label\";s:7:\"Reviews\";s:4:\"icon\";s:19:\"dashicons-star-half\";s:12:\"capabilities\";a:1:{i:11;s:18:\"create_site-review\";}}}s:10:\"taxonomies\";a:3:{s:5:\"label\";s:10:\"Taxonomies\";s:4:\"icon\";s:0:\"\";s:12:\"capabilities\";a:8:{i:0;s:17:\"manage_categories\";i:1;s:15:\"edit_categories\";i:2;s:17:\"delete_categories\";i:3;s:17:\"assign_categories\";i:4;s:16:\"manage_post_tags\";i:5;s:14:\"edit_post_tags\";i:6;s:16:\"delete_post_tags\";i:7;s:16:\"assign_post_tags\";}}s:10:\"appearance\";a:3:{s:5:\"label\";s:10:\"Appearance\";s:4:\"icon\";s:26:\"dashicons-admin-appearance\";s:12:\"capabilities\";a:6:{i:0;s:13:\"delete_themes\";i:1;s:18:\"edit_theme_options\";i:2;s:11:\"edit_themes\";i:3;s:14:\"install_themes\";i:4;s:13:\"switch_themes\";i:5;s:13:\"update_themes\";}}s:7:\"plugins\";a:3:{s:5:\"label\";s:7:\"Plugins\";s:4:\"icon\";s:23:\"dashicons-admin-plugins\";s:12:\"capabilities\";a:5:{i:0;s:16:\"activate_plugins\";i:1;s:14:\"delete_plugins\";i:2;s:12:\"edit_plugins\";i:3;s:15:\"install_plugins\";i:4;s:14:\"update_plugins\";}}s:5:\"users\";a:3:{s:5:\"label\";s:5:\"Users\";s:4:\"icon\";s:21:\"dashicons-admin-users\";s:12:\"capabilities\";a:11:{i:0;s:9:\"add_users\";i:1;s:12:\"create_roles\";i:2;s:12:\"create_users\";i:3;s:12:\"delete_roles\";i:4;s:12:\"delete_users\";i:5;s:10:\"edit_roles\";i:6;s:10:\"edit_users\";i:7;s:10:\"list_roles\";i:8;s:10:\"list_users\";i:9;s:13:\"promote_users\";i:10;s:12:\"remove_users\";}}s:6:\"custom\";a:3:{s:5:\"label\";s:6:\"Custom\";s:4:\"icon\";s:0:\"\";s:12:\"capabilities\";a:178:{i:0;s:14:\"ure_edit_roles\";i:1;s:16:\"ure_create_roles\";i:2;s:16:\"ure_delete_roles\";i:3;s:23:\"ure_create_capabilities\";i:4;s:23:\"ure_delete_capabilities\";i:5;s:18:\"ure_manage_options\";i:6;s:15:\"ure_reset_roles\";i:7;s:13:\"wplc_ma_agent\";i:8;s:24:\"edit_wplc_quick_response\";i:9;s:30:\"edit_other_wplc_quick_response\";i:10;s:27:\"publish_wplc_quick_response\";i:11;s:24:\"read_wplc_quick_response\";i:12;s:32:\"read_private_wplc_quick_response\";i:13;s:26:\"delete_wplc_quick_response\";i:14;s:10:\"copy_posts\";i:15;s:18:\"manage_woocommerce\";i:16;s:24:\"view_woocommerce_reports\";i:17;s:12:\"edit_product\";i:18;s:12:\"read_product\";i:19;s:14:\"delete_product\";i:20;s:13:\"edit_products\";i:21;s:20:\"edit_others_products\";i:22;s:16:\"publish_products\";i:23;s:21:\"read_private_products\";i:24;s:15:\"delete_products\";i:25;s:23:\"delete_private_products\";i:26;s:25:\"delete_published_products\";i:27;s:22:\"delete_others_products\";i:28;s:21:\"edit_private_products\";i:29;s:23:\"edit_published_products\";i:30;s:20:\"manage_product_terms\";i:31;s:18:\"edit_product_terms\";i:32;s:20:\"delete_product_terms\";i:33;s:20:\"assign_product_terms\";i:34;s:15:\"edit_shop_order\";i:35;s:15:\"read_shop_order\";i:36;s:17:\"delete_shop_order\";i:37;s:16:\"edit_shop_orders\";i:38;s:23:\"edit_others_shop_orders\";i:39;s:19:\"publish_shop_orders\";i:40;s:24:\"read_private_shop_orders\";i:41;s:18:\"delete_shop_orders\";i:42;s:26:\"delete_private_shop_orders\";i:43;s:28:\"delete_published_shop_orders\";i:44;s:25:\"delete_others_shop_orders\";i:45;s:24:\"edit_private_shop_orders\";i:46;s:26:\"edit_published_shop_orders\";i:47;s:23:\"manage_shop_order_terms\";i:48;s:21:\"edit_shop_order_terms\";i:49;s:23:\"delete_shop_order_terms\";i:50;s:23:\"assign_shop_order_terms\";i:51;s:16:\"edit_shop_coupon\";i:52;s:16:\"read_shop_coupon\";i:53;s:18:\"delete_shop_coupon\";i:54;s:17:\"edit_shop_coupons\";i:55;s:24:\"edit_others_shop_coupons\";i:56;s:20:\"publish_shop_coupons\";i:57;s:25:\"read_private_shop_coupons\";i:58;s:19:\"delete_shop_coupons\";i:59;s:27:\"delete_private_shop_coupons\";i:60;s:29:\"delete_published_shop_coupons\";i:61;s:26:\"delete_others_shop_coupons\";i:62;s:25:\"edit_private_shop_coupons\";i:63;s:27:\"edit_published_shop_coupons\";i:64;s:24:\"manage_shop_coupon_terms\";i:65;s:22:\"edit_shop_coupon_terms\";i:66;s:24:\"delete_shop_coupon_terms\";i:67;s:24:\"assign_shop_coupon_terms\";i:68;s:16:\"publish_hb_rooms\";i:69;s:15:\"delete_hb_rooms\";i:70;s:25:\"delete_published_hb_rooms\";i:71;s:23:\"delete_private_hb_rooms\";i:72;s:22:\"delete_others_hb_rooms\";i:73;s:20:\"edit_others_hb_rooms\";i:74;s:13:\"edit_hb_rooms\";i:75;s:23:\"edit_published_hb_rooms\";i:76;s:21:\"edit_private_hb_rooms\";i:77;s:19:\"publish_hb_bookings\";i:78;s:18:\"delete_hb_bookings\";i:79;s:28:\"delete_published_hb_bookings\";i:80;s:26:\"delete_private_hb_bookings\";i:81;s:25:\"delete_others_hb_bookings\";i:82;s:23:\"edit_others_hb_bookings\";i:83;s:16:\"edit_hb_bookings\";i:84;s:26:\"edit_published_hb_bookings\";i:85;s:24:\"edit_private_hb_bookings\";i:86;s:17:\"manage_hb_booking\";i:87;s:17:\"manage_awebooking\";i:88;s:26:\"manage_awebooking_settings\";i:89;s:15:\"edit_awebooking\";i:90;s:15:\"read_awebooking\";i:91;s:17:\"delete_awebooking\";i:92;s:16:\"edit_awebookings\";i:93;s:23:\"edit_others_awebookings\";i:94;s:19:\"publish_awebookings\";i:95;s:24:\"read_private_awebookings\";i:96;s:18:\"delete_awebookings\";i:97;s:26:\"delete_private_awebookings\";i:98;s:28:\"delete_published_awebookings\";i:99;s:25:\"delete_others_awebookings\";i:100;s:24:\"edit_private_awebookings\";i:101;s:26:\"edit_published_awebookings\";i:102;s:23:\"manage_awebooking_terms\";i:103;s:21:\"edit_awebooking_terms\";i:104;s:23:\"delete_awebooking_terms\";i:105;s:23:\"assign_awebooking_terms\";i:106;s:14:\"edit_room_type\";i:107;s:14:\"read_room_type\";i:108;s:16:\"delete_room_type\";i:109;s:15:\"edit_room_types\";i:110;s:22:\"edit_others_room_types\";i:111;s:18:\"publish_room_types\";i:112;s:23:\"read_private_room_types\";i:113;s:17:\"delete_room_types\";i:114;s:25:\"delete_private_room_types\";i:115;s:27:\"delete_published_room_types\";i:116;s:24:\"delete_others_room_types\";i:117;s:23:\"edit_private_room_types\";i:118;s:25:\"edit_published_room_types\";i:119;s:22:\"manage_room_type_terms\";i:120;s:20:\"edit_room_type_terms\";i:121;s:22:\"delete_room_type_terms\";i:122;s:22:\"assign_room_type_terms\";i:123;s:18:\"edit_hotel_service\";i:124;s:18:\"read_hotel_service\";i:125;s:20:\"delete_hotel_service\";i:126;s:19:\"edit_hotel_services\";i:127;s:26:\"edit_others_hotel_services\";i:128;s:22:\"publish_hotel_services\";i:129;s:27:\"read_private_hotel_services\";i:130;s:21:\"delete_hotel_services\";i:131;s:29:\"delete_private_hotel_services\";i:132;s:31:\"delete_published_hotel_services\";i:133;s:28:\"delete_others_hotel_services\";i:134;s:27:\"edit_private_hotel_services\";i:135;s:29:\"edit_published_hotel_services\";i:136;s:26:\"manage_hotel_service_terms\";i:137;s:24:\"edit_hotel_service_terms\";i:138;s:26:\"delete_hotel_service_terms\";i:139;s:26:\"assign_hotel_service_terms\";i:140;s:19:\"edit_hotel_location\";i:141;s:19:\"read_hotel_location\";i:142;s:21:\"delete_hotel_location\";i:143;s:20:\"edit_hotel_locations\";i:144;s:27:\"edit_others_hotel_locations\";i:145;s:23:\"publish_hotel_locations\";i:146;s:28:\"read_private_hotel_locations\";i:147;s:22:\"delete_hotel_locations\";i:148;s:30:\"delete_private_hotel_locations\";i:149;s:32:\"delete_published_hotel_locations\";i:150;s:29:\"delete_others_hotel_locations\";i:151;s:28:\"edit_private_hotel_locations\";i:152;s:30:\"edit_published_hotel_locations\";i:153;s:27:\"manage_hotel_location_terms\";i:154;s:25:\"edit_hotel_location_terms\";i:155;s:27:\"delete_hotel_location_terms\";i:156;s:27:\"assign_hotel_location_terms\";i:157;s:15:\"booking_package\";i:158;s:12:\"create_posts\";i:159;s:16:\"edit_attachments\";i:160;s:18:\"delete_attachments\";i:161;s:23:\"read_others_attachments\";i:162;s:23:\"edit_others_attachments\";i:163;s:25:\"delete_others_attachments\";i:164;s:23:\"edit_users_higher_level\";i:165;s:25:\"delete_users_higher_level\";i:166;s:26:\"promote_users_higher_level\";i:167;s:29:\"promote_users_to_higher_level\";i:168;s:15:\"edit_role_menus\";i:169;s:27:\"edit_posts_role_permissions\";i:170;s:27:\"edit_pages_role_permissions\";i:171;s:25:\"edit_nav_menu_permissions\";i:172;s:23:\"edit_content_shortcodes\";i:173;s:25:\"delete_content_shortcodes\";i:174;s:20:\"edit_login_redirects\";i:175;s:22:\"delete_login_redirects\";i:176;s:15:\"bulk_edit_roles\";i:177;s:23:\"edit_widget_permissions\";}}}', 'yes'),
(23523, 'WPLANG', '', 'yes'),
(23524, 'new_admin_email', 'admin@gmail.com', 'yes'),
(25055, 'Tourlocation_children', 'a:0:{}', 'yes'),
(25061, 'Tourprice_children', 'a:0:{}', 'yes'),
(26022, 'gdgallery_version', '1.1.0', 'yes'),
(26023, 'widget_gdgallery_widget', 'a:1:{s:12:\"_multiwidget\";i:1;}', 'yes'),
(27623, '_wp_session_expires_aa363a59acec1c70fe9c12e46cae6f93', '1559119085', 'no'),
(27631, '_wp_session_4c16c89334e3ccd2648b408a5e3d7f4f', 'a:0:{}', 'no'),
(27632, '_wp_session_expires_4c16c89334e3ccd2648b408a5e3d7f4f', '1559119086', 'no'),
(27661, '_wp_session_expires_8e9b703991fe20514990ca5ddd49b2ae', '1559119145', 'no'),
(27908, '_wp_session_8e9b703991fe20514990ca5ddd49b2ae', 'a:0:{}', 'no'),
(27909, '_wp_session_aa363a59acec1c70fe9c12e46cae6f93', 'a:0:{}', 'no'),
(28023, 'wpaft_db_version', '0.0.1', 'yes'),
(28024, 'wpaft_configuration', 'a:3:{s:9:\"checkedin\";a:2:{s:4:\"type\";s:4:\"text\";s:8:\"taxonomy\";s:8:\"category\";}s:10:\"checkedin2\";a:2:{s:4:\"type\";s:5:\"image\";s:8:\"taxonomy\";s:8:\"category\";}s:8:\"tesstttt\";a:2:{s:4:\"type\";s:4:\"text\";s:8:\"taxonomy\";s:8:\"category\";}}', 'yes'),
(28031, 'category_children', 'a:0:{}', 'yes'),
(28081, 'theme_mods_hazproject23.05.2019', 'a:4:{i:0;b:0;s:18:\"nav_menu_locations\";a:1:{s:6:\"menu-1\";i:2;}s:18:\"custom_css_post_id\";i:-1;s:16:\"sidebars_widgets\";a:2:{s:4:\"time\";i:1559504133;s:4:\"data\";a:8:{s:19:\"wp_inactive_widgets\";a:0:{}s:9:\"sidebar-1\";a:5:{i:0;s:8:\"search-2\";i:1;s:14:\"recent-posts-2\";i:2;s:17:\"recent-comments-2\";i:3;s:10:\"archives-2\";i:4;s:6:\"meta-2\";}s:7:\"footer1\";a:0:{}s:7:\"footer2\";a:0:{}s:7:\"footer3\";a:0:{}s:7:\"footer4\";a:1:{i:0;s:12:\"categories-2\";}s:18:\"footerbottom-right\";a:0:{}s:12:\"page_sidebar\";a:0:{}}}}', 'yes'),
(28102, '_site_transient_update_themes', 'O:8:\"stdClass\":4:{s:12:\"last_checked\";i:1570182096;s:7:\"checked\";a:9:{s:21:\"hazproject - Copy (2)\";s:5:\"1.0.0\";s:21:\"hazproject - Copy (3)\";s:5:\"1.0.0\";s:21:\"hazproject - Copy (4)\";s:5:\"1.0.0\";s:17:\"hazproject - Copy\";s:5:\"1.0.0\";s:10:\"hazproject\";s:5:\"1.0.0\";s:21:\"hazproject_11_07_2019\";s:5:\"1.0.0\";s:13:\"hazproject_21\";s:5:\"1.0.0\";s:16:\"hazproject_local\";s:5:\"1.0.0\";s:17:\"hazproject_recent\";s:5:\"1.0.0\";}s:8:\"response\";a:0:{}s:12:\"translations\";a:0:{}}', 'no'),
(28134, 'hotels_children', 'a:0:{}', 'yes'),
(28135, 'destino_children', 'a:0:{}', 'yes'),
(28163, 'cptui_new_install', 'false', 'yes'),
(28164, 'cptui_post_types', 'a:1:{s:11:\"main_hotels\";a:28:{s:4:\"name\";s:11:\"main_hotels\";s:5:\"label\";s:11:\"main_hotels\";s:14:\"singular_label\";s:11:\"Main Hotels\";s:11:\"description\";s:0:\"\";s:6:\"public\";s:4:\"true\";s:18:\"publicly_queryable\";s:4:\"true\";s:7:\"show_ui\";s:4:\"true\";s:17:\"show_in_nav_menus\";s:4:\"true\";s:12:\"show_in_rest\";s:5:\"false\";s:9:\"rest_base\";s:0:\"\";s:11:\"has_archive\";s:5:\"false\";s:18:\"has_archive_string\";s:0:\"\";s:19:\"exclude_from_search\";s:5:\"false\";s:15:\"capability_type\";s:4:\"post\";s:12:\"hierarchical\";s:5:\"false\";s:7:\"rewrite\";s:4:\"true\";s:12:\"rewrite_slug\";s:0:\"\";s:17:\"rewrite_withfront\";s:4:\"true\";s:9:\"query_var\";s:4:\"true\";s:14:\"query_var_slug\";s:0:\"\";s:13:\"menu_position\";s:0:\"\";s:12:\"show_in_menu\";s:4:\"true\";s:19:\"show_in_menu_string\";s:0:\"\";s:9:\"menu_icon\";s:0:\"\";s:8:\"supports\";a:12:{i:0;s:5:\"title\";i:1;s:6:\"editor\";i:2;s:9:\"thumbnail\";i:3;s:7:\"excerpt\";i:4;s:10:\"trackbacks\";i:5;s:13:\"custom-fields\";i:6;s:8:\"comments\";i:7;s:9:\"revisions\";i:8;s:6:\"author\";i:9;s:15:\"page-attributes\";i:10;s:12:\"post-formats\";i:11;s:4:\"none\";}s:10:\"taxonomies\";a:0:{}s:6:\"labels\";a:23:{s:14:\"featured_image\";s:14:\"Featured Image\";s:9:\"menu_name\";s:0:\"\";s:9:\"all_items\";s:0:\"\";s:7:\"add_new\";s:0:\"\";s:12:\"add_new_item\";s:0:\"\";s:9:\"edit_item\";s:0:\"\";s:8:\"new_item\";s:0:\"\";s:9:\"view_item\";s:0:\"\";s:10:\"view_items\";s:0:\"\";s:12:\"search_items\";s:0:\"\";s:9:\"not_found\";s:0:\"\";s:18:\"not_found_in_trash\";s:0:\"\";s:17:\"parent_item_colon\";s:0:\"\";s:18:\"set_featured_image\";s:0:\"\";s:21:\"remove_featured_image\";s:0:\"\";s:18:\"use_featured_image\";s:0:\"\";s:8:\"archives\";s:0:\"\";s:16:\"insert_into_item\";s:0:\"\";s:21:\"uploaded_to_this_item\";s:0:\"\";s:17:\"filter_items_list\";s:0:\"\";s:21:\"items_list_navigation\";s:0:\"\";s:10:\"items_list\";s:0:\"\";s:10:\"attributes\";s:0:\"\";}s:15:\"custom_supports\";s:0:\"\";}}', 'yes'),
(28170, 'WPCF_VERSION', '2.3.5', 'no'),
(28171, 'wpcf-version', '2.3.5', 'yes');
INSERT INTO `wp_options` (`option_id`, `option_name`, `option_value`, `autoload`) VALUES
(28172, 'wp_installer_settings', 'eJzs/flyI9mVJoj/XTLTO/igppSMFsF9iWAuNQwGI5OqWKggI0NpPW0YB+AkPAOAQ+4AGcw2mdVjdJvNmOlFxn5mepR6gd8rzD3bvecuDoCZqSxVtXqmWxmEL9fvctbvfCc/2T/5783J7t5Jpy5mVVPOq7osms7n+cke/HBw0rmfTcbw713+9zCf5/hvvNPcWA47nzcn+0/p0u58VHTvq3o4q4um6U4W43k5Lqe3i3zcnY0Xt+UUrjbPmeaTAv9z56Tz4fL1q6ybXY+K7IO59RJuzV6rW7NLeyuMdVZXw8Vg3rXPoEfgOE46i3qMFx6ddEbz+aw52d6GkW1V9S38fc9cbT606H0sHpreJJ/mt8WkmM57fN/+bnzfdj4YVIvpfBtubLZlHM1iNqvqeW+e3zY8R+XJjpq8pQPcf5Z40U1VLybN9ryalYOueS7+Yl74pz81J2aKZ/ngoxkvvm0f3rZ3sH90dLRv/nnsrYddubZx7JrPHBbNoC5n87Kiqd0xt8MiDKrJbFzMi4xft5ndVtUwM2PL8ulDphc1gxnZzMrpYLwYmj9l+bip/Cs+VNVZNZkU9aDIeMa24HXm88uJebpM/FFq4u9n3UE1nZv12V7MxlU+bLb3dnYPtnee4jXdcXVb7XZ3drdmU1zdw5OO2UFF3fkcVsI8FOasNrfLH57a7SOTaD7cDMXbqWZU08EDLmm4lHs8h/7+POUbkvNqdjgPbVaXgwJGsnv4DK49hj3Utxf35g8z+vl4d/cpvGwvcUFvXnya46vMsNtGET65nN5Ucs93RV6PHzL9O37Z09TLij8uyrt8jDOIE3F0vLcbbOTjxML9cz4cdudVd5DX8y9pl+JtT0HUTIt7s09gfndO/jvt7MXsts6HhfqjeSpJDDpbx3S4zDiP6AAnJMxg0uD0wVX7LJCaeW1+7c7rfNqMc/pYc27gkmORWe63rhMIcNk+LwJeNimGZR4+6ID3xH1VDXiXe2OCaw7hGrP85gvvyvmDOUeTJrroiEcE2z03wg2u6h5Hlx3zt/UXw+FDPAVwyVPabPngZoL/xq12yB+Rj8fdcgKHEGcKJ3RXPjAvx4OR+RVe3r2f4RW7vGvMSWyKKnrZ7h69DTYLTf4+rbK5/q4s7ulvBzyP86oaN8W8OzEncFzwZNd0Injb8qKVg48PXfOej/SAIxa5+KtZZiP774xURCkyrO6nKBpk75g/7z4NjjTcs5c+0bupE332+mr943y89DQfHe8+W32Yj4LDLAP4K51k/orHn+Kdv5/iv5/iX+oUh4q5b/R92zHeSx3j5+aG9c/x3qpzvIZSPg7OsR3B39hBPnz2Uw7ys0ee46Wnb2/1adhv3/0Hqzb/4fK9fxRs/eN45z9dsfHbdvCf/mSGd7i7Y/ZNaKCDvI9ny9vRrSrh76a7nWGe36N4fo8ToiOc4NazGs/wIU9wP2/KQYaC5q6oG/OrmmJv8uCFzd/YdCU2Kjr2sZZefbKNm7vzGFMK/G7zjs4aQiO9x+E80B6vzf7G4WbzRT1tVNRAP2sru5hnRu412dwunJI8GUx3bQ60ORlDs/nH1X3jfjfngZdDlnAwyqe3Be+QvWc7R2YFvhgdfHWwtbf17Itt819fLMZf/fpX//DFuPzqpvxUmIdmN/nczEBR12Z3zEf5PBvls5kRuMPsflRMcWDNqLrvLaby5mLYg53Tm1XNvMkq/PysNIMczMu7YuuLbfP0X//qi23zLnn7U3r7aP+rl+a1jfnXPlyCo8nM/4EBXUzMZrgz74VXmuebuYAda75pOMaPXTTzapLdjPPbDDdrRrsw6z9kiwaucJM8zWEo2enlhZEezbwwV1U38oRBNbSjlJe/pNmA72gWRXZfzkfZ1wszuf2ivoWDMvjorYyZG7PEZkmyzqgubjpZPjf2X9/c0WT38JPZGfmsGK54TzUYLGqwG2myb4q5UQ3mX+pVDYnGrC7MrhrSEg0r85ppBWtlvtI8rRijKZldvMgeinn40ndFU43vcLVB+prH9s0OnD/wIPrF/L4wb8dzcX1fmtcXRkbn8C2w8SqzIDVv56blg7LLby6zN5Uxpwr6FHwYHwGzN2AVzGzBpeahWfMw6Vdjs8JgeYWPfD8bwibDfWAkf7FtTOsin3RvyvHcDGRe4S/GJCiauYg4+Gt+V5XDbFiY3TuEMAN9XkOLuc5H2NXHxV1Mp8XAbKa8fjC6qs6NuTEbZRuzJ9nc7MB78x39ApXScAiDNe/P3AnJLsFiy67z/ths5tIM1AiTCcxDdk5rVdVrjYKPeAZRzeymNtt3Blu/vyjHRrQ2OA7YCfn4Pn9oMnOEZgUYauvtP3pHXUwqo5C9TYebGB5sdp3ZenPzSCMXxqW5u7yhpaHTZF43ydGANqewMB84LD5tzUazdU7YEOTrAOeLBNAE5vvWrFld0DSaafV35HqPNftkgudoZOWw3RelebzZMB/MSI08bdvPWiyqwcADX5uFrBZgcdCjw0ec4oYgCca3gH7s8SHtjfKmp+e6xxvb7W+UeQXNct7wiYJv6pkNbk7TLG8aWAgn2vDHef6pmlaTB3OVFsLmf0DwFrlRRS2yl4YM78tZNMDAZTfjD9+YN+F2NxLhdGoEMMwI/NGsfZHRBli2u9d4hTH0jeNQm8tuymI87OC7zB+HJexAc32HfsAXwQ32ZdlL48WaxR/extJvnRef1kbuGlF6CSqN33tlPJ7BCKTvpJOB8/TTv+8C1dbz6lMHJ+ynPO/9u1eJafi2HBbVj5uHDnx79ia/K2/J7eHHZOO8X4zT3+7p+OOtXafll202q+iVqB6MCqNhRRMNy5ubAixFEe8N7HEW3sFnXYA7AcMyD2SRNC77NUhtUJxnldE6A6dIi2mzqMl20pow1hHBCerXco5aDZiU6DCzlg+NKKIjfHUNp3fB+q1f3ICdeGb+n6QQ6ryfDvLF7WiencOzTrKzsTn32WegWntvyd1+zQ6eWdfa2MzwvqaakNho6KX4Ojy5CzM55j8HRhE/tIlRMQTxaXh/Y7YE3K3sIW0JfV/1afaMVp/XYpXm5ZRuMpc1o7SQNdcZu6TgV5pPBZlmjLk8Gxc3c7NDalJ4sGVfwSeYrQhm8204XVdml/7Loh6WzcheYuSv+c4C9nhn8LHfSY4AjVsatP6kujC6ZkAWFewZNP/YjpDrULGXxkSorYoGqUF/oRvSdg2+9GJ6U2X96hOsFyznZ414r5nxKMwRaB0u2hJkj96PSiOfxACwmt/YKqQc8Hr9XUaQtpodiePQ77MxXYHsNQ80SgaOJS/3Yj4ycwPWSHgkSdKID2dFFUt3mFZ8qDGQ6EzeGiOv5XTTo2RuPIFFk6DsbkiB1qijzHVof/7B/F+zOjfl7aLGKUjLRLSV4L7FtATnwEgjY+8N5mBfmXGHfoB7ZfJppMYbf7C8y8zTeDPBQxq06mJ55twg6/wY8YeOo5F17DQYsVmgWMRNbNxb0o0ocZSoNhM9TIsXtGpA6Zl1H5njNx4seJ846yi48ZoNjAzcZNoGsCuMAMruclhEPsSlmfKpMXgzq7vNI81ZNodkFh9fGo41SM3gcZ9uZ1ejapaxhDOPnsJGHBqnrwST0YgJcEDXMN+sMCtB2Jhnk2Ti0EO2kdj6Vx8gsiSB9icpdXfEyu5AK7sDpxT+wde5aAHCgHswgt6kmOc9IwB6s7qsanivs/7Ijce7WDbAfTjyDO5DwSH3bYWW3oHVUOFg1Dx7BjZFUmFS+Ayy3kCfuln0uzcV+Briw5HRumW8vftNjNDRAc/RH0YnBPaAPWlqHsyylJ/gjaiECysD4FajZcwV1dQIMHy7mIJb2fXI6MxRMZ7hkTJ/WhjL25hjdZ7d14B2cEZ2j4IR5i8gnv0hyM5oCnN6nPOLy22VRmP+OQAjAO3ZpJlzuMLI0d87hXGCiTMUz8bYXtVi7nQyuM1s40QrmbQ1/sHT1uobUDlE3wGesRzanI1cFNmpyamGQ5RIffA5wErAqfXmlPYL6jGya3gNo8dxSEA+21yJ1otxia6VRjr3NZK62T+U5qyal0+sgfhdlTekcN9U2ZkZzW1l7L3nMO4NEv1P/IfaEAhvfxBUMv+yDcnLUuG1nHxto5DxqOA0x/a6HfTBzgFLHFBq5nSas2SE0ICGV9o3gCcQDrsjcTRQ58UUpnqY3H4HYmW7SN67wuwgo1LvjYC9hakamDNijtSwMo7ZkKxddISNXZPXLOJvQAIU5s3pt6Tfgdrtk528eLuZZTazszCKrWwgjJjjy9GKQ7PUFyGpN++Hb3amj5LpxhZ+++rV6fXF2zdgUYNiMAqopBj32Ten707Prs/fZVfn18mX7K1zhq0iFusDnv0cLQAypIxg3uhY46DzJGn8rX+as3k5KUA4VFMr+7Pub27nn2fGwIUN2dB+dHFZEL4jDKiNFuaH6WLShzN/Q2qCfOW0FKTDPKh4LbT2xfd6IbsbVKJgYNTm1MEwkw+NxNFiClPB5kvz0MzNCWYHfsU3+s9PRIaNGALfFP7g2zHmTfDlYCZZKyYDy5iONI0iPSnR+LWkem3z9eb3H/J6iJsOIuM2entNuTfjqzyYZWwk8AQn2g+NZ8HGRhuKDya+/EXZ/HERDPKK5BceZGOHV/UkNxYgD9lznvLa2wuU40YbogmF4sROq+9gOcfL+VPG8Vg9bWi7sBMIlpa43WKFJ8UGWtkS6KrJ8hkWN7kxeN3FZkeSYZSWi7trZBgCAygfWwOItTFuR5JtMAbOLJZG6pjzsk7k8WfYNVEiRd73DQYF2aoYFJx2oXNkVr9mBy2XCHw+RJsO45dmnUmhyXTGKQJzo5FpsiMH455Nf/UaOZrkcdakSxs3jEYlMiQCgUMydy5mkSOs8xG52QEoi8KoCW4ZY+rP5UjclTC0SYFq36V6rs7ftsRhgwUSrTUsus3DdGCcgqlZEnfoTod3cKKGSwwUb8ftrG8IwpR+bfST2UrTeAlExtkwlpYHInunxT1EioyCaeag1wOjUb/teTG9NS+z+XDvkvcNnLccre97MAnu6J144O3phbU36s0evsV0yMakGYqV1CS4vy7MoMzSzTCZ76mQREbw17/6zbTfzD5fTyWCeXaf11N7Wub1Azv4Q3N+aeE6Elmv6t6gaThI7H/2iwpPnjFLZuPc2P5TGpr7QgniAOZFG02k83Af8xFOCUGVyFg05JYbj9+I3A2wCrLZaJYdg2mTski980wCEJ1FPmZDyMn3ZrDcZiBsJdYFpZXh3snMGMgcXzD3QJSAjqGZvF//Cg9UUt+9sGM+sYM9Mfb0lKFsZssVRuBA3Gs8NpY3yRdzz5yyeHSVDULfLOAMJEz5aRTgK6dkrN0Z85DjaEZVmD/JccRcKOR5jWcJ+4gSbebNxoq+C33LVPxKiWQXCcHHQkSKRKF/xwBjq3AHmGDuJlbiOIJf/6pdj6dTqzgC2MSHW/tbn7RfbebxtjcB6dczRlabZXCTI1Qge3d+dY0ucQEpdzpjVgJ6thqKTuO0U9wF3AsQl2mNCpfa6/whuAmgROYr2HwK7iC6GE7iqVGlOhf1bdkAtqH1eVXWzc4BBmUPnbU2VBoH5ceduYq0A4hBJZeN8FpujCgNmKPw5KdCnlaHx645sZhe0/7iVkdKBIJANqxSi7BfMX4DXjQFRZMRkKS1BwdphmUp7Co+dNEDJyeXTrz/sP/q6leaovpv2WtjxmWfoYX3GfkIZrAYNAJBPslnBCAZ2gwJ/gZ4MhsU0AnJ1Wbe1OxD88ezF6fXp7CP/vDq4uVLNLtb/I3Ww3F6lw/zINHACYTCX3Jll60fSQD3bf6AZ4jtPo64G98A7THYWO+uX9lTEYxfYxEuF9Pv836pjGQjokKL2uYqKcI4g4+QAAxIM9qYUxcemHsx1ZKiZ3yMC7CiIZOVthleQXQdjS38IlAYkJZuKIzG2trmVL2wj7JkdmNvP7XkUUzXSmp4C3waLxuBmVBiwV/NNr0pP8l78fFnLDuM9KkGCziItIaYE6UAmQ7DuPg7foL5YkLBlHA4imlDkwVnvF8bbw9nvO+9UBydPPv+94vCzKfKPFrZIzfbmDUJu2wDkFJNZpNxxlQuMPrOWTl+JIchjJQ1O3f4ZPUZgj18y1kyOfiiTCmUYzcaKbIpxGG970qAbzjYzYvvAseUVmKYpdZvale1DtUG3YcqkfG8yCFF95yQKGFOcOUz0aC/HVd9wHlKhnZcNRH8Kb+BuPiMAF9DJarJLZ5XsxklEyFC5Xx8Pz4JB7KvYjdh3LJ1mHamjDlsdBboK/S7J5AnoqQuzYgWRrwXfGshUO36+wmtay0qcrOMl7gYQ5ZYrFaJj/Me8e79rFm6AEb7wHd9cw2gULC9ciUs2535fGp8pIF5iT7zWhWzWBl6OdAO7NsOmIgQbpwAGCf9KrILPVU9hcRYPhhNyBZHMToqjX8BagpGAju6ZUZFw5dztFopOyowJjVi1ADP849wajt0UwkytymHRT+vO0kZub8svtA6g1fzHAT40DiXsBnf8GaEAZFNy9sWl5aDi6TJVKhvytlM/xnWLLa7Y7XIOX33usCwEFu16EmDcbrD2bF8AIg30bP3Mz5Es3xaJG3UPEjiS/QKbTYlt33/vHUXnHpHFrDCn1G0BAMd3vQoU1qbBDJ5rS9U5qG1N5R409trTQsmcDB4OWRgnbMKkWhXFUBq5oG16W2xveQWa0OZ9PPBR7OpB0WQ5dQexxrJ0eATYEcEgh2/yqVNNeJeUqjoyPmmY4QrCVxc3NEQGuUQBIrQcvrw+uycVLI4ambhr4tPc2OvwUFNvcBmh+jJl899/cGJ435hgTe0bRgjbPb/MlyEN1d+BAKEjbE7jMNcfDLuEUgs9eLUQEmtc6YXIOnwGEkvsDx32FsVQl0NG1UbEma0rBbN9hTmzciRcursq5VArt2loVTvSPzuSk+MyqyD1eHOppnhAR/Poi2ctvuYcFoSv2alDShqqOEJUTheIlrykix2WiN/pMM5FGec0eTjEgAC2MoQP0YnLUPcX5OUSueSIHZnUDuIoAAHcHJYzzMKyWJBamPI5gQejZM98rFgGt/QpJLlzKUEiybCqZQ0UpTC064HdmLgCmbBPAnRluonPIN531/+zIfcTMGiD2HQH1BxWSiH1DGkH8Qjhxc3BYL5MBqINtKi3wWWBIXuF+fcWk9O869+vsXbaJA1ux30xmEFOoldHR8NxlFInD0sfHGg9MassRwHEHY1m+b84ZvmVfCPGYqWci7RlLQmmpSNn34dVOPFBFXkywWC4XlhIIJLUMjUl+u0pgsmmYHOKrMDg610prf4iXGGyJh+/Zacfhum7tzafChiZs18gdWc+hCnEYIqiCAFj6EK2LWiLUC2GTN4xPkQBh/qFXtE8tWGYX+X3+Xs8VHMlB5MQRhIMrDFIW+0U/ZZi3RrlxAyWb9fAOweVO7lYjz+I/6LT5kHO0s+F44wGL5KZJlDYBzd70sbk5WBLQEBttqKkCNBf89lD2kK1LYHXAv4QbB72eFZALi09czJFrYoE0+xRsiLEVlobiY4ag9T1pJmk8h++r3uSUlzzgIqJVfkFIWKAgbmIkpQtjCW2+KIEHF2fSrAQz9j6gQscdlsmO2nmgMME0lMtyMJDbUi4ooBDsUsBtiJgpAKQ8AdWr445Rh4VjZGBWUGDdezxDv0EaGrtuTpcw7CvNMOJwtotzzDitCarkBHO6igvKe3Y0ADk+Tmr5c/pkf0rgCDjL73i2Ly1dak+mLb/C+BCeDIvv9YA6xZpfCMywixgHsAQ32/wJBoOW8U9BgetPiIz2mbWxHDjOTUO/RO0CT86Wgx4vb0E+FLptRtC1o653lS+InWy7OXAWmP29rDPdlxtUAzFo1YZbA3MflbfJoVdQmRMngmQxmhQNmYLskwsYs3kKVqFtLDrLEJEO6sNeLVzriiJwfBAeuFr7dJ7fIDzKYLaEw3rXVxY5TCqODySZxDJdGWzaVEKT3JhpaszTQ0ciQkaIlulE3IcpBPYsw6lILpioyx4m3iWSXmrU/F24jyUIjmzxx3RVrMxfgUii70F+OP3aExk2hG7OiapbMeONVk21M1HRmzgB6Nv60VAeotJz2NJQwruI4bWUdCeaueak5MU4IR+EcMBosFQWKeYAtYxcmBF0wSW+A2mY/5uMSijZx+qaYF5wL6D7jMS6IZGKxj69HhDlkP4CCcWCl9fK7ywXZ0ma7vg2UeFFCC6VMOOVfiJRVRycFNUQxRA+HRRbTuYlYL3hi3MW5hQhib9Zxm+1tPwRl0ET6dg8GsMDzrtDbyZhBWhLDBR//fag/WL4OU9eiSZ651nq2ycKHYkiry9NcGYUl4/unvTv+AUFqNWCP4/pyDa5jjZvyTxfKQhDeG3DzxUAuSeQ50FGS301abzcY28gTypocpFWfdk1MWxk/1RIBcdKgQJzcRCEzWX7tu96RAFDlxwUUt4V7KDrG5pDbLjlClGhm7VEoPAdwIm+7WwqQ8ry4Rq9Ena8Bxl8431T2WoYrM7Pjg8FaZdUtSmZWp8ejKISpCb1eAsjQ2WHnjAoawqzpgui+aaGIBwUXGBdap+FYJwqGLGUB/XoWqMTA6xIVknxmZRWSSLDaGBUjbM2Ri5v7EeN6vzaXhpgbb2Uv4iUtVY0U7ONYYmSCRAKGxUV4Xoak+Rd3iq0GcFMLD4vq/nV6Piq+rK8wEQXFVUQNgauWaqSwSJWvhONi8JjijxlIjaOXa6491PODE2tF+c3192fvm7dW1xPxgHeloyg3I/7ioxy1zn4bNhWXCroySXh3UCG+SGyFyjs4XS7e8SRgJGklVL1yG0bjAXqKe6gMIqOuXINqcpJ0LrArqFmYgG8XW7RYDyGbG1RnljV+oQ6tBT2ftOTfG8ZPokChFkfUrsl8okprTiWvKiXHhbqCY/WxUGkWbCsjvbB23qcMlwFIWdTa3q9A2bt8yOsOZ2BC8X9yOGEGOM2Q2HOzEqC4k1muJ0aTcWw5ofLjMrhYASzgzNk4CB8oWYJQjEJzqt0A5ZEFfdvWINQRjOPQWc4JhDo9WwWYpjlcZU7qcFDYd0ISBDcSJmJPMJ6b0UNx28OPiLjfbnaqJ2Qwlp53icGSxrBnpNzPFWUIWk7c1nCvILUuCl6sOjEQwR3eQXbxonc+zpQCY4MPiUzOhEwM1tpxR9GDyq6slf1p2IaXNyfwZ5cqQJQiLrt+2PhrJGrjj4oUvm9Do862teB7py0Rt/XFRDj4iaxuKTnKS9IaxDlMZQFZTsxbsSJWQCq1ZABFIqRqGTS9dgfoXZrsfmw3fgtq2DgIUFUKdKUfjyFHwKFiQYeH6PHzSG10tZ5a4pvhQ/wEredy+b8nB9aHEkKLQzhMtPuUAdJGQEk8bRKCR3sSIIYQopp9o/U9Cx06F/cVGaaw2uUHAxbSLBm/ZmCmdK1CqJ3OPHpEGwsQGI2LRcMCokCQ1CIkDbCV1fk/QB5cUaKS2O5Wxo8gGUC9BrSGHhMyoq+ntVwjNHTc9OUg9qDoxY+SfJe0xqqqP/vMYgsHDBYmEpk4g5uxQMeuuiF7WzDv5dBBmf2IQnpERlEJKPQmGy4UaKOooQYOoqAKCsFUt8SlBSaF2Tz3K1y/i8OpkQ13cQrqUuQKqj6VNrgxyQNraYhGS3PAHeFQyfaOfS1BCFnSSjHlEKqDVKQzWSIeRUVUjLR3RAAXEUSUatSCoCksfYx30GGtgtYXLjXiI7sOdHS2CLVyfbCFzXBoan8eKB0XUcU2VCu56sNq5jrVUoZan8mwEonnb87PGBq5VyHHdsoqwRHPCwEk/Hujzb3m5mVU7Q+tv/RQzpQRWRvVcNWEu0w6JkBzsxkMxBIL8spvFlOJx5nT1QPD0+g8bTzqx8QQcH0Zaze+r+qOAtdvwwZ6koZH3KKnZg5wM1zj3GMxgJc9f/pw7fJY1HYKkqLkfAZkEYAyEyjXsIsqAMfHcOKUEwZdCRYRpABKpsMv7BWI2Ckscl885U0DGUg157jo8xn+77oSoASCfRLnmCBUZ8DD946JYFEEqFuQZT2NYwSfwPtgRaJnW3mIT9ahTJSp/aqEr8+ovf5Z7bIGWvWWlNKETOUPJLDkkedzWaE4RGk+ZFYGosV8qCFNH/9UmZHy3uFn0J+WcY+IwC7R4Z0RHjBUATXYsqT+cdZduoTBva9VCa02NQMWcOTrDoMOE/HozE2Ggng3HONa1LSuCD2wpBw/KjdJELLATJ7O5BMcIZ+JGIHEqhO7beyBXNzZjHT4wGKIt16hlUFxt+8pNRPuqEckCxfxLqshphHSROSEoOk8zAlPqJliSisuyDHqVlNlNJhxVpLllUZloPtXoQnvhfx+y0pKd0JkNQZk5m4nth/sAbhbmR/rk6ZDrIRlhOmJYV+DpbfhQcAOahkJ/WKPfBA+/pAkIcuONDUxJ1NiWAc3rB+Ll4eIpkoWqbK+lFsOYcB8hJfD+QjYGr6nzC3KdkA4wvO3wTW3YWTYo8iumXIkTMkeB03DDU7fiBX5kmjgFSEh4x0XGD0g7kKBJc9eoQPhAWBuqn1MkDZxybFI8GVcjY7JzzohIDTAn7ybLbk6HVLLppSHTlgr8o9X1CMQmSJIxe2basqNjguh+YE4mVQ9irZhDcRWFmjEUu5aUhHnjXa/ymRp7njIGSQyKDpEd0KMHtSimhHR0csOBmSIEmq1aClblVWk0Ck0pJrkJMczj7VjSIp3l7kiu1IaGjAWC4StkYAAGhUmkXoJ1QQvH7cgFiyxbdcZe153ZLB8uu2evLpIOL/PJ8EQ5p5f/AOE9nX2LjVtdoeATty4TZTZxDygDMGxbnMkbM0v4MHO5x8bne5pwVrpp9BUGKOXzyPVq+bYop5kMnmrWVYg1ibgMc7dmjTHB/4jcsEYMkJMjQCB9XsGiEqgfQ3+I60S2nLrQnZaENAlJaRwObigchbHUZwtYUqhmALCLDlqefPb2nQfSXdvMwTVvMZdoUpO7+WCd8M1zDHbPM4ImjYqEFiUuPTa9KRxlFNFcgCToUD3atVfLS0hsjRoyM2HmdDrsGuk/HtbFtJ0nKUg0alIbUf9KNl5A2bTx/bLzT0bN1mYid3eXVSZI+AzFEi+xBXLxetkYAmkUsiAd2sOVdzLug8IoK9I7LJxZKgvqit4gtiaEEQVFhixH42GaWYT3n4aC9Kv5fFxMC8n1svaOuK61LGlSmyxdi+Ml+DW1CUOOCILA1BuUhne+cTSxukrar6TDczNcUI1tiHRJpRiD7XILhdrmpJmh1HNM42pOkHh1bRBbF11ZO+PihS2UkagEp5rxXMs7VmfokUnhfta7RToHyD4uyuFBB2l0LH7gwOVz8EmvcZLx+H5mA77dvOlqEchBkpzTty0HWBY3XQUTH2bPv/EAxEBVRSyYkEF1QRohTTCHqSk2ZQmN98pZIqxWJWZlQDssavzLGWPD6lZEJ4+hTggVyZQoqzdOmAjgR1ZdHHPvFHdaDm+nRe6nEsQnZqXmo4piGT0stuq9LqaL3oWxG05Oer15RTGKjSfZxBwOnjFnyyPJYzgP5FF4pbM2s+FAHcSjYaPHcroskz3mGdCOdUX/IbzE2ydLCX/a47nXCHUY5ByxcsQJYKZhlTdzIOpjHpLRXPBd0Z5waR7Py5S81feNeAyTfJYUbWtVwQQflgC3ND7LgNUpGmMdmde6hYEco9yzmQCURqAMtYftbYntAVIDoBd4kggal9e3C1smkdg4jy47WKvk4IwT7XkbuqiuxtHOTsKKUHoB8LMN90n1yly4ULbBaP3RcUG8C64hgAbdCSPByx8gOIaxZ0SnDBgyYodzpjluhdlAxAhcse3iPcaB2CbtqMw7iNOarwg9BMtI1AF0YddYo0UH33yNfhbMQmLOIEuBmzEmdsbRcoqMC2Dp9BFA9MMlTNjNeNGMaE6R4NO4ZuPCx4hS1RQLFptwY5JViUhKKGAfJoN3HbHrQwmB0QvjMXFZLSSzw0wGjzYszbhfI+3hFQTYgQGRYAKhC82M31T7SKsEG4Q7Ig0jaQLfEzhZNs7BNeOuQEwggxQLz/t8RSpvSIZPMTWWgRng9rCg/8ClDRIigExggwVtcrQGB7mx4I1JuNw2PnscInUllHhUzn3DMR1VtQEg9Ba8OUsVyWlLsXPtZfo62bCuZkPLhK6cJ8g8a/phNWipihRMpoQDSJ372ac8ILdIPC7xLM9iNhsgIMhIPEQ37xHAKWXPsKDKfAxhUZuEDHYF0BiYMRb8LdCBhFgJiocpzJujSQm3rvQIXr59+uYBH6FaDqNydsBQinVFrDYWYK1JAtndH5Vmq6c+hIw0S7gRFEMQb0sKJspW9xLHDSOgrMewPCVgSeDMT1NOSgSmGkMjNQWthebODN/ferb1CSxOEiitXxmbohaCi/BGZruKY70JoSHSwgGHlOYHmkvsmIiKaOuTEVuYO9JYUHsfVojh41AMw5lMvE8pJ2hAgcBjCtkJIbFwYSd3K00AoonQaxNoKuxM2usRDeUyp9zxYZv/B6g6zHbpojWPomgChqsdcUuiHZOheNiMXKKQhy5uCNym0vIAE7hhabWExpN9n39i8mbKuoIJT9oUMhLsYttIalt4AJr82MEsfyOT1VAOEGpHOWgh8SKdIzKnFpn2PZ4jSYxDQjPxKuehWVKhRErP4xtpgzrAdrC1RW4rSP+KOApm/ZdHwGT1LlaBS6MAGSLlmJFjGEfE0kaWETqIFjrUgU5Lniq5UW5TUPgXF/25rbVGXsACq6zBL+tKu0aWEUqxqcBDLQ522aO/ckRvGztUbjeLaV02BTSKSqwVcloFp5RjpBwZdbiz1rq6HKwql59OVy60ESX5T/16AVLXFmfEu4NB+aXyZTn1B0yqS/Nxnqq0RNr2yeg09e5yYwJA5GBSUQ3/FF0xe4yTFs0CC1fZrFUMlcAOYoMihZEqxt0njt4oAwCXHkNIJr1EGlfM1piuE2PtzCSOtshuRUTVL1kkNclqGiUNdCJbzCtoB8eEh6kMjwY5oqoZknu6Qnpe6XJn592B6GZp5br5OMQ+XW48nM6p8SmsryWxGfQjoCfj8UmHUyjcHxM7M3aoN+YcOfX4h0Pg4eCelID8kDa8ezu7z7o7z7p7+9nu7smB+f8P/N66B4ep3rrSi+XLo52nT3/DY/jSvn3X3A+JHqPRuvczc4d06ISWsiJLuskr4FZoclAb+dati1mlOv4+PelAZsb23lzZUxN7V1eLGc8IdASWzprQBRj7cQBZhjTthX670Dymh8BXboOM74XqnXk+tY3L1VW4DaQX6MXZq97VxfX5pVEtV71vz99dXbx9Y5shQ/S0l27KfEztNqfFmLrb2lamfNnuAc5Lnff4MtfK1PzSN6aLbm2qdsUz2BX7WzvdPqwN9pjeh49Hsv6u2ZIFtx81S/NLt/PEPsJLO54nWq5Co/uYIy3st7rsoclmq/v7T6nZaoJ/TeituGOqR3BiSbKFbY1M5DEzAYIUKHXIW4xktvQA/2eU79akYrpLSDysNQwnuqFU3AvFAXYTaBqgyRz1hAVE6Rgy8Q/VQo0e1E9XIvRD7kpnq2CBP5yLzBgbY/OOgKsCtDfoxE02aG6xcx9cAz4V5FHNx6Raye7u7O4cUSvZva1dWxeznC/SRsabFGNcwwbCwGiEPMQ6ZxvNAoLBDTp6bzF88EQXaULUnHK+ngFGmD8ycLmv8JModoxfcLQseOz3xcpJlVfaHmalZJZ4IgaO5uOl6HCEw9cBNSriso/WtjkG56/MC3pqL52ccDCsh8GwuGUkgRjAhr2DadJxE0ePBWFgMj4bn3z+FP1C1a81hm7xR5x/wqQstpXqCSeRwPFsj5MGSLekdAUtUmktZFEZ8APvUP4JjSjmgO54uDR/8Q4f3WhQzwZDmIkKAox5No8RBMjJ9nRV8Vrd/7zEB8J+fwtt/36bXb+2H4qtkqjGEphTqHyCbUcJBsYVF0TKj1Kmx3QIhOpFSDLHL4TnF9uwIjqM5oCD71hjFTwaGDTR3m8aGNGL53it167GfAB1wkHgKPCCi/VfF3BoE124MkBKocVcj2maqSdr4dqJcFLJPlkFoPVXK+PsOmOxC5+FzfKYCta2fuJaep5MS/hmmULK9s6HQZwfpTsxiU4oazYYVY0NKflbUmAPq5pvheyQkcrY4tRG+IEwosd8ZPrk/DgSS5JV5uyMbWQ01TXx+6rfxsThoVBbEjC/M7cTzbhmvpx25ahaclTC9Kwq3wk6jnGgUjcUcMVhbZq7nQ4Hpn9U5LopQuIhrRJs3Ry3nTqPro6UDwgRADkKbcLe4SH2LWzhgLvxOq9FNA0kSRjGJKCgfCKZKEpRPwQXSGB/rZnvWLb/Sdmgh1wMUSoArKTjOA1sVGZTZY54do1sOiNBkZ7XdZrA6OF5oFJy8NcdJvmBa4xweWfCyEAXQPLvzl9IjhPM0n2s+DQCoaWDOUMqkQTUPLEehvh3MVgVwsEqadD3HG5H5yg9uTsrN21QMofZuGbeg/2qG173mhwgyz8Uf/lzolpOvfSZHJTlliaGN348Q7X3wvQOCvcQFXVm0ECoZhpRtKX7dZETeZt+F0FJYcPRZLuYCf/inUQpZEsOby14wKUGJZH690rhvGOqKxKpWaFMYEP9r7X3JDGURyRI/z1otchM4S4jmmlC6oY4g5CY4qeaA8fbATFQ1e7ChE0rKJJXnk2r+ZlUEtOtAOrzJqlNPG0nlrVnQMcQLxwVFcMDxBdryztUJdyvPm2aZy6mFti9YvR+Y+LgJRwnhABvInsFLCqr5ia1FMdrHUYmYEpwTkHaQdimVP4ExLXyvbBS4Or3rwRiu4qwQFp2UCqM6mvpVQS/I8b8akFsUBCvSe6zpS6oxrkBEA1dSmn4K6mtT/NuO7tmuhMKBPYJ6mEtOCxK/cufBUadLKWEWK/tu+e1ESctP3LRFMEJuY5Et1TwvarKwZmavD3Nu25vx3K6/vLnVfuzxdx6+uMQ9pDg94nYSIhbVCyY50n4qu2LBIH3Cup4PqnWeY7FoxUSHzSh9GIGq4aVakfALXRLpH9KlnR6EFgHqFdhfU/+06chjzBVouEXNuEDkotx8IgzrTbGBbeMwtr4ahrw3sHSAzoMGAcRpYzgoDxlJT5dBz3MKQ6vU/BKBK3rvAHdeYxsWAAjg2qrbd3pWV5blLYFQOIcAgBykkLGwsDX9RrCArJSh6kkOKVMV0EnEusSnN/GdvFjyrYpsbPZGubU8NYFZGL6KUIeY9Trsi7v8sFD74yAQh2cGFJSrq8cBlWosN5VxWYMnoyH9QhecV1VY/O9OJMYcWz1NTWECLS3TblRZInOjBMNnsjYZCdEnPmGssrQUGu2AHM/HxSj6pGkxhF2gWw5gXjxMITdCigxGOlrS+9dzj2J+S3akf2wmsBKPi+JRAxtsYZzyIilsvnWBoF4rmodg9bbFNvyUJOXYBQ+9ysC/KLJXGzpsbHAg/YOPvYIkfOU7++Xt6pPasgYkdRSXp/LNwq30PjZS6mSYlgVqwSXUKQSNeFFMbr1ltKLWNMXqOCJk+oCYSdCDJHGrvUar578XZ37YnpXGg0DX7gCyM5ZW6/rytnlNcbaAfvrYQGWMP60opJU+F4koiA9pQdWkuA2Uc8uYkrMuYEGwjJHk4dfEJfXzJVN4RA4yQu7KglyvEJhpKL7VnPc0A2ePem2bIJTSZzXxhbTFlzrupdmVZq7tfAaM4f8Uy2MIkGW5pLTJvb4pUETPNgzwpHyTbSkUnCEDbqogKuRVuelnQtvftftxu0ZQnol5XghF5QZUxeE8Mbr90/CaMkaolO/x3ZZ8NdzlbldFynUKQUuRdem8KQBzcysLrrWWk/UWDE81EzEjOeB3REO3BtjiE3UrZkkK1c6Ciw0A8yxGtkmRo5AcFsx3q+MCTioakqj+u94nQ91mSjyPVAtmc1eJGoyve2xzK5I2opqTyOvwDpburE+XNR1OmAq43h0cqiPsDUo8sUoOJp6Ww+mCjE28Ox72dEnGPplUAthtwNMTUsACMOW4ry5gKCcpEDrcOBFxSewd5yZ5glJUxY9ccWcOpHUisBm27grATHd8v0y5ailVs/7Y42g4GAqgs/c48aCSjCFSPF+M94z+J3VfFQ4V1ysPKl0V5N35l7y13pFynn2e6w2xl3CHs4pwnN96FbKBNfxCLaKtR6xD2hFhQ5SHpowi9nUk1wfIb+15lcVjWVDeL2p+YzxAwVvVuHFZKuJCZA+3usbsFCnIiaD7q3sMp6il1chyaIMmcT2/ZABHPBhX1txzjJR09SAawsWtcCfkRoXYiUMgrO90VP59FWGlGcUIJpZAe/vZz2Ve17UYwnz4PBcaZExEF8oJABx9wqV2/LZ8uWSVe4gcs6gHpvDnSuqsRlfi4JKqLBv8gaQdR4lJM0VRZGWBDmX1HyTXU+2PORlSgyG2VZ1eGq9Hp5tj2S/wUIYCewek4orPXMkFumqCBLbgBkWJgo0uuHIhAdUVW6m/I7rPuyfnBg7BAIWyaioV+XoeWkkbzdRhN1XtuhBOKU3pUdthOEJmWWT75W4ss03lX6V8rPIG4OBvKd6JgUkSz7crCwSLcErOEri+Bic9lBd6UA0vNai3XzXVnaxbHjUSWeIfAeiTnN53AjZN8kcK8IZ0BaqCL0wo8DFFzeVL07gYJQJUExyGlwdU8jtq79kMwD8qK7wHLD9jQ3XpgSSQnokMAUa/mANDfZuG/aGYXpRTwKqBvWbJ2CX7B/atcyZBBBxxrdYL92mkMRGy/FyrF4Q+r3E01kMkTQQET4penVlnoz8OkC6UmOFEmPWsDpyUvUZ6z8pnizHDh+ddAiK9+PBw4c7J/uHAXj4aAV4+NmeBQ+71/9C6OHlCNGfCTrM726DDMvP/47g4H0IdK4CBx8/88DB/1HwmYQvPuaFVivcdS1nkhhj2GlpXFGIM1718DTWeMc84gMc5AfIxg3GJeYRzbYqSvKEyxpceKPRxMv0LH3wbTbpXgwYmp3YSH12yX/rFxipAKnZBpFieOaoGM8a8pfQDGm4IQ8/zaNJNU/GR0I9B7CXQpB3ClJ/zPRh2GNZbjGbYRPJ2hDMxbnBCY20hnIis2y3KPnZM4FB/Nu//k+frZ2YaLeSSOKD/cM9QRLbXHs7hKSPrBDYj4XLT5lEF2vpEoAyRJEZ43TTmWouu95AcB8+RirQH4KXtFBkwUWCwPJMPGGWCdwkAsvheZtKYBHZ7hwRQ8O16CFtOVKrJrM/6WR4CwZVu7y/u3r7xtbAEFuqCkhh6gliSIUwF9i4eQteJgQ0GdFZyYRAz4sEBUN6eAoc5sdCVa+9mCPI3FNWNVPJYPC3RkcDeieFLwygaMS4LeoskQhl+mTHrgOwk6h8vWyoZUsZo6PDFw4J6p9Mt8JONnNlBg/JnrCDNZsbHkfRCBNDECpEtBGg/fKBZmZMj0ImWVgYHYFkBTzz0pkIzEWmWENfFeL+GtOpQy7LUNeOyRgBYPNJzzyFGIx7ZdPToQeNX8e1YbvIAmMW8xnR8f2fmB/kCIcGxvcuKaRwckLP6k3N3/Q7ekHRfzBHcq7RzOTCziY80FgY6NmgvEU4c5ff52UIBkig/500gQyxVBVwQzyY9EiStWIajtqgcRBgNv9DfV9Ltvk5UP+H16/8DEnLo9eE12MLUgcteaDiSHLngbESqvU7MHVUWtQxZ3RmmwQ2gYAhFVYHk/Y6ryG8AVBb8Sr+8Ori5UuU4me0d9mLKrCKBduuAKGo82rWQu+/wLa+nLDIOm8Q4k42foeUIUu469fZi7wZ9SvswVEOPi5mUINOTnNS3uF6++E3Y+mCw41+YV1MoO9riKRu2z2qbUfIZ3Zxlk85mAGJBmH/oVAF+yTodYtLwg6TrfWg18H/SfF9h2ms9iDz/Yw6Pfh0FN6kMIaJ9ScfQsvnQCFDwXgnZmiq1meZg0eUT2lrijiggBJ9ZAaDc2YrtHYP9SKk0ERLoP52rZr5w1hOORE0SSd25ldvWk2Y1VzaNhKF1BX4RapGiZMfrc8WWFhQYr0i2eFFryxLv/SbvXH8KQgs6YjN9qPe1YYaWt0VxNY2o0yvC0eQ3Lhi7aVN38ETbeC/HiC0AKmtxWzOyBopZomZt7HDh1UoQA5BDdLCYn1LoG9zZpsu0IsyNF+Y/5zOUayFgpLvtlU0RKymc7+Pz43oljeVKGWUegGjKQwASe9pwADlaaBuSOLRyGRIKJoVzVSTr5TucMm9q46uk8A/dRgkIcgVskfqTJiUgRSMpLatPKc91uiD1spAQB05oJMgwbrbd9xnDfoHts05KQlhFFt3MpYIjWW7XeNEuYcedO9xiPocQcKF+80G1/2tuYFfjckXupawRQjiKsDHonzfuLxDWIO69clqWYfcH6eXF8xtgg8UzQdzhx4h8cK7lgSwGcKmkQHBlBD23Yzze7cFGDVNS9jJmhl1ZsO1XL4cw9XLwdqvlYnuXraOVodY2ScJNOIws8gP1S/L/zivia9NW7At4IqKwDixQESYLy7zuSEHCyWBW8u+WBdojiTT/pwdcAoPR4CKhwBXTXaLgRIuXtrd2dlZvQXsmgPrbJxEQx1bVzckCfJxWuiqPBsqgxyzQ9Btdz19m1anQeMcM8nr0v7mCmun2fCRNmOF2FiGb42ifzHcyNHyc+gdZVCFnX2nXStAwxzW8od6D6P8v40acWezmIDmR+Fcw05N3oYoqHILN4aeuCunfLkVGMRoeBNbHrDHbwV1gDUFdOnkuaX5s4SdQL1WmWPOAd42CmWRUJIv1EtnIUrUNzAoidTFO/oQrMYBsfsQn7VEmWdsd4VFAhwQqxBoisY8ihQNQA0Ey3LifWgs29WW+zL1Rq9CaiyjPTjxRikHa9DVhOBdw1SYU4KI+143rl6qCSb7L3++tzR0QQO8KXfAI7sjeYgfVcnI4P+4odEXCCcaQGTpy045hahRF/7U+arhTiPmTMMfvqLAFxxZ4A+gQvFN2L04Od2l9bZL6mRsF+WWo5LqM0FuhdIo4eeqbdZA7bqSu7ZIGKeiX1AXkCojXE3COUogstGSaAt2gqnJy+9GTHC7YcmJYd2jg/Mc63zLz3ZkJKTBRO4dJYE7nlGquK8Qda1sKNoLEHCkG06yjsS49Dao6k5y+65Xp2j5rcmq5tC+1FXDhqRgDySvVxYvEnWW7aTJZZnMCcoZjJAqNCT/EjqC2K/TThCeZUt0ZkGcbqxhqw2OKuXcxq5abo1P9T79LCsmeUlcftY0CEOyv5n2m9nnyz2+V9DgR7J5WEfRZn4WRFHdCEID48VlLYnBNWTki/KuDBocC4uOcRjK+Zg9A4i/oCHLkQS9QpqRE5JQLakZjhDfeE3kHaOgoodPNFmFRV27PaEXvwV2eQEfW9imEz6oQD/xZ7PwmWKG3l2ekvvHsfGWJuWTtiR5UOzzo1zFdnvbEpw95rEqy5Xu6dUUROYGzi5ziajnAiNKgSQz4t1ZTzQ9Zeuai80Ea2Dd5xHkEM0x3W63dTqsYwQPI2YQzqRRqJN9nUeAmEONfi25AET4IviwjAMwZrk/FpFKkbKCuCG8S2MgIlwLKovijBI9j4I02yaJqvKtWUwmAMEs463z3P8ALdE5PeBCQui1cpmhQhLwxFNhmqTOVjhIf3uF6kEX9ODIwEh4yVRkt3SMAuQJoN5DxYx9FHkutJaJNV87Y4crl4mTM9xWuSsJg5bIJPD7SbsY+qIbsx0pjiWooiWyNd4ptrU0lW11hsZb74CgmFc+5TJbEPoJTjZtKM8/10h4xZKcogs70pQA/hnwC4e9r8A4riu7C0zgdxXRZuXj6tbfoigU1iAfQJ6vfBxRcPZ5xiAstIHVsrCb5ozkBaI/+u235Dp2+w9Czkq16hI3Tc/EYyrybT9w5a4K39ir/AGsgRUexXVeQ2KaJYHk3F22mChLSO0mh7tujb0v55dZZyxRHQ0DR+ckMawQQCz4wO0Ly0r83S+S2+xPCy51dCJQx+yWVzC/n8blzU0XIEfmwr/82aJ/0df7y5+5BRCu/zzXidOEfXoK1HEwCwvMppKxGkYSzKFhk9rBP3XTRCq4jiIDUkXiyAqQExy4a8dIwigAT+2AQZUBadrVgQq9Fn6zY49sHfb8ctMVGylYuQarNlv0xyBJ2wE6S+qoeMMDoAGayKDzhqb8mnrAdf9qt7u40YcqX0RMjKtG1V0VbUv1vOHmrS39RzuvGU3m3J1m0bd4OONDihsj7M/z+zRo6Wgd6oU4gzcqb0dj83+tt9mu/xPWUUrBacj0EvaEG+TI5KCnPi7ZGyNtgGNb4gWIxOFRIVBbYnljPcpNtAY8PB6A8PqoIruzarbwIO/tBxSnBeGtMiXJkGYZ1YpAGxBzctP75xGUFLH+CXghqPGm69gXrwvEE+ri1mzYMQMIBebFlRnJDfQYuoiYAsZxHAjohozTdHTnd/ldfkX9z6V80FZ7C+XETBqyXZyreH6qOGPd7nSWpXswBrGIwBgJC3kemmo+fNbWIoLsrj0yBcnvlGqg/gM3LLdUDy1ShXuXk/svFHmaaSPhN+qQHzN10G7mancGhmA2yXqxAjB9ZIbjaA2Pz5piYNIG8OYP311dfPjuaxEhgqDJG79jRwDHouGkRvO3w3th3/aT2pDBN63l9Z0Dgn2gTjCIG5WL8xDZCmPNNcUVYxk7srk66dgb7nhtTGqVb1vffNZk2BtsbZ1wdQ8mhmTqbdFKH3DOxTx6jFkwaQaUQn2gfpUOtWTXSyyK4MXlCsyvr4qpnA6RDPeoLKxDlXCnk8lnri/2Hvs6/+h1kuj4qLeEmhWx3jKjHduiRLUFhQSzWVY0Q9rVcB5TGZGTyekzf+Cul6e2E21Ot0PZr1lB9eodFRZmIAaUg2KfLr+HTPv4GH3BQT7MEwnihql7Eyo4TOCZKXIBQwzOkCuzfBGty+o9TnrEwY2lDNTa5h72r4Gq3M+gbgtoCgEMKuuOGiFlO6QKd5nKBko/62ICjMLGZPy+8XDb0He8NsIGW3+w6oA52/jD1dWT7G4xBqpy1FNl8BI92ZE6uhSMt6Xh4cRHPnVWZ8WUawh04Ost9bki4pJzFxdV0kiu3Zqmwhm69zRmwwSWg+f7DuhVxE73JJ7szg6IxUdjs0KFdfGTFJYXB+VpESgJlXqAE+allSgBJSn08PwnHSHryHqtWq4vM0olNwps6fv7anSt3a86V8Yh/Ph2Mf/fsnPwo7JLpBhCh4QLY/wFabTN4ot+MwMo+we5se5gDpj+CD815QG0Ve/S0FyY5UFlNG2/E8xOPUz61Th18C2GJDiCjBCmaELPJgot5lw1dCmnSxq1KKcUneBtcYmF8xdYSYTndmHZfRYzqZGgcBlNRtsRSoVRsJIZlYdwXbR6Iq4FkuvmNBgwRp6FeEvTrjRmQpHfYgcYLjFUe90BqCgh2sFMRI8h37FNdNhidT6aBsh75iqkfYvaJKvx/M23F+/evnl9/uYaoLbU8IS77UlFOphEtBknk8VUoEVmSn1pW316sHgV1zIcq0o7gY4UFy/nGqwbzVTksluy1ROn6Zdk47F4vrezYhoS84oRw5FkTnKx9Sag7aWNoVKvwyiPlbLKAfIL7ZBoAW9f2h5KKkVsNJGgJ1guzp0cqGzLWiZJm2D1sL+u8zuY1JcVmHyUyGXuEClbkCRHG+CVYI22UaAZMievE58f1H0meiNhgeBP6I307ORg95G9kZ4dqPJmfvsvVN28ui71f5kKZyS6XlHhvPf0SCqc/144mi4cpWLqPd5XE+g3ubpXk1kM6kx5ra/0S6iXPDJZPb27vwudmsomaIhEEAaYDpdS+Jp7DacpBbey76oFOgFcQCPm0ITbq47HAsuiYG4+cEHwZEHy8S6Udos6XtofIyrqUgZSyqyZG8Mnt1w4VD9YQ1i7tVhjvapKlSOXb8U6EGhnTe2ZcVeNIPVAE7yY9KcohwX6Ey1xIszmDJ72Sqd0cwnSUWRZIoGJqjoTLBFzElMpO+I54exmKDIy5IK00UHb9oRZh5JjXTcI5+s8Z+TyDgqyXjhjV99+nZEHmHzz6rYIbsegHQHQu88aKwJYFkVL0lb7eRBXflIhpgrB5Orw0JZAmB0V06FjEcX/5eHrAVXsZHrUx7o3J33PYnZb58N2VkoP1ORz9M+Il8X1DKcG8fbR6Q518hlrBTB/WciHKuHULq7tBazX3pVLWM4N3UrZyBW4GVKVfai4rynUQ3W4wzBvmzvq+8Rc7a8Lb3hXkDjjCTv93ekfeOSu1tR8IbQgijJLaVTDEoYSKk4Viaa7/rBUUHFZCDpAdg5a5dk4KYocyIMBatIr7/C+/TGABt1N21EiteKbaBHjtWX/ghwDiFYoDr5Ix9Dpff/uVSuFH/n/7G4kv/HHoSDImKf3NxBV9J2nCOM6L7gkSJ3RebilHUUhPZgayKXLYpBIQokrMOSM9YZhuKmanEE+i4NJ3A/HbH2A0WX1gtvRqQFRQwPANUCuH908ZoAmnppN3yUKStRspWuAOgB5BSKDLRso4kEks1outJuSKxWky9t43fxYhy9OnDgVuCuMvhwi3QL5dsAOCWLCLVS0AFY74SKApxqtJ6ixVK5G7kzehCIthJaILUduuN1Y6RgWhBgJJMNPrxwpQ7+4gRzZYFxS0IO3SecKYj3RYMTvT65Ea8FxFO/h5AkR7yJaQXUaSWROhAIzzr6vEEIcle+45/fAP+/gWnZui3mPWl73bP1jx0beuPVj7ZI8JXUnTH782h0ScjOFt4FV6XFuE+oXC2V8q4QhF0M+w7JX7VJqNVYMffrjdBCW5JWW0QTPl83g2VnUctGrhuy7Hq+WmlBFIzE9wF+6fIcGdKmUjuCNoOaJE1G2GSKVzWrX4B8SlpY9VZZwzyWIE02DqFm9V/666liFgkoMyCpq9+btmXVR2GEW/LMz0PLYwlIa6LhYN/DHwMbGheqxX7Hx5LN0VpwWKTW4v8UU/cHOftZ5Yx5yupiPzNT+AO3lzvG1jqDBWsO0FLBHB/QOfP9BquXF/pqY7VRzVKOqKKgB9RhSSgmpNE7w09ZtCVheAd8Bi1nxOeOMPV+A4rJMpawCRY4cwE7dq3bHZEFZLhWUvXr7OkEZVlYS+kbqCthMpm8DwUME9sWEMW620KubN133fP+hZ4z6hPC8Iz+JunYl1O27YlhwrYsSD/0Hy6yDz8SnxXLVDkdmB3LgVmz1HzjIEriDSXyZ1/0kHHLKzD1XtVXGAVzcjpKp5f+Y60lzQs+4QqeCpG9LAitemcGoqhpBdLI5TDx8zciWjgam0GOTxKB9pRRoBfgVqdkEkQoBlnkxdaHOMXA1Ea+qL3dsCgTHTgWVKNVaipXztkZsLtgnIb67srhPGP7vp+aLIErmLNnPuPvTaX2L9CDn8stnXnczm+XjjZU3SxyWyH7g7eKo91WzlgdEp1GehdQhVLCb7e92jRLAe2t2DPkrf29qYOvlMKO5cc3zIHCFojuaHdhXGJN0vCE4palh7K4NC/ZsX2jEOoMcx3TwwFTEIDA17/QmzAJqR1BFNXXVMaOKbaP1wa/JtvCtMAXaR6+Qf+0hO22aEvOyHcGF0ylsyWZj1vXUGESWVL3Dbw4DaC7VkU+w3goQpK19LyXMOVErEgcbBB9oh2WNU3QsHLEKdnQE8U9L3PFp072l3lm11FHnvTMwwKDPAOmjZCipZa3Us96z/YWQU7ttyqLZZC0gKzhWWWIIExG4iC39Llp03FS9mzxUu1t7B2u57a21ArZH5cRqLEpZ17f5tDQ6ZPLAS8h0rRNjg466eOFDkdddSCQOBdRvwW9AUj3lBgHa9r8q5n7uSHPN2IOOroM9ysnPZik3++qLvnx0/6svtmdRqCJZWyr87kY73ZW3NJTAfQ5zJPgmxTvX+sLTYT6T5iVkz46NKpzzPmBvkH061UtpOtSU8uKv9V6fv7g47T0/vT77pvfq4vXFtQNbgFdElJVg0pgpa+2fvLXn0in4z10VxXeTFNgwgZvsKChuxvlt1nkhCxRe6KPdzJ6A1KGxMSvXiEHLMv6a4OW0HT1yAxQGBB1WkCX/O3fsd6ZPhJdHUvvDSR0GSUrvWF+iNoUHjV+GHzjc2v8x+IGdZ9nOs5PdvZODvUfhB44PjjV+gN/+C+EHliZl/xNAB3ZO/nsrFuAQsAD/iydtKdtvpu6+qgbMPtLVJOTJfP++WQxNV/JFM8unX+lWFubYwp9CDMDSF6U51I8OzOIZGY6J39/849O93aPPYRvhfx5/LuCASf4R0GNzV8MA6eHFFOfqwedVBzYbHjk3KkX75Ys8G9XFzZfusFb1EKqSGzyxXBGzrT5gu/OVmoYvtvOvUBt4D1KHvgO1S192ppXRucbvMzebBYK7tkgbgfD7F+Mvqc3hRJ6fPYDoV4IwBjj2EeW9aVRKXUIEb5MqwKCsTITCEyXLz/PG7yTv0EMe4/5mWLbpXB71tH8pilkjtp8KhIqjD7/g8YcyXs76qduvkOGe0V/gDDNjPllSyFlPAYXSRSvU7acEEDGWLCaLHoh9HqOdzCOCpbGYJpb5Qsso7PeEEzOllraSAwKOwyk0ltbTjlB9rpIRnCHUfpHNGB77g6/8Cixui+Ied24WaNqQF0ZLPzMfNcEkE/Irxe82ZmcjBVJy85Z3nddhBro544EI7VgqK6zVUza5wsPcecL7027E+KiIXhMuTtxM+qx03ZO7nhu0raJGXX1Dv6pgrZpum8jYjg+U+u7nfDscMLWuv8jQEXHShcRmtxmVs1n4+/pfcY0ZuHdIVM1P+vf4IK+U90d+ypV+xr/HR/Ch77JT9iM/Q/qWnopr9++yvRjlWf/4bSWVU/oDrMf0ig4PqgAq/3GDdKFXso9RPIfyBFTbP2dXBfkdFpX4s05P9IUCLddfmhp3arCBHn6P6MsL4NwjG1OJ5JdYJVTMIFCO/1uqy7LKhWsgWRi0dBlVs01js4Apmt1WiPxpsRaCGeGyZ9jE3xtfxrNDHrHwnjYwOwBtNWO3MGxsxkqHYpbU9N1cvJnRs7j0AZQ8A90Bt0RpUSnAAySUl2KgeyrubwuWhLAKEJmTCp6a6WF6TV0OT9WCFGtC9hFWsQ8ABKE4C+1Rqd1xH3JtzGN8ofk7sTXAU9iMlLbFYkqimQGladbS2SQaDN/eoX0EsCGjfN2rpNEPklMhRHFz1Qqb07WYNNvzalYOzKG+9W3LtZdRpWAWk2Afv2A3U21ftKTZ4QxPi/dc4EJrYivlN7fzz7N9ShjytwO+FmG0+bipaAIebQRDhO22wHW0kbVEblriXC0ZFYIGNZsKuwBlLXa7ti3FbFEbv7FJTLs3JWevr/i4IBxDTfTrclpOFhOZWEqAWs44HpZbhNZJR/OY9xj6epXkiOyTYc0UGV1Zo0CrpmQrS2uGIrLayB8MPodbN+AZ2P1c54bljsQi6Dv2AAno39GyNu6Oo0jhfGALnbEUmN0fFUZIsv29uWSbwsbj8sPceX68Nin49rP9vd0jwm8fWHoinCiJbxljq5rZ2mJ05dH3sBGtKEP0K4Vs1gARSvOrsb94MG50OYBi1QE86jf5ZPZ59qJskGPCot2NbnkHryWAe9mINCZwAFWXms+tFvNUVqHxxmS0EMz93s7n94PJuCdisrcoe5id6jECGC8yC5Q7plRdDekolChdaewoyR9WYtXptyKP7Ff4SoBjKOHWEwkuPLK346pvllITmwKHkyCTP5xlVuZTvhFrLl88dy9kMg8hLoBZ99ZQ+JRlh1BznvQytiZrpMJpaFcLgJVTViBzrtYQKlqdwly2AxBVpz0XMyqgN2Rx6A9MlNfFG1Fbf1wU6JW7WmckMIlTqmib9Mtbinq4p4pFiyEDMmKwFYJjSqZiVMIaeY73rxjBMaMNYrkO8VUuWF8meqRTXtSmjBv7kGQrZjXa/OHSbBXzPyhUvjbK+h6aL9mtCqGgbDF1ROR26+R3eTmWDTDLsU2Huwx7FeiO1Pi6t4iezm+Bg8pV/L1+yE4HxFgICWnGWBPNC8wdqE6xnyUSY4MO7uEA5NEBK0ZdZfmszD4WVI3CJ6z4RCIMqqILj/4Bn3RWLWaQuDO73DadmM3GTHzGb1ac/W7PYklrOVfL+bGcmRNn5DgzRTFsaDCucCtbWr3p0IgCouLk8nYmLdDL5SBSb7jAA08F5ANRqQWTE+ei1VNsNyJuGJ31gckN77hR5l9yBBiShamTgCEXWHlc0pjKtMUisrnvhZvdvf/DpaIIxPML8+UzmhIXjnvSq7ZPJrpX2y/OHmBEk4XKRc6R3dQagMPT8hym5Vqm5ZZOiJ0e98Rv5cBnTY7jga/Do19ELHsNHBaSZf3F+CPrCC1EsL2M5X7lDvW2PwQS65bTyJL80piSR1s72ZDMc9rkqGtH7G/wk9Aa9UXhi+eOv1Y/910BM2JbFpVjPTCjWHniwy1C+qpnjtvgY4/ym6KfAgqC9Lmmnc2aluKHGT5MB1XzuV33cXFXjEXnYv10KHwYj65j//z4byB3aHsDyEMsIMCyL7RwO9gpbA3QtGMVbJ+bd8XUbKyx8ZLvKlh8KmEeiQhKyG4hUfL6EyI7BtCEFENu8Abocf4tBfXTevX6YVaIzaTeg+/H/dwoxvUqaBLu+ifxgNQx4Hr2EoDmk77XkATpk0GaTO23baPtyPbkUcKeVMy6NHBBeraZ2BKytgqS/KT4bYfB24CX5PwOfYEz8zmgRk+EVcJJjRuugJn3BpXw1ntTR1uU5gJh2KiuxU1KzgtPIk87AUBFjzsdbKZd6H/wcLhX2/TGMARUcT9PI4GsmARtzVUTTbaYjPMFJwpcs0U5Zqp52NeARQHAuJHV07IZhfILLcTFvOoO8vFAePaCGiEPOMcfCy8eVsoQROA6/qgEOE7hHxelkQhofkaaQFlg5XRQC4cBOXkXL5pQGQDEE+1rGy7pSby5NzHGYzXsldOeULaQDIzsPppi+rFATiZaLDVzJEOJlzZ7PzNTMW62z4jBB/47oyIu/AbFeuBe9b4pYgsQqBHRVULWW2wp+6lsUI7S6wh0wRLvjflWNMZE2JG4wX6pkBpKqTWVTJR9RGKAnSmObuzv7PxWz71KfKVO3H5w4i6Yog6byaYMGSEg8rhdIKFE+Ci+QRENc2sZbnOg+uv6wpv6famtKow5dAu1J+E/kkrAqQofYpk5gY2yuKeiQQzEOJRLCQVP9oJxcUOikTeKOYyxk2LWzByDHn9eT54ly+d15vJ7r8ntl++v5Wrazf5LzP6YVSX3fVMWuQLCM909H1ZkvLdwtMh3jP0l2oga1mx9pTKP+adEPZGSGFcYdnL7KnwhY4Cg04s4lFgXWrBY4ZYAGKQVhmAzhm0JQpDTYVV9vLaF+OcQv8fTok40VLkIf456Ek/922n2TTW2hoXZHLImlLU1d/FvCRccZ+iWAbsO7mmdSSm9xAkkvJAHIrJINKlCSX+VDOkK8iOLWfaysJuL5s9aaYQsV+aNkwbho931qAusx2i9UiW/vHOPM2qVz3pKB3YxsbnIXqbK5U/zZpt4j3XDd22Nb8fGFeNvpwo0AhEaObMkE/oVooaXSDfB2fr2S+pwhIFhMOT/S/KR6zxQpD6p+pSJbrzb2hUv9e4HPRJtxoRZCA69bFzjTf/mcVVh2XxoHzTW1HLlJ0Zupb4jOTHBdmdUdeUiHp6b9+GM/J3gw6izX5zrlfo0dFzJ1BBxzxWtCRMr9SLvO3YS30Evss/A1iRKjaD5hb0rQEj4MglEGQgQ903MQ5b9Fy/oB7SQYJY4plqcp//ifvBnJZhSPLLMYrcgBgRV6icGa3gkjFm2gGm102bFnSdoYevZr2KkvLFjnNKkUrahZCfCfR8saDr2ZqEvhBghwmzyEOPYUPqQgK9uI2WpkYSbnnBrjp03C3ss22sHFEISVeRDOJWGSNgQ9wmngTaP7fPNtMJiHFVk661+9OShm2u97pR+Mk7oOBAsHxlrCWlspeodrOMcH5LD6JBARJsfBdFsKG/BPQskn6J2RlX1UXUh+eA2v/1yuDw0423YG4vlcb+aRa5sYyl65KesX1cfgauw1aKwARGqGuBcitJpVOAj/AaYyfWn2ycw1W2/8JHQhvF3FbKDiwMrVBtlwzUd/gNvjNk+1ZE/K05yVdfPMR7QdRJKDE4ydoKF13sxKdw1GHsTw0zbY0agLlEgvDUJxjpXYdJwVu9dNMGTvvopamNPbTwYwu3ACzyNrAzBNhGxOF1KB9P+MubjkQpmksz44yJ37JFhtN4jUfA6jpXRB3o9N2jThOVlOpKadNPBIDbLs53gMuU+ltMp+c8aHDBMK/qAqSJtkzJj3qIPeAirq4CRM23SLrFchbrWDBHO4//euzq/urp4+8Z66L74jpWMavBHUUQKdp9kb6Eo3D3FARxmecMk89joxihdaaronqx5DFUNEzUZBuN2wklnBWjRWWLbgo1I6AnAGi6nmCm+4euxR3u5nIAX3bNupkCQAbvM7YxU7ifQO/kUNwilN3wrRqctCQ1qU4eyDcKoht3SGTHKg4sJuRRdZW81PQkxP7miZkjrVhdVuLpH4lMyzS9H1bwKo6Ue/iVAyipR688gxylRsYFL7KNSlboYxCjS70qAP1Nk1onCvN/Emu2gxcIXxQGWkKNTavMTDiKjXis7GYERjiil6UjbZkzQnpIzvnRF4Ne7KvrIxVaR9N+M54g+2NpJRiO9ACuWv5tV2afaMv02wORWyENtHQKbVEAh4uWTvClITCMsD1SiVUzSQ2sEu1HmNFCPIW9APJwVN6Tm/TSYVSmEFEY0qza3bYsGONaWDspGBr2KL6SwwnoliGdBrSSURUMg1gJ2wCrq2ixEqeSX1CMcxCsQ9Z7rL4CB3AXGzOjycROIDWp0NwBwj5oNCS07FsbBuMCMWj0PO585EELgQisS2DpHnAlaCTl3pfb8PZmz1P5ImJBxYYfRA9WgBEHx/PTsKmNjt5GQugcmx6dg6mdJqA5iW5sQXpkTHRYyP+kbIpVLVY9kR72qbqt441iRAgHJM6LGdLYXGzlS8ZgWUVgYd5Z8Upi+Ic/lnjNxXKm6wsgJnRkShU4NkX7CLvLYawDqEzDCw3iFwGQKEk9FInXGd2OOnYzDesEEcCsQ3CqYlNyDWr96qTJJ7VMcOxzyjUuI5HWdP5AFX/s53/MpddLBcIiusQ/8DocBsvWc1NchPC1+gaYz6S/fvXUSFZtsOA768ViXkwR0R4XuM6pe9AdoXhaAF+wH36Vi/k20GAEGPYgqtmU8X5pRYaQP6CACMaQusykhVn5271Hz2oDmh2pzY7Izx3gdjQ9kGFdp0z5znlw5X4THgH1LckVDq41TQoG9Q7egnLZCnPm1jFihSkp4EuLvjLnBplqZ9nNs9OF3AFEiYTd94BZuqLIZvQvJfmzfHA/+UxDElcllw7APVYg26mts82510yXvKKKQoX3O7ejCBJUIOviO+7wON4MwYuE0YneTABEQnQq7+FD8plBPYwErwXScm9PsBYQ5+5pjRyRbwhIMZgDd+qIXemoUW1BJ5VOGJd4+flSdiQ3A8h4+iU8D9qZxvlTeOBy/TTrQTyrnt+kgH8OCU5iaqsqRF5APO1eiT3QDy4YHaqAiU+ZkP4HsAbfEsF59iCgVy0Pgpma0pRUzs3mWNAkpi1gQRORSlH6iwu737171XtJ+ODmhHFuPrNkexH8aZbmiiRqHByNZgytKOgl22P3ACZHYPobhoP/Ck0+OPUi+8Kv5Mgoch9aTlw4SyoZ4pakaLxyAs1Ktqeh/kWB9XVq9BtYrln3ISQ8tkaGVMnBAxg6csEpEitzrSZltIy9hSNBhP/Nc0irMOOt60BzsHPgJnOhADYA+Bf6D+VTU6Te+KCC0tPhY2m9beNgEdMYaDwW6DAKrKOKVLjFMEOKPzL5nHKiRedUNniXBgyq/AwZrWfJWIuwkvkgUl7iLkymJkXoY1h/S9tUOO/UgRXuwX9UWWAwGksIsBkvbsGilcNGMsYvD0jLDeMfcwUcLyv0w2S1ld0JNolFyAPp3cWQlfC+zl3kDRU3ZGXKipLf0DacgBX8nipKxx+GblakPUn8NkAzbRMpYhlqzt3q12GKX+A8HenCXLnm/AmzPGD5Lgq1xvOeBQar8mf0UUN65S5Zr3maVCVgVQElYYqPs8KLU0zCJ9Jw4ilOSEkb7yjzhalYg9QssFlZM+NYhT4s/IiO+lzh8TWEsjTH6F6h84KTCIcK0FZZ1Bhma2kY1GmiGs8AUpvl/YH2oWwfYSrGZD+mEdT8t4R/5oxbYO8TauODHRyYuyZU4kjfutOtxwQFj1VTn4L0NESLdxIpCCkaKa9a9RT1GeqU5AYkzJAOrkTAn/KSX2oRRfGJyqjcFDCN8SIo01WV6hpUfQI7CvdIUzZ1haQmHiVarqaBVElEHExGMecWRma/bch7JaVAnNO7A0naKC5t636Xx0eZNwjHj0ntMTDsC7SDIeBCsw0Ft/NhEaG8/AgNSnLGZh76t3RhiPMQwAotB8qJv1PEJe8kmVAM6OiGmrmwU9oqfCkHx0lal/B4hcYCesWjYm1RiW2FkbUw6toNbqORyq7OwDW8Mz4kcTud1MJ91m8n/qrpH+e+6ybFy9kpejLLvQc65B3aeKGvMGMJ08lSkKo2N04oTa8tzpOARNz3goteAMinfSWeWSAZAUYgjBGsJWMO6R8FHtKvRvTDyd2ps3WdhkNsx68JgB0b1unaTEOl2TuwAgaWMtoQiBNXTMUp+af4pRqWKhEdaQoeqS3ofrhLCBWdtVy+seo4MidTSPKdIZbAzGhHINuXZtdm3ILa5JM9m3ueSDg2ft9Yevpqg0T4c4w4g+22cYGCkudmnYea/MfrN/KyeN1nMx7rS1lmuNs0PvBShHy3Sw7hNoOEpykR93epb99kUiKMMSpjn8ATaQdLkwB14YrTjlNwd42mOIc6pz9v9rAdAql45nS0iKaGCzW5lpObdYT4EGWSvCUwUu1CDVG1XoefTdiu2zi3jzCNcWSKUYJWchsmR9WR3HgyPg9L+6trYEFOo2UoIY2Aq23tApd5Y1P5x4T8itxaGrX3mrN2QiFm9uTN7OgS5idc1RpsutouQf2SGB49jtNA+1WzaSR44n+yXcacG7I/YUI4RLzaTOctrbPCACVIMVMXWl/XXotxDzpPomtKJvigwmLXpcgLY9x06z2ByIBUWLBGtcy8Ygzi1Z6EfOZznKDVLGUFcK7/9NO/RYUn32nbd0OqpRJqaMbQ4hQMQbIYJtsdQcoOQCjfasli1KW1CF01jBt45waDgJi6+PEzBb4SATpnFqr4UkjcMzlDaSyqjH6hyjQCNm0hyHSdDEke1tQzTt8a7WObulQ3V1bjwov7pEodlrqeOR+qxkONLRBpTWtVo7PPKbFXV0aXkVoPKqtHO5cokg9pdPpTiXpgMcIL3sZythiYReBVmcm9ECKVdE7sToDZSYZkTNh2+w/kgWFTDvZPFP7ZFOSu2stiyUYST46hxnNpTNSGsn60N9RZyym1UlmqBKbUBVTRu/2lHPmn9BiJN4kNcBGcbJHAjJIrIhDq7xRDwwwYVI4hVGVkxpCarqwpt31F3W5gxT+9QeEjVSLB5DK9JKiBBXaWdUDb4dPUM7glIFUAgNAYq+tVlQv/pwoM2jCyB0ZTHxTNsbWyqbfnAtYawWTFM5MLVAE8DPQDqxVhLsRkQxd9r+egAJG7dWpTifnA+jhP7pplH94fkyVGK2NvUMdYDTPCBDWpKdJ1Q+pS8XZkmf82xWYd1DvN3MRrXH1XyqNljoIF1zm3DToccMF2W9zpXQJYYnUdAgBI5BTg8fxCH5/3YitvkPgo56G3kHnL1wW4ssvcbD14jDVdTqIH9aMHOpYUH5Np7knTrXXHcsXddTGZjlJYtT3dSRrfJemNhimTrBnC66RBzchjwhcvFvxDgPx1CH836MuKEVrTe0pIrTMvZBd5KTUYaQqFimk5DWyOrn5JmWIFGAtAn8I8lGUlMH+iRyBKluJhzFayYZlf5jTGF0vdJbiA2QO3yEbjC9lxqISNXES2bSocX1VtlBeC3KB6MWVXaAzb3YF0EbVFg5hJaUbEO06iEWJF9GxYz1hwMRCmXwt+4mLBKh/iy+rXnJDgoIScJXOWbiyv5Tp3OlMWJxud8OCW0zxWONjpGcFILAaY0g3vMtdrGQfLfenlYcwa+Q6MQxo0CqtLSQ/yQsE8VxGNQWVhwgyXUJDSHGkAiBiff4pW3KAsLw8y2ThGxQVIzKmnOappai7+OwAgNLLv5KMpj3FttkdwsGGYEQU24QL5Wk274/Cs13iSxIRXTW+LjtId6GnYMXB2y+0wdKd3gFn0exAbCMdu6JlVYwJ/Eos8o7lSZTpqUBuYXIMjHoDxiN9TTY3iq1ajsKYS4P6cAGKwXwyM8pHjRkjIIb06xcp5kvnPkIWYlmhDmnm16gQ1KiTYEMK1MjS/ldYYSMYB6mAdo9hjPTQP8T2JAZOGRBEBZ7bAFNEhyk9jAbRxRSIsf4C2YKkymqKUKv0BGD3vUlHxkjTW91NNGfn8v86K/L07rn4AuyV6wv88ICoRPqC1k6cfkApF+6bd4ICx6wVV5O4USzpuiUBXN+Ch2rHw9pYUwrIlRjhUUjhiJSQ88IzMPrXmX5sFwEZlwZD1Je5Zl1u5VCU0qsWfXWzPmSflDUdNLfOhblBGOYD2Jot7YQJVEqKIVtk/2U3EtRyujwT13fqk/o8viAhFmrDIjoayFVJu0xLlcXZY9fKok2+xFSGPNWqVsEIyhT3jLnWvBQgLoAJp28d56Z6yvO7PRm7IlYw+nRCxSirSkixhSUvhZa63kH+cP9tjZrl2opi14B6BIUT/ywI9nyw2RilCzue8iPO6pbYrqhc72IiAGsGONeHWOcEBT07xYlvGVJNNgVDVBYJ9VtW0pCEQZkxyc03SAqXCOi6XkKac67gShHb2oZdEoSw4d+0QhhLc+T5cVM4RArGfJJwT3f1s2YDI+zz8CaJFEYoRDoH1v7cbKGmeNV8cRc14IyQOzXvgdfZZY05REgX7ROmhv3wXzpBQFA2L8Csh8aotmNFYHqKYCHLEre4c4OnebQDBO8D22Foth95oyPja3CfAD8tNanx4uqqXyxuclIvuLE6wvjXKF/9zf+XzLdgTQWWePckPAKPF2/dpWo3Qhsay5UMSQl7WOGK1aD+d/JTgD+u//bQnTEn3Ru4JJtvsCVq9CuttI/Cumk1AQJDj8yEwUt0BEh5G048LS54kHyTDZEPd+YWEBdl5IwMfzsMZiKpSB+X84YObC3MtC669FgcIWpxXf2FMq7QnPaqxf07Xr4FCgX4kuSDmwQKWbsm6UCUFxMmVBeaLkuKUkyHfyvQor7PRp7oyLedjhSL4n5HxKlmSC+lmj+JlYlPXJ5bmDMBcidtZzmoTfT5AZpHPMtgYTDJSkMkFFXoTUl0JLTMxw2BLPf7yQsPKqcTtcJJWieiBOGOXcVVqhWjfof6ABzBNvb1rXTnaJiymled7WFwHth17ECc20Mn/5AEY8f95LlQgwfqYKQBR1d1zdQs7aMoq0ICBsx5S66NbFbdlguT71veSQAwWc8kZ2ka6IId5Hwk1EACvxF9RmbGHMk770nqDyTQBlp0UPiIjLeKT8u+XFA59X67iQr6rdMD1/n317em2XC/67kQxB8QnbxBPifIEbeplxrR/Lrgl8n5djVAVLaEY7VtSGTtW2hYOpiDf6pcbiz408bbGBQXJPoaugK64F9CgczNCfzb7LR1Vlq7cp12wtAouV6xdEU2mmD2CfyBtBPOtKQ12Bq+jQMPDa5z4ChmlrJdYF5YRWWt9X2EAJpTIDZ8AX8cuZHAfU5CHzuCK8CCQig4DoygFAPZkaYhlb2iV4fXA0969DLKsNO3cluGqwvrnlwsjGAJiUjGzMvq/6BLGpUmmzJvuvHy6RioHH9d+UE4curQd69eG+m9RIFzmkZRBAtzZ3Cnn8IHIDgzDrSDQmVr3xMZxO9KSzjC+5xKcNROPFO73+N744BTHqGQWeTPXqIgIHerlZZqfRYzCsbUuUvjMvisajilAgfxWtQGeW/B6Re+Kewb+xvhldIwhv+mBuNhdQlzKnlOcdRKUSyqYpJxQVNa+eGn3xg6ssdJdj/QnFQ7BGdSBbQ4pB0gvhkbHHRZM8j5IzZND/S6xnxDz08rArt1mxcuyUYs8gtHUJuVgCZLMA3KisFo2QhVfUzdjGXoP6Ab0blSxWNYWewtcJI5JKIeaxmYGsvSumUGmJRAzWCDI3Gp2REkAhdpdiMYIkBQaEUTlkHKnZP9Apr4RCc/F7OGoDdQYcVB0hSSy8Fa9XUS66U+WPKJzIMMhLYfkEWynbgEy84BpcMeoTc7opJIqiSm0TdbySOYOGEvyLqc7CSe4ALRANRAl63iIrnMQvECSGpkbsbEpohsKk3y8acQLZ4/Cp8OKs1COc0Ut9CqEnoxHwZoIRkjOtAuGrdCMHDDDCo9IoBNvM2TLSuVK4kpMgYWwc2xn3qZ2xC0XIvlUN3zUSmpoTQJYxwvmPfQDM7RjmxzqmYfkIyH34bk8eETjOJpcgFNmSkUZMF1oTvq8U8EVjkDc7/4SR+boFe0Qi2FjAs8VcB6ldgzav8tjC/NYqB6Zg1usC0aujcqZTW7YkqlYi7T1uciJUcolREssoGAgejblBUPaCzeZ0fwjDBNSKbQ0SMxLZoAdt8RQthgYwEXF59qLAoH80n6/zTzTjUGJHJmacKgEjMtBxchw43g22IVvHklhMDUxAWkiqkuKx8IRliAsm3KA+K2qZpTezW2vH/MwkrPP8U0ZVylGC5CoSDdvWFqhj71YvKTRyUEnhmet74G4Mtx0VRLfCu5BGIfZP3hBq1na7SuYeWqIqLGdns/EDnVPggUsUGNvNB0vKiF5GDXkHzHp3YqzksUGKSSZXFU0ZXQ5BxVaTYxpon5h0lpHqAR7AIeaADtQ1W7uXtDE5CE4FWDACfCgVReqOAK5ETOtDdmaVStPG9MJWJ6xlOnlU7d7GD1GKpwncmRiUw0KDSSAOHs2UNwIGgWH3oNS7Q9jWa+dvPde0ZbYZCMWmLaVZO7HRewmHRZTYqqiZeeEsttQrc1UPOwsTcVFZIDEvKKjLjJGI/wjHH3q+Fi5wkigYzDHbrifenguH/Gvp/uLNuN/y6sqc3ULhha5drzLp1O2C3BKqQl6QPBHuzQdA0L2i7PeDB0jM9VWb3gx5TEAIIYCPVUUnZvYs+EWc+ZkySho+JsnPI3EInGjQdNdatNDjiGqEYtwoetIFU2nb8jv3dD8StP1P/B/Gfp7/k6MJ5uUXTuhgp4TmvuOKteFvM2TjaHqRHw1t5VG8n4o6+kF1a6D4WgCtAtxY3A6AGoipdTtb2q4hmIuLud0iut0Mpodc9wPS1xbOn6xLzm0T5h2epZVvSTCh4Q5qBMGuooSIlpKHpBAb8dlu5g/gTNtIIpxtEYB0+rBUJFcFHUsy9dd2OqAqgsgtEOcEgxKpEGX1rDXhOgsqqkHYytw6COujx+XgY2G7UWAj9yQkPcbuJgmkVFW5WiiqYcNzJ4kOqLiEe4V5PXR7wef1jjlVw1k5zlzEYr1O28WaPS5WG2jrkLhAdeRX1svC9vKk3IEPiAcvkQWPbZWwpvAO+frlPIRRgkZmVMjpSSsmyv7nDL9V0W8BywtESc8TTR+Nhxsq2W2EFeeOisPnqVZngHs9YcxH5BAA4szM4jxJ3HMJ3jKB7wOVhjPAE0fNzHiXkhfuKjc5YCVbDMl82XjVdSX8OFAVyiT1bZYNolkBAjEg1uUkbY8COk8CpWrh9LZMRkb44ZIH2ZRDTTKhgEAUHPK9NYgLJWxd8nr7C643MgM0+1plY2TVzdcOnb5Au8KLoAIZLDebCCC7bdgzbteepv8rFN8WbSCnNV3Gx2Nu1nSv12LYEqYmUK1KegyQppQKrAoC41NtNQfWxg92k1n/3rhQajNVQdH5ve6OAs/FQYbgSo4hGyPMs0I9n1wb/UOOFCsahjBdRJtEl5f4Wbt0WBq3DVklLLo5cl+1NjcK8JYUzSWQmRoThjxd8gQo2qCYATt/5rX5anOcWpecDnSFjZGG5V05pHB3kFB18TE1AcK7ofBJ/tDbtYpgCxhXEJJMJLJ6FGgAzlmVZKuiipkA+sulmwxkAiOyrsbp12kusFSMhODtqnoaJdoEaqm8h9lod1l7zWJA6DCBqPL8zoQAmKLX3O4jZAr7FH6m3q9ONvpEMMD2xWfgMjr4wBWiMHkJcgEvGWJbruCzIzMtiG59HvjR6P43Xp2jJ9FyL/MSLwLIGNX5s87vaRzM4ygd1fh7SNBw91aM02CIlrpVoWmvkOtW+ALVgGaXQShVO3PN3npMnM5QJUcMAkINgVB5rVCoQcexUIy3PqlpDRaUxPG2qknbpRdp5diwquZjpciB9dfV2KyYNMe0eGMJ187ILg03rYptQLVyLkF3RnsjN9D0rjRyz1YxU9bWD5k4+8IthtdzDTTUJi85d+lwsRbmkdd+vA4Y2TplD8XfqNQz0Ivz1ROb8g3apgSOL7GJ2JAPjxlqJNHlMwKWj5yDOnpU0eQiA8P0v5x/J1ta3BeuAPBPRoDocshplE0pSwt9aGFSBIZyWEHz/ZDmHFf3CTBYk04HNv5hU6VZedMyScuCS+xbjQHAUw+pTbGlGNxg7hpkwX1ik3dgpGIv4EU9NlKhuMEyZGVAoR3pzxjNh2Jixgm2jS3GyL2CEkGmRuOZo0BNa4wGV3IIMU2I4l5XCzRro3DqqU/Nh8/zwEa4mSfIN40dgaZCdpmOd2tlnwQlN34cRtG0g+VKis1V9rJEgWWhKKddCr9PyM4Tf5adGvIT9oFHuZxQKrgGCAUip5MGbEOj6rRfXVnfJ/ayZM1l983jsyTnLkZJEqDXInkpZkZxDpf1HIbZJj9QF+e1PQa6BF0MNdQRUp0gymMnaZkbfUUO+DxoY4GW+Pf5XU5aOMBaCGJoZVwGcb8w2eMir/0chkeljYHj0+9zKD4yWzbqa7ukWOqE/4O6mjU+1EnRROQ+GEKb8b5AsmHmiRkOY5JI69JyevxzXgcaCEL7jYYr+eZ7AhlplKuu2cbaZjhTlj5UsgawCYQnlVkJsSF7nMoIXXFPXcrnc/2afzBT530Th4eD3ozPflAeLxIBBejm6qjTbpxbQ/FGWyeou1W4MBuZuwojIw0XJSjGL2ro0PQoVYZZut68Mj5/Pm3r6yDRYnP3WTUjPkN0r4e1WWi5C4O4GKvjGm2HIQuqWxO4PxTArnJrxK1QRsTP0SsxtmHWdcAZI/wr3/Bgft4MyWgTjvRgYIyK6Rz9NhU+T2w+G+HYDMh9xYCaAIzYd/bz2B63zytrsAiAhIh2jVk1D9dkZa0CR6K+ZXRTwDGsY7KhoVFO45lAuU8eNR1MGfPyYNeV2+ktJAOOUMkF/Vx5bTI30CIReU9b2dwXkqZQtrak84j0iYOpFHNKna80+wH5TCoQCfxWy3iIP1z2jD49OeHfou4xrho/XmKv6zmLj6CE2n2iq61LEKCvO3Lb4+p+0CPLpMeUTRtPWoZOrnxEosscGsCMsiK3ZuHkZtbj1KfZbxhjUg7+khkbNEKSoc2QadViq9hpTW2AdJEARtfQXj3cOkihT9LzLp2G3tupLs1/fTqx4zGCqWWCUwuHJKT/9q//A7cYlIb827/+T2oQDBWQ4r3r7qpTtDZlqquboPqXXsWS+2JKTXmQ68b6H1f/8t4WEkXty6pa5yc9gJG576ftxQ9ndvNxxtyKRQ+sjRkBwUnVxgkrU9Qdu6nGioVq9kXl2uvceD4dEVuc45/h1dRmCmA6IQRrbWsG/gV59aCIGYpN7O4ysioq/2wNZljTCWsoS0+fNgkTWSOf+XtCtnbAQEEkAXu++xGS1c/Xobm44ciyIv4Ntvk3eWvX4Qw9Wfro07OXCIraAC7oZvm1yRLdtW68zK4InHS1qO+Kh/gms71OdPCI/K+U34/5eJHn1C3dxZtVLo6NJh20MUbiVvBK0Mlhd850JUegSVDFADgWJTcb1JY+KG58GL5YlZ+BX2Xejpjl2M4QxJeLHHlmOqV0AfTuV5UnP1RVNss3AgdhE/M7mJcZyfkiqvjlsldr6oJIxfHcLmp8cfjet7q4yWlo83BX8fePcHYuVRYLnqp6iAPi1TN44ZrwRS7dLREA+40pwyAM5umvN4PbhCEgSVbExhivpOJ9Bct0Yk1TPWZr271/92qZaRc+HnDHwICovofrM1qtnPXkjB28NandwHlXqOSiwiAKcCR3/JHmJc0ouy2mRY1C2jURjDbi9agIeG9TiB+/bmpZsRQ+9PmDasapWvZtEmJC/B4riWPYA61HUGQDWWzAcYSv++DPt3OnhbAC3+onkaIkSWt0ittkK9Dpzqa/rndBNkjFaKONnZp/1T4EcsmSrAqyY5ZI30t++h7+qoWKLYSdyCl/bkzjGxga1T06lDX1YmAP2EpXR7FtLegImZZgE1KRF3lfOmGhYsuY3XWURYAV86gvV2Yj7assPYBDThOLAMcQq9pWCXBk6Xaq2b9gxwzGC+aRg5C6Unq0mcoa2xAlXp7jKJ0HsbO1F+xbCKDxBm10Gz3vS4PtITuBCRqikI97fTJyTWtKsP02vwcj0oRWAfyCZ8jK24Pkun2rlNQ428GjSI+kqTUPhZ/GO+JcRA44vfoGmj5B22cMuyzFJNrRlGk3Hek8BGyswaU22pbPsY4Q4gbZRstuF1vsSeLFvKrAfWbpHtXHI0C0TiBs/CxYa0DW0ctDjZKPaRZdEfA5ebIgzVTqhYiolgK4nB+mgG13LxkX7vk2X4Pc9cbvPEy9LoxXCI9caLG5k3HjcUZzqtMJvTiI04OsKmsbAJbnYxq9c/PNU12e6QAq4OOBpv1qO89EllUCrIDiWRCEVuc7YoEMaK8D2Lvdbaj5mBiA/S0s6cEAHTAZn3D4m/JEVS06s/19HgGUsiJc3MZT/LoizZM+HvtoasraE+OqgyabqkVbGrSxiZsgJTPxRKuwJ9Hzw5ZGnJsO2xVZzR5kcr0YQYyVSn0HBR/XCck3KoVdrmrAS2suvQbjLao99UUjjnWOpaiN7QKMBUCzxTh3uflx4RKQjxjDYmZ+C6Xdnh6O7LbWWorvKmihcHUOHRyLSbmYnGTvuKylcaQKfsjWR1umCveTrNZLRtFSgX2SfXMNpQygDo2amgFYrpJar0bF7P0wQ+7n0aysTzfMwY+h82pVDaURdJp3Q/lbths7HYyUWkFPtDvLHxxUjzHg8DGKh4Fwe00xvqGZyLO+2ZofKckVHuP9rWepvi82gKoEXokdOrYOSJ6xLFP4tFQFRiQ28AltBL6pdphou2/EdUdPhP/QuWCqbjoiwIihn+04uXD7nC6M9wXg+603RgScXrzOvjb70phg2QgawE4TWIBBjaYKYVMY+NViDiNkM9g7RkAay1P7RZZ+xLGnp5vrLTkS74q7arzAe6/GpcdpKk2N5ljaD8WPlOf2+2d63VFhKxsJk5szq1M24yYdxAsmWUkuUgJYXh61uA38tJ/seyQ8HT9cUboMpw1RrP9WIuEXHLqORbQUovxIgXZZw/G/mN5VUXPGSLprms+wRsiR+lp8oO1fRZx5AXm83KDWhFunERgCeJL9xhveyU/bnkFxoORs0qmUeWUxSHbRNAUwroBALWcSPxsUNQQxlxx/FT/Rae4gToV2dTrVNMk/Wtcl6kJibZxIMJFBxrJsWEyTO7AFsGKhRd4khxa3PQDvG6kVw8QcuBbCS4LdKXDyrSdOAal2T3FSTBerThk4D9ZtjPCgOg+UJHIixwLZVaL3RJFrFFPlPBRTLrTc1kTBPtLxDTAgEkt20GeclFOJBxTDNnckapdtn3y6EkVmXZWo5sObdGB43AC8DhTFKStBQrnMQYdAT8Etc4UL9Quw1JAN814pHeLtojjRaL8mlWANiFuoL4HnJQqU7HDrKGIsxhcukQ1KW8xtMFNT0Eg004+PcRHjikCB1ExTbsCRfjiUFdX/cmdoDqSIkBjGbLzeWUBMiYQugmh5ENjzlG1qUZLu1mB51ggSdhuC3+Hq7KyYD5j4UO2hC9necxfXV4AWoy+rQYnLoB1MGztZU1A43yrABLlM4XwUVfuF9wf38skkEw8N/HmuojrtFXspTw9X1+oTW+yy4knGS6uwKsrntvC8TjyCk4qjeViHJTXWlUedMH1Qzl5J/l/Qn/U1uoRLJx4YoczcY+66ji5NLst9hagoAOkXA2fnIY4DUwf85xPfw/Z1U+okWFupkSKWKG9orOCQy19xjLjAZMtBc6BxknFQbGQ+RQ6ZC+aihi7uiT+5GCZddftkp8ohZeiouTDYhLJAIEYMneOdwtMF1nEqNulhBPO0ic0mOEwPOP8zszrKw1kG+/d9xkYe4Z2rRsponRMaVLPZpyRrmMUzAz4XYfyhYqcnCSSbrQnkhXaVwC/rwvaz3CDBEjzuR9rIjsbhETlKn+6wneL6k4Jst/ThbQlArPoaL4gHzzcjw2ostok+7F+fhfpwiVha5REsYc2KFdDTiOcOiZ01Rw+X3zSOnM5mas1gCZ+UMudyzefqP9FDRCVtc+cgY5R1nHO4IlGfmBJO1DBumWFsU/dRVXocPHR5AAslFkruEFYrHzEsyeTmqKiXCPAaVFmVFna71ke1uANkRdFFmEIu3VOrjwHYUwZFOFi2e7t+uTrvL7R/U9shHTnC+gVL26j2KpdmYQRaL3GaWibRNQfyMkuOi0f3BFr8qsR2ht8mAoh2ypKh71XUoszDX38UcOEnaYsrhnjj82FgEHFKRGjmKxLjCLHacVyiqiCWaN1TEe4E9PC3VAziQnD3bDLuUkB+69Nk7MNI0Co5gdzcg4hK13PGnx3j0FY8Bb5TyhRS2ph5i59MxZoIQbKuMNXm2Pxean+15q2D3vVDaUAs2j7Z3CfZcbEkJTbX3h1HboQGkMRZwml5GhPqoH7QFpucoUTWO+zp6CPYPK0LRlYqDM7xGHLV9fOIFY4YwakbppNZXCz345QE18NYJvAzu4egGp9sIF4MJtH7sQrc5/GCSv+oEjp69HrfcGY7lbTVyaN1BnJxvQfG5Vh2p6aa5YCSksywxZ6wPTSsqxlkFcQmqlRNcSO5kRjkRJlfAI1v6pDEotaWdjtgIBDHbZi+VNVWKkvYHnb1H996TNXh5LmDDW6jabaGNwynpSyLRCtAL1o4Vw0DywDCZWQuh8SgCxeVjSTLGNxMLs3nB56NdLf1W2rQSY57f5DDgZAdnUJODOJnFY9J/8VCKYP2OEljTUx9SxRzqWrLW2odQLq2RjJxGoWnMq5ntmjRgdc8oz0DpIyBVqa7UvsOkqqPMI0JtjpuMEDLNRgVyiVFPDs8KJXw83MVrSjZdDcadS41zjB1Pt29AVjVixzOi5HZTtisjFMDqoTRfqpQYaVeFEEQneu8ytLy2f/wOdKJYbnI9WSE11XPO52O640tcYoBBXI0XOy0kUU5P1xo48WOJIeCZHe1oFFAtWgF0pJmgcsoN3PicflaOjK0GIgioYm4GrhJmmANOXTjbRju+GENDoAM1Covn67GSuf21lOVqazZ/tbOb1eb+i1mQtT8Cdccivq1xPPwjCAeuymSyEQsNXCKT6zYsacxYhrzZFg6rL3212HpLPDJsNBjoEAsjMqgY+tjXuJCJU6wW2iconNKpqaq21sEJAv0xqdcXsOFC/hJwzL6eapqbPVTFvVikr63fZ/Cjc42tCZuSG3rTIvFvOo6CDYF1PxK0RQi3K0c8jYspuUfFymP0MlHCV0hC4wYQbQwi/4cManDbGdrRzVwfI2UEOrdTInjKK/UBrCDFe5NKt42mjpiyHY4LPh6YVKAaoJvLq2mAlFi9gPWQxrvDtI006SHF/GRYk1uAayImyz/xhC6ADvtpijGTBM+USg6FKVQZb4P7qKVffj3xNwH9rPan5j+m7mEonbNrFtvIzHqVdC/jiuUkEHJvGnAtpX2r9lRR97jlnj5ed6URR3GDaB8QScaJuYFzIgI8+Dj7HLXF8IuNQejg8J+gZUJ4bvMjN4YMWHeFVQg3I7m5up7YBhpijnUEZc/wD8AzbFoRxfrPU6V/RfEbma+2XaUKW7Mo+do7zNcl8WONWbpPDb+nmTFlgZkYVYHONE584IJEQTaR/hxileQzYZsPdAtE+AGitOKG6StNph1j189Kdz9ljUJhlNuQUlhxZZSrG8W5nqIQfRJJkjWlrabzgipQ3W8tRuGaVdUlu1tHRnXXTFCYW26ET45JW4awZz+WFc+pfQ3AixO4G7GrmbKRla9q9Lmsm9jOs/EX7uEtrKvSCjK7Df5ZPZ5djpDa5nCPAiabjLVtY30o477UFB54sVe7HsINpkghXbmS2yL+aaYvwnaYH1eyPT56dmVTVreMqxNe1aET/EpZhNFcSmMOrtba1qFQYLE/5YWyKD9Fh+mmArfnQi9VZih1Rn4wHNgk/u1x4sVZXcsq7I2E/zhh2FCt7lU7CGPCijMt0AdmpCKxvymLagyTsCZQ0yYHkdiilHgdgrCthO9fMVO4j708/qBPR1F4Jvk3EOlyQ1CHv9iIp+38zHC5phI2MtzaeRXxP1g/uYTR6G359LPrb1dndZ0G0HAAnx2GifVsbyNILmBm+5l+8V3JC8RIXgKyIsBKqVFrPj8oZqyNpCN7DmY0hk2oCVyWCp/g6ZZJRQwzzKM2YoUaUPv6iiZj8iB2A/Dlebe240qMaFMuppyhgktRTakUBNJge3dhQ1QI72tomsBC3SIFfOnrBUehf5nOy5ccRXNbK959j5aCed8pIMWvDfY6QStqNDK8LEnbN0lP1yc5NyrK3Fa1sPHMBvDFYGgVlddpkwk20o2gEDdF5AmWlLW6PlHBNcP0vsBFTS4AbYdgD70fidEacYOvi3atStgVRbWRkg3DEjvbSn/6wozXv5T/PyXKrVYcmQCfY2qDZp85br8PabMbgH9+PggCggld3eajCL3WFfdgFJJQva3NkC7wV+QVKUa9/NazLzHWJOviwnG1DDk6pqqn4R5ECP668EICgeThD5GVrUcKiEBRq5n2ZYB+YDAAxvVXt2vV8qSEqmMKMEoDwI74WKKETeeISvel6dIolrmpQasM2rAwM+Zeiyqst/UBBB0mkh14kwXQ/vtFkAD+asJkqIsg9V6hGibCe0a1Yg6M93hhDQI0+bGlhZeFwHnVIi59fk7MYQQtAtjYWfefqo7jwSv9/oKSimvbw+n/a9riE412WtsZjU0Rg00yYoJfLUu1o1zFMy6EgcVE1SKG0/QMVH1PddQ2/Ir3vDn01sjQkbpl1uEvg5MeRWNPFuQSt8ywxAO2axZ3EBVJ43TSw/RPnuEIPi6NlLf/OllBXaDjs6+TUGWjiPUbFCIwl/gHXImEndWRluSM3xWhQEZahDNwGgjiAdM5C2E9u48EoOIAKQCNyz5NWHETGcenAUp5sdyiwDTOnIat4AFHmqTm62qvl21dWNSmt2tZ9DsT8BxFcqnhA7UZj3pTlGlPza44LUy4Xyzat9pc56urxlcspfE9/2UF+cRyN94Are3aP0PF7XVJLY4hWtWVyTqXtr5XNdDCsZls3qbGmJnZsj1jF4Gk3scZoO3MBfINSe8xXXOxDlF2wMuO7snsttlpXJKR4g/S2xK04cYroDmFVS7kIwvVGdz6QsZkO6mtHaaQIDGjA1SbA8cMYmLubJ7peulzR5LylKM38qFLXPHaNbqJfu8W625nMX4I5DuDT6qcBNln5do0ptxfhswqabCbebj7jTqkWZeeFBA+ZjzTnBK82HtzSg8ywuKhBDOw0gL2088TUnqlI8Fb7SslOpbOV9qoRgDCKQ2iQ7VS1PaiorFXuvumakEoBgWBJ1kXOmowrgEw1IZtZemQE5J/OPl+isqm/PFEPq65dziaOAzXpqx4rFMpsf8OlgdewDRNMQwv1kxTCkDUnH5/a0wpfA2dU/cE0LasW6QD68BscECECgh0bZGbWcBcduaxx7oyh79oXEEf2WEb8TQsvLxCs92VUzoNHxh/E8tawJJjcl6ow0p/a6anvvQijBKSUxQITcNohxWFDlzOZBEFag2yIGduWDPiytJ+hzQRQwqktaI3JvTAdJTsKw107crtmhoC3uBKVty1fdCeapkjzkIUD67KIjH9UIJxf2t3d8mcJ/H7SXzy8IH8MyANGV/ay/bSNTQpYSv2AmO+gzdySTBDmtI981Coi/+jNGa/wSn959EA6g6EAwca7YAPYoEneYN9b0yzos5l+SkY4oSxR4SFw8LbO0sYb9cAoHZhsepCnvgJHt29HQ3tgWDjYvNorEiN3+4hAMjwfkW8I86PgK41HDMXAEyeQ8D5Gf5KGxNvsPlSx8pC9fJ6zp/sEg3DxynZ3yEHdMhKAOPS+24VRkQFYzxEx+Z7o+cx6F6W3qaemsa3+xljGMAs5LOG35N4xPL6G+GfQN8dxQXSsXFl7/KpXbzvlcJutGSK/gZX23mFcU99Z2tFjUWQiXpoX7+76We8dTtzXtnwFL6+FcjXUxcUUo91d2o2h4XFT3FSJr1jWwk+k7FFeGwIme7rvxhLhks/ln0IYCRDGPHYbiEdTIqjQKuB6MH8mYRRfZEmcaDaTFcs7CYNCHV0VJXdkSHuAI/JJbhBSWSmTg2RuQuFJxOIC7buc9DPjJOKRNdA8MckVoeqk31DENrFQAeD7jwCe3vmwUGNYi4bb3Pb+mwIaF+m/zQ/FNamem2mD9XvkGh6fUBcNIdq3hzMF1W0xttxLIU9Y67AoCNKVVOHQzA2e1V0551/QTX2fTKac/2kNZsA4r32poBRA+mGOxSgjxNwxbSaImj09I3GL3EDeMGGGnql6cs2xCPLt1ycEQfhIhsy2ikU+owBNcngLmPfncC/reR9qxwwaHEmH4ahDUly0w4lQhY1VCRDo46gxKNV+aDDnsE9CuePEqgxB0toQhOW+uBBJxgzS1ipuKbBSI0+aZ0TYm1Vy1DshfE0e2kNPFXHrfxxlWK2SXJsCF6ajkQLa0Q3cmjxjp6boXu2VZEWsnjXeZiVQDGAG/eyeAh1/HgkTZ/RkYxRA/nDzMf96Z0A1ZGwmSMyhnJ/ygI5Mw6T8th6860AgwaD/pZvaWwMJedTAZ44fvWVe9inBrnt6J9bZ3qVms0MeCVxqfEFZEhOyqX2fLgYQqWQR3hGU1IjqJ5Auc+so139FNjvcDf/vQa9NY29hrzBvAEOPzZRm2HkI61P/0ZhoROGQkvoiRlBgK2Dchn81MGUA7148bGbpoNfquWpAk7QTckVULN5Sq5RJkaMWFSky41fo/5jyZ94bBaFlRdvxRR1ZQxUQCoYIewULzEEmgGkVnWjSOvzW9zKulNwcqjkA58hFTjwLNK12SnD43SBvVi0ncCQQt6DJkCjTKaEtA9qBxQfxMUHdOIMi8GhqXKvkAAyQcbs2BO8UCbkQw9XUfAlU5yWDByIm7SmvFLAbWtTgUHKYZ3QNrb2LdkQY0AWe4VVa4AfXiJlZSlbV7co/Dm1vcNckPr3nOwahAEZs1Fro8DpEyLYtjmt+R+1EfIyZkPpNVsaKO5wHSAq9L1lIj3AHtzkuiY6ojlQuBCzFV63cZgpTIEXnNH5cN4WqFrB6FEov5ay9qBpOq8QquAzBpAT5sZY9xCnmEilkqe2jJ1sRY6iqFezqpcKwZPGaepn+4k5WLtj439rd2tZ651iD+AEI1jp+DMc378YEtIfUbIKGNfWJ46NvOvwAtkwKCY+sS9kpj0Swc+SvFX5Q6IE3RAM8InM5rDyZ5Shb6oWGuWFjsyzFE105E0t99cmzaJfVuhGEfLIUyMFYC/dUOlkcvmW9RjvCIxlHDl2/PhEnBlVQFDtJV41hjQpchM0oOeaUEaRUcI71Oa4lpjv5DrydGgKJxhbIk/Qg/CAC+L4RDIhVui8c38AcGHdJeUOntbUxcfxs5+iIZt1pXIQdDL8aUKhAOpWxMzd2WziC0RKDJBOMGyuI0iXbnX13ldUv3U6Q4BKu6oBac6jSVlUhVPvqs9bwmIdbsLaVweYIMP2HtIzJfqD5wmSrFJeYU2i8LBuH7NDNj8nZfGh3bSBl2bjyJ2tp/U7IOCP9C8KZjNsO3a2OfFpaNl21d7uMu8TvCRtu4HexupNqAKMm5phfgd8/OL86uz1EaJquW4ShjahFOzhTa4abDMW5+yjWhxNh1QJKXsXfckzaOl0InwnmSdD+TqxLoYPzA+yEyjKEL4tMPUK5fKVdxnD9XC5pZyEatOCHCh6iYLWXauopp98XhaN//SgYStSdw4SDI4tCSNM3bbZ5blii557Ajs+8S3QMVYROTjusnFKtaO1XOfR+/VtSbxGtjBzBwHiKpMWToasQAQ1vL7uU2oEUOeiO+x+bWwZS5JAvl2zPNRFG5wRpaVsOvQQzgnKVa7W1mxdbsFnkz27ZsXTM8+hf8+OX//zu+LAHtpf2dzZ2fnZDe1QBjIcvwuEYV1gt1AK19r++juD/mtTnt6s5PGK7RQN1P/GUny+jy/KgvukuCpN4Y59nMOCoSi1W5PX/pF7QyT/LV+OIqig1z8GYBVBTcWVWDZM0V7/r5KxaISwzilDtNJnweDIEY5uOW04Bu5nHTHZjQdoWBP6GsIHy63JvWRucnLMcXJwJxUUQZua0zun3yxpeYJ+xtbk44qfnDGIXqDIoB8w2U0bWCwLeFqkyjatFJkbMICYU9uyuxdzCj7th62MjQ4N/BA42VtAKtENIyAsYriNeTED4na3TSgCLTtItI9Eykj5PUyZNhZUAoYscUpN8/HIse0F0FtG/eiSOaX7VO/phj+qbIIEyC6FKGw2YOrSguimxK9F1N4oNTRhE1krrUoDlE4c4ZJWvxoyJOSoBZRLOC2VI7TulCW4uzFZe2pdVVL2+mw0TepCIwUQ9SMMclHtV47BX/uxc1TmSjKfbDZ3CwmE9CWlmXP0lgAiCsrpRzBmZYovxsboJe0F7I9m0lJp3d0Pa2TSUqYoYHGswsME/DB40KXTNjVRRpLtJwSL3oPire9DCfiXFO1fiFAKae4qyfTNiznktBFP/GiATriWYw4j7nWEfSXDf+T2Ai83iJLTvuq0IGXWo3IeYJYJkQQP5mFgHALnoOctS9QTJFuAwvd9WVkK7KkDDDE2QYY5YeXEaEDbGYjSas8GctrZZS8zOumkK7P3PcM/7WZLabFpxnByK97l6enr0+/u3jde3P+L+9fvL2G/4ZWPn6bnKOt3bQTFXKQtYUfsOufSAHbxiKELIY8eFut1s6KWvxAraVmblnvjtV2Xxj95E7fRp/hnr2O9qz37lYiuFMnKTGfTK7PMsdHwf/TWcOUMgzZX4TDvIUzNt0IeW1GNqUeU+9JvEJQnUO7Z0RhUUXbLJ8WKf15TdmbW6/3c0KIyesi/RFEMpjjpuVN6Wb3PstcoMKZucY2WZACzY0gfpA8bfBOpGjKh9jPuBw6cHdOERJstiGBeK8QGU7F/aBnXmbZ1tBwbXkPr0CjYtQIQ44ajXHIW6XtnLkj/CvewU+daW2pWxPBGH0zrHZobxi7tOog5SJ5wrzJp0Zo/VD0CM0WZBvMs1+YC5oRJne+Bryt7mlg2xUAJnPC7Nq2XHKuouOg7tRuAPJ/IjdyT3shOAnauIQ2psz+PTOWsKW7CaYFb7FNOvxpSmMXjWgXon5ax3q9QV0p4YDVnhKySPORbs/uMZDEXp1TQpOsdncHIZXNl1oK+CaB7TiKsB26MFC8MM/FDLFfZGaJipBGnwyB2EvMCTyZOibRVICQaBSNBhGjjf2a2CUlqaVXguowiuWwELdGUo2woOmFotC2ddORwlfEDgF2pS4SxZclS/EuhLfcVtNiKzsFaia0QrzQjIVk8fvqoit5nmJkn5Mcn+a5915I23YG3EV24UNiHtq/xHOKSQjLxZP061IDUGZ26SVqUjSnKnGYe2E+ixZLvYJcJxgD4hjkgaR0mR6mHTSORUUK4dCkXmGj/RF+t1UKQkSFzbhlZQ2OjMFuzBl8SawhokQH8Ytg2p+IV8zZaUuleLkc6wiSYElKaYHBXo/KxkWfGim1AZWs2xTBXl9M8ztj2cO7thgA26ZLLI4PcBOFL7nEztDhKUvK6rzXICJmo9tL8CSnQWaIgkDQf4k/dkdwu/TXROuOduinfcvrylh54DBAqxHnJOuSQ4YhRkyekWsp3ROSOoTlk4djJ4C19FkfL25Twru1ja7Eh6R/lGQjbQ/0FuLfhGkWov1/TFatfbIvHcujx35/kt0U98Cr28/+uMA01SZy45o53Mrez+DVBzv/ZNQqFnxWwL1Q3xZUsajO/VVAUcjWFmwty76l63dSFIaQANKw2Lf241HDaJXkDFUsH67qcI+3RGHESiACSz8dzkM2x3paWFyn2z32M6pZl1ToMvF3ioT/FtKAJSgWjrOqH1cq3iz3CkFp6JHaotvUaPjTLqZcCGy/xcuuig8BeCisw/LTUTa2gaY6tsBos3zbYFb5GCOVhLZK3XxFDJxvmeSTWPzOAJKYAcGHlu6Vv4neUvh0SfSN+/ua4V1cvoHwkC0D5jiYsxmct+zigS4lLzqfujFinVvqnQraavsBK8obVyW9ivzmg87OREZZENhn42zTPw1SW0e4GkdvLpcnZN5hlN7hARVDi2rKgzCxhzELamGijIxePcAr3bnxhgLx2hjXaeihZmZSJvBVYSQEXMQ9xoT2QrdnE760j8WDaDPNsDkAUTkeF8MeGnA9MZJF4elCYvfUc4zUSVk6VWZRuTpuNpoTgaY7PHtboTqt+r/96/844332b//6Pxn5hU0cl2x6WCaJ8+R9MD2kKpjeySBh3Ml8LkUAxET8fobQaIfx0IMaefumJYKH+yZ3aEruiRLLRnQoUzIwmOt4P15Cnv4aOWGhG0RD2uugDb5+GIXM1COlI7oi68Udx1vlOzNscfswXy77AmtVSQG3rgvVH4EbPVS8bqFeTCNS2ichIXBEuLBrh/U5EKZfNolchpZjGlLy9S783pqfP4yCgCuYafa29rc+JUeyYu4FZwjTPeP64BUz/krE5aAaLybTdFwrJmlLPkuCjdjB0oq8dPVfREtt41DlD6KGky95yZVdxlhDoitbnoigXCswQFKiq7LKptAst9etW+jtFPE/gIOfj8AYDyW89Vfa6TL1jhwpc96n+lkKicM8Xczd1vqOyCz0ubY3pDqB7AkpQnA1CFQ+aizCqtb4n0TdQ0uDSxgIYM+NTAUhBrIVBINqzyXdLon/wLaqAemUjiHCI63d1pjJQqPMR/+K6cqYbbYNfeawIDbNHOeBr5x+vRRdpqiNWuvz5HSYTRbHLeGpp4nysdwpHy/+YgH0Yoe2boGWEged7tTYEcmu6j7kXhVE2IPGE3QtzKIoHLSf5TC67Ftxt9LEM1dWUlnGTO1GphKb4CSq9eTScUVIrnnkB2som2zjxvYFioIGm+Lqq4aI4/z2STQC5co6OESA0Zy6jJrqa4z2SnqHirMRx0NUG44UPJe5RLC8mtLIYDwDrtteqXbdkxVvp/LQaAxKokGWAr0ivHTjCX6r/SP0iOC/S/pDZROZTT+rGN6dcLtgNB/U9ia2BXwJWXs8Qh9uwIfAdZeUU0Ahb6+rZOLE+RpKKsFusVvAA/2VtUZlhH1dmm0wFUYLUZHLCtSdCFLu+b8Uhc3fyJaC2LZ5KwS3P5qfrdcNYUrXdHiKoV8bGtkMi2Aojk97eKk8zL43WpDKjMJEg4gbvyeSCtym24I6PUZ6insat6eJ5ASv7K6mh/3zCXBiIpIaD8z1a+gK04yF8S6X3TX/Yk448wFYGowAJUuzGEHcWna89iCrueAkrCAKiAVXPqMuQNoG0ZCo4jc9KcpJdz4pFdZiXn3T1zdSSzKVfV18mmGxa0PMHbLFaX+ZM9/4u9LXDy6BUt8uJuxG1fk99Z1i3qxY6Rws838cnDyu7SSYqkQc3fe2CwzjwiorRnmxQUgnMlow2s4NSNO74MqeYDcNOscEEEZREZJ2IggSU/oCGK/FDUGTjT1/irdRIS4LT78LTKhjWibi//6W2fjCDD1I33/71/9Hsw5G7gP3ZTOqesyxT2uMJzzmFrWlc4yUvi8HvBSqbV5qKVp9IltMYLNvrgIeM5RlI2ytidh9eBDNbmlgX/cfYKdQMPK24sXsjytZiyXn0QWPaZrc5sCaeAGSiQ9YSs+esd09ccYR82OpYxRxdwzArqo4v5vK7Wr2f5eE8h7aSl/fZkBXE4onAnLBVhAC3gEXJu6mJjC65V1uSbuChWQcT/O/ecIiDiM+p+5waRPW84zbWG8jIReDUlJ9kKRrIaFPbH2PJ5kcSkW95L3F+LpqHJ244cMdl0q1hzHJD4s+hHtJahqXBtKR0vozSlfqpmK+L5o+2BetTT/tnudqXWXvrf0ovzWPIuKIGpavynFjsIlMCJZ1rATPPyH2lKYFMdK6nNQ1uxGjw5ocW9mVvUUFR+hxbSOIwU4+t7xYAI6o30U/6FKOFK3zvdcjv+i1mdfm4AJFC/QTnrGR6ygS16xXTMNh4IWvmcs22V7XLRXzc5LAyL2dl23ERetPAK1jFGL6neep/jLQIEwVHeOvRgt6hO2g9ogHgtmAeUoDundZqUS6IhZCZPYC+FHB9mGNuitKVi0D5G/G88+zva29rf+Sel9oO62Mdu7paOcpwN6EBXx5UxCKOaGDhe32YlTYpQ0RNvHtXhtBAqXmH6HNHULr2nbYlsCa1VuE0AL5DSJ0G6S9N5X/fktludqpd1FQ5D41k2Q2AScf0BWPOEGBIi9GoFI/eLG2l7KnQxhPANqhQJb0CJvX1NQsgkLN1GeHSRr2dNp6aZ5kz+EmK0LZLZdAow+FcjqzhZRVWVnckA1ysKFTT1GuVZ0PUs6vf9iil8f7KILQOxcw0WW5nb4k8QLWpNb0z4ZVoZg4BtXsIahI8guIvJOa7J1ko6uvnLuI28ECczGs3/g6LgkrcUFrHrZX45JqxavKtaF7IaNbbM1KrkqkgogB3/4aAZWnyOaKDp9tHurRvrF5q88wUvJCeQf2EMU33Kjg3KIRAEsSfO09Pt6fjCZD7SmYWg/cug59iL88Z7DUnB0Mot9p37ElqPSCeqa2qRQ5MSLkvvzNrRH+Cv8UAqdPIeBkez6rxDH53Hwge9RYw1YnhfIN1UQrxH7ZazDW0QMh1wM5YHetEbfLrza7DEziHz8kuwUtm0XpkVkoQ5YTdsM6J0UAto5k7swqWAY/mu0rcBRauMogN+UfLKdMuMi4cvLBfk77ufNtPAlRtfakT1cEcK9dpW3XAfY0FvTPqEEo2WaEFUM5CWXFcUBzQB1WDORCAmcd04DhkyR6RdZdoqNwLIXPiNYie0lB/ziDEqunU4eCA/kBfKXOcfbbfS33ETyxHTrAV1GjimD1gj4EuoLOcv9JsmcrtmusJYM127IuKzlp+XpoXfb////9vySR0JQoPdjkmsCdeFxNGFIPceEyUosoktC2vc5LG/GZ9B9q0QswTxary92ligYGLm6RjRFFtSbXdbWAZrSjqiJlmeheyel8ZZLDpnybbhXv4QurWYJ12bewd3/rkA/uXqtIgIp+ASWTFBIJtAnexj6L201mbb0VUcUWo4rDmVHVMm4YDVxoL9jUOz7Y7+2Qzcq2+AYSNTRMOcEYIzKxLBMjcwtprTgI6BIUKKpCGPgd9cr++v0FXv/az4NXIb2aXBdFahooAwIfnAp2wGWOjPB0XjA6Y5JlhG4NNo9vxOPUqztumTLyg85ev+pdQ4XQyYnVDz15QQ9ncSO/q8qh7k5BHSnVqK+gUIzkty7I5F7YGGVqNXRfFDMg8KZUEB2jJd0w64Dlclf3HoTOFkpLOXp1+FRrPDqAJ5ZnqC6UgLFCqDCBPYzYUJLnRUX9JdD2cIYi9opyuSwiWYq/Uqj8jDQcjIsc0n0Z4qTYijN/Rzlj/reByVSNYMwHwK9gJoBv7IWhGd3gC5XX7LoRwg3yjPd1CV3XnbsDfECzybhLmBDqk4op3+IT6MZSqcBXAMw3A3jBK2i9CxgUx5HJ2EibsrrnvHOAorpvYhK1dd0F+cFNEbmXrOxC8RLENFxfbQi5C+FPmeyP4sNoPmADmNHMTAo0JvvjAjslAPVSGjzCUAa8Cv11VULiB4TU8IJAathzKMO5xb7qdkq96BtirROIdiJayDlbXklRg81jDyulj8Ww81DdahRqis0eYzAx1QZ4Ed9Ii6NVK7JpZHSDwDJtMr3Nrba+RfYKCx0ccnYx9bkW2EgKXcHX5pzVtkrY91+o7QKeerO/iEW+1ah0jzQTxn/simCE5UnTP4RzseU9B8WtjAYPdcWeIY+GzwKskX00wSEgjItOjflN2drc05yAsLbJU8PpzvZUuHXwuckhMYL8H8X0iZSvATChJd3WXlHx+0Vp9h9G0/2aVV4QjImGR9d80RmIUbCUp5L85pn4cNa7ouxv75scqrzrkxOjMTeeeNPwMm4P4nUbQC4HSoaYl4AM5hnznmKD32UIyLO0XaQE3U43u7Ic4y91cWPUkm11Gyy8MTzMEE5h18veyW3TiMKVjAIbohqQGOcqS8LtGFPHTpUjYBu5dFBJzJ0oMKtKXBGUjILCdSMz/1QprAunXeGD4GBhrNWTeCfYToBgmmSemFXNvWYSUo5lJkJgVMEjAA1oLjRvwcTz5IHWE95aJUvOyMs2v9u/YG0eBZL8rjne8uPbLm1VAJLejhCnIKydLVD0Nb2Y9ZdBzGJRYidKnUGQk2XGsIAikiCYtAoieoImBhROaTgKzCZ+deVDzTkwyrhpzwnAH2gzt2edXadjZrhgDDN5FCPjEvjltfZqaUKWYoFOMyCI+eS0UHrBhVs7TtZ4HthL5MvP56Ow+p7b1xQTdq+2Pj0J95D95BqhhSoMZEmFPdqUUP2HD/w6NA/oSAG8KFFpc5K96OusEzccXwHM8EvnnLAPHp3KLBSJZIZmzfSiSuFQC5uyU64SQjkk1lzeoIA1mg17JqRr3m4EcabbIJvVBmic+Z+t4LUulWtPFhVrKgRLMYyhHYB/ITyUF1J2Dp1fjRg0lrNj2whc9HgP/dzzfCmt+WzUKcqJ2TyrhPetw+QSG+amljZFkQoOHGTWqZoj36xLIgYAR5R5cMsYW+6MfQQkJ5UY985KDPIMKYs5WnbDbh9w7EcWrF+1MBhVDZwk32VJvEB2B1WSyaawGVxevm3HfhH7SSr4sReF+5K+Tjr2xo8u53HLoB+R/93b2tna20kMcXXCdzEzz07EpZTR7m8Vhsec2IoFjwZ4prmE1nhGxDXudId7ahwiCpmTMRnopWqzDdeeLzy+52SH43lU1a1RKJ2tCAAoQQdcctxUFVu66OaEnDFu4kcAT/Do/VDv6v4FZKIFfjglUAHcRLgSxZiXDCkvEVxe5AaJvv2MpfiIOoBZ1eEA39usCVQi8x63XKpaDA+AzwPsBdg449IqNeJuTT8hlJNU9loXUJ/YqAaN8BzL/lapqQ33kDocUbBe4b4CO22jNJ4PBcKQD0Fm90n2/Pz6NN6erZ32ABxwYaz3VxCkg6jhxqyl9Z3as2+Xxhv1UUCec+WhLLVf7dZCzD3i9rFdXxNA24s5SNsR+Hclc4RwX9eU5D9JaUFXMGgPT/JWXWx5Sw1WbD6EXBQvI9Iwx98DHgjs79dwqecsgW2gd1zNH5BQQ/YgcgwJFRR83Gmd98tBeC9YZNABU8fIPXo7cu6Tr4zZOUSlke6hokH2arEbnh+E0ghD9VgFex9bqhsJQsmPL7CxIVKWxkdgJzoERkVST2nV0+T73y8g7WLbLY2Nzt+IGEhxSJ5TZxmUcasPV4dGW3YCLCyngM4UPz44ILa0uWpNoNLzNBSHYaIwOGkzLgmpixapzBGYpgDOzCcR2pKfiAqkmVVT3dlY2YcBC1oEdeCyh3F5O7U5AGNwEe3SNrTUAPOLkz8hJcdKfAJNxIto5/nbblnxgLf3yhjiQqFjReSSzmwqNI9b2QsKKVOIwzIKcaoUWRid1/xgBn8Tsc+8K5pqTDJmSSdoowEb46z289pDWqDiV1rOsiW1Ty/ywEGQZYCgxY2g964jV8bNGt2ePkAXEb93tqFMIpRtXt9zztVi5RAcuic67a0uLFhCYg2navnIH6gkzLkrvDuBlkgItY9cqvU33zs2UQLwM5n5GxJRzAViAKBt+wJIg7ChiYi4J8Gkg0jhrhzkqHqwD8xCbfyWWNCe2EMOkESLmJSebWoCxgNKMZVUmagwtOa4Ag5hNMuwEF9uuMDgx82DyAEzqo9TSAZJHRyW7kJUx3xTaXTpwmxzy0kFZfmt3AHZhoajO3Q4hO7gL+Y1ifY+UW+fWqCYkPiE/4YUw824uk/bLkXePCSrANzlCpUSZPdjmEIaBRAOey+BUDUnwygQ7H2IATCNn0oWk3qHCgkbZg6T1ujUxJgZL4hwwU9TFpoTQ0hdmBajyXK33/2ydLiVwtm+CwE5QzsIyQIg2DMoP7oCMnSFR23c2QaqNmTDlyPtfyn73Pn3+Sf7ANJWmVdLFSy0x3lfY5s7awNmG6P5fHayvX1/f791X1VcyWkk67ac++0+3rOtZNkF8DkGVRRa+Z7HqgkHT/GtXJeGLbhvD+zXFI87bg7lT1H1CxgI7H356e7UfgsdZFyAHAj6xEJj6IAmM3WGrRIaTENuDic8YmMISgilR2VExhNRCrgDcE+5ZJZyXKWrmAdpkU64Hmw3sgiJNBfuhLLJegqJJ3CDfSYM/wRGGKa9BIaJQTDTRAgCiHkP40YLe9Exflcwp7LXdXuqgoqUzREaX4f8wZPnM4L6ZUGnriwUsoZDQbqwb+PMHGJHZxMh4C0p52BRqE0srQND4BJkg2mhYy8HMUzoRtn+f5okHLekTmd5bIPKWVIufa448hEbx8qyjWr/hQIUMkGti3C62prg6z2YtXsYAE88LLxq78EQSq9NQD7RgQcNLHCJKZJFMco/7TwBPBymYZrf2fKV0gsB26ioL0PFRxYFdBZKTbVXQxFwKQQOlnZfsoeSV7IY8bTSYVE80eEVxf4258wnRkMIb2yudhE3NbTwKIIx5nA8EjGzXWfZ2vAm3pPDHGPhIlGMUiVAuK/AXr3Mm8YoWtumO/anHUyLXWIXbtHHOWUxnGQzSETrqgTu36FiSWbf27ffGo8T2EznRIwK4L4m/WCUvmGNg81gAVSs1vQJe6n9euFgWCdEmv67q+2zqyuS5/gsr6+mWrHQ8IJ58sUvDM6nb0jvIl3SSDeiuQema4sqtOsB/QiwQA/XhLrk6k2BcsEaCYhJkZF9OMv8mh/YcWJxQ3fFIE/Ftpl/AuUNNlnLZQpN6g1ngrcauFyondDdiGWEBMNEKsXkOCn22Rgpo3Tldf6R0YJz9EqJMZ63WYPTG3fmI9aIqDgSHSAkMySVGPRQWGYsqB3W6BzBSk1tZyCxfOmefv6deM4ZZkixtIbgZdgCQxE1u8XziIkCuwN8BCY9jahc6bgZJeHvdjKEJpqI0wKFAngiazmXM7RoEayDNsNWTxEIX1PcIUO03XPIWsv4XxXUgu22FWxDswvty3w+JuQPR+PKHAipwGbVHFlRu3F1McISw57CLOgQ4CnEkZbERwte7zPZmY4as9jEmW9mJe/lOTKr15VM0+rbUcbgI2p7/kMyaa7oQ4iZw5F4tKsBlY7Y2c4IxnYqUb04G8FlAPDTpxInmfPpyrjYvhL7htjRhRNwWk27SwBh8LkzyctaCIQrd4X0J5lXI2wjFbBd4GBCdg15nTtdrqg2b+6L8Tg8rlRoLbSfSe7u1p6cwbNgZeMiIvCiXWp540Y6KYJcfBI/oNHtqgG/shhL02gdfW59zrsC0K6JnmAow04o0uf+WHqoj3DxN0nw9QsjuCDVljdlUYciwe521UaEdigbUWlRxIA0khzis68vkZQwaGlygshkTVsQ+hopNEqoBijQCCqAQpzB6U1ez3xLVCvDBeQ25xV0dWXd16Z9bK0Opads7/rYpIl6f1GYD3or5HXREk9hH0lkQdSz5J5ixn0qq7Eh8TCPGy9JxH6BCn1UjGc3i3E2rAZIScPLgOH2JtT+E2NJkMGg+4Srz/AjleHts2g+lqya3pGFT+BYKhBx6MDxRouHJ9pVhYFbjErzS9R9h6t/tVOOT0MCwURcbzflxxTDMMfastUSHrj6oiWhoSIyVlOwKbrwd1eOJj8i2Qsv5i7Ot8iXaK/cmFa257h4ZE/oVIYPeD/rNkbUN9tnoNLovyVYtyE0S+NxypSNkgauj/l9nGjQ9It1MWNokR6TWqSE6+Ke/w45WTEFPTfmnDz0/btX4YCchhGe85CeRNx2RGkk87Qaa1iTEDdvksVJJNRSD7Ar84hbyRbHemOP0pGGoh7kf4BCSFrFzunYuIdPOPM7UbPul5h9MHqvcA3j8fLO583J8UmHPWv41+FJ5wDazMJ/H5105sg6zT8cbpmTB/99cNIBJQb/ubd70tnb2X3W3YH/P3t2cnicT7KvX1/Dj/snnUU9xpeY/4Tgb3OyvS2MD80WxAOATarZqurbbYo2bKuS3a4OeWzhuLZ+KGfwwF3zwJu6KLrG5rqfmds7n5cnuzCgPfOD2eyIcoqu2OFbISZdT/NxF/jO4Hk7Jx34n6cnHVgEyKTg15kvbRsPTwqCOXlSbscLvG3XTEpd4F3QDlCGtntIl/RwJ/Ug3czvhHzY3LiQePORdxVGcPHv5gUfznqXr95/ffGm9/Li1Tn+1SwfVuH1lHmMM27G8AriWwCm7C8gzecFkEDQBQITT2LcTnSLdwlEqaYFfveumS7exPw6GB22VOnxZU3n8/xk9+S/48QYyyO3//Y33DPYcMdbO93+1tPO53/6E60P79UuQp5wJY72zLz4cRAoYhT0X1aXtyOKTwhPwVJGJR31iolmghpM9qVecKfWRlKE/YfsHbyWme4aqS5j4xIx81yWlepqF0RFLAP7YDK2VOu9RdlDdGKPTX1bpTpw5F6a1IJCVegqIJJ9OBSrMKpZhLd+AW7rV/hKoOL02N9tFQleI3Fqi9owbwJLT1yQD2cuWkfgWkxIvXiesPUovA6z7q2hlNdKrQS1E1kGW0k3CxwxHQivFqSqFfgDLbtZotPlsh0AxyWR25pXtxihDzwjIS1+I3pNuG+NwwjAg3xK7ZxBvPtUuZjr7Ze3VDodZz7vgtp9HS/HvdBiLl9ZN9Mae40tKuty479VuFjlqy5PlVKI0Pbn/dr255WtCsZutphyLFmDwV1unNxTJFuyl0HAR+C1Cs+G5mx+Cygbxwr9+gFakKD9hOFpV5LmU4omw1zu4W+CppdDIdGYldg3QeXx/P5bQJJopItGz1nKUIRTABKAWbxUyI62iA+EwXIxXaV59bGcUeXGB2PH1kOL9hpXuJVFsJVTo20xuNxEJUspu/wNpwHwVIDZYQ1zHTpZ5lrwm813Mgamn085Mn+jm+mlRoCV9ogUIvkqpESO9YzbqsFabHmbGzw3nAj3/g+XCoeH5xfmy/1pZqmi3ZNetX0yKkXL/OwOsG6rYJVL3KJH5Ux4Wp7DtFzLtEj8RaYnkYsgRjgVGSnmkXcOh4VkmcIXayHiHHVXju6qErFMNMjlASvJl9i+cse4d3gCFHEjQ1AsbZx5QJBEePGcPaGgWY1A59ncxXaKdmB9W1QRbhHSVz0MUfTIgRX9FDp26fA17mzWtOfkeFG8g4Bi1AvEmehjY7uPLV1LkxA+XCiuCmDl8d9AyyZbrCkPcRSOQs61Cs3g9Rr1wmWtoLQzQS28K6ZmY0EB311VSl7UyJOmFdb94buriw/ffe3nizBsBhyAUmKFLRhsHXj8BV6rbuxGQmdavcdxdTctvdJQL1lXiAekjgGux5xLQ/rllJMFMAE59YirYaf6Ho+xMPfQbs/vzKSB9m0Cuz4/2dthw1UcgX1jpn5Nd2Qv4Zbsi2aWT7/SkPcvtvFP7AtA1gcN1+XvImchsN13j41PcEps3jrG741gK/vOWPYSrxKNST0WkXLZ2J4llrGqKC0ylNsaz3JOCi0qrtsyigC1BiYXpRJL4p74HZuoi3V1xhab8yQexhV+/v7ujrHbOfXGcZsvRvtUE2n+tf/Vr9Go//WvMvN/fFVAK+iitbk3AaKjGlWOrffhC5/o1L3gnGuSEgyn8KcOluH2q09Uk95x57RzBhD1Ke/7Tvhcjo5JSzWyQlWAgFk+GJJjieMW3EqTA8O26wI0GKiAkoCAGnRAKNGgHgprIQPBHS5TvbNsqv8hMV5c6Y9QIV5zr1TMWAmnhsS3LTydlTPVjkg+TFUgJkZ1oEdF0bnUwNhDc4RKbsdSIKeAEnYSPhIL6ryBk5qdCm/LS/jVG4L5nyWToRoH4eOucqabHAhlDvxYd/xJkRyX7XQtBgItst0h/0DZA5Am9PwvislXW5Pqi23zv9xL2HzI+4+1OWdlrrnZECB6XzD6BrY6UK5SE08zNfCgxUd8TmLC97d2j9fcBzAqo6sbo5omuVLxumW8LwEB2xV8IKcDfSlDvIpIuPYZsRbyEaADkR42tZv8wkyw0RJqs/Affv2rUGxIulbKagZS1QaQXSQHfQ5BEGChzxsyl+/NHq5v8dPMTLbQvdndg6+U8dBUtg5GUSC1t7O/WtR3xn8wu737dpqchEN/EoKX0it55sm0p/2IvWDZuA1hzHyDNF7GIQ4VJc9mS4tlzAlMgbKncWm47hlyJVEWuyvOQPgVB0u/wvsOnZ0Awmlw3mqLgg7AGA61GL5xn/c8/5OSM1/MvvqiL6/vf/XF9kwvHL4e2dVQu2XGzONKMHTHou50qG83cROBM+DTB1Jthy9HLPXWK5Ij5Kc+8U+QIC9vwupagfAplACty/tpia0lzYGtzVIXdcuU7K67lVzJqK2lczg9krk6Z7+ld9VbBCtOyqkZdl+q7JPD2fFW6Jn3r6f2X+nh4s+JMVu1ix0nnNlKcoHQ0bi6J0zp5uMUpDM736C/CxhDsVaLQO/G8uUcnr3pZgHgoSjpGHw2yWJsjswBTlQvOSD68STaSSOYZAv52RbsW2z6TTXHURzMntjfL8of+GziTVdMPmJNtK3JkNSP1F+Q4y39OkS7wudRcSqcStINW/JVLKrhO8eqaAYJpyBl2cVep/UWVDmowKc3MyTpPoD76LV0B/QwX3LgbRI64hp5DoyLzIIJDzBmaFUaxdV0sg0EFEluD1TPE3nMXst7AcUpe7X1kl2djn8v1IiQwb0kAezZoywz8U5OGvPr40ZXvqLd3Xq29WkLVo87euIWsQ/ZbXkIwqT4SfQglqPwIydH7VPWf4Z/Y9vLsTTE+wrKz/MaCL2NGJFbyUwUugzrZqJ2n3mZqJ1n4FkdHPt5qINDl4eCDYqJp3+WjNSXT58+3fsNj+FL+/ZkrmnnZ881rXIUf5Zkk/krcsosyzSZdfj6JS7a0gzT0Y7KMDlzj/Rn6C40ENPx/dcfn1Yy3nlbnmj/4Bm4m393MP9qDiZFUI4xaTk3JkcXruger46hHJjVPaN7aH6P1w+irHpdOoxyuJMMowSDuKFoyoWrtrSkKS40QruaStkUI9imBFzo92pKSP+zl8exEzRx6iMZKtmDCWLohI6UJB3laC/XxgqBfNk2NXt2DfTCbfvaxTmjHax08s4aEQQS+6jVfANE7IZgpsm6CHZTUu7v/ES5f3gYyP2nS+X+/u7h0dGzZ0r07/yion/19v5FkQZm5B8uzR7ufXv+7uri7ZulaoA/6WeX5Lvwxn+XA0ASzoypvxgOHxCgskaE2Ezmc7iewABrS7Zlr0lKteMjK9TqxZR6m/vQjqYaQMHktJhjQgcyyZske9QAMSHWJooOdnf2RBYdrWzL+qZa3BW5sQGKyWzsE4bEF+MQXtTQIgJ5zqICKjC7wncyTq4Z5IhQJzOfaP58YPiab/ZyEd6b4w7er8Wddd5sdE+6xBFDLyAOa9XLG0YCmVZbLz6rS5CWVXaouY0lQIPCFZ1wToxLn65UO0McTDAU70GnlxdAjhsXxqWG6q4Rg2Zs3G/EjWIcghg54Hv+cFlXFMREByM1rLCA4X1cQNE2wm+Lul8ZV5nIuzn9PgR7kvOs4aLjg/5g/u+Zq/OPP0ZbBJQVSxX3jm3XDP+OSYEMsjRZSO1lzEckzp6UzaJJgoQPW5DbmkwChp5szDHjKQ7wjfI1ixkoMhgZqgmjj+8Ai0918mhgUvMO1VM3Uagmq3JbTDHTAxCm1Hcku8ngvsAKIuKpaCzKV/Y8Hmx/49XFbcGFANgsRVdB0rj7s57xesP7SATM836jJydsUGIBR/grKgYscDQzVbl+CMYUL6xzvPJm3RMQcRlsb5vPrqnlMTL5EMNwBDtzSQ3mlq1ubkAWqB2emvBQwNh6Ynto9J6zr3t+6c6m3r2YHSH5KwRgQYHNsiepemIJng2o2imcvPbtzOfHR4GoGL6uquLBQXCsWsxni4h3KK7q48BQA+P2qgPtD66WE3KYwwqynO4yyxF6orAh0Xf4wAnzVUq/hueUY7kwf64TCB9Wjk22grfeaP5g2jbzKlluZAsPbQmRWpKqmhepih0AKMPuLl0vUHQJ1dd41G4JnkY9Qoaz04IBIS2IHFsyhV1unrt+n+b/0dRMg7qagaozhymWVFlUAvzcmk6Z7E4EVbc0PX5Nu47w1NxeTzSf1GAhLkJpH5gZuYHup9Mi73NkubmiylVfN6bCCuBTmOKBlzqheBvHbVQlwmn2sTHF9E5eb4uWjYLVQEucyWKgqIl/d0Uz7sPNZDvnS0F+V8auvAeIi51CRgFh81VG2jznxrdMBLpiqLBomjTYUh2HS9gIv32EkrN7xZIAu3s9zi7pKggDN2KsyCfUWNgZGAVBvEqEzpcOm4LIUsrmGCFaVbdKuhYgjLeyDwWlhXDayzkSK3BCJS+jmyCPkkFL5HnrmTPDXUzoo3PimkECefL85vhCgYKMq4o6WWIxIeYYJpTLQtagomCSOyqmNR8+ph5zhbTxLJMVqK30hvHWPPVqTbY1ORRVz2MwXSC4GjaKvzpUmltb7mOqI1MtwlYXykU1KN6YD/WY3X6UMhN/AEwJzlvAilfJN4n0sNyveaNI8wNCiQkU4wCGARQhIGum+V15KxFxSwmv68vaZr+hT4koU3a34gIcrjJXh0C7RyuN+Jjbz43BLQWM9Sl7l9kbdkF9WnIaR3wGvJAZ/Jsb+jnvjV1XOrYJ8g0Xtlo5yETVTCR8n7c4fXBtojV127XJapzZom8OheQBt7L0MCMK3p3Eur4AjCKcpUYU5CZLUhsY0mRrpW3MZfuuFcWQJFQxhsrX/215jdA+ROiOHlkh9LS7u2P+/+zpyd6zZIXQztoVQi3xki2QQr9sedDy4M0vlrCBaJvbNkujdYdPVdKmXkyXRY6aMGj010nZYKzpl4kvYWTPzGg+uJm0JCkAeSkgMi4Xfsme4ZohPff8dFYCEn2IAfi3f/0fsJr/9q//0wLesQbYmAFUee5j31yAgJtIwYG+K4eUnRLGUExHcA48/SHpiN/B0b5E/CxMT4X6L2mAGFaQxy+mACA1579JoVi86nj0ljEjZd53K0DB3PZuJdtE+vHxtwC4okS+7BBnhpVqSdSDo0bAjQ1yTqqydAmRD8yIvjbeVqdnL7OvF2bWjfF5mz0fV4OPEbyPu8eA2ofL3zJIm6waS3fMPKDV2HEmZhvEMeZarrW1ZpVngkHxJPEpe9GnhElDfJFxB5hCl6a8LBq/yILA2KvBSYOokY8tDzNnoDfJH/oFFpZdvr263kiinTQkbjEZ54t5w9TOtmB2/JC6ERO3MBujcqYpeAFiKBOd5pDxKZsAxyxJYGi7FKzrmbSsQZ4G5Gdnx0ISunAme2bFe3i+euLqnpzgoEhM9xghu/HEK6Az5jplbfOx/1bHCPT1m/fZ15evjA86KKYNVkkUqenwss3m8/UWROt0o5yjUwJ4pT72BhPqEhQqMf5xDXAanutqgIUuHvrXVhkJtWNis+6qzYpvAEA7jBBLWyjApxYQcL+QjKV6Ab/tpg5oYdUgRQI9dNqlolaCbjTguppJMp9O78Ie1A6sIExQkjGja3vfXLw47728OH/1onf65s3b69Pri7dvrnAtqwqpp+b1okgmVA/C72UmdNTm6Cje4KrZ+ArWzGAJV+N9SZKMIBQ5iTv0yonKyPKh/ezkqPfDUdOzJLZL5a1GRFJevKpmyafspZ/S+unJh0QbJv4s3ILwJNao4s2nnpd+moTAiN+g4IBv2CkGWwwQ0Ewqf/DVmKoxDvTW1me2JAjCuonVUFVDxTCgbqn4SWov0/OB5x9XnGLF93kz/Wzu4iSWkNJ7HwkT+o4RRqtEpRmfz7vyGyQSNms5xBgeXOKSbZg78KISZ2yIGJFnDp4Riv3qk/c8ieiCMWApBiHaCbXH+tAmzuupR8zsZIKWA8wgxLPW9VT2zbj4hADmG10L8A+c0sGVkVonBzBOVDJ1I0NAzZrdT+Lnqf1Ew6UQr94LZNm4NZMiUF3NZ/fYlCmV+Zl5NCltIpKYHHkPuzkC/wV3s/0NIxD4q36RDNiWNNDXUGX3cFGLjKdgNqOb/MHrxzHtIPGFg4buElamUfNgC/iawrXO8rNU9mlwgOwQb2zbF6HxJ3uSCadL2rmevcCdTCn1Y08u3rYNy+DulE4QZtz2qCvCZuPA6ZFZjmu7pYAcPhQm/vozVz7oZZ5Y/A7FheQdC7MBteHML9qgXN+ms+g20VQAUfQEC/7U6kBfPmib3NJSb6bmW21wB8zeYSizJzytzQ4f0jwMpnYtif94weh1zWJvdw8uAYyyc2Y2RwdmPHHEjsK3Xrj6FH1IB2MwblQgy3vKYZsiKSe20FsTUZn9pY5y6oEtj3MWtxYF0qG3hE5/N3raJMHuAqax1vg0Lm9uCLNNWVo6+A4qHt8yyT+Vk8XEuPXU4AtrWrW+tB8bqb34WyMjJiB1gK+tkdwHjATMh+BOw+5+xCegqJk3zDp1weg2M1ADQ4C91TEVP0kYMjRrlsoAIfJk4CsLOLFoLd7d19rxjL85MoHypH9o1IJCbApCiduKGsNfOi5hkQF8ZuOka4VU8ECIWt54It0l5WIBqFkMVq1bZIC9prII4AREE442lv0mUNLoF7RAp9CNLaWsdyu7oLZ9kDBxW7QhTgpI3zIFWhO4ZZtMQe2cqD+8unj5snf1/vLy7btr9pHApKYm1tzCGosJtCekvjQ63MIgrwmQ1HayLXi08PU8R3eCQcmBejnJLuGqt7hqm1RfBtwBm9k7pWU2s2tWB/B3Wp81wI8HWzuPBz8edfeOst09CPDtPXsU+HF359nx4VMNfuQB/DLgRx0u+8UipmZ4Zq8th7cfpeHt5JdCMcOm4kATOT4lprWwruHnjZjuARfSf/7oHEZrYZGplGg87oKCruetFfofLjNIPV7gVWvHa5NvSEMvzV38cJ+Mnd0gYKOWL9wyJx5J+5rMH9ZvCHb561+lwrC7WPrPZO2eJMu8uk1iSpmVUnlp5LWZB8y1mUGIdoUk4C5XMFJZGdwnDi6m6ZEEkiS6WNzQ5aHJPgPp+hku/GdoWn4Widq9WNTK+NYb207ikWJmplx7LFTDWcSQARq8ctexFHmKs/uJPA1rZOfjwQJP8Iczz7xHkwTmhZ6cbcBeyMvu8dPNTP5z9wmUi8qrIis0NijcKLHpimuI596ciAgoLzk5M9rO9AHQTAhDLE38vz1k9bK2ZK+66TkeXPAAhL3IcUol39pi8SFmoF7M5mw41/N0n+EkVVRkRO+1R5pgVqjd7LkQyQyNROQ9gEnT9FR6ZEZoy9x7ZEnG7ihte9tgA7+fln80Nse/FBgr5H9xW6bS+nFYWJj6lD21h9O7lxoU0Nn0KHzQ30RoM2E1xUJ0jNL8jt2Wd0jFt8C4fPGT96HCSJ5BMTBWH/NqjlGFGimV5xDLRfYBd2R3khbLnhgmj7NYDrs7x1iusWPUdGCxHC+1WI73dvb2dq3BYt//yxgsLfpC2y5mIkj2tVgvO+3WC7+zzXCRn3/xagysq/tb1ERUrbHLawJA7sHIrAoU0pglTtsKZupfmwvP4ML1SzXa35FO9MJE/vyJXjdwv4EbO2JJq2Jnl4yKnZSUpQIHWhVL2y2mDYGxEl6W9Sj5XySNkvIB3/pI+fC0u/O0u7cD8uHg4GTv6eM8moODvb0959HYAfxC5VzLNsp/bjFxaKXEj9paZPE/g+nrNkW1RtWVmZ3vKsjKQv/CtS3+tjckz/HTPT7GHTrE/4/tEElVWNzfEI+xn5JD7i0YmJxjl25NntNDKE9fswIU5zd7UUH6B3A8WD7RtUwdvvOFKHo0Bsr5Zw7iqg2fDKuSIfoEtOGQfBwh0RtCn/vFDTK9DIdhywSBM4ArN8ln3hPfSR8pYROCmbLt4WnZ/JiMpdpJV53SY0+xzAZg3iqQyH20XDYxt0BiYGdajIfIakPoGM/0zlqSiDQ+NhUB4FVM56EYXFUmawNtWfGpbDidHC0MTIvbxNz2AFAGlgnzr1Yye2zMsGzn+MQoiMOQKmFFyezh0dHu8fG/V8nskiOsJazIwf8wsnU9xmzMqHf7MOGtjNkHuztL6mf/Lj7+ncWHQBExnIy6bTfQbWg+VtUYko/XdFWIM5zLnxNqa2/HrD80kIVqwDA9uhngDVS29CHW1IgW3srOp99XD2HMk/Mrm/RwL8fqoh6z6r5wnDOb6NdOCwwh3NaUL2biIaHCAAO5bqSfWtqqfbr/jLkl9y2F0BLGOO29nENPWqbiQ/bYOU10z+yJqVn0HmaDoSc9cctazBaTi858LFEzKwbQrjkHowDQEw9O4GOcZGI2E8Q/cJKw9AT4Zh+6cyO+gLhIz1sABEMyd3+QAKhjxFrrQM2oKMnEmQcMymjEBULdsoZ4tfsPPOvQBk/awxRzKZICLnn6kJt8EMR7VQo2F1Q7FCQS/sCIlQLxYB6drOwZ+hdmgKhJmfzJ5fCFYxbyxoOQUjEOvOFXSN+hugL0B+0EBHfwaTodDMBjQnnS2GAODSrkjFzKmJZZejBzuqEKFzYPhP7NUl+X04fXZ+dZSdknYSWmLOWCwVOWTR3G/Y5BiIKqgRgdAGoy3ZrpAUGk2CntVhhvuU6ikd68QFU25u1HFTfzkfm42xHk+XgSokVErZsk8yg/ncAmGucDvzaTNmU5GPeoQ3tvcNODARayGWH9UheBhLMblhq4BsMJ2hkOAW45gTShhBDcgin57NBUdMSAhApPHGel4ZhS5pKR5I4MJ0ySQJTu5oFbs2D9HuaUsAcT8Znp1i5GW0DYTiVVIo9531GYeQFOKuJqYXH26VMwTUNGBBwOoTqHlpxUXB2GlEEesUpCpFoCpQuihGjK5z3CYG086UgmlIibKcQVh6tPzPhaBg7TBnV6eDxVG+br+/LW7My+ma2HeLBeXea786trlCO2cnRYiHrzIWuAr4E7oFIT4ETjxYQViZx3x/luNLv8kTDcMeJQjYcq1FQiLLt4gXtx4I5yLpKNKvDNeTPfXzJP5gYRDTbY9/uGEuY8TTmn3bhEf1gOwRTDEkZ5LTQxBCUFLRB1jyqIqCO1KITHnqQWhuS8oJXcJvcQA7YFRilgsNyi5QJhSMIWDSdMMQoRBzNOMb+ew2EJJsmV129S0f0Trj18EOJDVJlwRs1gRnE2f99S/alTc2Vx8uQrDaqZv82Q8UVtNX1U2/lYzerUw67xu6AgtLqZm5Ocgm3mlPlUFFyAb+kKiaqgFBOTz2uMsVE9+Uj9dWlWHDAFnYzkJFVOKxZ1BNuBDDL6lS5JDk46SzhZCFaD0YcClQZUoxSEIIhBGwWzEDisw7wX3N2mxkk0Btw0DgzuW1JFT0MqJktsn+rZE8xMRgo5ba0Y6xNDMBQ3RTItBPCbjUjNQuip+J8QXq1qYd7/ZK4xXqNRig0QQdaAr5JmxmarwNptOosBoVH4A4Ol1G8CFqXJNzu6mA+24iKMfcsZmQyX6xJkRMiI1UIW8GfNUmMrSQHnmVbKC0AhE5R0mAePUY+KmFaJrJRtlUsmNaHqdPekeS01FzkZV9QOFa1gaqlgZShqZOieNyXhBwuWs67Rn5KuPiB22dsxsiDgV7TYt9h22YJWhXAycQja9r//XjHn+HTS/OtC6txHE4vPR1/XMkbUD/QoIxxQOo8A0TYlmXy7MBs2ZTm3VGbUSjLBzND0skU9Wkz6U2w6asU3lozI37M+tPtWilnv6Gg/K6sfWRScL1R8mgGXia8JAqXuD/9bNlnh/LJY1vafarAjzsBsIeh7Ai9X5ndYWvXBIjGYItc2ex/W+W3XSIvuEHgPxA7K4bWbikXHnno6pFDlYoTXJrVNq+p1jqXUFHGtgO1JhQ5m4RpbPNBvRjJAMtq5wC3uQLZhrADjCJTj8SbdRL0dR0XpN4N5spUBSfAmsMcD5hALXuQtNCjnbvOz4fOo2ZAQzEAFbskNsPqF+Q3YquD03tzQZ3iE+MbLNd55YExftvAYn2Sy8mBHTNhDash1hb1FfLrEpMOyGlskSjctNKAgemXeDNV3D9goE3gMNiAmj3+hRm/oZvGPT9Yd3QXoD2oIkzUl/MPspu6kmGCELCcTZFJAUKJsmC5UjKsQ9cu5/MBvAPVVSgfNRsSZUUJmFZvSH+cHvYpgMbx+cBWxHRfboUU9p5FXqs1M5wMRhlaqV405IEoedXj9yPG27WlCKzo5LhR39Z3fgxtU2Weq7RccZaeKeNMJQoMLx3L3KcsPGUyWJxeUmE/auSz7ofTkjXiGMyTxtD1m0CmQwg+24lePAmzirpWqSgNvkvG+maHzPEJWbWYzogmicorQcF5DuEDbKtbfwCbQFuMR703EjcOf5Nlr6rUtrT6IhjxPaUUKoXhisc1MWzlXkvP/46IcfERwFARmPOVK+8SvzUkrPGAYSpQgOmMEgUKFc9I0Dp/QMuPiNh88xNFLBuLMiVQFHhfvBco3ymDAJDre2k95GFuch2w5OOSYWFYoI8wmM9SCILVA0BSKaE6wmXANfyWwb9WAJmCQkWrphQZY9hDGe5J7Cp1KJloZ6loa1Ah9QGRIo5NSmVGCcU4YT/yJtmxGTEbuiQnRXNqLfm0OWG64we25pHOCKYXBfIEoJRwPBYRbTEWU/1BnbbsZBJ5a5KM5gjeR2nQ6cvTmKZatHDoCp5e3U8C7tklFtppFX6ijAARKcGyMPHhLCrDgilow3PlWuKfldKNsYSVOWxTrplcVWZtjXtQcwB9TOKHlNKOoCkMDeMPAPAEsL9cxasVLIwm95K20G2FzQmGINAWlLzTWZY6EJkR0LU/DKNcm92e4h5o69F4oxu3u5jswUmtONvldVLHZPnch4ba5B/3md1JrF3+cjHlel7e3hWqrrvVLcsMELZiGZn7HySwCySeSb0NGsS5JKsAX8sWrvnFKnhmrjQlpCaUgWnYjHTBLmH1ryQWJdsqc6cDuEkxTjpo6p4NAgVvHtGAlPEwpnEPW6FBs5NsNqiTXGRbgRmGxHYTKtrKroiCZ/Zc/i0TOs1Fd3HxpU9235gGL/pYR4tsWW7V9K+PZpj29vXu4f3TcyeYQT5h/2en1zUH42IEZ/7IzrYy9MTXLAWLBzEZd1J2vfsTjv9jOv3JNGKibsNdzZckmXUyFQsG4SipkyZlYxzTRvpxqviFEPR6XjU2And7lwxzX9V1xV40X+Owrs/2LevXuUkzzkCrroqSXllA30XgaLYxSB896l2jqr3OqaBiCIU4bB5Tna5kcbgx2x3KU+ujlsRGxyd1WoPu2M9CXRS1IYvUBqwDUlJhOSzjke6kCzMQ+8Iw5VmnMZDYsGChcWGI7nTPSoccUD2CKkGBUcEcBtPM5Z0M45EdkbSACWw4w9AFz5r2I8rb8Lp1sZD++yXSOlPg36IUbTyiYnv6Zf/VDb01sDriMpEpabmUXc9xmDAgD9/TBUvEimQSEbW+n2qpKLmpUWaDDr9DEfd41e93FYbVPyS3WYAcsZrd1PpRQEG55cte5zdBgXGIfoVT8WKxYn9+hI4SHIvN4W6AcST1nqrNNpfmvTx37SN5tHXHEKOwdbrolxYfJgdfFLXx/WXHyB+bzkI8BJ3xnsCHpEuuSom1LFkKh2oKrxsyt2WFZtaj89zWIG9WylAOCS31Ar7HYXZm3kbKko/NhVPmvu7RqX1l77N3LrznINSqN7QWqxigYuJzMZklmL3mgMxTZqMVnisNoaV7oFFK2j+MVuG3AeaSxS8TsWtK8gtqALdanNoCptNlblYe3biBFCDDswkQcFbOskFTLKdQHMZs5eS0S0Ufv6J3n2cQsF/zq1ygEIZzqEN19NBY54Ox5TjInv8vv8isMNqwMG6ZealOnVrRwUtTpKspRcjqTaLqrmlQ3p1uUrUY3/4iA08ptNrMQC8Y6jEMAEtNuV9MuVn+rhnhsHpQ1WaP9BxYHrWfksNWJj8/+QWumx0lpxrhhoG4uecrk0+I4u4xLrbRtp62Dc1e6rzp3LqLIxuqghjwLYF5r2JbWXgrYU/BRBKRzBNcAwbA3WIQZWAaBY9fqfi1L2AIRa13+AL7JmBjaEwbkstCU1hr2mW2Bdyyy8wMgM+kMuGxV43yojSyzau/MCjJ2/Owvkna6MAx1KEewFgDLbeX9XAwPrFSuLLcJV9G4A4pmq5dCphahoBi7+KJ+3pQN22G35Z0QGq0MxiaCcC7UyGZxYLS72EKMJeSmm7nXgNauj2T6sZNeclCW4mrZcrL4RmtYBk1Vgrkl4MJ6bl83Kzs+Tq8m17+NbUQpvRrHRt22gKxHzBSaSUxh0XmiNOmN63Poog4JeaYj5UGnA+dVK3+MYedg9QI2boo3FcMgBqs+breN2Munias8Lz0wqcU0hgbUEl52uz7xVZ2ZsXXNw3rGK63qDjakF3QMV98idyKAsxG6rLIByW+I0/UM6cv6tTlXEPTT0btGBOYKVavf0cJcRqQSlK3vUHODL+v8HiIJxqrCDgvyFamZ0AleecqiHn8JfBkdm1KGT2ftbWQd0j4S6sh74rWribYnzU0rQN3ve4uyI1xIN7nRO8Q57ohrQrBBoKSiDJLnPJrt2NnB1dSN7KyamNUlYSzR8tGT5T2NcNen03z80GD6lyDGEty9MjePi+4r45dsEpcZ//fFBO289+9ebYZRhpdMDzgMMvxt+xM/xdiuCmJLXhqztTE/Au5UvALmG1n0yLM0BycgUSPgYgBftS4Mz7IX7kNZ5T3lzMWtjZL0Aq5EFo0voVClbOxLjKl9/f7Ce5Luugqf6TjrOKVEnlqNUABz3XYKQihTCUg7pOARLZXkj/PhR4IGpt5JYBZgtxtyNOLLkmv0YERM8HeyYuDcqYwAzIb5xsBQYeQHZ9/seBh7BjfYDMwkx34dIwU2TYwHJV//Ya47OWfV1ItJYV4EXSyzLauhO1+i0cqA9g+h48DOak4q0w8A4SkI1y5qMJXLCEIdHKQyH7KdXb57mRix2PShRaajWR74LTL0L21yJNAV1nnysh3siRCSiPSF+ZiLy2voxkzzPaKuCEiMZWyc2aJGLIqCO+OLXxRgoTaBACWRi65mOUlZ+5YBTVELCUyCYl+EHYHb41AmtJTg88afGDI8hpMsodcWkK2IA2qvC0XwqSEft7gUXFEAIqxHX95j5ijCZasXYdtQDOJ/RHxBa0K2qmewv2DX+F4Hl9dwug9+j/MB3EPK2D7FdMGC0SXGGWJ6g63YjAMPzqoyjZP92VtzUrSXJhgim2vWN8ilYkZRSXh3CqUdQRtITD27hkI1TuZaEUkHmJOJSIo2rrgMARA89pMtLC9p3TogHUWwHRBZiyGwrOcl2rCMMHa90FOP9VkqLeMdPtnMfEUrZ+YH9dq6M0JKOmtmgPK0gs2ZniRRKVdnvJopZPKkbga1f+qhMkjBAFIan89eQKNq1AK6hcuXjEixKdSmQ2m60f1mAFJpr9ixMmHo+KJ0nMoFeISpxWLUEENSDJUOWJVXxRCZ42+ilD9n8KntWwEFeSu+nYQB6Qs0EbnGBDbMXHaQSAa2zvClbMoAX0mXemixiWmFHOAUKgRhiw1toQwrBuXbqsFHSuLTIgQsTwqJdHRsUvlOsSh0nNHfzJAFERd0WCkdTrPU5BD2/6HofSwebBELpubmyr/wvkkpGZ7bGMJED/9w2Tt7++b6/M1178XFO358Uk6Sj+9jzTmJpuWg+M3o2LJDbL1N2tH4JIW8QtZkSeOG6R5PtxxFuiUuyOJJA+9Bl/04EnWI1a0CPyX82NCLhQqne4HPoCGBodK//Fkm9vWr3tk352f/8vztH3pX56/Oz67PX/Bo/vJnIfle8XLyvp1LFmxK81EqnAZ1zmaWkzPXwhhq4yntJRnBKz284YeqOoMa53rg+JdWBtwxOaM8PaE4VP4zMhxwXfYq38dnQPC2KWrTYK8GpzqMo6gncwAcxiKWj5bPtJkx/n5tiwcpSTAGmjkIfKYLfaIEdRC5ItUINraqxPA9neQax6HhNU0Q8DB88toV8VBaSLIDZQOkRtRCsKVCQ6zeqmnCm8y6XxFqD23W2NNAfKDXVYEbud3hfm7Qgb/B9ujGZoflUSEHsu8SSyNMCG6Y1qrgUKwLU3FiJlmqZl4JFjm7cnclzbYmpJ2LbWqWAGhpl9Xmeuvh+VBTJF9AvZxMMLQu3/e/h7Rx9sJ868xMMicJlwLBzwhLnp2LzURmhl8SBixoNw+S880mpYRDuDZ9WhTSIAr0N6B8ZJMnMgjLDg/lpmop23+HXVbZrWZ1i1IaED+cgsRT4MpQeEjoYm8CgHsKjnbp8FkE8crF0jETH8U5fnz+ZWeN9inKBlTHhgxIyC5hiqlKJ19Wg2N9r8mXjWwkWigZBVfQkkm7OssejVkiqzvb0NJUFVzABpuNzcmus93d1W9CGDgkLup5FGSm4bNFBxwMKuF/dfUq9XDS36P5ZCy2gwVN00/SE5Zrjq0iA1yxr8jaHw9fDTIfKkF+2pPq/D75gFX+tivcT60KTmyqwYgegLXrXCQDHOiwBpPbQDrFLPsXSAyAzXSp88FWTds7VjyRbaOyDmV1+3aaLiYYzKEy2ICLvc1+WBViae9oU4ZRzE3nXvMB9FSjQHUhCwhll+0YS9oB9zMBHlXSaVkXwq84lETISJtx3/GnZitVjCQD01YlbokoAhu4s5TvrDD2jFNiHCnxhZMPJeAR82EAdhvBRxTm4PBNuu4/8S6L1lOwvfRrxXVDXXJPoATlKHL7JwFIMrdMyzBw52BVehCK9ZBymFaFbq8ENkT055Dq/iD9bUaYVDZx1uklMC28XLYZw88Iwmx4XnK0uOIMmnrHBW1lxsyyQrk0J5rQ5hgyATrGBTfOgAJ2Ck21M5BE8Dr9u/m5/yCIp02hya6oozqzp6AsuafuT+A64PuJQp7PRj8OGZxkp8bW7DcDAHcizj8uiRWACHi0n3kp/NwuZElsk+YvHXpZx6EVMCTVLEVJmCnVYPcco722Vwt1P2ZZOdmb2NJACGHDNBSuScOca5jBKYP4R+JVV7lmVPGk0SCHaj2sZjSfNil1jd8qOJJ6w/O6+ojCQsl4DOYkHEPEcljwJIt/Md0IBIf0EtzwA7tswVEJOxUp/ty9rd2jdjpJJPt5PNWZ+f/3gepsd/dkZ/9xdJL7Tw+f7RxZqjM7gB9JdbbbRnVmPpUPUJon39I9mQvLpgt+rbxRk54BM5nogHHRJZzI43n0/0YpJnd3j6FT5d95nv7O8/R3nqe/8zz9LfE8IaffUySmBBMqTesHRNqyQSk+iSVJ9N4vO6PydjQ2/3fe+eqVObppAlvvHWn2P+hNTY9/hV02GiliB/76iC3nZjEe82hIXSgrGo8a1koDi5+5EtfbCGUUa4AtoMjVcwJW+7TUW5kbxGY2ln4qxKRok7tkX91YnlyEx1vMMHSHmj6QYVcqIyxJCrh38OxAOmg829pDJbmqVEaF38A4ye+M/YZylGoJVLLEVRZjNFNKZo36yoqx8FWAwZXjdyexLHiPrU3lQBEVBOTDTEcXlEn0bGs3+SnC0iKI8OdXB7yDsSKJHP6YPUPm8Vu09DFFaKVLS2WP6jamPH4FXaQDju9FpqhhtYA5bI3s5orawZEeJPG+LUOS8H6bAibtoo1tBWpteSbIEpXg+fr9hfj/yA+VET8U01Vik3qHb+Y9ZG5hHgyU40UzKoq21/Hcl6qNbVt9g0s+MCqxa2nhgXthDjCYeSKwaTbPkq3zvKrmkEOZZQdWwXLA9FVVzbIP2DLDG73vpSv6DPDaYHMLP4cKLVOMl724uFCu/fl2f5k9DdJDEv0Agp4if5aAY8mwgUwD4eR52XCLjxBsYF0aF0W1zkm6pC13je3oaXFpSe5DWKXeJbzwccmAa/DX7lCcnOXjAkrvBK8svCs407RLeL7XfkVQUqGOEqw4N0nhzDi0SFF6br3hU6XRwYpD347sjzlQ1G5+unWQ3M9ebeA318a+mee3bvOReSjZ+MpmncHJNpOJWQbBYSD2FQIV9+UQ/ABgxSlAKSsaPu/jvHeDzEBwpy20T+wb50SjMsGD7EKWnJSvpNhoZRZXSjLArIu6x1Mw8ZbRJogVxY9RAXg6EWZF+mJsUqHv707/IDIKihGsLboyiQrbc4S5np/3yHiNJr3tbz9QKPBI3pDXkzpQPt5gyc6Wd0oQNX1gJF2HAucUaYdOmxSBu2zj/WXGicCbShfIxhR0zDtEwEgJTqsCgQYBZ9iDdg6mBQSfzCMAuMLp9+Sw0jbTxdTYbGDgIPlGqUU0qEwZVvPQAGkDZhNhuIk5XqY+bE1NcW9PLs00FcPxbDgIVYIJcdXzvZNH+iCQDsj3lWsBkZyo3RabDCDNVGfbKuDwZ5CSbIenV2K5yeeKNVyiiTX3/ewOW45gT3Y/XGceWOtOr7b4pgn2hPeuxBJDuQYGpWmhzaZq2s1d5U22GLhPISK+trWuimvPrq7w6P3uCr8vFCKNs5vK2tbcthNoLntN+vlGYZAok7rl58Bd/qAg4wRw5LURg2atl6M1ymJNzoP/DS2DEllIlmGqKs+doVNi7E8tSloU0AGjnVbVH28kkC8VuGfXCg/+XFWxtp/TB6AkqBF6CzRyFgTRWN1kDUFWR0FAIdqu3jF3DETvQBK+BpgK5nWkxC6tBjxlExPc+yPhWUYVKrA7Umx8AeU9nME6ABZSTIrWoQ+WCUnRoM2u84am3CfMHIiaF3/aSD6SomjUUaiIIpxYXUZNEunqT+nqeu91+ULSyGC1VDDV7C6ZtaMX0Vkopxjxw8pprtnNGx3RKtCaTey8463D5N7TBSHsOr/OZ6oYZp73tbvkog/t9poNDkFIlLBF/VyAfLpkFakcbJeI/BYIceaUAIHoDpJPhJU7BJAlJOyneW7OIOW8lDGmKVvJR4craORwlLDy6PK0RYum2qyCFVhw9n38oLeic2JLDrySYGQp1+5JNLNyCqQ2ZD4by7FRo+TGGLbRB8ZnQAY1GtWxxK8akgcnkx0cLPTc0azilJK9EOE2ipuowfIu8xnVPCXPjltch0Q18CT/KOtzX0ORaJ29uPjWrptn7PGmYYEshy4G9W0K+J/D8Lo4TYwT+gCEAJI/D7IPZzk5jWrEgVfHKCV+INP+xorCL81QCo+/hsqHknOZtl+1DL6hUaItPDeWcj+vrYjYTAwGd3qol8TIW2JFJk6wE/9msjmwgXZzWzrmJzyeqWXRHCLBbiGBsNLplq8XYrEn1BVbpTpAgRsN3Q2U8O2Dpdn20wL9BzliuRDkW/08hnrJSTWkuDDVLGBHM3MAOaa5+gBr31JGbN1QHUVFh1IpAKv61lFzJGy0vwNhuaTQYCd0BIACdhrshdyhqA0aPQUwONJWDx7cNGFgkS3e2hol8RZO7dU2605leaiA0+IszLXa9WYvpuCojJF1JX47TIhiL8XtwQ8jcckRyKHkMyNf3BqveMHzIgfo3vM2ipT/CN/wbdlAbhN6U1RNApoNkmtZWqAB3mCoIwnqGrWwJntQsckEgh0OtBCFu7RpqWt/Dh16a1VQx5Fb8aQpecTHAZo5m319u6AUBN4NdUA58zJP8vpjysc8fqTPpXxxKRu2RZNoR2jnHchYSBpB9rXlSCjSb0VAiNGhlsiZo1pzDDVsAhSWbZu2iqtjweHEz5IwVGpqlmg3nYmm3YduT4vrmS5tFj0puUCeVNuCjaVWQK/DQUWCJWKCjgWhbDtM+nU2s044mg5q1w5WCXT4bckBqchSxa8Tje0qK6jYQCVKzD6vggEPwBY8Y74R5lT+Ce/dlHz+o95/mde5Obaz0bJXfytbFlOqGaKaZA15wofxgvhUKvT81ONBpwyhB7uy8/geFBqY+IZNlNrtU+M1IK0+6OPoV8akRX/X6j8xpMft31f5g7F6UjPnITKk8ofNgA7UgnSCwiL4OwSnsATdCKiins072vYh/MJa5GfxEHIpQ8H3/KajSk558Qief/NYCzTxXi+S2AhYlaJp1mtRsAJg1hmoQkHrJtDlK3WBr5pV2B7bLEYbgPbXpq9mSbmiwFxwlQQgBEVn02qDzl5L84vgclTz1NFXCHxxEd4zFaGZjMt3bzvIXLComcfPHPmmAS06xrrDeeOsCTYGvJIN/+wsG6ME6lvWF0l+7Bit7Ut5fBVPFMTooJqVLoCneyygnZPIcFCvzMbG6qwtDLkPeeFas7z0uDieJBvcI+rwmUi9RsaCVxFFF/YCm1YAcZl1eEu6jbJOFsYnBLMjlCh6NyTggRgwsSLgCL5+f/EC9q2NJfgFPFNaDvj6CvW3reyyMgThnRIsIYNfwqOdK7I3kS7WOhod67F3KEn/klG+IbmJDjBJpXNFxBJ4hCwk3AKCkwFd/RjSuagBzQp1+G5Hkxdm/TuwQ/LxZoZlrUXjCRqsdeBn037seEQQfHPCoDnaOliOh8GEBNawMvxcISfIDY4iTfbsb7rE7+HWp2VpDRjG+kanEi641zrfFADKssZMRVDtOBhvD5Bnpht7egYF9m1sUDi8ZWGNqdoUhGCnNlOg34S0izcpho3gSGIuupBWIsRzncAH6cAJQi8k1ADejygwL0Nv4292MLhr1W2sHsAckOIsThqlkzUYQHB4Vz5arD0giiB9mkI2MZEyZSMEURj5zH4oaqimVEWaiEddKfpiq5/MfEAAMoBcUbSS0e+vvd05a4nZ/jgffBSrSbmfjbIGSL1ZVmzsigtvH2O/IxrwWi+j0j1+E73F+r+MyCIbgXigwZCtFzMkaq6lRBmZACUMQc9wPFwISl4tuNF0dOouqcs2cT3Fr6XaklZrAzP7vCxYAsCoGe8MWkUE7RPgb0kTdr3Rd1jBduRY4jdI4lYCQiBeNxVq1AyAgHEUYW02bcGVwIP+ym/n6jsQsfE4KFtoi0cwgi/KDWtUII+PAG7zA8R6kUxMWhCk0XL+HuxTeYcOa0K1DeMXNSIEbQK9eqsf/nKBQpANVWZAx5hjw3AaM342XKh9onXSxWyjoCXsysiA28z6FXwBENaq0/uIgNWHSz4uL1Wg0BpGwIEbWdq1RuYsbm+hNaCDY9PiIHWypNaI541w+Sgq7E0tUU7dgyrd3aiRGAc+b4b05GaGtsGDq+aK5Fay8aq/GBa8sahAcvJk8rRtwshc9d1XVgzaLvHyCGjcRJtUOB8q+S/u5Y5XS3evtcaE7osS1apQLy3EgiS9L5I2pZ5xyGVoSZ/aUpa0Mwfr2j1q5Id4pLDz0g/lTK9mW3YniEQG1hhtYvvYbadUVPqzKDnrZ2W31/Euw92Dmdq59b3h4jS9xWrwHxMEk7PJ2rRDuKuOsngTaKyOYGpBBLqTM63EPfUGcUZ9f8gfQ5KuG/84mr+HqYZhgb1+8ExJlYY4BejTEeHfcFF7sQbPNkynvJyR6k3KCYhyng1rPZjVS1smrQ8ppq5zhfa7lSfit5QNDGdrHCctPoXMYYStMyMoctuCXMZGxyEmRbLE8Pdw/r3wdxhZ8WY5cg+oWIP6OTYsgGpCYxSsEfXMqLoHRZJMLTVIAVIwhmvHzGgXU4cIFnvef5o8yFjprDPHD5sEbsqHdyC5h+6B4/JjEdgBsNPUZOQIQJmUNrBY8oBT9BRxGSTU0bn6hh9TDLm7n+0enBzsnew/84shD/eXFkPuHRzuH+3s22JIfxQ/siJy50dVRAZVMH5R5O5/vqJIqSQyZlJu/x3si12oj93p9nd5Iv7UWkb5FMpk/oPWxGChFWwp3hxd6lLV5fRssu4KLpcj7au3oLhq2XPTtVaHZhFOiYKdG+DWVMNE2pl7aDVhyoYFhCtV2bTeAskc5EjiIYN9iD1tQ+XMPbGNLoCSLEIPQFGW3EiWT2ONa2dukwNLtfhNlckRx65MtraLxx63A33NP7yiHuvJaqynzw6pFmt362krWxx1BbQWJruM3HeM2YSaZYW03IePKdsBeYwcRwWy9FZjn7Cj8Z1jq3dghG2sbEvqNIh9FM2ekKkB3NxpzvAf2Qn6G+Kek8lRaR4xGNTVw3RgTLUpkiOyMV5YFodi0i9wWiVobm3mauquwnq/IKweINUDK0syJ+7Kz1x4O6J09D4goh3z8CrGpB5VTORH9VSkhQmTKIVWZcOdtLHoV3MweK+K2OiTr6oofsWly0xXRW/iiD7tvuQrIip3vYulHTo4A9gY+ZatScUHXRRzhkrgmydRKyZ5IBd/zRFgeS9hPKTlDMZsATuJcSc5FPA8Pt5s2O/uHWVGM+4dn+wcPYpDYe/p7tHxwVNrNtgB/KIWw3LR/vOxKuz8bRoQy1gVYP3+FmUzqnqYDthUXeNRDj4+dNHrQS2/E2j5XbPCV3iRUUx4kafbWx6UVutH5kbQt/p5IpA+FsWMugtgOb1K6YDTnvWNDsUEA3Zn8UJ5ZlEA5wF3FEMOGJkHPkBLF4TNgkKmxyMr9JSDJPSKxQymGU7mVvYBVgOrqYmzGtqb5RgEaea12QvGFYHGVUUNDgiZUxiUxdAHlgZtpl+BIMBygpC3eTF+2Pr1r1LafW9355mo98OtHZKLo33hUDD/5fMnvGJ/h/IYVMZppNnvrpALZlEPEEA+fpAIhzfvro97QiofiOpe8vZ3KAWYC6SYfLU1qb7YNv+L6hMl6PuPNURkctfWlvm27sHH+37RSMJ8XJmlRLUOD1p8xOckh3WQHJYdmPk/NLSuEWuAfeHxYYaaeNB1hz/KN2msrihgy5luIxp0FytsL+fiDXB/jXkjnp6AJy2IRsFEnPYb6AVa4ILR3CJEJuJ8sL2PLINHUwwWNZNQJIICMFJW7e28L/Gs2ggHlVJodPwlrK6NUeeN0IVNivoWXXLzXTH+JDWuXX9cSf4Qymsz5EIKomx9xyYLSaddAqNNYrcw8u4ZIuzBaB9C79QmNaaddccEpWrEftpwUpMEoyuO8Vt3SdFA5Lp49ouxT6G1lNB0IrqDi2Ms0Srj3EqKB8/G2E2aNk7oHvqCwA9gUks6WKcmCFMFFTLXr1zHiqmSJhy5ZrFecucnXKip8ZggsHZfDovw4YJcIc5TZlOpC1X0hZxfhVCUWLOVKG7G43jZ9rd2n/Fp5H8+9f/pWjl45xL1GeiYLhGWbM1GM44Z40v8V5AX9sF8V6OOA1Ba7dtrDluv2bPXHPhjIznywh01srDZUmBe1zGS3pvVGszFuR9Ly2YjeIH+zJq2Ng4mb9hrGdSeGtRu6zW79pqdtmvkCloEF+cjmQS7FKtebJ/Bc2jN3YwUu6U8gdbtSmQaKVT58bjl/eTq8UVtqwQXyTVtq7S7dWyvoVUiyUPELHLNEUdCF7f8fRig1Hkoxc1jn7evntf4TC/mqc8IdIMYkEN7T9vCgaBqcU6MNfF452Svu2Ock/2Tw6cnOweBc3K41Dk52nm2ozwTfvvP7Zmw6R64JK0WqfY9zESQtP/P42+Aof5LG4vkS+zxhA8mTXea36XdCPPfZ6+vsjf5XXmby1dqRyJ6StKH2D16Rj6E/zBRN2ZRjWS0fwbjamyz8BAqROseUfIcWMCMpVh/GAbJKC0i1BU5+h7DQb2Y9BtwNsrxZjasq1kXtjsainTWIbUP9Vju9ckQ3t7+0x1n5Mfd/iCQpN+IaSGfixfEhLgh4ATF1kPC4DsUw8r8X2fsmX+EZp6N8GjhBXWaZsfVZGkM0JAac0ocASoDzRvuvXa1HxOEyiHkKym6Qu3OjbOrq+3fXT2hXA+o5qEahSi6tK2b9hv+3d2ZvbS78Dfkz+ztuRG6XZMaZJpTsPNCKsUb1UOlI6k9/Up85IqZkAAyI27cQbEFMl5vUehSgCpylDc9LlODg4SWZPp7A/fjb8Yt2lvbB/kF/SLPwD7wDewDa2C3DtuTPzj2/+t/R+DzV8hZCajK/4uY9mCdu9QM3DaPZP5CRi82xTzOq4M1Rl10LY4DNyVa91AT3EH3pGKUxGIKGIlNJqBmVCLMotE23Ten31J/Mew0NlzgIy0fuvlH/HqV2EDX6DM+dc6psV0ik7NLVivqI8nM29psJkSBtBeQ2C9mW7A1rwqSmlblbE2ooYHlvSFFeVPRjrRsTqB2JBxuObxlHC6P8yhHiZIeNBXIIUSNE2+y1w8XV6evjZS/JWpKTaaB4mgw7hk7oGdUaY+0DR7n0Ps6EK9pifd1IK7UEu/rQJwh+8/dv673dbDEa3KDetbufNnnPF3ufB2wd5R0nQ6WekUH9h2r/aKDn9kvOniUX9Tq8+w93uc57O7tg89zcHyy9+yxPs+R5/Ps/YI+T8J4/s/t7jwLwBY/v9UMUA94u5nqZtG3H9X0JhotAp9SfJqVNfs0+Ofy5Oh49ym4QXjJHmy0h6bHDLd62syc8197HACzv9Lbzb1oTTK+Ts2K+QWKkLF3Q28w83+RZmXdST5z/hgMFs/la0hEyErgxpnIX/bNkE4Ff3VGM8T1NNjdGarJFvmYd1g+uJmMKbdz0vm6Np6PkTFUnRNebRbsVi42/61bqyUuvR/QpTBDOORTs8AXmPO3E4faZzzulu7Pe3w1e4dtZ2NvVyZCvRluYoeNrodyS97bXD7pp8FsoIE+at9eFppz3sU40D15prqKgQ4gB/UN8wkuy75eqK4qmdtmmIHRvekVhR2M67RNMza4kWv1Au7DAacFRGRMd6KmJniHWkoQivdVNeCl9O/C96lf1f2yvvvxQm4H/7Zfll7zvX1/fcP5SCz/gZkjcPVnoE68IcNV2/YneUa4I/aeJkJMwXv9zbF/YO+AzbFk/fx9si9vUjdwhh32Scu9sGX+hNNs3J4RPsfMwtPi+PhgcHRzXOw/3T04KHaO8+HOYDc/Ojwa9A8hwgcSR6f7HUIOTF789z78wTysRHV6sOvS/wydQJq8e6OraXKHxZ2xQmeyqTVt976Dj3WzSwW8cJo+uFtJtq485tg+xdfWoNJFW/MQt8w+FPEDawy8jUac29ns8a2wWIlbt/MBEozh/mi2ZUDs8Pbm+W3ja+iZUe1g9cPEHYNW2D98tnu0Q/9Ss7j71O4vSeXl9UMwXXsiu7vIxOFdloiT8SjMJGBlk3za0X760+5nXa632l7MEDS0beyhve2dA/hqWEjjSlS7WzNSX+YkoiOD2M5dMjBmeY3LVJ7sHe4cGfVHc8CKyCnMlo+VvaVjhk/5k6N5SQUGQYAReuy3tk+BMasyXjVnlHLjvq3su2phbFMwHCDtxN2qPR517oXtgGkSZpy67rY0P2DRut6uPEcz4xpY6AuaSMqQYAurPDk82j1igzD6vQccZ8Hyx7MRPrmc3lSiZa7UD5JqydBieRBRFr8VvJY7qCOYq73kztZ++mxt/zMYmcYbHOT1/Mv9w92jw0M+CmZrFPe5turMHxdUyq7+aMbLYqRD1pNFDXGnFoYS7/EfujT5KO3MmMQWV08E639kJst/4J6SW42ZRmNkd41ROPbAysEFaJH9yezup7vPnh5Gh9gMfUy0DsHBNT+8cj8kdi6cyRdEV2Em3HiLjCOVwhrM8U5LbFBe57dds/m6EH9WfUWSR71Fii056vwBS876/rpnHWYfJutw92Anlnjgj/DKeXNl/n5q/56YKoDSn/G5uwd8o8PeIiMOhvb5QFYKApSeoL+CLNx5/PzsP3sWzY+ZEiOIhsHsmDdRRXp6co4BO4TNLTDeSABnghxYotLp0HKKWroMpCUHAHq3mDJ+akt1yYimbffR0wbfsmTS9n7MpB1Hk2aeaUsX/Fn7dklfj+MDe/rmHqmFgBss++A0uxkXnyhqatw5FKaAVbivaUIvv7lM77O9x0zY7raZM/yOn0Pl2hnbOdqLj6HugOXP2LX8OZmCA+eF4sYYmFQ9oyG9VheDAsLsfA4pL5HBUUR9bPM5m4q51fEg4TUkspWGRjy9UtNQ+DUqxjNMfyywwmuymILzqfIPi8nPtR6kbFrX4+mPWA6MD0QqRCFtfRWibNzUkhyYS+jUswq5L/qkRWyZgbOqKZmb2r6U+pyZ5RlBrNnmQJkuikl+UAgJedRmCNOHRRSCo58udo+3d47kMlyAreYumv+Dw3ABduK5P0Tr88DpdTOm6aDF8jxwvskpX7bMzNa23p6R50usvePDvacrrb2W97fZeeDrfFfk2M9U/b6ufWdedni8f+zbeOAjr7TxdneePjP20E8x8nZbrTyvGs3Ma2BkGXeK7WJUL1JC1SXqBNwWSVPRGNw8lzpuYV9z9DlFHPGh8jMunDxN4O75rJHDvwwGX57AfoAohd14HF7rUmGTNRzAL2U0d1d0UVd9L4p9WOsbqJsGJF23lJ7cv5gJTCOQH9AEJSx6+iCp3lwX+tp1T9PuwarTdLz6NC0ZxF/1SIUJhPWP1M7fj9T/SkcKptzG0aDDgPHtbT4hPFNwsWznS+/idQ/V0aoztV48onUQf6VDFcUh1j9Qx89+yoE6/GnnaelOPvjb2ID7aCxBMn9U1V1/dVJy3cz8ZV1lp3j9I4yj5eL88OjZGsZR/O5fasOtFfg63j14uvN3m+h/KQEOI1j37ECQ65HHZne5T2GOzWoryH/tX9PuOdj5cadm99n+uqcGUwkrhNbxWjILagj38kEw+essC37i7tPj5HwGEu1HixB4sA2T9DBuL5CNP/1dbvwHlxsI8QhftMckJMG66jVN4etVNvVaxfQEXq9DfanAOpUPzCxO03sWtBn+jPoMAwFTgmbDJ1ZTBW2qzI3rCoI41FZ26mU48mbUr4CM07U25oA/1AE/zEeW36yaApqR2qpbPOkM4DvD8k66PyN7g9mRk6LqEIPnlx2QiN18XN5OT7IBUql93vnqixJ3QtbUgy/tAUXkUL2Ft+MpxfZM27vHRwd7Tw+PdztEwPdl58jIPO5o+WVn/2gHuLnM0/oYovqyY/59X/Q/lnNEaAPW0sx+gQxpP4R/Cv5tvolGZv7DfBd83ujgq7O3ry9fnV+fZy/enr1/ff7m+vT64u2bzezy7Yfzdy/fv4JG8pvZ1QVche0zX759l715+6Z79vbF+bsrwd3Ovrq4gTn+zT8+3ds9/hzxvpAchJ5FCAACiB0n4QEt6i6FmOwMiK6goFk4TKuJ+cuomDYQ/v0iz0Z1cfNlZ/ufIafQK4dfHu11AMf6ZWda3VTwmZ2veMeY4X6xnQNGfkbjspHfmxKRlfO8hNq/20XJXbESjz/YPd7ZPY5ewY1aWslhCBFv21KppnKQEIFhqUj1CY/QkoekxnH47GB3PxrHmUW42jwDFltSPyE1vAbeqQC0ba/YXfcV4afbhi3rvWjnqP1F/GjIvkF9KDKnrPnUZ+mnFn6LsORYqVrAbBNYuvV3AhDo+9tMibtsshiMzCsHoymiA5v54uYG2WiNOTT9ZytjkDEI4dL2xSmcSfhuFqjw+oyBIU7EEWurJUpzIlLF8JlMEwmFMYBvRaV8DsiF91fXb19nLy/OX724wkN/9vbNtZEPm9n16R/evnn7+rvs+vzd66vs9M2L7P2VJwusrI9EPR8U29sv25gUOUHl3Vjxl03FNco3SwIND92TzbADHFxJ7Uww3YMZXGD5mwrUn0AY2HNQJ3vtdlOff3p2dn51hd/87u0r/H6aCveR7zGrntgzhzsHO08P/pFNm3D5KNlBwuAhhRvRWWmerlRyGjkGqdFfcc/5lvv8YdMWpgH5FGH76esRw9vo+gc40EUNRQD0XCpXgB35gAYbDgmuogZ10iqGd/xLYLb5lMNOY5ZOtwGhZQj0kqZejCXQfEpVnE0aBZ9NRBnqtjFoCybQAYUNWtouMd3fUIYPqVXtfSKL1aeqhX13/uri9LnRZVfvLy/fvrtWm5aSgbrsiLNVMyqY+L7iHOGy47qN6cJmO1p3JQ90YhGliEtPSspTriH6JlgsNFQWtVOiZmCQuIRNCBM/LMYl8Jvcgujj4w68AeWkYJRRTY9qO+Th8bU5O6+PB5bcu/oOfaq3Io3Ggu4KFVMX29yByaSsLCfb+U+Io13v0g/fXV18+O5rJ083nAjhVlPU2uZJ4uYzpklfPRZEqGdnllZ92R3vkDMaT9qyy17Yos8rpJtedu1LKLmhPOayyy4gM6qmIljDPKur/gKYuuC6rpkj6K1O1UnUO5hKaFJT9QLqPNyT1TN/d4Vd6brUEDZ17/nEmFvLxv0Ge84vu+JyZE7+sguuPppvXXbB+3evlv18Cj1Tl13wLdjqyy44F2Y3hEovu/KsGlc1TdfSbyb+ORT6Az35BOWixb3EJHW2bfZmGdE1OTDqk8jWYSPb08hQT4Uiep4D5+8wUMdd5K5GjbApDTiN/hnUVdN0wypA0Ljo3GJj+iQ7a44GOZFnG11lFIF8etj72n58LLcu315dZ9ffXZ6TEcJ2ycV5uyVi5HgJAalivpjFdry238tCmRGM5YT2D+pqow2aApjarenBNhXXPLjGt5XlNi5IlxntNKPuur7ExOoTsQAqEOd0eVDjCjWyTVORy6QcY01NHhHAUGdL6pRXDP23+HtBAEvYg8qaHvEDeUOZuX7+/uLVi8zoVvQeT18Zh/F6yTIMixsQ8DPZwINoAyc4MVV1DSyMcx+9RTWywrKdwaq0NxXFn8lcmVX3RW3sHlKbaqO9fv/q+uLVxZuv35tvend++uK7SEs2XPQ6fkjELtRuYcAvkCny0BvmyvfKBpDhE7nJYAkQDXxDFgAurmd6qPKxyNwAiK+1LdxcKYvL1lCreIhGUoH6pa8Y532wxNhnCOE/YpN1LQ4QWp+j18s0DzO1S67Rlr66Pn1u5vU6NZ3QAZmoHm/yCSys+W8OYenhIYZZ0bBuWstoyAtfSuPB/kM8b/f3W2aEo+K2ah4arFlP+Vpvp8ZH+7q6oktoPt8uasvuiBuHjtDhzs7mzs5OxtHJMufdtCnN5920Ncxbii7a2esr4IsDLX8PZARABM+l4pvwl49TbB4DNt2c+79s6qrHTdWnEWuZpUATuA0GAMkyNucWVj1VauS3lWWV96MtUOKIO+H3p8HzjOh+aMpGWkmTZOJ6Ol5lhmn5NBU7x3tMRrdvuXGWVMVrKgVqBk5MClCh/BVb2j2z16bmWPTQVdwwKg5/tQxU0mWS2jzbpjnYd/sGPsUoIDxpRGtIDdHBiwT9Xf9/7b3rjhtJki74exvod+DhYrokNJnKu6Q8XXWga7V6pJJGKVVN72KRCJKRmdEiGWwGqVTWoIF5jQXOAepZ6lHmSdbtMzN3cw8PkqqurjPT24NBlzKTDPfwi10/+0z4X4UeqkuAxNxpIBlOJunciQshY+ucKEiBiVK/9xaKD7cTZXK9r8mMZEIF58eh0aE0e+H2DVICTsFVuZrwZgOYOyZ3C91O3bqsR9NqTMEyYVpdLavyownDWJdRwlsstbl58iDyqOE14mdEvqngPlmcLKGDp5hzasgfenoVD1iT4gvuxriMJrWXKKGNZAY8ize+AfeaDg9VSbqtflfNb189edbDq/nySKnwl1YH0pNCVvmt8OtpGwoyjZxnsNcLDPym9a5hlheVC0n6sVhW9bpJukHLlSQ0pSxCaxOZ1dJXswTu48vq0xkdIgpkR80D+FBSJTxnYS7GlxcIYOthROwr8yFKCfgDG7cl6VkKX6bFQa9MukNciV9phx0NPAjJwqhMKmmLYFfh1gqRAVSUNvgIbbvjCTynvhqXt7abI8L1IPZkKgFmP8fOkxdEUpFi0VIs22LuOPLUXAkX3waqaToIxZi7vPXu96TbOy5bE9iHq7nUmZ+mbRsQKwd1IzcAXM/ZQJoEMUGiRLp3X3A4/87dvlJHiOrkGscWd8QZyryyE8+yUrsz++6mIspRZg9vTZYZCPUyPHM2OMmRc7V2J6Xmg6Kv/r6SVrhMoC69zhHW0Pv+1Kdsqkv/y8fcfFfp/1o9L7gTORVNFSu3C9do5fbiKc7i2FLjaoAZrjSXdVdCVHJH6IGI3wY8NuhmgWUqtKv5DBd0Uk2ofxCaDuqwU47DraqVE2O+qSr7B6DWcPqxuZvbGJbzpj5Ae9NTvbk0wgvNQyqiJvI6IicMWdh+rKsJbJKyGReID0kPLLHj0rhN707oGTfgtld3aQfQoEhYQqAy6Y66yVy32ZmOPAGduTXn7oxxbAF9oZsxbLOE2tweNXtVM5fNd/yulpMhWYnO5q8vV+4mZzsTwQCyzW+o9HSoLDYrVWrtxZc9jju3yHHvv3E7Tt55X/sEz7jbp+/rA86UqP1wdnJgMXHPDbKQrAanD7V3JYWutGwe4QBrFLSaBytTD33zhaafsYjOIZq3OfWPPPtfpCENmYaa9cGeEMoPVsh5a6WRQDQ3PqAYQI9SJW7vC25RwU/FP6s5/40t4U/uM+WclKI7j1Nq2eVu1ozqLXFgae8GwWKQ2LD7w1zNVf83CQvK4rsTXa7Ge3ezK3DQWgG/jqaankn81WrxDPubjK1sX7rItDJpcwgZJvEJp6GaIwbqxTR/Czc4Z1sVpP47VJ1lvw8dQaSopgDVFaxgfC3IUGhk8sOkpyGT/LdjR9k3J94at2BXUxIBwvOat28JVxB65FUTaWbWvgRd5z8eV805uZ28/izMIA7cR/SA8KCCkuW365gj9AM/ygkHSGfuIcYy+WrtDmzOcr6bn+PSSCZaGV5esaiv17PRvKjc6fbiG22w9Pe9EbVEKjINHYwIVtDCTfWBgunNar+fcwSSnqKEfGnKRDkkej5+o2/Fig0uqOXgsSlj9Q8W65UyGxVgj3J/p902a9CkxIkjZ1q4uxbXrEZkwwNR67RaXhDwvXW6u4abjKBAvdzlpiqDNqcob7gVYiM+Zzkx/fvwNycsmmuy1rRCqsND6N0ZoftrNZ0O+EuIg3IGy/auvkv+elPD/yf3/xq2k4zCk/Jj6bPp9WCWVMq6SNwJWqs5Kt3fqho0fcXlJb8G2mBQi2l0wUBLi8S+ftPBrnTW050n00J7tjXszdLZ4sYkiO2r+CaaIfQ4BISHbKrlGhddAwnub07i3NF8n6EK1T/e3XV2nsmc7I6KfnCnaTgr3f7f+ozHrKQ4RdXMeD/V3sLhjDwXy4yo8pU0GsIGxjJx215+dLvYVPE8v7O7SEbEq9uAq+gbNAU2NbSHC135vuNOl7U3V2CiGhHV15YkXPmYNAR6ahL87XlBAi4/lhHNI2m3L5oQw+ZYsGonOXRK0d0UH8VN1lfZfMnSDppW8mdNX1EHTtf1vlFnkQ7GIDDxwU+QhJ8a9ttnQWby0Atao5QHbM8PGBh2DZI74WbjBeK0YCYHuk24MDWub5TXFfZRh07Fje1SKYWS0nhZaPyKnKLkqEokFrsst61rhSba7kl/XlfjD0RSglhNpG+FdsUq2PyDweKG+TOpYtnqWDYpER4tMnqVogswAtGLrN2rCZY/xKyYVe2zwOXttkHo/b2jnNOhBewdF4d9lVAV79zpBbQgSS0mHPQdmMQRXdHVX8lbggqXMmn8Su4fvhsRbLLebRoCyp4paewGfRllHaARRpRIoUZFHOcMltU7BdC07Sl5RZU3PorBrPqeGbaIszYw5gKTLg3E9+S6gP/OTWcxH44Rd1iPvt8cHRMcvsR5a7ltnHWwUptvRwEHnwEsxsdj+tLqyhmp6RySzS28vjBX4bxalV9zu/jXrADRytUNSLa8fJW+03G7IVtEifMRJQrR7GJYBeOuufRo8I3FOm4zRFUaLcAXFPGjFDPZ+2kHbUnoDaNKl9k5EwRr627puvDJ3SNmWrZPQ+CLrbN5eTO9lSbbHPYO35ZvIHjrbnbPd32mtvZda5dpDA5X+q1m1tsvp3NeLaurK7RGrtr6JXtgGG/l+8FOCmpCkEsssHxi+ebmeEm27aY+TVWjH972jnN21kRtCMeoURAdp5EvmE+0soxFVzkkgNydTuwuZ2lV7HWSpi74InAs9+u1s3id1XcVJDwtqXLgSueP2G4QMxs6xhsW5FkhhUXRs73eeVmyzP7xB5XIKQrryj1gPQIIyyfb7l3pfO7xmb53cHJ0er8vXcG/7F+M3EX44BN/zt6Yg1YX4Itluex/9RMeD2zmJYJDyGjASrUR0Q2HdD3HcWZXyUQxJevW+KBa93aa9aao9dQ5gD4n9uhjMSmwr2/Lj9QTiP5y7o5/udx+ukTqMt2wwgilYbizhNL5NFYY5S6e9y4ZwL/DreJp0G2Qt8sYB5z661gcIdzSXjfVioOTLSNiIOTHDA9QA31TIIMl1qjkZsacYcv46Id79zPphfY5iIw5UWkUcygIAhg64YhlbNNINhpZCESFZI8nFct3jXbeA3VeJjtf0jjMdP0ZiRwKylZjRENozeIm2kjlaodqk38UP77p2bQpBrzgAe/c5fh6/s/y1zga17TNgZCkNHlMAC3omBXcI5bcUxxv+dKIkDrSnr7l20Sbeppuqo3IAucxdGc9hGYjtv3JhIEBbte4NE37F9CRZ3ddabqFci4XUlYrVlJbYqr1Sf5X83WpMk+OBeRI7jlzm4Cq3L8+9f0j5bT11RHjSHh66DbwkWYnviyv6P2rWvJBtJ4ncg0eeVI8uB/1PLiksG3ZQqA2UeorookEtz/rTBjrrrXayr4icYObbwXLZh8w6hPwsSp6HeSt+YB9Gmj+226tOVfeHnv7/GsJcl1XzvYiVXNNtTLFnM1mzW9veGAwFMWoxTPVYaT1fB5AUZwAlHgFjo0yiRU+YvZOM78K5KAjNuLuB7lM2muTmvduIEcIEHaRkihOhGkLl4JDfRSzWfU8JN57R28jzwYPyA39CkKQwqkB4jOCsSgx6Mhz0jX5Q/GxOEewYWvYMDeoz6Z60SJ50qCrOG0pGU5uxlYvWXVLBsbYavzlnxBw2nrMFh51IfCHqcd2qpT1fbtoveema5eYB9WSrVEnjVkcdN6Rk04nvn33jzuTP0FKSw0XAnWrQL2fedpR62k6L7PTnOQXIarBOZ84D2JUIhvbgxr6LNt1eYNt6e2lOELDj4qbJzAqo0iqL6WSKnbsOt2vTTlcJ2zcafyefJMpSlhyBuSm0JTVGv6ZXYF3mmwSAKFziQj2pl1tp0htj0zcFIIALFoJYS1wkjAMo7GB3wogPO5Ay4YHoWIJoIZyAA9+DRcUZmuUVUbWpCDFOMRAo4KweWyHXVVoJrtTMDYThAuhxkWEQ7fI1gSm7aFiLFnpgFQhz+T3R5P/tLb5SfEV2Yy0UvENa1gnDaV7UyhMhPvNxLrZ2PHtjGt2/1sdxVvdWLTCHSSZxHSgZgqvpIerauaUVwtfDVGHjDyzkXKPzvA5QvGqjT/WlM74LpA1ILjcHF8qJ0kM1r5cZz/2cOqiCxyDTBCkMdg21ZySJAu4StHzAvfQzNp4g4rjZ5P4EdwKmchRo2aJDWciK8AN51CaNlduAKF833xsHA+LE4d0zcJh1w/YRTWPRrXVncpN4mNRAfFwt4cCy5WGmvhYQDEH76nweCgVTnRSrU8XjeV3KloA6wNDleCYIPFUNHo+yGBYrWrhRyfJLbcZEFSk7zrWLjRzAzY2HUzi0KrLUMxGYztN6mQeUuWXRBgteeBGwnyiYPGg/HDewAm3V3BMIQtLqpGkooqad7YHh7lUPLgJA4v6zKgiPqw5tFXnZbWVtBID9DucAQf07DuJXmyqWTUtxNzxUtO7oPU857xvHx04PzJpgdyTt1NLVJuZseqw6Kq0kmSzmIpRDMWKrQoa6ev3L57qUnt5yQFAVKEpZI6zBMIDi9gr/71hR6tzeIzWxoqyMGgdVxKc6HvMkVdpFcGsHzsLYmfKU3guwX25w76y74PwKd2xfRVlNLi0H948FnrgoCnXFUUkIdm93CdzhtzcWx1Y6/n8yJjY+7esEVnKsZzhiWfGjhopdYT8VApasAYdvJvFR3RrKAunlqd1nbsjqNILmBvcM70BCO+QYdkp8qL1iQ1VKYRivw5NpUxDmHZLHvO4DIjajCDBaX+cCl+xFs6VLwHLxdeMsj3ItOcUM9Z2bq+jkHgSv1IhsKqDvtr4ev0FE1ZcjKnosI+6E39A6LbzNoaTZlLv2Xdow+UEUk9NFG8oABelyrx43eLX2jFaI/y+uroe/nnNLcX/WBfufc+fvYbmu1pmYuqR0w7rzwffm95QGlsiNO8MHDfVH39AWkEZXS6pbOkG9CtnPSKc73+1uqmjqrLYK8OdRCQKAoDkdho0RmvGQuk5uvM8IUmVPqGg+F+BAGG7TEUkcztL/URZEyj+Ma+cteyr25N8Dkdjo8lQaDbup9Y21/l8imTrs2T5clncUDZlPmEBrocrn2Y0KkMfs15Ov1wtKaalUDs6khLCYDknX0we+S6pg4Tm9OedmordXKyrPuplKDZYTKlzL9spTmjNCXGaojATV70DR6MxdHcSiKCnaPRlOD6oEnuxrLj6BPrCrlf8OD7lj7Tcyhx1rIFU07+s5uWA207Jv1ECPiCpP0izLc99q8sY/BiJjtbLvH3+tSk/4nC1exkCR1MsSfaEP6Ek4BJid0ItvZdc1ZHU9niDUVY6OoMr2wlYzrSx3S7j3DMtsW+CyUlqFjtv4Bk4IyR+1LkpR6I3VeE+T3nI2TTo3UsqLCRNJetJlQj0JO88pa/PrV1jfLaWS9HRqFFkh1JCDru2P5bfqVsnBdI/cFSH7qAxh2hJ3HsmgRsBxwoayc9IjET6gkekODE6vlYvjx+amxG00+h2VdpIHsLbwQgDUAQxZ3c+60m4auriV8kd4/o6d2/R+BML5M4o2w9DCElj1ifJH0nbuVe513vz9nluzhrmTINUNsEXlQjY2GesC1sq3QeUIwSIRGcZcM1q3b3OizfvyEPjNYdaKdgAdPJ5sV4Cn9uqCntakjXUJAKVZTAsROeVZpTtvvT8zMUAVqa3O329nd8lEi25ebVxWuFm5IPlmo/uKEZSycBN/9CaNDPl+x1xVqm8JHl2wW/OSUKtXzMDwRuHaR5M0uzVqpcLOmJ0cGKlzxaoYqDo722QBD+CAkLaMNtW3ogLSwcVWY1h4gzSzWAYSohfdQJ1+DDNkDdcQUpR1WvEqxPEfbiJygDQBaY3z15Sg1BBuHlZyZdYEFZoZYymxvAjnVb1r+zLF7Ihv1BwwGn9ULBlZRH5HqsKgT2pxELDEAjV3GP53uutdg8w0Re38rX0Na9Zx+26IuL1OVNrbIRb8MtYrHJkY3RLKY0QB4tc2Jzo0VoJxjbK3Yux+KQd4Dht3jJ2IDn/aPOLtsHKIEHudlc2e5lgolg2eWc4xliZB+A+gLUU/fB6YBvYDHlDXk+9Ah7WiOxUU1K8Ysu7szBglQGTUWpx6cCs9ASpZNAgI5fYw6whM344qVGhwCanF3IUZqhRrKa+jsd3bplUbLsmL6loMA+bdOYAxVanItIR7c2BwNSwsMnX+DCTT61x+UltFDmvUlMQFuJ79DD0xb5wmVbGD+yy2mVt27hufvh3by6ENu7i6Yu38visnORAbFyTJ8giKwc1wgfXvcqGlPAkA0evLInIBh99P8JwdBWuy6KRM2HLoym4OitXDOzYigjPxJTS0D5Vgt8ophiWBPLHzl2VhX318uLJ7589+efHr//14vzZy2dP3j17KrP58Qe39yQ7s9Bhq3KhbIKPlhxK91Imx0j9pd0qZ1euhaNIkkzdpavJkFERRhTIkQY8W1EIQKwYx48UUPyaTCkn/bBzjpC1ro34dE+Kjim0aXJWk1udJpfMkwUVAJo5sXyiBlg4zAAlhJZWjJyYgkVvWXYURJcpai9J57FqBJ9TiFzGLk92j9v58h1NEERAlcypdRw77UG2A/UA5GbUqjiWJ4Ywrag36L7UsewNv+r1UcsAo7UfrSN0BxI+NUMP52AJZlkPK8RJGjj0l/TPJ85sBxdNiEGwhZfZHM3EhIl6u0Iy1CF7J3iVHAKEhiSbXDy6jxWvNwe1DcKRPrDqjmBlJpg4UnP0vIdmzuIuOjfwT/9CaLoe0ccx4xnHeTfVx1FPRqQPn4nZpDCTuHz+mxqsDwKG6zE9N1xc1hbzspxIdEJpgPSgZ6AVmy4Qg3ao/Izo0nvM7yf+tahcSGqCQgs2i7MRvmRXpgRfe0CVbciEVQG4ztj3Qq0d4d3MgsU+H5iyn4Ew5GSEBrvD1WEjkuKZSEbVeVTK9qqhTLjUy0cxFD3GniMtsGby7s6mR4ecpwbccmVkzKBS0glbTN3dXvYODraPhPo4QnQsV63sO09frDqkXEJS6Pz8Ze7hrMOvV7Op2g++moz/xALB87N4ZUYFV7Ey6348vTXJfcpc/HVPWhY32Qds87kDyVFuV7CwI6f6yoLqvvLOkbftQjSDnOiUr0KYqoJy1vNLhE9OyW92QMSy6RpjyxPFPqqWqbTuPk7z9QwRHaYM8d5p1iJqBaO7wiwxOsrGoKo0pDkILrZcwDgRITVMBI/yaIusm80n4GahiGxZgZg0aMuldBdlrMTvJLCyr5NTMoqSyluWOBId0dgozOX+iVA0lsQ5U+oPZx/KiGzhDgOuglDZHOqQEE6eIykzli9jMPUM+WHVfYMuuWG0pnEWl2wOauUIh3y6pmFwAHFINiohYGZYEHPSiCiLmTBHAgFz3Ayzyqadv3tOrFTPNx3G9DWSUBvuSwGbq53tNGO84KMsOCBRKG/cjeYyPIRNKD+/5tIikP1weKqbra1Vd2D/7v48ulUouChxn10UpjnIkhtg1uE+YHzmIJe7MWqHDc56j5y1OWrGVPWCAsg2fYgiZ8mr/SLCNhZ+I8kTpZr7otfnwfoBxomwVLMRPuqW1FYBctsEj8NiFIPIytnhzCO7uEtvfUOJgOJTNVvPxNxmx4xiIJmhzgvLPhdJo3FBNAacAJ5Ws8qSH2zDaZsRHi/rDxAWRsYjoJNxDrldgFaViPhX042rA5aBk9TdE86poCPx9GOCJZS+u2KjSQsVMCFKM6UVDGz5wwnl2aXlChl92krpcP/g4XDf/f9Rb/8+9XHZP0xa2N3vaAekPWG+PD05+Y3M4ks/PrV7oU7Jw3o+vFkQk6g0vaXuOZduJ0k5DlufOJCvqhs9dIKrNs2NHpz1ie/BNIL2TWPcv3F6kyZJyxLMmVSRoFOgZjdXzi66gC6WTkjhS6fRX2FB2T9TIyXa1Yt8+6X7TFM5L6fa0klCDJV2QsbbLYsL+Zhp3kNvLsSXQ7f12gzn/hH1Tf8HseU/iC3/QWz5D2LL/0TEluhDFnVu29L461v+VNT4K/p+vnn8g9PkEZ7vx3NDq+b2jECop+N1axAWmaP1CVEAUT8TbmdyXddNuffrX7n3KWdfpUVi7l643xquCoFaeUuWvoT5xB+cVgIZxxndy5EXH5wenxwxefHh3sNOFN88E/cCSFNh4D2ubTR5isB0gjCiUng4hdMrp8qfRatVYCmjeJAmffAdz5Uh8RkuUCwmPevUeyud3qJV1aAccgoJfnx+LMcNyDV2sdtEXio3voVtjcScFwW5WPq1B7NKOD0kP3wVBd9GjAsey0m9puXrjKYWhmUq8C9lS486pqRB9S5tyarAmremvqbjmXTxTVqF+qaJxw18dY/x1UIJj4Z9odRKjo/7ilByMTaxuS7LruFk7WU7NpZahpC/YDaHC2VzIBqoldQH5M5N/tQ8rusVJS0WvWOvCCU6+bKuF73vnOJZxgmQ2CU2uGNykehIq9QwcVwOqIrL1C7X736+P1ruOFP/Ac2sUynWHMSenvAeBggF9rlaT3YMp/sa2X3vP4SQpfcE8ojlQhkv9GntAtcixvZq1W36wc+Lvb8j5+gjhMgT6qk6KZZaNaXsb1jpSErvPERS2GluEe34DXZcU9Hzqrk2+mi36XO98/GW+95dX9hmYjMH+UGb4DkiJ/j9O2eCrIqrcO7YgtPMd+0zvADdNzWrLcE8AHZKAQE0dGRaPuCJDTVw9F7R2CQpAKr0TD+ZIxOcVWgPXN8QGpQEeK3VzlszploTSpaX5seliJxEMemxK0F2AKKJlzGBbr4MbjNGag8y08gfHv2rSiaqhvTm4taEJZ3Ma+RUft7b4q8iTS+2T/QFlZaXRQ07Jrm7lKkAyx9qHVODlfm7ookxyJpH4D18pC1Dsie4I/VZKIrI1JEh09vmPGQAosZ/TXFiA1xXA5eHzAiK77hHED5EstzZGbXrCefjJewYlOxVViaTetQZcfsNgeSvsrV1m/SFL+Utb/x95fXlGvxW05IMJ/O250f3jRVAIhNQLVhYsZBdo4NsQakwe3QKM/yZJKIEb/Lr32nUhcrQkLwRBR3V7cQhMOedL7nAJm3IlByCaKzMxlK5CgK9vL3uFDXdtqxx7jqs1wdJlLlTqhkSjyfn57hhfzjHq7Xch2AUVUvP7dHN3b1pmPzznV5giaX8KI+LD+oiWMygbRlroDYbB4epKdJLL0D8Dh2TUpHHZl+u+j9cmkdcI5jbjw4IMZ+vevnhUkPiSvLx5J3BVz82RBndd/KWWI+WALLWXE3LgILGax9v5YnCSbz61iGNrnRwHN+SwHtFkA9kSHyb0u3qpGWRJjORBYaSVBAbqy75AGcQgjU6Ju5zpBeXqW/VUx7EcZfRFk3NuEWIwasiV5/cSTmWmLDYOF4jfdxoPtw3kj/9KU/gEw1XrDUhix7XtNTiBrm944H4GlRzhN1AziK0IEVjw0olTNXMobvfBpzZAgtxhF8VC1NgsipG1gPiibysElMhMsZs6Z9AdEaFIuLi3rPOTIAzi5e4Irq9FWcRKLoCaqtE6AnSlCGln1aFu3mcODKWluWIZ7ebPsEzp1uEep43jzqUZaxQAmqylBS2thTTYgr1SytthAdxKLKt20NoFtV8XmoxoTMLGzNLbpw3UfK6gjvAXpEfZqARG/wl7rjtFzu5U3DGYTNJXsZ/EJgVw3woEaE/r+tVTordz/Z8KROaEel7CMm2JPaJZe/pi2/9lkVGnJwXkcB61drAuIEC6CUCbqu91PzguQNGx945STwscHYFzYwTR01QPvJAaTHQ1gxxeYPRcPI2XIWTXcaWXWqF7iVPEObtyhm/o2LpZcIgMw+c71QHqQW3wUTM3Nsg7906S5gC9nBne8Cf/nihq4fVE1UQQ0yY/pLRCGqJZ/STmJw23IAzBg8CIr17srzacTB+dKsXq1DeCa+Qp1R7OKsn1SVxqDHkn5Q3WYgSl9x+ba27qDP2nqWNhMJHNBLf67pd9BqLGOvHUHwtKyrEr7ymXLx4BP6D2ha+w9qaE5Ya3THGt2GZmAdkJggGtULaRzh3VrssOZNbkZp+hSi4z1pvWlyUUmIsTsJVeHdaEMOIjuMhD2MhKaHEiWYRW+61N1TxgcdlQVH4x120a/8V3kEaQVMLrLrJIJtJaHVE9RvKQVAFRlITaEU0236GnC4R53SXtRVJyFNWtmrmJGCetoVoAlemrJcRRXITVkRgWCyv1pxBwLepgqaQNg+zYvkh50De392rMu61Vt36SkPYDNYfJ1o3lkHaPj7zpqZ9iKEyRpinIwQWSFsD152o+9L37eADEoo/MJ32szSelFuVvDqzCV8+bnBsOvzKFggtUoyaL5P1JOf3isjiRUwlHH0SGGQIHyBhIvn0sPVpd/qDXj+dTR/qtA9UfV9Gy07IhIhqGU5VdKhEYHC+SXGA5CCe8JhMvidCWiaNGf6KcQeaNv+s8d8Uy8Jd1sX1pqG/1dOK7GYPCCDdQ1nwSXtDYj42fn7u8aREJtU4sunkO0yRU8shyh30uXMO0JuHFHDrr4Lfav2+k0flp5zfl8WtM3NyKxcBH7RSRvR+nyon+kkhDv2egk6o2nZiqVwuVn1r7EhL2l0YVNtTKLRoA+P8pm9KNGXzGMp++bkmZ2bcKC7YKLCTo2TeOTHZe6LnG5vCupARx8e3aoBYF5vQOyiTWgeAz9cg1qusTZmbSSoKCE2nSpp3m5T0TqpeBVfoV3NTTeDaBSKT/nvhM3aL8ebt6z6q/ddLIQN2V75pSHeCjomm4s2Heaa8Ib47m+aowfaO/QVToJ+jN3Y5+W6ChYquHNeLKkTnbKMmpgJqZymY5K3xgThv/FL+QgfcaZU3XpdAtugjd9x/ZKFSr/GEc/Qp5vlEj9F5TUiSRV+OZDgou2RSYlZRP0ONiQ9TYiGK7TKLAGYAPjBiiNSQQVzsMuftQBUsVLevg/IyBMhIjYmwha+xz/45G5jgnPeeRd97531Orz8XRKyhBWnFkQL9IJgYcIU8fNqDZ7PRWvsY1rnQgKho4m8Hrt00X9+nE1JMBz2UgZZNJGhQFyDP5vPYj4gT5MsZW+Z077ibhYrSCyj3FJS2gTuwy9uKJflrPwgp25O9T5uSFDSDnaxMI1Jwwvq/Lwnx5E2YmsHM7fi6vzaRSe5s5wWVoXdxW2FmHYGLuSWhBBTSd26vlepTTiViQnQHkUAutQEZd8fIoHhsaARQCQ0mkH+jGivKqPu4mp8Mjqn5mugD0v9auSTZn3zWBSGCgCOVuyTqguIE2vAx5SA1PJZCqISIZu/7cknFhqaGETjPrbKubeGzSU/IOkFXG2J3NvDjbfeHZie5OpoW4w9qJhkHszHqn/WZ76VBsUss/RRdEnnCOw3GdW0yEo/iPVwBT7FRwN0jyHJdrhdo77DUGl7wB2uggZ8ReKsA9t0uqWErBv2WVV4D7Ke6r1x40WleIB0v2wJ8vKBcouvnNQ81XaLfZW3W3WbfF43a12uJd9C8q4Z8SJ4OYn5VxrAJ+enAVyMpnOdvPLqUppFgbc+Dc38xw62n0yWIJGXgAYx2f6BALpi3tHFRHtgWn8ER1z7YwCWoKiVGYGAcMALs7m1/+PM1hKBYptI3BVHFRjAwbv5iqXAfZu+Qq53GYUk6lS2LbdAb1fQGxAJrbu9nhKS+eyPX5bkJBXpLiJjzW6b10sJp1ldX1GM4wJx5c9BwQbNlTIrGeHeICv+ljjhmm2wz7YnYaDwDz1ugqYlboXvkstUrQ42vafWED1dFBVqaZPOhXQvG9mnsr4pisIZIlCSANdM6pEqKUOu/nHTzn1YE8E5zgr9iRHXEZpsTYknKPRZJAy32m0iNVtaJ9pwe3f0GbGEbdwQGiCjt1/h9tbC72ZW6SQKOiQ3Gh9g/9l5QKiatWVaSzfOyO+qT28PpQfJ15Z1t+nCe/2E7WE/aCrB3Kdq0z2CpvjFxMxCqvsJfSQSGmzOv1R+NJvGEuwWyAwYWq8v4Orrfp8mESYkOgbhTWv2gXgCcOKbFm6xjHtHILGzls4JpGq3HGUlxWQhvOLiNyxslnQ8p56HVlfWxjdcRt6VPzGVvEmeNPYOuETBssCA4QNuBL3ZTvG6BSzTxS79Plz4KcKdRlGiBWx5JCK8Yu9QpU6DoO9Jv/yIdSTU9yrj56dS3SqjUKOlOlKVML955DbBN3heNOFVdaOyMs5RkIZyjdPLb3b+9NQ9jjwo7m/bARPoO/SeKKaptIB+Ml37rJNSnXY2ATGIW8X5+6sqQsYZgPguzlFY8fzBajqLfrQginghJDb6Z9MuOKd7tARhazjj6ooaCZNLZcaNNgBOWOUJqKYjNvHUCVB3HB5+LSPi4+w4jIngDlYbqMrEghGWwaOT713Cj8+qMeER7wmbMnTiAviFfrh1GszGwjvO4RmRP1LXWfF3XtTuRfyo+FoKxn1ajpellb5Uh7TI1E3fKwo0Nn1oiLlLPENIExcacfO545aVO5u7BILInyB3CP8m60N+seZWtTBBcl2/ZgEBr0dlS4ydMoQP71jEbNjQ1hkHVvTfFEtamHRh8Gia07gw9ZNa6789Pnn5cJ5N5phQw5p69KbXWViEA+YGokpFuueY22x+E2EoXm1kAJnRrmpDtjOIOkhLarKVa3+2CHGx5DhcME6ms8u+jEJX91Np33tq0OdHzVPtcl9NFjyq6uGbJMCRIsZv9MHF7EeU9Z0jq+ecVRoSNLLwWYJ2S22z7iRB8rZbtgq9BTyCz7sCnI2n6P64Q87GctG3vTelsEGmlGL2a76CbVLrWy9hJD6vP5r0gGzkm58H9hKnuWf7K7luqTFKTegyEANs7bCggrkaliLRNgUGgQ75vEHlNBJDU/iILS9m+UeV6jTuqJ7exwo0aUnSdgN1A25SoICd8qFmoZCD392pZ6rkVB5Lp1dDmaaXlOW+fPUUW5fNKnIRtoI1DijppGgZEgTO4uc+UM3Q8LZAida7gtBpXq0hkZ+3TDYvNfJ7xGoQiVcGgFb7+k8g8uM1M1LA+o2xPtpfNekvqHKQzMchRjSbphexhbBJTQuNK7s1p7ksANdc2K5wUZnLyK7NOvoQ/7mTRiMftkdgZVPeOhU4eMTVmAMyVB3eaML9tnx2DiqJqjfw7ZCFEYiOAUzXAWVsgPe5ZMQYI/fPONT3u2bxY8kHdbQlMHj1UsNVLE9G6IjrSerE2FLCLAlOOBY9xBwh55EkwOhqlRDrMaZhQeS3ObgvrZfsjdbtICV40axPFyW3uZ5CEUpPIJCevpXbkDQ2uf6HpBofsDpB1FB5I/M672dvZ8rTcUxaFR6dD3ngYfdqNgvuJ84d8VgpQL7h6EqLhv8d17dbq2Ql8SaqmCB1lnZmPZInmhIWBjiA8/aizNDdVUF/ughXXBf2TPnvhT98FOw79bkiGBui6a7U2wQ2zREBgFfgpREAHh72D47OT/bOjB59LBHS0/8ATAfnxfyIR0P7nEQElJBL/pbmADoRAY+RsMP9zvMGnxPS0Pxy5jfxLJ2/QA/eM/6qUEmAWce88ZYxYnljkJLCCvNTPRdQi9gFZZpH77lePepNlwVUWk2W98DlIoeRDG9UApfMerqGnp/xtluXj8HjfzbrfGZN8E9I1Z70n1K+DFtxH2lV7spQzLXuI3NUzWfj6oBLLm23KkQ18UYkonGhqJDEml8JYiI/Pj1JBldGwr999fX6PGCW0cOzWmBSB98PSrm6Klgi51VnPd8ONLE9DCREH8eNg96tqDn+HAmSTP63JmRG6HTI8ZoRjkeqDdzfVlTOU6gWXjSE+GTuRm8bpBLCRW7msJpqI0NzAd2+cAXNFAT0pZf3chz9eTya3AiFQ11Cj5pLqFHJPqY9Kd5Dojug6UhBR+EYVGZfEO3UVwpIH41kJoDivOilnFfJUicbdYqjrTj8STj9S6pi0jzzIlWbJEtCxJgyBGYAej/mz+TH6vRycT0d9hnzIJBlLn016HTw+QE63hsbaJ9+sAhQBIXJMT6GYnsKRP1Aw3DieJ0fGqHqJ71/y/CCA7JOjl3u8vhqC0iq2KSRgIhUubIH6oVV6V/P8CufturYoebxk72WTQQp4ZBejdNZedG9kXshchOvKvRq5tWP3gm/YXpeFonhO4Dt3DqyQkjDm13APaPAHu0nwffTGk6c8IWlYga22QX0dXzb+a7rqZo7EqinMO0ivl39eIwYIR5eBTO+KEUMSHjlhtJwg/+9Gi9xOusIg4yIJcAuq+FEJwWpDJHBgxE2tPwjJUB1hZ6Q+kpP3HPTcNH1OOz/DdU40P+e0/cl5KmInyIcnXPD1HZAZatZvGOs75hPjA+mMt4ty7hbLmVqsoAWT537v5n3BiRD/J8KyIIArRcTT29yBSo9TImElVtakV21TOJhIWWAXeAdQ77jn74lQZ7pcQnmr7drdETEFPM6Ybs/+OEPFodLrG9/Cuol9IxYT42oS7AidgcCzCObxh3NDLSfHjGyY4Q19Eb3FpgH1wQKHX0+ckRxwPzJlbDN7Z4a7hWK0hhNCznyZBTjSmEi6h9QDjZuVWUYFNMuG8F8vaJbthjg5sWeTXASuZfsv+JmX0u5NGe7IJVi6Z68p0tWOrnQ/HeLsjfNdoHgRvC+mN0Q2p+JHqa51DggrKubcWXG+15yC5tM2zN2D96NQpk0eZqoFjW2n21iE3r1K1Ni6BVFZfnQyN2jzTIt1BBpJyWAalOgoV5JzKJd6XL1vMdZPz4uP1ZXU6zP4RIQZ6crLlZrI+vFpClR8rxkNnRX5rCv0CqgR2CwqzfpdaqpGcWPe9KCWWcI3It0axZibleE4yp+aGBKzeTKXZTkhx1dLFVgMSqMhOapkzDEshy7oGlbD5Xo6ve2+eMxHXTLxD7qmAPdBkAXKz7P8bMTWgF2gHBe9UppFiEAIMoBUJ4nYXqAAvUO2zt38WX1VfCDeYxo2w2nvDVRuJCIW05xasGmE2stMaEU6hJp2Rjt2bv01kH5mTghPp5giQ6RXxZW8HtpPEcYdml/60pfOpUr3JjdznYPfi70/nL/+hs9DRQ0U55MpFkk2yK2w0wzsPi1Ucxt+AHyRrhVQZXuE28KvcuQXu83nT01uNnwS7/0NJwW+WM+5YkNUz3GMns0nkZ3sA95TJ2+nwopJBpuzWfjAJTYWWoOQUDrrlXtXeyqPHhFJLvxy+QWbff5HNt/K1XhHCUoRvxuS/E4nrUQScgrPXSbt+KTeNt/4xhSk+tdC+Uk05lObAjvraWYMGUwp0TC9mQCryUrZljmcurl0vfVgvBZzgOKTasBM5VXRyxcEGbFUEJ0rEMpleek24jro/RFhIQiGz4xtk40ut52LZAT4/rZYniTh43b7/75ZzKZDuZ//j6AbuxQRqghqyldZQJVyp3vryxNiNPJ6m2bNopiRFuIgEMswgmD9/+Hk05ffPnt7/uL1N33UIQiyhC8SVpbKR+gmGntCF1XUvHoCeDmJB7C6b9nGeul1e2C+qCsaulL2hlxvHPo+c5jK/V7ISsTcoPW/Ry2EJjWDiNFrCFTefyo+uZ+HshWYG91Zfa2gEDI+dHKlbtSMx1Mk2sbmEEV/0G226X3z/uVLbdy5DG0tMFv9qDJ1STwDSETSClRs6M9W1ExC1hzhqoLKSJz99MoZQbAyuOoIYnuTl9DmZ1Fb5m05FJc7O7h09PBGXlP6EnqKoZCXx1Aqoe3A3WP75YrKkYGb5Opc95cIuB1IordHiIxI02l63JzWy0s7zXqsKV/qDxz1eDMLcrRV8GjwRDVr2kOxb+61mKYSjVuaVkyCXqq1BhrJx2pVht1izbD8GAgAQp+Ndg2vQNGKqN+O+yTU0jCto9u2lu7e3IO9CqP9DpkVAy7MloKCanLXhzcJlUreQOr1daLZOhb06S11wx33zp1FPHLH19McscPB4N9HxOgkEQOC7OrgNNi0KdQrrHcZMIsoXa7WZSbJuvsjQmScrNymd6/31rl1eQhxt4LmNB7iqKn/QmuuKPqlVD/LxnPFcWpK8J08NBUivIC5UNuu9gOMBVxddgDr2pD9UWH+x2rCVQseo+odMlFtqmqrZSacKD3cyD4vPpLxrpDH5CEWAcvPIpG4NF1tdnwjtUiY3izc2piJI9zOiKW10Ayl8DFgy6xO8ddwB51ii4CSryWzEfXIG6FGqQdRWH7Cz9rcau6MomrC2qP9FEVnoHr7HpmSnsFbmfk3DcTEaM2MlPa4bqiEeayWdDW38eD07TPSOpXVxtN8Jugdt1fEzuJGFsvgQ0UCbExlCw01Oxx/8KKTWX+xtNpyK+vFeiBCAA5C261X9VCKlJIKERi9xRUTdwhzP6Xwq9TjYxRux7iaTvSRa87SiVcZPFSP8WEh7oG9M6KxgRpG6dNGHx0NqThoYGMGGny+NeAF9zKfo10sDUUI3ailS/sAQglTIWA7nIUV2zCmVHyE+CzizpfVkoRCMdL2kXIw3Dnos0XQ58PNUeplGRUzUlJP9wp3Xn/wHyBZ+HlXLNWZuHLrBariFrd8t8LVqpe9CHqzo2RDvEZdJG+oMbZsUcwnsWAj6KibGnXqvpnvNgIV6RiuNk6VXVfuGMGlgWVLMKNFs9vzGOjC1hQLeL27An5xS0Zh8AUf2UpOSCEEgOv5UL5VeDWBkJmQworK2FURW8GOzEgQwEe+6YB6Xrax7bj7MDQRhoy22gmixaimenScQBwET2EpxxUsFHm/CWKBRGr1nAwD3+TgeH/xiZGnC+unyR4RVSCVD5e6W6PymqSjWzIKTrLcuAQxQHbYtwUs+fJTOV7DCnVOWb0URDdHNJmlStrViAQK1Vh67kP+1rt12DFCge62iF+ch+zh6rrSBOMXXM6o2nqJXASie3JE+GO73lpFSY+bxtvDXiCxBN8hKclNqiNYnYaSAgSByfo/bXhczA/reb1CzlSwrwMlKuFX4dim7wfw21gLlMuh7whFCodE8YTRuO6JUdwmm1sW/iClKqy5o115z9SaXcQkPZLifv8i+zzK9lgNSV6Tz64MeWJRq7pLhJR6L2BGel7QOec9pLKl/S16IYlpU504zUhH5e0AB7cbPztJSaa1cY3kDCzgDMAeTcNugPtJIyuyEF6EmBukdtM2eVrZh+7j+qEsERWutaQdDQU8WXtPOxni0EnfEg61SGNKSTnQw7hfM2JkO1qR3Had5SS1NRCAyQuw0zyuP7EsjTiuNmefouOuzqd0omxK5znWU22ujbImG3/v9X9DJLX9Heeu7sw0cTJsU+enSyeiNj1P6AHyDSCkmLUrTaKFueWngo67cD5DlLld+2O9frcecWar6wk2Cdk/L8i0EaHP8GdKHNABQScoU402jbAgAsznNzbwAcWcgF2DEjnCHpJzb1KZ8pwMy1v3aWaujT7LtkrWgIy2//W4LObfvZFclGEUoiPWcABB4LsB6q+1AR3QDgn8XB98RTJHrmVj68xgc7tPHdAXr49ktt4OFrCW+8DRV6HFnIoRN8DAd5r78YeCKoT5ZfSTbLIjdS+/0b+EL2pjkiZtj+eXQZwCybmLn0EJEgi1nbnZnAByomDmlrnhZmFFYGqIh1u47fWd1/BRxG0GhBYwIQcZmPs+0dNU8BkmSen0TB3J/ihjXlaCH8uasT2p6B7VKwq6S5AgxhYNQog33GkBLF1GpITcMV4WgCbxHGtbqecgINOBOFeyA9ycJiqIcJL7LG4m+Luid+3k55dZDHFUNnTPwHSH/Kx7UEFD+cqQDo2zcJ3Y5L/f63/1iH763b3iKznWP8egOpxblWFBeHT+w1AWEL/nZIff/mYoumLoPAFiU3Azo2/+zDPLLId0QCuhbP2yfC2/xdn+Gy0PhbqGRvG7YZ+6X/3Mo+mi03s2VZMM+DX/9m+/zDXJ3ZuFX2CRw2ZgabD5jhnWbDL/Q6ndv0hIsCKUy+LMtUtpSYh2FLcU8ZvRzee4Jhqeqp7xdREok+IyQC+MOOnQZvSk37ak3AAeEwbzfrWfMjQkdx/m8j9IB6kwJ/l/KJAustLcD7/+1VBhq4ll3vt+yIVdSyIDYZqbq1COI4bRSnClisKcJ2KM1RaNolEgjo9RyllpYFnBc7aNsx9cTMenZ697ionzAFcNTZsCihOWgKTWDU1ZGcJs5Bj0nyLdRlg9HrRvR53HYaBvu8oyE3IFkq9vyLp4HFcu1vNu/d41qmT/31GoSXIKvh6MfGyFL+mB4vdWopwffwiHSLDCccFR57ivQG3+nXB5kjdB8EvtoySUaGTP7bxJNIHj/WPxnZUVupW2737eWDglRuR/U/mFoEFLDujS751acSuKPrs+HxNm6KyY5JE//hCddcV+wx4/Fx4Hf+z9YWsHz6NVoGolavnLhEDT+uqqbJVmCHq6SCPe9JxzdA9PX990dY1QwbzMQN+3Ozy6L92P5pZybOsbyxZpDrKidFjlJr704CKPDy4vKWxENwbBaC2K1K9K58iuc3WzAOPojz/cCScTcehAVvrjD2Jq3ZWMjWcxDZEsro5Mt4EGDSn5BOGAxkwCwhH06kTINbnfQcS4eG2Ax6p5eHcElWSNbPKoOVAlsAMSmByosoxqHv7GgWNEypju2WDu/tpBMm+tTg7chv0oC9Fz/8e4tABLe037Td+zGdQXTxkNRJ21G8JMeBNaDVSOP9+glFUyXETcMaaSlRkB74QLhIKjSyLBLUdci6MmgEwlcUvt2UKzWNK4DQNjWviTJkIzrZQFzbbrLFo5uQRB1ZqH6q+C+9ZW416fgH1D0Nr1w0qZIp96funuhrLPHyW9Xn1nndlub18zR5UhPusLUqXf+/rFcwvmEG7rJbr3cQofab2M/7i/ARmKS+SDUXTZppG4kQSaQhdI+1J2m25T6B9Drz5HEUoi4vNVHu0x21UVo3gv050kYMLuA9qQgzyATCc6pOrraQRY397oF1gWQr/Wc25WldSKZoMC2ZLRFMdKhyOQecXtH3+ORxfNbe9pdVVR9cBTqQZN20x2RzfsqjmTt5oV6mDHM1DhwZVb7vO3vfPq08rNZuB/5o5E9BvxCAZcSTzokUvifiA3kf9I29kTdeFeAoa8M8k2Rm7e+JZHGgcWlGqtCB4FVzltwJQhhGAJTdVJ5nCWXsUOYUsGuPLVZGCF5N0Ym7tDXOklRcfEKON42crpwWVFTTy4Xkp4bxiMKBGEzaEqOQmSpY7sh/fzSX3vbTnxtKPWoslM94k8pdHHXhLkJ5sGb9n+XQ/SMKEGBPm1NWjoLJax/k7N21DnKqU1MTPPmxfuoQK70TqbWh0wYNUILeumzAAQJr1HPrtcEg9jDmgQPZQQmmD+JtBuhMqKmq4UoUAshNBzbJvdCSH7bCVLQQLBWvnEG6Uejm+S6w8n8lG+o86287ihWMI4KTqVlXOZysS7EKgPLEP8Obg6bH5e/jQYibU98PYaz+UBZwANcp9ETgQ3i5rj6k9fv/KU24Ga9K9aDOpU4NTZrW9T4NOMqhRj5N6C0noL7AV6gYgnDiO6npfWXocTH1gmAv3GZ4Bfrq65a4JgNAP0PLgtPtANsSLhRclgWm2emnRtBOAqUJqKrwu9HFCsocjNCTIiQIkQVauawrREm82z5moezaP6PuJoFnmjA6oFxzaY519S3ljwKtcMjqHf85PdkPW4EhbKRjhjGBLB9ZyeDcSvy67HQXDSAWFFsusToBnrxYDUaGMLo5p5tViUDMEI0O5cUapvLu/bJd7CQ27WFLEO3ZM24nsRA4G+YDlaTPWwtbHaIckMFtDr6oqyYM51XW9ObTUonHSC9WXGJvRwVouB8Sj1WeG5iCfVhCIv6KngpDJFqle4IMy+pVhxc7hIJxjeJwZmba2t5dli784JJyJoN3ihhNWO26NH9rGF1va6Iekexd5miSlhyIh9JK2aGnhJvuc21XiQyTo35X8z5uHlpnZNQgqukHaOfQiEai+KoybTtLS5N+6VkU5+3+hS8HlL+ij5w0Ln+F3i60m2RV5lQrvmmyczvhPuh62aI80FJaHfZceWL20NnME0MaojezJ+wa/fOx1NlfsBc5fEFIumLTOSIIdzo911ix+c3KcyFNdGudWZVC34ISRgG1T4+bXTAx73Tpjz6a1noY4lfHbkJPpjeKRJgXnS56kx7PnyhwmKvVOPoVgmP/7AHKzzFuSUi5D1EqMeSyh1aNdYt2ilc9ekqdhjwusBsSjq20BGBFEx0S1iW8J/w/850KRi4/jT+VG/LZaM5o/NUgS5cze6dZ9TA5ovNEU6DW1RQOUpoT21didLK0bjbHok4zfnvq6Rnv9n4isGcJ7RGKxCOG4fsITVnKm9kD0cpbCd/Jie6rmieXPaO0e7JOArEDNIsp370SotU/QdCO8I79nrMvCtpPU1F0BKUuTLOyBjpEBwPen3sJECVrSmleeFF4JY+QbzOE/dqzLj2ybZl3OOo5sV2d3ILYefBZRaJJ2quRtLjHC3IHbVrxGBIW6o+81NXQ9Fiw0Rs5bkrIdwN9tfp8Nt0ISCwkGyCHYpX940SCA8lXCMkqcieeXlV9w0HUqFsh73oFmgBUC/PnNv/lmvBJWpbUOUXIGrd4Tv3C028iuqo3DOaJWjceDISQFv6MZGumZJ1+1zzqiKM5IKnPIjlU5xNiGWZ66HWdf4YS09gayfR7pLQlysvPyERSq4kWdP+JEuqsmXL572N79srz+ZTIdCcyZq4mJ0e0Hvy8RZptVPVAlGRvL8VvgMPRU6pM4XWul1e48RWouiWm5SY6aTZ7grwj4YqC5tPdQd1JHmjjV/7e6m4chxuAdQDYCtUvZhzNOpVmw0DC/LFYvt8D4mk5G+XKayomV6p6rpYO9huzYgNeI2lCv1kI1TlCLJU3W/WMknhn+oFrc1HwB+2RKtZ7aKYZO6nNYjN9IfAp+3r57djNVkJSW4M/KZzoXeKPv9ZCdaUa5cxBhRCbppRCSRW/XuELiNc2qAJVQsoD49NBB/Vanhz2HU7UE6ZXKys2+lVKwXH6CPa8E9Ij5mCJlEMMUPya7gOZ576NXqsoQ2VToUctHnUoKvTNCMYtQ6av79No+5CcXb9KrutGju3OKRU9sCLBSkTDwBanUZzBQCVdyJo413N8yDDuU5H0q25QPhWWwTaKQ8in3NpawkiYvoqmwCf5ZL7Qtn+cY6HjTgK2nqCMz3w9aasIzWDizX8yiGvbFeL7J79GFrCv0Yp6Z10vBpSastKa+t/qIotU3HQE+5WQNKnUlHKCp3XkgP+p1kZI5zqotOps1mobaKG+ptfTOgqpmE2omSZ7tWPAowAy6e39ewkINWx4srpvjh5Uw8sF0HLbl7DmOVl77LShra9OUUmIOgo3HPbog65RpeyI5DioUwFu7PeGwuExuhs4QkQTkBKcZNywlzu9hywuIoisq+wKEWWOoRs6xareVmho/SPtLzYiqW0rfM0DhG5kvYk7E1LMm0TyUzPGvl59FPS3LWRhOj6UhSkRKXko/y6C1c8ppCoy14KU9YTODgiyY9M3ggX+hHV2uGUA5KGqJ+QklOPOoiJG6MNlFfdjzehLpEYIkybKVcky9OI8ltChhhr7V9XRsXjxGxHQOwE/ZRIyUa6/FtxZuBGdTz+kgaDvKOB5bidZa8G8bqEukcRuG2m3r5OKvnXfuOp7YqIQe+PKX/nISnIDtEnPX5VBehzbCtIm7tW1hgzWfw+8KYUGHF72JXqjABAsEuiY2l2YuuOuZkBv2nfKltEXNfqq4IBE/0pgNKunO6q/exYjxAxHLG+K55Hd9wH/3rGLqFlBqQGSDhp1ADLmKG2lfIsRC0NgIzrK0QsW0t5YZjkvMzfHdIDo1L/4TyIzW68WWPWPJF/sG5an5nxA90lrnG7DAclAuiUjZDabOKS9+LwDDxiL7LIKS8haGpJBsk3QD/49//52Ti/U/91H/8+/+ixXV/vMj/NT98AvIhLebOjBkSu+Uu9JW026WYC5kaHa+jcWfD5xF9MAWwQaPz2iptTggM+PJaoiCmkbG0exsfCKOQe0j6IicnedCIJqLQpa2u51yxSbmB7Y9lxmd3Aii/Q9XTA9OhxGkHjvn2wCLo/muHEtnPKVb3RmZFS9+NpTaWXG42CCH7HoZXxXLiCVioXCVHvtb9MoLxhKmx47JSedVyUY0/uBdRBBUXmsM/Lw14c+ueh0JKiXOpXVB4UWlAl8+dHLx00sM9/ry4LJbV9skGma/tHpRY1JSRy3O3P42golqziUkyV1QAXOKQ5V+8m9SeW3sf7vglE8rj7BerGTV8xEDN2IcP9g4kTi8/PuzmL4w4WRWisCwNSwIzARCVpjsP02LRaPdA/ADNQvmNvC3syV8LHagR6E/jGevcH68KWs+cxxG2cuR0pu+zYSIlvhR5J78tPos4ic+VTSX8FDJ7TMoRH5tt2Av/mAjVoMINUoOB2FgYE1q7rmdlO5OuSNYzX8uNqnDTFHakSCcjQxUenaCzGF35r24LPq6nhAnTLlhzeSr7leAui45WR9OF05/YdOGImi4cPTjbP42bLpzsb2u6cLh/+vD0yPRdOP0l+y7EDPv/pdsu7J/9W2crhYPDqJXCL8LbjxYI1D6AO0qJXTpkNZNviHAUGiKgPj1ph9D9sGxzhFP38WdFUxFPrxQ0AtvCXRvQBCGKEAdsFrfkynVEOLh///hEOyJkKL8tsMAJyNLTHgUCX+IAoYp6Wrq35ZNisXIjmOoAdepazIOCdpH6+AjAm0uQM5jn06KSyARI+8DmUQUwcnklfUnd7n3f6jSXfa74kuK7U2ktvINaHzwTMJEHfFytK+1ABw3EOePcQKqz3bO4XauMxaJMDcGG65fj1cnOu1MLE+3/K6b9Z1BVJYD0yreUo5lL09YRE+nHILlNTN1CobBD64fIJWr38pNV8DCUzFsCLEtUND4vRYcEcbv4xCCL5Utca8XbEF6wNMGKoKw7BlOaH5opB2Scivc0wKy+xI2jTbgsV0ljOJqNmIcAymBHqFPy5+2h9H6JaLyY6zcKf+FhTysxv2d/g94am9gYs50ylQc/mJ9y0NA90ecg4EbTL8L99959WwbwSELW6D9nTga9VPQ8MqZbZz2ewi5DJi+nfcXLtE5l87sMDMqRRYp+d6A9A6C00YUSvyBfC9VL79++zEyLCZc0pEMvH7f05DvBx5XGnftAv1WBFGyBE9pKLvlmBmmHw+hKW15MDYYyi+roNsrkV+j7anjN5+vZiNUHGTpgtw5EPN0DkncEjnj3RdUkRWAY5KJdH4tg/A2++GjykWY5oZb3u7WnyykYVEQhxyyJVAmf6jvUkfrxWsfEeIGNe//uydYpfPfH8xff/fFre5qZHsrHcYmmvk0ss+25Lb0bnuwDwyA33Pn5yhpkfUe0UnDPHFjZ6A6aXljL0YyFdn/DuYUJI1fG10NIw2uC4ey2dUpjw10rc+KijnSHZ6y/7V0W1ZSin7Kj4Ss7jayBW3Z+ibRKMMMsiGufymD7go9va5W3DgW2+KhHL44eqQDP5BLhBSbrMpRMazQQZO1V0ugoGS602WK5wNsZoE8M/pQTALZtpFrJH1fRK19RFCD6dks1hnOht7RDzzU4kwsvWst9lrRrSFhJr7Ng9dwOnMT/UKZZJBHAnzF86IZqxudX5KZBKo+pCGXOeOWd9hN2JKMqQjrq06rV+jZedil5Zz5Svmaa0m/ZG+/nynckkhTYdLLSuXEhOwrn5Wq9QNCXouFYSKBE6nlWvXgsfQ58eZRpILa9i2jVKp1kHS7m0AYjqGXNx3s3oYIHX0SwXjiHjyv0+VWEP833j0tb5EQv1rKIs56E6icewIP8mbPKPWYgJQxSQCEwb217sSyufmMa3mXn0bLHIl3J7WxmmqiU/hq76z6/2dhm5sb3EWUJYreILAigyUgBL8m5q0Fo0gN/o8MYtnVmYToIurPN7yNHTKGl5ZkyM04gh0X3T+hazg1+oGF7AHWARej2QKlAIddLaUvjLsPMaY4uryLAucWCSK9SxCW98wFoNyHKbGjXzSWUTzh0zz4RzI9zi8Ek0JiqsqHUu8+thbRiw3VZSjuXRnoGzBrjT2k6WuxTBlvwoJk8YtDsIZ/ovpa0IFKD2QCIfRLzxVO1W3UDpFVeKctFIJFom7vDFDIOCDglqycmlryBMqdcsvXuAzcT8RkNfxn5btoTAJ2HdjHsUlstsKB59D3UBGBGyIWyk8xWCB2Te/qNe3S5fQ59SzCjNbK+t9DLNAuGcyQA04D759jwALV968VKSapg0xQfN5vrNkVnyFoQ6GTPl6fE5zmY7ea8bxcGEDYSJ/HcDmEw+Uu4NjCgd5AxZLDJWsl9Y/F2U41Le9nS9qfbH527prHRewYomPJSTfyeaSKqJpdFtqJaenCKNkES39KXNcnN7TJ32qrRiiNSLqUUJeYYc7ifhngn6lsIfI7x7bYh2i103lW98u1gd94Lc3jD3Vjd1Jpdnd+4ax2Va+gB/Amnym7/1PLTK7AjWvN2RWS6vb5ik6eDPNWWq2v2wBTeRhFd2pSoHk2PjJ3/lmHS/WbOKlQByauS2K7Kpsv8sWT8oYPnlW/E+HmvmRxtaG7dCJI5PkhhJL8n/9vJDVRlbxBdBKVsTIBoN989c2L4EIYbq2EBb94nnKW+BwVf3TRWuX3UjGaRMxDWEDfHcyhCfvFwcURGkvHuTFl7g3WTXFY9gNCNXFr5fbHMEZpkeqFEBjCTIqI5YSZQRfGzjWbhCxVt0fsHhLRKPOl+xgHK24DKqncbRoIofPMyS91SWR0RrIz2E/0bok8h6uY/jQY+3pHdcbYZZZP7JpUpSLKHNEZyIIo48sOylw4J7zy7bbZrRFr2m52LUvbItugM+JRKEloiBN7E33kJNrV2sHHZnM7GtUTG48x+K4SWiaVeo8jTMukekO5t/FeuUiTPlmlybirEyX1axn4atoz6bbxK9u3oP6lNa1M9goMSuKQsqMYH2mIsupBspVtIHKdtBGMnqTNDPUYl4mhtS608fO6iLJwrImWDG9JNscMZlt+CAP01RT2CxK7pSIzAo4oKhFtb+JEcryriQtuqG/TbiH2yJNEnsanD62Co3zIn73DvIMOy/de3eD7MtY4WKhhO1HnnwQIzCX8TQl3t7j6ZRcFV3+ScEBEAxbVYAlP4YOIE4+1OupfuH/FUfgTE6rLWeXkD0ZKWlFqprLDMWeSganU7I42S9tSUt8/Ko2Vh6WI0MiGqLSP18nuR7sRb6VDNFyn4HlK3KJGsBCrppHspOKUpw07VdWYEWtrTNreoeOy0GBEBY3BxbpxYWbC4YcvcRkzAbK1tr3LU6dlgHUf6ONCkndqT6LgQRBAP/RKycnnLlaHvqKxd0ljgrBu79wXxBIUwdjo4CimGtJAbza8idTrXte+5AknGZRH1Mhck7Ih+iPSUjDW7jTSCF1bZyIV3xE2LgDR3zk20YsGHuJkTN8Y/8OSKMnp2PEZs1uFGN+XSZLs6B2hH9vSJXDwzFAEP411JPiz3tSR+wKlSMP06OoMoW3pyIT1zQTFu2+aRMuhATpNwH5WgODLu16M3L7YfmOJTPa9nt0YRFEEHGuSthoL8F+Z1j6jVS+H03WL1m/BGJlHEjPtwm7v0T8qpqmQ40/KqGN9Gj9RYO70GgN9EhqXA3cYK6VWUeHXW5ViMLCpoiR4ZTemtUhVj067r+kNEGBEH2gKWElmr6a16wJnbllGI/uSJAajHh3luJRlFBL2SZ9WI6Nb4XvTE66qV4GOzJtQHFzs8UKtG7KOVGZ9+VqHthT1x1mVm3jWGSXxybj+HoBnEHPEGv0FcufmpBw42BoqzuSE8bLGNGDA4SWZG5DwuDx/AkHDYAtIRTaxpN9tYwGJ0sueWIRnS7HxZXV2vohSciP3t2jGTXM472uaiFNxZJFhLNuDd8c5JOuc6NGN1N6a8qhlSY7IJknJX2SoIGMAXtr5VfBXbERQJc8LZN6VUOKO3hjg1QubuOFryfCympOmXMfVtowhkzenu8mKhGE9E9xpJXdanSgEDHb9YTG9tjIoP8i5DDHcYgpr7EcYUmVbJE3iRV0xvqG+ix3rohzukX0b+peIfz1aCOn9o/xSQ6ZuRDkktMSsPkxgM7ks4JKt6BbOTSFScAVp93zn7DreDqIsCIZM/1FbRiisfdWCqlyFIqhvxtGiu0b4sv31mGJNuL/zX/Zt6gWVvbZegSIhn2ogeLfbwsW2WVUXYIEAbgKPPL13bDyQSkVX07mabjL2odZARJJk6Dvi+L2wNff3+Rbddha6Lc7m4DHrh/Q/17OJ56TCPGClRcatpXgYpT0nCuNFAYIi4BvoDo7CiMK8DWsD1kuN7Nu4KIRG77RveB+dA9YnxSkSEk7Bb3gatZUvm6Yd50HIU791+KLzlEKqcpR6LR2U3TUMmxpMlaKnoAYkQMjDtmknzmFpLn547O+nJ+UZ6o8apYrUufLsY/9ko4qtRegSpb938P4FecEpqNUUYPWYQZzN2+pBaf0ksWRwUgXhGLg9FxsitD+nUTOhaHmvU5CUikJ0bn/9CO4ya+5IJ6QELnwCFI6akvPmRe2qkBwe8miM7oOcOrfDEP1H8CItWT+Lu6XEU7wVpHGJmn0RygfVRYJ7OtPxqr5E7c7spuHwsHQdLbX7u3g1sltqkA87GuP+sxnfVOvqnf3r++u2ri6eP3j36p39q5fFj0yQs4PbLRy3XSk2gkE3NRV7fB1eX035/OCdhBZZaJUlcraiuZNJxFrtTsuWCVPp8fKttFGYjajfoxl5dAJ6r/hYr7BnsUm6FWjX58HcI6stwTS5tw/sEVPu8HK7qofvPQP89I/4nOkj0D/njBj9ue5YIoQYucJZomoVGJ6CPmlnc1cxSBKMpumAZTB779nnExmTIVKuxStoeCT+h4WOSWBF2IRPokycyqxA1hBn4S8wjgep+7pCXlTQFTpDMjbeuvfHOuNBlOa4WVVeWZQOlHleKHmW0zP5eJhRm/DjN8SkmRhgZcvlAFRoWH8A1SLYUF0dL/94xoQ5r0yS/NUwXLg1AXDbqiEWF0m5HZTAhxJcqrZ7MT6Ud46UwDituABckaBvr5XibN6F00jMoJ8/ZyCFx489hx3HrZMg1gQCx8HNhNpOGIU9g5f2EtiZqhw9jlg8hsQqFUpqBVWN5dBvoRf2yvXhKwdzL6tNGy5/ZmuieAMaHPW85wR05rnCet2Cw4iYlMBUlA3FVm/Zhij3fEAyQs4pKsdaQCI5uCJ200sR+WqyeGKa+LCZVHdtPKmUCQqJLFnIliNfTvJ6LAt4StH4LV0cfyMUkc8ewVZZINcwjKmN1hyI6U/nwI0O2Q05Te8YTwCWJiEa7PhAyXo10MYubyQ42nrP3UkJjbQAVSfn16jptFjHnJCekMQAPvCSJ0+umgGQE6oTimbaMkHbuVqbHrxHm52fE/ebC/ZIAWeFlL00hM0bm2qtDzgZaB7QBwGBtXByRyHzuwz1FKWigxRHMgmwyccVsoZePDJpXT+IQJrhWGH0Q7KtesLZgYdnZbJ+BSg5V0gtxSSUHKN3CZ0ybPMgEHTfXleTL27gOn1UBwL988S2gBLetQxRaEASYpp2EutRSNHm4LJu3NVtL0xLsmSFogCThGELusNyVVhimxS5LQZ/6WMwoqZnxTS+TC7fh5Rl31KzKhZYVME6d0xqsf7N3vOuR9g7nreodARg8qski5i7lfJIxaTh8hByjuKLdo4Sec2o5YW4BOeVBHKAXtMWSW1Y4Lj5kdRI9WxeiUchCjd7y9fKDLwnnRhObVE08VPw2mHGEAWu1acduIG4XAA1nvfGUGhitF0F3Ms+6fpabmjSl0cbjghomjErf3QIWC7riDLgfGmjeyB1nXo5C6U0an6imyBG7WAI3oXCze+u6mAyUk3/S7nkiDTSdhrtGYx6l1yXnlww902/jc5MJbZc9k03gfAzbpZpUmEfu2Ra88YYJeDN4MqHsVsnOGfPmePxvyODKj1AsC+eOWGvejMjDxdlMGoqJuYDbpJdW4ye2fMHgwm/3zbYQRlSZF7qoXIaCl/l6BpuN7UBtDiewt6TU03ZX6xS5+ZEloqTFfzCkjc/O7W+rCRdiL0CwYUGRs8MZUBvN1kBD2sPS2/jFlGTYol4Qiz5HzoUdFRsZrl/nfmG9TOYuiv8mMQoS29JbQWkaQi1ezRHZDpO9hYWG0GKZyvI2q29zONGIZcsftowc91yH+lo8lJQq7v5oY1JkRvF1c0uYKrR4FQMM6KTv6iZxR1APLA/BX256kryfb5yjorTlIxB37GknhCprUzKETa9lXHzo2eIFPNdo5J244Kh9C8KjhIAq8HRCxURz6qAjOmHWoZ9MR3R0P6YjOn64jY7o4OHDw1PDRiQz+GXYiDYR3Py9chOd7J9G3ET/YND5/xWDDliiiJ4KpM9Dhl/l2aGOAzvUI/lYRA/VfkqeFsrJgLdkpPKnPNwgSXOFmoDASc2vKji1LD/Ug2NQbSEK82AT6uCyWKlJ0IuaEgmiDdGT0pOYm9ZENnEsZN30GviAeKHRR5a4OiHTG+FbTNDowQaYwc80XSntJjtBZu0bKvv67vzMfvK8YPv7TnHO0Vk74wEVL5Ap7r590fTeUiPsMj+2jsxT/bJ/U32ohuQ07Pfpkx0GtX1rCYFpyzpxuGe+9R3mfU1gYeINFACvIifumG/elXfQTqCGatB+hR7q32SH+RlTRkC9uL0CTNa8eeuBnaLh5Xr84fa7N0QWOUV8Q2opmrgVRBQQ0O7CtBTammaKXpBCaMWA509MWcUwSk6qoWiMUunaV60Ld9K1FMuymETrQfomeXnOlPPR5qZ18TmzTUJeia1D2wQ1hREnbofFgrSVZ3+qR40gxK+WxuoMi/P+w5KwDsU8S1zS+nifZGwfA/aZ5K7fOoxy9wAL/5rtaOdV3QzcRkjMjAtYd3mWkv5HQmWKTsn6pQtnW/Xj/g/eYfYV3Cag2JeW6tF3LtFPjpPjBjfS5XxJU4tYQDCS2neKk2UQu6K98ha8KYCRKLeWhh/7r25BwLqeu0Vb+CCBzJps8riHRSAHCW2TMg0Q8trdJocmJTV0XBiAJ14+fj8OrDkhQxQAZA1khN39LuIOrrpqQZbk1dYLbpjNnxLo4WNW+fhcSHG10n1mkEk9RlMnvhld6Fbf+wBDp8cRdsgw4kfJvmeLGGQnyUAjvH12/g64b6qdqBJzzxBrauxoJsEUd1rW41L2W1m/LGlmdhpcGUNZVcY7Bb0quD7RuCSPi0URd4aMNGWr70usdtSPtMbOUjG1SBzKcfJJVi5HDlFrjmkjqQszJLvu2/g4jC5SKz7dADNDeYWPHOIjiTi3ZMOVFkS7k0ABGLIkt4bCspv+yFazsD7a+iA2guVa2x4eAnvqy5+wG30VBPNQB6GNptuMb61TQhopRLq8vuR6AFVhdGCszM/tT8te7TjRW9++w8AAxCe0i2YThpMxODSc3zVKZXudCQvBC7HmAwqFw0bJZsZU4gRgrnhij2zLoI3BMNMkOZWHMaIht77tBro57eVvJVFAejtRQKCNpLjkPrJFS73xbnLqjqOZ83JFIf4hJlaYgFAv76VigASQ+sa+bWYF+ZSFcHqg06UOFtnjlh62V8WflJ1zWV4WY6FAQLdw57/Nqu/b8OuQpeufrypnefau3aaX7kZxPhmbKy6SPQikzrelkvxFgozxfHywOfd6bxDJoGVQvctWJyAp2gx4pR0jEdrl8548ybjLiv3V3mh7vRdcUjmgLA1Y5hoJxGkALjzV1Dzyc0claWJpKDwve04E6Wd5yEddkU6rgLikQNtwidDiARgBNp22r8MYpxKwPI3mEgZySm/H+I7JpN3kevtM1EL1j1fkK49QzVkJ+cIcWCG+k8Slv6FimHeFvZUYS0VxctOXZbwOYTrCK+0GQy/bISPh+TGpsRBydblhmlq8IRLb1FS6lqTXTTWdyliKRYFIMl/OD/OqZcQxyqF7mdMdT7eVwiT8wjD98sNK8i7TjM1/JFW3KSq7Y3vkY+2vm73JiJ3TzqhMpFiO9497VkWL7lDnOxZ8or26VHWf8zhayR7m25eInpjTysmAh6GjDGcX1biZAm2cf6lMpcNfXfHeIij0MGUjraRUUPJjEvH7+r2a/ElBrRZe50+CrT5vYGZjxqiEzMzvJFPnz4Bs+qohuaaQsQ8epDOXnFNnyr5jCSXAqvwZ2cFadYnzpMol+1KdVkI73kXn0VniV1elD0aE7F90d/3HbdwoMmU3UZp7CpXLKZFLYhH++PqR84WSbq9q6dqrk7sS8aP+2X2V2rvWjcJV1UWihollFLd4IgHbrlRi8ugA3xf2imTCRZuj0c59qwHKXm+of9piFW519xpPCZNxRLqjBIaEvO3dvkWKKfCXE0AprWyiC/z1+xe558WEnnwif9csink3Am1E5dE2G8h1OqRxIAv3ehQhok9hYGgHH68Wg6XlOaiiT4F9HD2ktcCk8q9w3HqF9yFtHjwbT+A21VLUWAtMQ5M3yqUbHy1vU8cNP80LFb3+E3Krpn0jQZX31wf1F0OnCbp6A/GLHW3cmwxqT9GBRXJLmZXC206+GzVDfefD0AaEw/1bFvxwm6/jme7qOJATYgq64dHKKr7tEyO+fe7ZQAawhRmrH41iWXNnHjkpmmvLE6Fl2sru3NzORu7CYJ+k2ZnGXKqkSX3kNXIQR0qR7VnihU1vOtiKy1a7V17UDnx5u7vAzGRMyXKQ/s+kBPj56fbnT1drD2O4HDhhilUr1kgLfe12Z5osdP7bbgvd+lRzG8WqJALFgITc1UrCNqL0puXHcho/hjmzjFGYvajjglm3ksjb2NdXRJyrL55unBJ92yRTBP1qmwo2QkmRW/X2zcGNZl34Zf+SHOubkhBgZ85M3f/vfUOE4svrwFDgo3Eaddk1zpdc7d1msZEtGVHLiIiAjBEn9anYQnpaMkYpKlGI4MUaWPx5pqZ3Mp+szOvun2fkwjccJ/6z4UTaT/i1slv2sw2aeomeiKokSU/4SrcYHrkT9ICJ14XONJ6EiB3vwndN4kxS8kz4rCxOqWupp0E0UZOuLEnx8x7HdsKg7PVJl0ieS7VJ3zkyH6urOBfx80zBXMrWeWudeDqWX0gPaS85sGsLkGhptHuTKt4adOSVCeJKEnCa/dyC1LpPSC2AHT4bq3WwP9w/6B0cne0/ODtIsFonB1uxWgcP7luslp/DL4PWyuFN/l5RWgcnDyOU1n9GGAtDidyr39T1WJK0Q3CUZfFEhycBT2TTut/yN2JoUf6pnW3nHnGkFqQrgF8N9asWO2ZHpSXAyFlY0cOjk2OFFd3fO9jM6jqpmjH6+GovyEvZBe3MLXk0oY5WM387bi31k+NQgjxP/adQK9paXOaS3NBA4r7veNo+cdzGtRdouUe3WlMhfUVChfikdEJtXAgzm53H0d5pF8CXZMMNSk+6O7+aBxv6L6Q6Vtf1pBmIXYM8PPFjovEMV1REULnPwK/rfl0REcjS27UhkKGQ9eyCtnvGZlTAn9fFfIV3nS/IQVRuWPO6GsgS0gZ6L97TwMOyPTX6sVhWCHv6M9PmLy8nO40RveSDrkPTohm4WXwcFpMJVVeN3U4M1S71wcf8bTDJ0IiAblSskIGtlTzOv9gGbGVrUhEdjfdmPTiKnV0+BDFzGPehCcc7uzitbFuID9ibkVSxc8iMU2q9VXE16HGS1rn3e3HBcGcoCL4TpFnD7aZpKw/3TnuhCXZHh8P3YK7PIkPY9KykICaYB9lXb4WxO0vkRnSTNoTNz8kbRWaz90a24tyZYJqlzPz5DVHx88TdgUuTM+2cY7of5+uRVy8NPyJ6wrO5+9Y4s5G8zpJKR2tijVXpzH7/xqgEZ3gj9lk0PmMplDbdeODoBP+xplTe+bPXadSODg9aJtH5aZDInJjA925Ppwc9KaZO2LnV/r58sfpvcja3PydxRt3GsD6Mj8rngJ/pMf/qTRtTY6KimHrEy51Bjq2uV1uY8tT4J8HkLI2hbNKQWyGSpwxdMmOC24KSFlzAu2pTCXcOUODxJFmGRIhjwBJ+AO0Z5k9JTGD0OaCxxOtpH03TQCj08S4nbW4yy2KV72PTCe6i6XxT3pz14pvmdgvctzStcUSWIRqebTFztvCQmG5BnuVsDveU1fV6Nmo4YslCU6Pfe707veO9k7393m97d80Tffj5rPeq+FB2XGDBILK/KPlBChgOyZPeyz/uaU11kQo0Qvqwrhf+qJrlrFUeI5x9u7pmo63w3/bUWg23iAthgUeJ3bhxDhvG12g0EQiliZh4JogdKDZIFOxOo7cZUfJTSZ7NdbD6+qMSuEp3t7/Q3qlZxLgFufnLcNZ7PW+c+HInd3IFE52hmBAWXJJXEm4RusIYe/Hiu9kuzD3vRG758/p6rqFgNBUANwLZDiRFJ5nD5lszRJ5CNUOOa5UYB63b8doTxAvOqKIuSnFvFPe/4zUrGmcf2xnIQU/Sovrsc1vhLYuDqCELZ9npQY+C3GBWpVSz7n9i/PvEBppIYWWrEKHP2VFeiLBfF5ghOqZjR/PoDrV9WhrrrPfdk2/j9/flyWsxgep5sP1MxyfzjJz9VWdMUyf6nr+Qfms/eS4z2xwRLm3mSU+mYG+B3eq2xTxYCVx0AGpCckPNK+ulZDEkIxdKWzPPf8vlS77HHSorQYbv++FJJJ7tdvpwcCQyD3weohlNLoYvGwAF8bgsiGP4MfOq5p3YrF6MhulNuMdp694YNv5ySQNN6pLFDrBo4/dvXzLPCuKknXAmp1qk2lSKzEJ7icbSQn33xJ//YMW4u7QQvsoig8066z1e1h+QJvGcbYYsKHYq3O48OT/PPeR5Cln0CfDixrRAq7UtNPeJUCc490S+CYJwyRGbP3Huy/7eEZT1n3yPv5FTqyAb3fjwN4ZcjyfUVN+LGOcH/zY7J6rfdXqTGmPz829N3Z9uSe6bPkb15lHvNZTX41vFNo5u5UBXZLbM50rTF3sQJDdHcoH+D3l4S6iqrGRrxn+ZFmUyXjrbxliL9hB1dTe9H7EQ2TQrA8V/565tPb/66maMYNqFO+oXqnYu6Or+7p58QgIDQQQkqcTcDps3wFR+m0/5dRn4re8LqWpEfavbmNm/TVF2liH+6JhcGN3uJbpRdCF0s49CNIX7WM3aRfmayIaU6UIptDJ2dPfk+hN+a4YWAPI0v3M5VyXsmj8u//Hv/28jD9s+eHgZE55RgIS8WB5oIYFBKX6RqGA619H6dlgvh4zuyMx10zx1BD4K3z25EBf/7IzW9yK0vBsIIr9qbOTMyVn3ZXEK+FRlcXz5SF1iQP7hXNLrS+nJm1wAVdXiaSWhVvvYJ51Bzsd1DXH4m96jBUItAFu+YU3FUJFNEafTjnDcmbYqlr6EED5E+uGjj4hqRZ0dCBFC5yBtjhS9UPQmZ8ZTOXZrnZvf/VRAaY3n4qAvmT35RXPQ9/Jfbt0T5ZQXrRQ5HKJZS2nO3vqOWKDdSbtTjVnJTyc5617DYxtda9OJUcAh4uUItyundQlv0+RlqfpnSQBAJxGfHzkW79gZHvYe3ZSI3+oKvKDFWt52xW42HUeGHLG0ZJ57OgY6O8Um0d1KHm5XtYWMwzu84woqgR6nC6AK+HDv4LcbDCwOS2q31+DDmd3IzeioO1gRxSfdO1+ttZgsHyUydYqZPuH3ZAGv5VrXsVOER2Q3hMGU3ob09bkc+a6JGoQzTKH9QN3R4iqcmqmT857Pj06le8ZoDcBQWLjYb9sK5e71rBtjAjt8KSSVkppfBIq7dt6H71QWed5Sl1VdynnzXuKT4CR7bWHHf+vpFUx+kAY55+unN2Lhbdr2NdYRsgO88Jwy9ovWPH3hbYwo46fMFbUaIYHSmgdo2YYbTlP5qRyvlaFWsN92Pl+YtOkF1/9fUBjjgiJCF0Sg9QVO5C88A+zBhSzIRbOezYrlbedMXhDX7IzTcBxZqOYfgSm+9fQRxkGPjw6QopOJ12Fiy8QJNyVM24LsjwMRXgxoKy7ytPV3ooqGq2LUCLGydnOjpsZUQ9S6lW+lg24aidTnu2fxrc8OYvyDRsfigfhl09m2cm27ib+6Y3hxYoQXRgehW+3+2hqCnQ73EHcIyKirQATykQPQBI0OBRuBLgx1t6Dma24l4cweq1SU+wtGnNL02KYVqDttk7O2DrsqnLVQnlL9HAVE+Ay2S+B20GGxQ3Oyd/Lbz39CMKdOcobkW4vae2pk3jt3asBvUMxCHHBWfDBUtMZeWc+VcS1bGvEwugsm4vucI0vmSd5SIL9qVhbzlb0H1dzgtzuiyD/hmSTWuoLSfKwFW4O6QSZbzQXhuvIAEjHzMfGKadfSgoBozR4YU/LEWL0d4yE1BMMXyEdMmjQnc/bNh3E0ndIGIuk4Wq9xKoT8c2F6e16ceJaPfCEtEtogE75oUel3C7RiAzS/fyOeGsmENfWY5Rgb99ilUEJ0hToyRBz4Fq6Ie4E1ImNsK+g5shYXxfgD2br39BcvpIdLW+x+/sCIp/3V436eyJAYSgcI8JRAgARN+ql8bQeEpTo8SDCA+1sxgKdHJycGA6hT+IUggF24sL9XHOAh6K3+DoFnDB48Ev493dA8cPAwAAfjdgoparD9uCxi8JgQgxMyb29h4Yzr6VQI8U2RFpPW5dCBh0fEa8i0jhmuLE/qWPRGHLCn4kgydSVOdYW4I70ePLeDEC6Jv6/EldxMtFeNBUQesI2Woq+TZE9JREOkTinKTbQMEk6xdS1L4KAdW9JgiOlODBxBttbtc1BGm8BFB21U1WfFllEklVkg/jgHGi03L2pVOQnwRg6LIMGYNjEzwUxhcCdSC2tF1KDHmefsAvJwBuKsWs+YrvdtecWUKeBvcv5K5jCQsv4Gyvqs13s/1yqgyv3r0xnn6i+cfCaHNvPtHeP3Jxak4zwSFqZubS+cmoHThF865wy/aMVsD4PBaxaks0R2p30/CNHf7eg5vy8HEfuxUo1lJtcudnSz40tGXFF4cv+dOzMfen+s171XDH/sM6+AT3LEYfBX1ZwQcusrcAa0cz4HmWqx5Mo7YYF3eUYIRxyS52g0CsmtsXp3lJdXpZeGsgoVM5b7mP2PP0gOzPCsZabUqg9/0nnsHwzAxEbAXIIoLA0+0W/CI+VOzgzF9+yxro9vCLcpz5L2ANfqmydyQrlglvZpSOwdyrucGZ3dSkzSHzP3W0Y0NjFDPq+s7VbAwtpd2WLS+13Ru3ZS9Mv+vf+x+PLo9P7p8WH/K1mjk9h9+d29wm0EPRPAtGrOueKKi+qxaWhLxwjWvV//6te/eke/1CxIMW182Xwj/Mq2FFcJKpLuehqn+B05ZV/927+Rkr0gVNwHt0gXskh/+cvv7uHvCSdQkYFc0j0w69vj3rkLw7CXJ6vS8+H5sPFFp92Lhfv1Z2EKbbxSiA3iLd4nymbe5PYRplWOqZlD8TW9tPXeAdyVB7IQOxeGciw1Pt+tHI78d4/1vLuv6bHwf2RRoAlfGBtM4Sft+rgxOoU3GuBH9HuH5ntJ6bJ0ZIgxQ9rv0GpJaVHk58IX8zmaTsg8s3zTsJ4+0395MNyn/+85M94ZYfsPPpdv+sHDk4ehhsnP4BdyX3IG6t+v6/Igcl3+zsziQKTM52w4KxYdRMrGf3mFD7VplKNnZJ2WoxP3uWdFU01vQyfP+a1vapPogq/rmrIeNJ5TA7+bVB81t8o9CvC/w5tiSRiWPsq05U/9r8x3uVTsewJ74UcCRyHSY5WWk8QXlbtaD46ODw7+T8otD8WlckedmNLWV9fuv9R2KLzmkMUmEfI462P1Zf9iNHVqoU8S48v+vK6JkY3K9eFgLMtl/yt5qCdtMK9MilHsd6dXlr2bciRcw8Kl5XuYgOurGK+CTUCzcVvrluirbC3Yw9MHwdtrJTTVm0EU9tbteTXunaPdEwUbR0tqzYdKB5bD7p9U7JQT+DFY0bheXSyOGLJiinGNnU7WiynEspBXmhIQAz8LXOTSc6SLHYdG72BvmhXLD5T0mrAhQdSaTTQ8DOZFpolemL3CE3Gk+T3oIhdMqbBEmqCYMwFb+GwRtUP8SY/uMcOfcsG9IhTM08cUXn11e/4vL91uUb7nhGpZup6vHYKk9Do3nu/JoM1yGAMvH/VdI2bFfM1B+noCFZ3dhg5O7rjFamgFtvbkNXQhR3hvJoies+EXo0iNh919xp+ek8zOfqd1RP29CMZ2tjlVTJXCh0pCCRO5TtI9LT6qsnPplTPzwyjnxHdJhgp4ApsZIrPhXBKwZ7IuDQKWryawttkXbd0Gtbluron1CUm0Ephopcmhh9OApvHk5r6Ssm/+ast58YwSpCyJoY4OEFWmeN5FSvKE4zemBKpkMALxM7eR3Fobo7pwwVH8VMwwbR0hsIlMxr1O4X3DGjz+ksJwV0BvGrcfWtJLAjL5+3fv3mQAqik1HggDGMDk7lZYE+YYMVQGOom+IWwH8OL8/GWr+pkvoqdLAAff9IYSPP1v6t4LdKx6TsmMfjZa6jwROooV027OyFYRHJizjAj4XfDTGanqzsKbb75WgQl7ZeN7M6AMpPlu66mYzxl0Cnn1joX3N06oDSpTnjMtO58QGFnufL/+hvkS+FnCHR2N/zTYO1Pn6g/Xc+azpupPyh7Gn/7WyUqi/8FdMi5M5EhKKRo2JrBr2sf88xwkHPTGZ+E+NsJEJJ09YXPQ4rpDRpfvILAxEr+qVKwC2CawNVzRvd7v6xvysQZua534mOrNWta10HWz4w/WUIT+5jKiesp4jhSTQWMP+ON+fOaMhQlGvnhWVnREAqc10358joB4K/ys7uv9t+iW1g8oTcgFlQhzZ58te++zYroTIZwMDYvlVbFIALZeSp1/+3UGiKbCm9vsshHp5LE0KQWRONQcffYFHYq5kyzPPrkT6cy73sFBx2DSy5fvkhhsWiiAfKzoBWG2wuh8LEmpkKorCcJJql+IUzZzLPe6rroykWaEjloBd/juibRtWMjdzcpFb4WwqKVPbobrYnR690miGEQhQooRtMrpghsAZ7lrtcw3K6yV6zxrc3SU8UYqZ1m6IzwPZDbrFeoZJaxGLXvXDZiUKdIFNwV/d9uWqJScbWAiSZw0DZ2C1QUaFYJ/S19vy/MUhSZ5NJ4JsRnMYzuDmeOuKto0gHIzz6XKU61IXlDdVwIC9fZdMUEFVLNaluUKkJjNFhHXzok5kFD8WEMTOsjvqzYvpI8nNSpbjTJ/6d6/OGND4D/+/X++d+JydusH+I9//1+A7zhD/0Pp5KJeRTqaZK9H9WcCjM7ou/cvsKl4x4qb/voXGlLV8rwsedcA2eMWkdG+9R9R7ZF+SQmoc6mD7f0HvK0Rjjavvp0WrjEVRRYfi2paBAYtM8PMmyb3lTHe/r2Zc4m6WEhL182uWUqfMUOWwIa0GcTbEfJQSSi8GokkEVopY/t2GoiS9+WOP+UngeDpnPF0jhukFvkjwneNuM8Y2xB0EkheD6yS4IDOSGv5wwOzB/oDdSclM0lhadFrMWQINXRDCjoVTqGX+XNvdMOZkqC7Xzs3gdbmyfm5EqVmj1nLCwqszCGGQjNQjolFsQyN6U3YxX3mLCJqX9hqd2NpncX9tMfLejp1+0MxFKdw+gNSN0upM3ZL2qcnfV9TKwuKOsND6DtZMeba0XI1jpbllWh0HUNEEYfc5kmGkT/M3S/xV/+137979VIL21OJx9SXTmaQ28Vk3vO2hlNn25yrmOgTtNrRswMPrVJeipxiBu6OA/V8TUZtvDuJgVEFdGp8CHI57lCqZ5GGjHYErcd+YuZxpoXOCJ1pbBAKX0nEKwc9xM0dLZC+CaXxbEoc0texA3ezD49jT169cpTod0QVste7E2hDQOJJcqaarWdq2vi+bRIlvHXO092NQiOSN176gQTupbtlnHp7fXnp1sf3EkhLeLc4YSfGSNLdDoVe0leWmxvNhJpTc2Gp3s9e7514zPNZFHo5tVl8kIORyjao4bbG7/ac1NCy+kjtjTkEkgvXnHQ2a9s0K0LQuiWkxY00XGrtaGnVpPStLPAofHHhqVZ2Sde3UXfnbAe1d1g+ao21co7W0pE0gyUJhww1ulrkLJ1J3JfEJmw2GYX+JHKb6jsImg4kbPybUE1OdnJz1y7WbniC+Mq7+967091n/m7mmUaEmDbNlJIDaoYjzLDESRiM+fctSiV52YWYz4dunYKHBlFjcLVaTkW+XKHtlJzVShzf0J/aNkN06qRmoFe1WncG+pyhTqE8s/2F6fnoFeOw96pySqypL1dGZ+Z1dZHTHmhn33jHZEQikT5E2ZguvnmNr7RFNF1bkh5w3hBvTDSTc+TeeVZXBJ3arON+oKCS4oMyTFUUC6sGqYkWz1ikYBKjwccvtPZAq7LZCRyI8oPlmGX/aRKN4aMOxvRRewqgWCG3YPa2aUXHBaYFdZfPcvCkup3N1RhwcM4FIpzeZwkk4Tky/snemxFx0npexfbEk8hVcnZlHB0n2o/4aHpSkCiUWgWicSBMB6JXKoZbU+UhhZ+Sl8PbhO7x2rEi1CbG5Rlvy2n50VntTSXzjYQo/SddOVJrTl01qAYj3U/DOP/see3sMkm3kHPmoXSX+gcwHRGMx3j/nm4XPQqiU2uBTRlyZJF1dGtYiaWHkDr4lFMQ6l7NqXWk3wYDDDN+QYarWgg0uKe5R5hy9JIG541WTaqxb1TFkYAJTT6Qy0NZGIQUyfTGTX1WdMW2MjL8unJvPKcC3RUB7BZw2JYTH022FS+Zd8mBvbHwSEqq5xaal9GpD2y5kAFSA7hhEISjyk8LIlKYC8HluBWii8Idl1HgpZfeeKgnJlhk6WlanNk4txNaDFDziLIXgNM7UXAWSr6doCTED2vqdRWo2TW7XiiDyqpeDJypC9QT+3TtRawvOc/LZFoesXYHAds1Ge93vSh0n7Xp91yQDbXdEqoXcIIolzL7+bZtFTEMoXm810hCGmjSKqkS4afc1Lby5Q41aVIAA7fkkl9IBOju5on5gIa/8SCZlKgW3flp3bDSEyFxXly66WdlwHYWfM41pYKA7Apu2jnF1kYODIdOlIIlCTlId9Uk9NRPTgvu/SKtlTYPOF84G3F5eesNJZbzxRR4nZVw4tdS3I/E1JT2UdPb7lA/Keam4MgHMukyRfJcJHM2kmma1iB6hQWi2lQ3hem04g5W5JrPwInA3VhyiedbZ572AH2QnAqERVbLooWFnCC3wwONoNFRogjAkMASSi/KfKCo19VKSgkmZJ6d7rIxC6QZgpodDQtivYl3jvaO9vc+3c2dsQ4to/H+q7L2B1nd86Gm1NBAl9a1M9Z9R5K87nLfoKftegreCKfFJaTnu8HzFT0/f5lcsDCf1IIZUvaXz5H8hmasukmYMTpdrK5RmBUyeGz0fu4971AwZYiM3uSuB1A6G2la+sWqmjRKtfnhP/4A10F16kKbABEmauF399pmE5vckwNBkjmfJtSM+6q9+LS9cl7ASmiQDrxWisfJxOjgb5bNEMfgXAjlBu4G0337TU+iVi+ebgNYf46bd7iHbouf4R5quOWIgMXp9+gl7KVjV1VyrM+F00sJreOrr4Ez3OgRk2fl3vQwH9xoAk6ujmp9cpIeGs7zI5FIkRaalCUoPtYVqBT/JC0+nFqswBrlvEaBClP2mX9inTmwieWmy5bCdChr7JZiWd7QsaEm6NfVvMi+6IEvz/RwdcaTR3/hf39XTsfoIV5HNkTP/X3Qe/TPj3qPl2tnJEwbD7WmDIgw5Sp0OzFABhJ1QtJD0esD9skMepu3tBGosI357lkEegSzleQnxTB1xGjBBiHRreFTdtagumAAMfHtXidg9/inFBzuP+ztPzg7Oj47PvncgsOjk9P7J0cRYvf4F+45kIAz/0sDdg8EnEqdwPzPmdLS/eHIbehfOvsT7B9F4N6/JQoSSNtDuxHuNaflkGnLl1trBl/h41q8k6BvNz03i8M9PLnv+w2Q3Yt6YZVT9E9+SiClkiaFrU5yA4n5Dmyrtqj2EC3b4tlLHX+1Yk4EH/YLrempTpNwhasbghaGCBsbNyjIoPCY3i9w2yIaSY+RubcZgV/JH17yXubLIh8cHAeg7Gkn1iQqHRCeZB444CaKXmeQVKJPHLEgu3lWSZM052LWgLrZZnVITWYBlV00yt01I6zc2bVK9gWEzvNC+g7rUbDv0G6kl51VSqZ8fjsfXzstjjSkAFtL30uonI1KLKua2F4jop+ffAoKwbjDsABbjFBc0siDgMsz+uQXga2WPbo6wwadBStHYQqJJyD5AiSaaHVm1pFSGnQuApOX78a9GzI5O1RtMsMeBqmeKBpY8OnbDXVrT/FYYkxUVUlNMKurtZRfelaGGWU4uMuQz5tlcbAK4/Kmvm+H15ozU6I42dI978zCeEYdqr9AXNvZGolNrSEiOdx62zNJiah2F8mtclaHyCMZYSJMMt9OU2R8W/CEJEvcCafrtvg9l0NcgpxxV+S0OQN0WnpzeqHkF4GJVoQTrO7MY/ilgTtorcqUZBReTB4vzxKd2OGdAUTMoGcfBcx9b1NddM7jQP9D9+xXh69iSZTBfkW8iHaCacN278hplCNbFP0gv3dZct6UlTch3xXfQmpQPfcZaHszDuGZ56yjFIY6JjgkGp2nyJoi1kpJtdInpdIo+9A/nEfExYKXni2clHUbz5qWCxcE0xJ6h3HmjDc0SkvxAOAK+Za8IwpQ2c9pf7aF9HUrht87L2T4fw16+8OHg9717cJNhW38pF1ZboiX9ZhQlRJTqVo+fTwPp1xlKnJFOeXFXpx2MZiHhf2+WuCh2dPQBqKGrumxXh3VnxT71zh5SGnQjiC4zK6clqbYFj1xb+FYenmKezwgS4rTvpzIUnuKG6xvHoOegMfZp7gHVIw1cksxdybOrTHsNtD423U5NQ5oBwmlJa6yVaiN2+qSuausUv8cOiQ7k+NoJkfRT4fRT+IoI5IWLHgCUFsUafff+S3VgUAKFmYWZsGoK62EPd6zwUL+SmOwKzw5E7l5HyhPwycOrIOfe8hRXFR7Lp4yQxk3lrl2u82nn+82Hw0PT6nO9dD9//7n1rneP3p4cBx5zae/nNe82an6L+0/b+rZd+wLXv9zOTzsQB+FPSkmHykUPRmy95r3oI+CB/1IPk9gfXw+dqE3PTnvQz90K4VomfLwsz9NCcKsT/1Ra058v2NkN5mlSMmff/0r0uxgRCo9IXUQvP/66qU8mR3rxXq5qDk6F0i/wpgc6KSngiy5UrO2vhFkjKYgZZGGjEQXAibyy8cl7RfFTz8VaOyzCHlLcml+/SsSh5SFuZa4KtfASQjOw8azzjZ167RhQGvrc71EoAiIjkIqn45IPu1/pnS6P9w/GB4e99ypcbt/mAT16B5slk7H90+ODg6MeNr/BYXT5uP69yqdjuKGopsPCckLN4AImqHyiQ25q/n2/p5qcb+qhCM6FRkbH56vfz8+EJmxXkW98hgASHATMIrwU6X/unAk0h+0rgwwaaYEBoviQD0zMqaU+EzmvweyHpjaVIzAGAMZVvAMDGUouJIn4u8mnfupB1d9Oa0EXE9fAWuzKVlbmV7nJkijz5FADSUYMkX3J/sHh/cP+l/9nmoiav/6XBHCTxg6n2S4EMLq5A2pbj4nXo73H3TKl+ecn+AeG6HSg6M52v9O+eL8OCaJnP8+b1DjxbruICOfpU00OT36aP7ADk/m5H4TpyJnejSzD3hC8LWGei8WUu8n1SisDHz+htQvzyOpeyk46kOpNw2jMaIpO9xrFBo0pdSlZlqh/22E+NHw4LS3/5BE2eHx5wpxd/ROj07/NwnxLQLk71eKn8Z9of9xF/9338W/8IW6pK4thCcZatK7IzN137BZ6ncCaWxKDtP15KyOvO/O8styxYa0z/B4IJqnajTJIHkkIyed4mHrlGNpWcVw/+F91gzEqdeqEPWREihkBjJyYy+JXRfSNgwbtgxFsMYRotTk5myFWDDcgUJipn4FVUELcXiFADf+FsKy4srbzLxMMAfeSrrFrhdSpYFTcbx39FudbSuSQmuUqQrz5ag+Mqj5Cd4YGC2yIn6CWJZklslAXfUpnt0VD+bKdY19Zs4gR42XsrAew4GVS5IRgYXg5pqcKd02LvFrGO553FPCOiL7a3p3qr1yTwahdSSE4fHeQfLl3qSahEp/yRBNb9vgMX73rVUw7HfjsFGZfMiM+leQs4YuGvGxuNPcDeuw1/umvhlEeSuduYoItjQpMpSfrQ+g0U8bKYWAgOdSJdtoSt5GNsFnm+D7+4i4SZtFxy4kxpbMqcWr4nlitDtsuDOXzO+28VloiwyijYIzIoI3xNNi0UPvEpYz89i5knthjlz4y301PQc3L8AOz41WvoNJKeE/DjcBT/1Q3uZv3PaEFFLFPLXWeopqsT1hOoH4R9FYedmUroUdUFtIgvovRIdzd6SaVxfAIAjSVg4eJ1uqTLJz2/M0IyC6mWwKAPG5H0z7Tffjde1xY5Be9j578HBWjsFc4Whyi5Vdnyv5zKK5HtUESVk502HphLJ09xD8l+IsGbO8y1lruU2hycbXgZyj5xMMJj1Ln/FsROGCqapO1Hj7USEFfsMNBn2BUyuVTO/o+yanL3G4d+ApK+0hR6uueCAFPPBk26cx6eTA2TILMEGM32v5ji5dB54FM5s68r2p7GQ63qpNnbvlfUIg8aaaXJWrruU6zJzdXJr6/duXjebNtO4DIs607Yy/HzUkUL5a+PWScKqyfVEPfKoinlRbgNh0ElCOakkJIDE/LekZZip75KDygYtPAZUZEB3T0jk0Y2Z8lgZ+oFYRYj/WH+AzQUkdaDNKaVRORCk0SsQfpVOyGJZEHkpfVwNSxxMwl3pcTxWwddnxVmpP68ntuIbxynefsgJ2DdF0xx0oNrX6tY9+kN3U3ElrFtWcqBQpi24kcqXdefOP3+nEaNtDPTW7rMl9kz/kn3MvomnOFrMUac+0BkRuq/Mpq3nm1GVnkRnzRUbmypMj4yM5cy/C9EjYAucl7Z5zI59mFXkQL0thk9E0gEyBlvuJIfH1IUqjfvlR3l/0+gnIFNwqRYQxesnvj5leij/Liwlm+e9Y772WRdDuotqYSslqPmxu52N4Cfbwl4HRdetjH0nRt3ayn0a6gL8abUNbAeTfNGotri8sUksVTuL+bXrcqxKOEaX1klXb8jg1VAkxnvRXF+EZNcg04lMWWcywjU/FtvozL21yy08aYcGfLffmDsVxoT2QTGRaX12pB7NJ6v34A2ZAwprGjUfaQsktcbMm0Fgc7+0zvcndPLLDVgB6ixUOPtW9k8eB6PocfDCC/NlQjckqiyUWv/asmIjROikLjBRYviVcVWru0RsGaT5i17nTD2/98TqH6kUnFlKBvh/hfLhYj6bVuPf0m3P928bjwXXKFJqlrofRS0I8RbMNUKqOafv2827apm8woeUu3N3AIbhwn3AmyAXFw0ItqTiH4I5GXZ4QJ7lZ0ZvDtGJLXdZzSw705KyPaNZPKW04PO4dHCEL+tkYjYPTo+MHPn7uZ/ALVTZ0Rxb/XoPnh/cf5Jsp/SNYyaUedPbR5BORawpc0wZrstxNa7niqPbBg5Tj3CR/z/VzHfUT7hQ/Yn4IvB6VvC5NcX0EpOB6BjbAfY73qkRl6dLThKbL0mO0Gdk6NzUGaM4CMj5OrJqA3Z15jQbYwpFiWxyr43zXF1CRhPM2mN9eUrvORQ/9RoyalmORjaqfejjHcQSvO45q0iwo70idC/npQfTT/ein0+ink+in+JlH0U+H0U92JvZz/Cm0MkGhARq6TLWdEoKYtJdnSaOT/YP9hw/6XyWn5qz3qPeN0+TPnXgjmA6Dab72H0h2nLujI41tUX3bJ/PjD3/b2XQAAd3u6r0QrpcLVRcHrC6ctrh0anN1Ozw4Pj3aH45Ww8M97fTmpD10iIo/d7PKcu6E6Eofc3qa1zo3i6Ek8+4JBfA9p8FO7u0f30vu995ifiWK0NklTj7rYK/nbgW+rs9vGwLQ6m+xnBeAIyRvkk7hup6V6WD3OlPTJ6RZuWjw8GGsWbcXDR4+fPjw6L5JTeu6/zKqNSc047Re/hM/u8bD/AjMc9Aabzi+rqaTrDCnTycXgcppp5MOkX5wBJE+ra6uVzcl/W8PDxcZblmV9HH4y56CmRtkdtXh9cVnlIOaq/ONaopy9QUnN9kJIVO80o4PRR4od3Toi9JUgB1+9dRpbYrAs1Tgz7tr6/7y619xCImUB7c70mhDs7e4XkiLo1//ytnbJXEWuVvsfqoue3e4v8YFUjDNnd4X3715+vRCNMQXvbu93xSzxX/H//T+mz4zfFrKBC8mk+nFNHzpbu/fSEPzKGMNbtXJyNLG7Q7GfHnx7bO35y9ef/PFXz+mRQB1oE4O/rby7H4HDGV3ecYHfcgn7j+BbDsd7h8PDw56zjp2N/z48HNhN0dHx4cPLHbyF2xgtEGOxPi+TZ/7+UEx+/t0xf9xrXcdk6x9Wky3u8165GV5czGzVeG0M+WnRaUITvy6Ojs5ffjAuweHdLxvmwttJGS8O6fi5LfaIS5opL9I76SpKUEym+z+AvYUimNcjBfxXzSASPX4mNRDzOTYwNURC9R77n+wfZgo7CJnlhpy6Q2KKgbTv5sRHqNXgYww8j8ctCGwcuANNG1zaTqNkqlDN3NDPlMMypX+237gW9MU2TdI7mhCpZwGO6CSnPSKogSHD2X8IS/xPfsDXarWBhwdSPszZSUZMm/TPfGM5DtmzY8MVpuX+V78oxknbAOtsCz4vclEYYH60Xg37Ajxuiez6tiYY1kEp5DGl/pZuzMkCp2ywkbc03+YD/odOjqNqSbu2R+G4L1bmiXSnTs+ysZx7mV+p9+Od/IveNx10VyzuXTWfzg5ORwfHR4VxXE52d9/eHp5OLo8vnwweViWRwfHpVxgMqycbFxdkM4A31JVNhccrSDdcnByf//g8Pj4YF+CPRdO9lwcXOxfwPm/oADT6Ozgv//l/wN/duw9', 'yes');
INSERT INTO `wp_options` (`option_id`, `option_name`, `option_value`, `autoload`) VALUES
(28173, 'toolset_executed_upgrade_commands', 'a:3:{i:0;s:55:\"Toolset_Upgrade_Command_Delete_Obsolete_Upgrade_Options\";i:1;s:57:\"Toolset_Upgrade_Command_M2M_V1_Database_Structure_Upgrade\";i:2;s:57:\"Toolset_Upgrade_Command_M2M_V2_Database_Structure_Upgrade\";}', 'no'),
(28174, 'toolset_data_structure_version', '3', 'yes'),
(28175, 'wpcf-messages', 'a:1:{i:1;a:0:{}}', 'yes'),
(28176, 'wpcf_users_options', '1', 'yes'),
(28177, 'wpcf-custom-taxonomies', 'a:3:{s:8:\"category\";a:25:{s:4:\"name\";s:8:\"category\";s:5:\"label\";s:10:\"Categories\";s:6:\"labels\";a:23:{s:4:\"name\";s:10:\"Categories\";s:13:\"singular_name\";s:8:\"Category\";s:12:\"search_items\";s:17:\"Search Categories\";s:13:\"popular_items\";N;s:9:\"all_items\";s:14:\"All Categories\";s:11:\"parent_item\";s:15:\"Parent Category\";s:17:\"parent_item_colon\";s:16:\"Parent Category:\";s:9:\"edit_item\";s:13:\"Edit Category\";s:9:\"view_item\";s:13:\"View Category\";s:11:\"update_item\";s:15:\"Update Category\";s:12:\"add_new_item\";s:16:\"Add New Category\";s:13:\"new_item_name\";s:17:\"New Category Name\";s:26:\"separate_items_with_commas\";N;s:19:\"add_or_remove_items\";N;s:21:\"choose_from_most_used\";N;s:9:\"not_found\";s:20:\"No categories found.\";s:8:\"no_terms\";s:13:\"No categories\";s:21:\"items_list_navigation\";s:26:\"Categories list navigation\";s:10:\"items_list\";s:15:\"Categories list\";s:9:\"most_used\";s:9:\"Most Used\";s:13:\"back_to_items\";s:25:\"&larr; Back to Categories\";s:9:\"menu_name\";s:10:\"Categories\";s:14:\"name_admin_bar\";s:8:\"category\";}s:11:\"description\";s:0:\"\";s:6:\"public\";b:1;s:18:\"publicly_queryable\";b:1;s:12:\"hierarchical\";b:1;s:7:\"show_ui\";b:1;s:12:\"show_in_menu\";b:1;s:17:\"show_in_nav_menus\";b:1;s:13:\"show_tagcloud\";b:1;s:18:\"show_in_quick_edit\";b:1;s:17:\"show_admin_column\";b:1;s:11:\"meta_box_cb\";s:24:\"post_categories_meta_box\";s:11:\"object_type\";a:1:{i:0;s:4:\"post\";}s:3:\"cap\";a:4:{s:12:\"manage_terms\";s:17:\"manage_categories\";s:10:\"edit_terms\";s:15:\"edit_categories\";s:12:\"delete_terms\";s:17:\"delete_categories\";s:12:\"assign_terms\";s:17:\"assign_categories\";}s:7:\"rewrite\";a:4:{s:10:\"with_front\";b:0;s:12:\"hierarchical\";b:1;s:7:\"ep_mask\";i:512;s:4:\"slug\";s:8:\"taxonomy\";}s:9:\"query_var\";s:13:\"category_name\";s:21:\"update_count_callback\";s:0:\"\";s:12:\"show_in_rest\";b:1;s:9:\"rest_base\";s:10:\"categories\";s:21:\"rest_controller_class\";s:24:\"WP_REST_Terms_Controller\";s:8:\"_builtin\";b:1;s:4:\"slug\";s:8:\"category\";s:8:\"supports\";a:1:{s:4:\"post\";i:1;}}s:8:\"post_tag\";a:25:{s:4:\"name\";s:8:\"post_tag\";s:5:\"label\";s:4:\"Tags\";s:6:\"labels\";a:23:{s:4:\"name\";s:4:\"Tags\";s:13:\"singular_name\";s:3:\"Tag\";s:12:\"search_items\";s:11:\"Search Tags\";s:13:\"popular_items\";s:12:\"Popular Tags\";s:9:\"all_items\";s:8:\"All Tags\";s:11:\"parent_item\";N;s:17:\"parent_item_colon\";N;s:9:\"edit_item\";s:8:\"Edit Tag\";s:9:\"view_item\";s:8:\"View Tag\";s:11:\"update_item\";s:10:\"Update Tag\";s:12:\"add_new_item\";s:11:\"Add New Tag\";s:13:\"new_item_name\";s:12:\"New Tag Name\";s:26:\"separate_items_with_commas\";s:25:\"Separate tags with commas\";s:19:\"add_or_remove_items\";s:18:\"Add or remove tags\";s:21:\"choose_from_most_used\";s:30:\"Choose from the most used tags\";s:9:\"not_found\";s:14:\"No tags found.\";s:8:\"no_terms\";s:7:\"No tags\";s:21:\"items_list_navigation\";s:20:\"Tags list navigation\";s:10:\"items_list\";s:9:\"Tags list\";s:9:\"most_used\";s:9:\"Most Used\";s:13:\"back_to_items\";s:19:\"&larr; Back to Tags\";s:9:\"menu_name\";s:4:\"Tags\";s:14:\"name_admin_bar\";s:8:\"post_tag\";}s:11:\"description\";s:0:\"\";s:6:\"public\";b:1;s:18:\"publicly_queryable\";b:1;s:12:\"hierarchical\";b:0;s:7:\"show_ui\";b:1;s:12:\"show_in_menu\";b:1;s:17:\"show_in_nav_menus\";b:1;s:13:\"show_tagcloud\";b:1;s:18:\"show_in_quick_edit\";b:1;s:17:\"show_admin_column\";b:1;s:11:\"meta_box_cb\";s:18:\"post_tags_meta_box\";s:11:\"object_type\";a:1:{i:0;s:4:\"post\";}s:3:\"cap\";a:4:{s:12:\"manage_terms\";s:16:\"manage_post_tags\";s:10:\"edit_terms\";s:14:\"edit_post_tags\";s:12:\"delete_terms\";s:16:\"delete_post_tags\";s:12:\"assign_terms\";s:16:\"assign_post_tags\";}s:7:\"rewrite\";a:4:{s:10:\"with_front\";b:1;s:12:\"hierarchical\";b:0;s:7:\"ep_mask\";i:1024;s:4:\"slug\";s:3:\"tag\";}s:9:\"query_var\";s:3:\"tag\";s:21:\"update_count_callback\";s:0:\"\";s:12:\"show_in_rest\";b:1;s:9:\"rest_base\";s:4:\"tags\";s:21:\"rest_controller_class\";s:24:\"WP_REST_Terms_Controller\";s:8:\"_builtin\";b:1;s:4:\"slug\";s:8:\"post_tag\";s:8:\"supports\";a:1:{s:4:\"post\";i:1;}}s:23:\"main_hotel_informations\";a:19:{s:4:\"icon\";s:10:\"admin-post\";s:6:\"labels\";a:15:{s:4:\"name\";s:23:\"Main Hotel Informations\";s:13:\"singular_name\";s:23:\"Main Hotel Informations\";s:12:\"search_items\";s:9:\"Search %s\";s:13:\"popular_items\";s:10:\"Popular %s\";s:9:\"all_items\";s:6:\"All %s\";s:11:\"parent_item\";s:9:\"Parent %s\";s:17:\"parent_item_colon\";s:10:\"Parent %s:\";s:9:\"edit_item\";s:7:\"Edit %s\";s:11:\"update_item\";s:9:\"Update %s\";s:12:\"add_new_item\";s:10:\"Add New %s\";s:13:\"new_item_name\";s:11:\"New %s Name\";s:26:\"separate_items_with_commas\";s:23:\"Separate %s with commas\";s:19:\"add_or_remove_items\";s:16:\"Add or remove %s\";s:21:\"choose_from_most_used\";s:28:\"Choose from the most used %s\";s:9:\"menu_name\";s:2:\"%s\";}s:4:\"slug\";s:23:\"main_hotel_informations\";s:11:\"description\";s:0:\"\";s:6:\"public\";s:6:\"public\";s:12:\"hierarchical\";s:12:\"hierarchical\";s:8:\"supports\";a:0:{}s:7:\"rewrite\";a:4:{s:7:\"enabled\";s:1:\"1\";s:4:\"slug\";s:0:\"\";s:10:\"with_front\";s:1:\"1\";s:12:\"hierarchical\";s:1:\"1\";}s:7:\"show_ui\";s:1:\"1\";s:17:\"show_in_nav_menus\";s:1:\"1\";s:13:\"show_tagcloud\";s:1:\"1\";s:17:\"query_var_enabled\";s:1:\"1\";s:9:\"query_var\";s:0:\"\";s:21:\"update_count_callback\";s:0:\"\";s:9:\"rest_base\";s:0:\"\";s:11:\"meta_box_cb\";a:1:{s:8:\"callback\";s:0:\"\";}s:18:\"_toolset_edit_last\";i:1560793257;s:15:\"_wpcf_author_id\";i:1;s:4:\"name\";b:0;}}', 'yes'),
(28178, 'wpcf-custom-types', 'a:0:{}', 'yes'),
(28179, 'wpcf_post_relationship', 'a:0:{}', 'yes'),
(28180, '_wpcf_promo_tabs', 'a:2:{s:8:\"selected\";i:2;s:4:\"time\";i:1560698973;}', 'yes'),
(28182, 'wpcf-termmeta', 'a:17:{s:15:\"hotel_gallery_1\";a:8:{s:2:\"id\";s:15:\"hotel_gallery_1\";s:4:\"slug\";s:15:\"hotel_gallery_1\";s:4:\"type\";s:5:\"image\";s:4:\"name\";s:15:\"hotel_gallery_1\";s:11:\"description\";s:0:\"\";s:4:\"data\";a:7:{s:11:\"placeholder\";s:0:\"\";s:18:\"user_default_value\";s:0:\"\";s:10:\"repetitive\";s:1:\"0\";s:19:\"conditional_display\";a:0:{}s:10:\"submit-key\";s:16:\"image-1546501370\";s:16:\"disabled_by_type\";i:0;s:8:\"validate\";a:1:{s:4:\"url2\";a:3:{s:6:\"active\";s:1:\"1\";s:7:\"message\";s:60:\"Please enter a valid URL address pointing to the image file.\";s:17:\"suppress_for_cred\";b:1;}}}s:8:\"meta_key\";s:20:\"wpcf-hotel_gallery_1\";s:9:\"meta_type\";s:8:\"termmeta\";}s:15:\"hotel_gallery_2\";a:8:{s:2:\"id\";s:15:\"hotel_gallery_2\";s:4:\"slug\";s:15:\"hotel_gallery_2\";s:4:\"type\";s:5:\"image\";s:4:\"name\";s:15:\"hotel_gallery_2\";s:11:\"description\";s:0:\"\";s:4:\"data\";a:7:{s:11:\"placeholder\";s:0:\"\";s:18:\"user_default_value\";s:0:\"\";s:10:\"repetitive\";s:1:\"0\";s:19:\"conditional_display\";a:0:{}s:10:\"submit-key\";s:15:\"image-407397921\";s:16:\"disabled_by_type\";i:0;s:8:\"validate\";a:1:{s:4:\"url2\";a:3:{s:6:\"active\";s:1:\"1\";s:7:\"message\";s:60:\"Please enter a valid URL address pointing to the image file.\";s:17:\"suppress_for_cred\";b:1;}}}s:8:\"meta_key\";s:20:\"wpcf-hotel_gallery_2\";s:9:\"meta_type\";s:8:\"termmeta\";}s:15:\"hotel_gallery_3\";a:8:{s:2:\"id\";s:15:\"hotel_gallery_3\";s:4:\"slug\";s:15:\"hotel_gallery_3\";s:4:\"type\";s:5:\"image\";s:4:\"name\";s:15:\"hotel_gallery_3\";s:11:\"description\";s:0:\"\";s:4:\"data\";a:7:{s:11:\"placeholder\";s:0:\"\";s:18:\"user_default_value\";s:0:\"\";s:10:\"repetitive\";s:1:\"0\";s:19:\"conditional_display\";a:0:{}s:10:\"submit-key\";s:16:\"image-1084980070\";s:16:\"disabled_by_type\";i:0;s:8:\"validate\";a:1:{s:4:\"url2\";a:3:{s:6:\"active\";s:1:\"1\";s:7:\"message\";s:60:\"Please enter a valid URL address pointing to the image file.\";s:17:\"suppress_for_cred\";b:1;}}}s:8:\"meta_key\";s:20:\"wpcf-hotel_gallery_3\";s:9:\"meta_type\";s:8:\"termmeta\";}s:15:\"hotel_gallery_4\";a:8:{s:2:\"id\";s:15:\"hotel_gallery_4\";s:4:\"slug\";s:15:\"hotel_gallery_4\";s:4:\"type\";s:5:\"image\";s:4:\"name\";s:15:\"hotel_gallery_4\";s:11:\"description\";s:0:\"\";s:4:\"data\";a:7:{s:11:\"placeholder\";s:0:\"\";s:18:\"user_default_value\";s:0:\"\";s:10:\"repetitive\";s:1:\"0\";s:19:\"conditional_display\";a:0:{}s:10:\"submit-key\";s:15:\"image-347572006\";s:16:\"disabled_by_type\";i:0;s:8:\"validate\";a:1:{s:4:\"url2\";a:3:{s:6:\"active\";s:1:\"1\";s:7:\"message\";s:60:\"Please enter a valid URL address pointing to the image file.\";s:17:\"suppress_for_cred\";b:1;}}}s:8:\"meta_key\";s:20:\"wpcf-hotel_gallery_4\";s:9:\"meta_type\";s:8:\"termmeta\";}s:15:\"hotel_gallery_5\";a:8:{s:2:\"id\";s:15:\"hotel_gallery_5\";s:4:\"slug\";s:15:\"hotel_gallery_5\";s:4:\"type\";s:5:\"image\";s:4:\"name\";s:15:\"hotel_gallery_5\";s:11:\"description\";s:0:\"\";s:4:\"data\";a:7:{s:11:\"placeholder\";s:0:\"\";s:18:\"user_default_value\";s:0:\"\";s:10:\"repetitive\";s:1:\"0\";s:19:\"conditional_display\";a:0:{}s:10:\"submit-key\";s:16:\"image-1933859469\";s:16:\"disabled_by_type\";i:0;s:8:\"validate\";a:1:{s:4:\"url2\";a:3:{s:6:\"active\";s:1:\"1\";s:7:\"message\";s:60:\"Please enter a valid URL address pointing to the image file.\";s:17:\"suppress_for_cred\";b:1;}}}s:8:\"meta_key\";s:20:\"wpcf-hotel_gallery_5\";s:9:\"meta_type\";s:8:\"termmeta\";}s:15:\"hotel_gallery_6\";a:8:{s:2:\"id\";s:15:\"hotel_gallery_6\";s:4:\"slug\";s:15:\"hotel_gallery_6\";s:4:\"type\";s:5:\"image\";s:4:\"name\";s:15:\"hotel_gallery_6\";s:11:\"description\";s:0:\"\";s:4:\"data\";a:7:{s:11:\"placeholder\";s:0:\"\";s:18:\"user_default_value\";s:0:\"\";s:10:\"repetitive\";s:1:\"0\";s:19:\"conditional_display\";a:0:{}s:10:\"submit-key\";s:15:\"image-201762415\";s:16:\"disabled_by_type\";i:0;s:8:\"validate\";a:1:{s:4:\"url2\";a:3:{s:6:\"active\";s:1:\"1\";s:7:\"message\";s:60:\"Please enter a valid URL address pointing to the image file.\";s:17:\"suppress_for_cred\";b:1;}}}s:8:\"meta_key\";s:20:\"wpcf-hotel_gallery_6\";s:9:\"meta_type\";s:8:\"termmeta\";}s:8:\"check_in\";a:8:{s:2:\"id\";s:8:\"check_in\";s:4:\"slug\";s:8:\"check_in\";s:4:\"type\";s:4:\"date\";s:4:\"name\";s:10:\"Check - in\";s:11:\"description\";s:0:\"\";s:4:\"data\";a:8:{s:13:\"slug-pre-save\";s:8:\"check_in\";s:11:\"placeholder\";s:0:\"\";s:13:\"date_and_time\";s:4:\"date\";s:10:\"repetitive\";s:1:\"0\";s:10:\"custom_use\";s:0:\"\";s:19:\"conditional_display\";a:0:{}s:10:\"submit-key\";s:8:\"check_in\";s:16:\"disabled_by_type\";i:0;}s:8:\"meta_key\";s:13:\"wpcf-check_in\";s:9:\"meta_type\";s:8:\"termmeta\";}s:9:\"check_out\";a:8:{s:2:\"id\";s:9:\"check_out\";s:4:\"slug\";s:9:\"check_out\";s:4:\"type\";s:4:\"date\";s:4:\"name\";s:11:\"Check - out\";s:11:\"description\";s:0:\"\";s:4:\"data\";a:8:{s:13:\"slug-pre-save\";s:9:\"check_out\";s:11:\"placeholder\";s:0:\"\";s:13:\"date_and_time\";s:4:\"date\";s:10:\"repetitive\";s:1:\"0\";s:10:\"custom_use\";s:0:\"\";s:19:\"conditional_display\";a:0:{}s:10:\"submit-key\";s:9:\"check_out\";s:16:\"disabled_by_type\";i:0;}s:8:\"meta_key\";s:14:\"wpcf-check_out\";s:9:\"meta_type\";s:8:\"termmeta\";}s:14:\"hotel_location\";a:8:{s:2:\"id\";s:14:\"hotel_location\";s:4:\"slug\";s:14:\"hotel_location\";s:4:\"type\";s:9:\"textfield\";s:4:\"name\";s:14:\"Hotel Location\";s:11:\"description\";s:0:\"\";s:4:\"data\";a:8:{s:13:\"slug-pre-save\";s:14:\"hotel_location\";s:11:\"placeholder\";s:0:\"\";s:18:\"user_default_value\";s:0:\"\";s:10:\"repetitive\";s:1:\"0\";s:10:\"custom_use\";s:0:\"\";s:19:\"conditional_display\";a:0:{}s:10:\"submit-key\";s:14:\"hotel_location\";s:16:\"disabled_by_type\";i:0;}s:8:\"meta_key\";s:19:\"wpcf-hotel_location\";s:9:\"meta_type\";s:8:\"termmeta\";}s:11:\"hotel_email\";a:8:{s:2:\"id\";s:11:\"hotel_email\";s:4:\"slug\";s:11:\"hotel_email\";s:4:\"type\";s:9:\"textfield\";s:4:\"name\";s:11:\"Hotel Email\";s:11:\"description\";s:0:\"\";s:4:\"data\";a:8:{s:13:\"slug-pre-save\";s:11:\"hotel_email\";s:11:\"placeholder\";s:0:\"\";s:18:\"user_default_value\";s:0:\"\";s:10:\"repetitive\";s:1:\"0\";s:10:\"custom_use\";s:0:\"\";s:19:\"conditional_display\";a:0:{}s:10:\"submit-key\";s:11:\"hotel_email\";s:16:\"disabled_by_type\";i:0;}s:8:\"meta_key\";s:16:\"wpcf-hotel_email\";s:9:\"meta_type\";s:8:\"termmeta\";}s:14:\"hotel_phone_no\";a:8:{s:2:\"id\";s:14:\"hotel_phone_no\";s:4:\"slug\";s:14:\"hotel_phone_no\";s:4:\"type\";s:5:\"phone\";s:4:\"name\";s:14:\"Hotel Phone no\";s:11:\"description\";s:0:\"\";s:4:\"data\";a:8:{s:13:\"slug-pre-save\";s:14:\"hotel_phone_no\";s:11:\"placeholder\";s:0:\"\";s:18:\"user_default_value\";s:0:\"\";s:10:\"repetitive\";s:1:\"0\";s:10:\"custom_use\";s:0:\"\";s:19:\"conditional_display\";a:0:{}s:10:\"submit-key\";s:14:\"hotel_phone_no\";s:16:\"disabled_by_type\";i:0;}s:8:\"meta_key\";s:19:\"wpcf-hotel_phone_no\";s:9:\"meta_type\";s:8:\"termmeta\";}s:11:\"hotel_price\";a:8:{s:2:\"id\";s:11:\"hotel_price\";s:4:\"slug\";s:11:\"hotel_price\";s:4:\"type\";s:9:\"textfield\";s:4:\"name\";s:11:\"Hotel Price\";s:11:\"description\";s:0:\"\";s:4:\"data\";a:8:{s:13:\"slug-pre-save\";s:11:\"hotel_price\";s:11:\"placeholder\";s:0:\"\";s:18:\"user_default_value\";s:0:\"\";s:10:\"repetitive\";s:1:\"0\";s:10:\"custom_use\";s:0:\"\";s:19:\"conditional_display\";a:0:{}s:10:\"submit-key\";s:11:\"hotel_price\";s:16:\"disabled_by_type\";i:0;}s:8:\"meta_key\";s:16:\"wpcf-hotel_price\";s:9:\"meta_type\";s:8:\"termmeta\";}s:13:\"hotel_website\";a:8:{s:2:\"id\";s:13:\"hotel_website\";s:4:\"slug\";s:13:\"hotel_website\";s:4:\"type\";s:9:\"textfield\";s:4:\"name\";s:13:\"Hotel Website\";s:11:\"description\";s:0:\"\";s:4:\"data\";a:8:{s:13:\"slug-pre-save\";s:13:\"hotel_website\";s:11:\"placeholder\";s:0:\"\";s:18:\"user_default_value\";s:0:\"\";s:10:\"repetitive\";s:1:\"0\";s:10:\"custom_use\";s:0:\"\";s:19:\"conditional_display\";a:0:{}s:10:\"submit-key\";s:13:\"hotel_website\";s:16:\"disabled_by_type\";i:0;}s:8:\"meta_key\";s:18:\"wpcf-hotel_website\";s:9:\"meta_type\";s:8:\"termmeta\";}s:20:\"cancelled_prepayment\";a:8:{s:2:\"id\";s:20:\"cancelled_prepayment\";s:4:\"slug\";s:20:\"cancelled_prepayment\";s:4:\"type\";s:7:\"wysiwyg\";s:4:\"name\";s:21:\"Cancelled/ Prepayment\";s:11:\"description\";s:0:\"\";s:4:\"data\";a:6:{s:13:\"slug-pre-save\";s:20:\"cancelled_prepayment\";s:18:\"user_default_value\";s:0:\"\";s:10:\"custom_use\";s:0:\"\";s:19:\"conditional_display\";a:0:{}s:10:\"submit-key\";s:20:\"cancelled_prepayment\";s:16:\"disabled_by_type\";i:0;}s:8:\"meta_key\";s:25:\"wpcf-cancelled_prepayment\";s:9:\"meta_type\";s:8:\"termmeta\";}s:21:\"children_and_extrabed\";a:8:{s:2:\"id\";s:21:\"children_and_extrabed\";s:4:\"slug\";s:21:\"children_and_extrabed\";s:4:\"type\";s:7:\"wysiwyg\";s:4:\"name\";s:21:\"Children and extrabed\";s:11:\"description\";s:0:\"\";s:4:\"data\";a:6:{s:13:\"slug-pre-save\";s:21:\"children_and_extrabed\";s:18:\"user_default_value\";s:0:\"\";s:10:\"custom_use\";s:0:\"\";s:19:\"conditional_display\";a:0:{}s:10:\"submit-key\";s:21:\"children_and_extrabed\";s:16:\"disabled_by_type\";i:0;}s:8:\"meta_key\";s:26:\"wpcf-children_and_extrabed\";s:9:\"meta_type\";s:8:\"termmeta\";}s:10:\"hotel_pets\";a:8:{s:2:\"id\";s:10:\"hotel_pets\";s:4:\"slug\";s:10:\"hotel_pets\";s:4:\"type\";s:9:\"textfield\";s:4:\"name\";s:10:\"Hotel Pets\";s:11:\"description\";s:0:\"\";s:4:\"data\";a:8:{s:13:\"slug-pre-save\";s:10:\"hotel_pets\";s:11:\"placeholder\";s:0:\"\";s:18:\"user_default_value\";s:0:\"\";s:10:\"repetitive\";s:1:\"0\";s:10:\"custom_use\";s:0:\"\";s:19:\"conditional_display\";a:0:{}s:10:\"submit-key\";s:10:\"hotel_pets\";s:16:\"disabled_by_type\";i:0;}s:8:\"meta_key\";s:15:\"wpcf-hotel_pets\";s:9:\"meta_type\";s:8:\"termmeta\";}s:16:\"main_hotel_image\";a:8:{s:2:\"id\";s:16:\"main_hotel_image\";s:4:\"slug\";s:16:\"main_hotel_image\";s:4:\"type\";s:5:\"image\";s:4:\"name\";s:15:\"Main HotelImage\";s:11:\"description\";s:0:\"\";s:4:\"data\";a:9:{s:13:\"slug-pre-save\";s:16:\"main_hotel_image\";s:11:\"placeholder\";s:0:\"\";s:18:\"user_default_value\";s:0:\"\";s:10:\"repetitive\";s:1:\"0\";s:10:\"custom_use\";s:0:\"\";s:19:\"conditional_display\";a:0:{}s:10:\"submit-key\";s:16:\"main_hotel_image\";s:16:\"disabled_by_type\";i:0;s:8:\"validate\";a:1:{s:4:\"url2\";a:3:{s:6:\"active\";s:1:\"1\";s:7:\"message\";s:60:\"Please enter a valid URL address pointing to the image file.\";s:17:\"suppress_for_cred\";b:1;}}}s:8:\"meta_key\";s:21:\"wpcf-main_hotel_image\";s:9:\"meta_type\";s:8:\"termmeta\";}}', 'yes'),
(28187, 'main_hotel_informations_children', 'a:0:{}', 'yes'),
(28192, 'installer_repositories_with_theme', 'a:1:{i:0;s:7:\"toolset\";}', 'yes'),
(28194, 'theme_mods_hazproject_21', 'a:4:{i:0;b:0;s:18:\"nav_menu_locations\";a:3:{s:9:\"main_menu\";i:2;s:6:\"menu-1\";i:2;s:11:\"footer_menu\";i:204;}s:18:\"custom_css_post_id\";i:-1;s:16:\"sidebars_widgets\";a:2:{s:4:\"time\";i:1560702415;s:4:\"data\";a:8:{s:19:\"wp_inactive_widgets\";a:0:{}s:9:\"sidebar-1\";a:5:{i:0;s:8:\"search-2\";i:1;s:14:\"recent-posts-2\";i:2;s:17:\"recent-comments-2\";i:3;s:10:\"archives-2\";i:4;s:6:\"meta-2\";}s:7:\"footer1\";a:0:{}s:7:\"footer2\";a:0:{}s:7:\"footer3\";a:0:{}s:7:\"footer4\";a:1:{i:0;s:12:\"categories-2\";}s:18:\"footerbottom-right\";a:0:{}s:12:\"page_sidebar\";a:0:{}}}}', 'yes'),
(28764, 'otgs_active_components', 'a:2:{s:6:\"plugin\";a:10:{i:0;a:3:{s:4:\"File\";s:30:\"advanced-custom-fields/acf.php\";s:4:\"Name\";s:22:\"Advanced Custom Fields\";s:7:\"Version\";s:5:\"5.8.0\";}i:1;a:3:{s:4:\"File\";s:19:\"akismet/akismet.php\";s:4:\"Name\";s:17:\"Akismet Anti-Spam\";s:7:\"Version\";s:3:\"4.1\";}i:2;a:3:{s:4:\"File\";s:28:\"categorized-gallery/init.php\";s:4:\"Name\";s:26:\"Categorized Gallery Plugin\";s:7:\"Version\";s:1:\"1\";}i:3;a:3:{s:4:\"File\";s:44:\"wp-custom-taxonomy-meta/wp-texonomy-meta.php\";s:4:\"Name\";s:33:\"Category and Taxonomy Meta Fields\";s:7:\"Version\";s:5:\"1.0.0\";}i:4;a:3:{s:4:\"File\";s:33:\"duplicate-post/duplicate-post.php\";s:4:\"Name\";s:14:\"Duplicate Post\";s:7:\"Version\";s:5:\"3.2.2\";}i:5;a:3:{s:4:\"File\";s:29:\"photo-gallery-image/index.php\";s:4:\"Name\";s:15:\"GrandWP Gallery\";s:7:\"Version\";s:5:\"1.1.0\";}i:6;a:3:{s:4:\"File\";s:25:\"profile-builder/index.php\";s:4:\"Name\";s:15:\"Profile Builder\";s:7:\"Version\";s:5:\"2.9.9\";}i:7;a:3:{s:4:\"File\";s:29:\"site-reviews/site-reviews.php\";s:4:\"Name\";s:12:\"Site Reviews\";s:7:\"Version\";s:5:\"3.5.4\";}i:8;a:3:{s:4:\"File\";s:14:\"types/wpcf.php\";s:4:\"Name\";s:13:\"Toolset Types\";s:7:\"Version\";s:5:\"2.3.5\";}i:9;a:3:{s:4:\"File\";s:37:\"user-role-editor/user-role-editor.php\";s:4:\"Name\";s:16:\"User Role Editor\";s:7:\"Version\";s:6:\"4.40.3\";}}s:5:\"theme\";a:1:{i:0;a:3:{s:8:\"Template\";s:10:\"hazproject\";s:4:\"Name\";s:10:\"hazproject\";s:7:\"Version\";s:5:\"1.0.0\";}}}', 'yes'),
(28966, '_site_transient_update_core', 'O:8:\"stdClass\":4:{s:7:\"updates\";a:3:{i:0;O:8:\"stdClass\":10:{s:8:\"response\";s:7:\"upgrade\";s:8:\"download\";s:59:\"https://downloads.wordpress.org/release/wordpress-5.2.3.zip\";s:6:\"locale\";s:5:\"en_US\";s:8:\"packages\";O:8:\"stdClass\":5:{s:4:\"full\";s:59:\"https://downloads.wordpress.org/release/wordpress-5.2.3.zip\";s:10:\"no_content\";s:70:\"https://downloads.wordpress.org/release/wordpress-5.2.3-no-content.zip\";s:11:\"new_bundled\";s:71:\"https://downloads.wordpress.org/release/wordpress-5.2.3-new-bundled.zip\";s:7:\"partial\";b:0;s:8:\"rollback\";b:0;}s:7:\"current\";s:5:\"5.2.3\";s:7:\"version\";s:5:\"5.2.3\";s:11:\"php_version\";s:6:\"5.6.20\";s:13:\"mysql_version\";s:3:\"5.0\";s:11:\"new_bundled\";s:3:\"5.0\";s:15:\"partial_version\";s:0:\"\";}i:1;O:8:\"stdClass\":11:{s:8:\"response\";s:10:\"autoupdate\";s:8:\"download\";s:59:\"https://downloads.wordpress.org/release/wordpress-5.2.3.zip\";s:6:\"locale\";s:5:\"en_US\";s:8:\"packages\";O:8:\"stdClass\":5:{s:4:\"full\";s:59:\"https://downloads.wordpress.org/release/wordpress-5.2.3.zip\";s:10:\"no_content\";s:70:\"https://downloads.wordpress.org/release/wordpress-5.2.3-no-content.zip\";s:11:\"new_bundled\";s:71:\"https://downloads.wordpress.org/release/wordpress-5.2.3-new-bundled.zip\";s:7:\"partial\";b:0;s:8:\"rollback\";b:0;}s:7:\"current\";s:5:\"5.2.3\";s:7:\"version\";s:5:\"5.2.3\";s:11:\"php_version\";s:6:\"5.6.20\";s:13:\"mysql_version\";s:3:\"5.0\";s:11:\"new_bundled\";s:3:\"5.0\";s:15:\"partial_version\";s:0:\"\";s:9:\"new_files\";s:1:\"1\";}i:2;O:8:\"stdClass\":11:{s:8:\"response\";s:10:\"autoupdate\";s:8:\"download\";s:59:\"https://downloads.wordpress.org/release/wordpress-5.1.2.zip\";s:6:\"locale\";s:5:\"en_US\";s:8:\"packages\";O:8:\"stdClass\":5:{s:4:\"full\";s:59:\"https://downloads.wordpress.org/release/wordpress-5.1.2.zip\";s:10:\"no_content\";s:70:\"https://downloads.wordpress.org/release/wordpress-5.1.2-no-content.zip\";s:11:\"new_bundled\";s:71:\"https://downloads.wordpress.org/release/wordpress-5.1.2-new-bundled.zip\";s:7:\"partial\";b:0;s:8:\"rollback\";b:0;}s:7:\"current\";s:5:\"5.1.2\";s:7:\"version\";s:5:\"5.1.2\";s:11:\"php_version\";s:5:\"5.2.4\";s:13:\"mysql_version\";s:3:\"5.0\";s:11:\"new_bundled\";s:3:\"5.0\";s:15:\"partial_version\";s:0:\"\";s:9:\"new_files\";s:1:\"1\";}}s:12:\"last_checked\";i:1570182089;s:15:\"version_checked\";s:5:\"5.0.6\";s:12:\"translations\";a:0:{}}', 'no'),
(28967, 'auto_core_update_notified', 'a:4:{s:4:\"type\";s:7:\"success\";s:5:\"email\";s:15:\"admin@gmail.com\";s:7:\"version\";s:5:\"5.0.6\";s:9:\"timestamp\";i:1568654295;}', 'no'),
(28977, '_site_transient_timeout_browser_40d2af28a4c309bbb824dc957af59b11', '1570212132', 'no'),
(28978, '_site_transient_browser_40d2af28a4c309bbb824dc957af59b11', 'a:10:{s:4:\"name\";s:6:\"Chrome\";s:7:\"version\";s:12:\"77.0.3865.90\";s:8:\"platform\";s:7:\"Windows\";s:10:\"update_url\";s:29:\"https://www.google.com/chrome\";s:7:\"img_src\";s:43:\"http://s.w.org/images/browsers/chrome.png?1\";s:11:\"img_src_ssl\";s:44:\"https://s.w.org/images/browsers/chrome.png?1\";s:15:\"current_version\";s:2:\"18\";s:7:\"upgrade\";b:0;s:8:\"insecure\";b:0;s:6:\"mobile\";b:0;}', 'no'),
(28990, '_site_transient_timeout_theme_roots', '1570183894', 'no'),
(28991, '_site_transient_theme_roots', 'a:12:{s:21:\"hazproject - Copy (2)\";s:7:\"/themes\";s:21:\"hazproject - Copy (3)\";s:7:\"/themes\";s:21:\"hazproject - Copy (4)\";s:7:\"/themes\";s:17:\"hazproject - Copy\";s:7:\"/themes\";s:10:\"hazproject\";s:7:\"/themes\";s:21:\"hazproject_11_07_2019\";s:7:\"/themes\";s:13:\"hazproject_21\";s:7:\"/themes\";s:16:\"hazproject_local\";s:7:\"/themes\";s:17:\"hazproject_recent\";s:7:\"/themes\";s:6:\"hotels\";s:7:\"/themes\";s:4:\"html\";s:7:\"/themes\";s:7:\"uploads\";s:7:\"/themes\";}', 'no'),
(28992, '_site_transient_update_plugins', 'O:8:\"stdClass\":5:{s:12:\"last_checked\";i:1570182099;s:7:\"checked\";a:29:{s:30:\"advanced-custom-fields/acf.php\";s:5:\"5.8.0\";s:19:\"akismet/akismet.php\";s:3:\"4.1\";s:19:\"bbpress/bbpress.php\";s:6:\"2.5.14\";s:37:\"bbp-shortcodes/bbpress-shortcodes.php\";s:3:\"1.0\";s:33:\"Car Booking/wp-booking-system.php\";s:5:\"1.5.1\";s:28:\"categorized-gallery/init.php\";s:1:\"1\";s:44:\"wp-custom-taxonomy-meta/wp-texonomy-meta.php\";s:5:\"1.0.0\";s:17:\"ratting/index.php\";s:5:\"0.1.0\";s:38:\"cmb_field_map-master/cmb-field-map.php\";s:5:\"2.2.0\";s:36:\"contact-form-7/wp-contact-form-7.php\";s:5:\"5.0.1\";s:43:\"custom-post-type-ui/custom-post-type-ui.php\";s:5:\"1.5.8\";s:33:\"duplicate-post/duplicate-post.php\";s:5:\"3.2.2\";s:29:\"photo-gallery-image/index.php\";s:5:\"1.1.0\";s:9:\"hello.php\";s:5:\"1.7.1\";s:56:\"motopress-hotel-booking-lite/motopress-hotel-booking.php\";s:5:\"3.2.0\";s:37:\"mailchimp-for-wp/mailchimp-for-wp.php\";s:5:\"4.2.1\";s:29:\"multi-rating/multi-rating.php\";s:3:\"4.3\";s:25:\"profile-builder/index.php\";s:5:\"2.9.9\";s:29:\"site-reviews/site-reviews.php\";s:5:\"3.5.4\";s:14:\"types/wpcf.php\";s:5:\"2.3.5\";s:31:\"traveler-code/traveler-code.php\";s:5:\"2.0.5\";s:37:\"user-role-editor/user-role-editor.php\";s:6:\"4.40.3\";s:27:\"woocommerce/woocommerce.php\";s:5:\"3.5.5\";s:69:\"woo-gutenberg-products-block/woocommerce-gutenberg-products-block.php\";s:5:\"1.4.0\";s:42:\"wordpress-social-login/wp-social-login.php\";s:5:\"2.3.3\";s:27:\"js_composer/js_composer.php\";s:5:\"5.4.7\";s:23:\"wp-travel/wp-travel.php\";s:5:\"1.8.9\";s:25:\"wp-user-frontend/wpuf.php\";s:5:\"2.8.7\";s:33:\"wp-user-frontend-pro/wpuf-pro.php\";s:5:\"2.6.0\";}s:8:\"response\";a:14:{s:30:\"advanced-custom-fields/acf.php\";O:8:\"stdClass\":12:{s:2:\"id\";s:36:\"w.org/plugins/advanced-custom-fields\";s:4:\"slug\";s:22:\"advanced-custom-fields\";s:6:\"plugin\";s:30:\"advanced-custom-fields/acf.php\";s:11:\"new_version\";s:5:\"5.8.3\";s:3:\"url\";s:53:\"https://wordpress.org/plugins/advanced-custom-fields/\";s:7:\"package\";s:71:\"https://downloads.wordpress.org/plugin/advanced-custom-fields.5.8.3.zip\";s:5:\"icons\";a:2:{s:2:\"2x\";s:75:\"https://ps.w.org/advanced-custom-fields/assets/icon-256x256.png?rev=1082746\";s:2:\"1x\";s:75:\"https://ps.w.org/advanced-custom-fields/assets/icon-128x128.png?rev=1082746\";}s:7:\"banners\";a:2:{s:2:\"2x\";s:78:\"https://ps.w.org/advanced-custom-fields/assets/banner-1544x500.jpg?rev=1729099\";s:2:\"1x\";s:77:\"https://ps.w.org/advanced-custom-fields/assets/banner-772x250.jpg?rev=1729102\";}s:11:\"banners_rtl\";a:0:{}s:6:\"tested\";s:5:\"5.2.3\";s:12:\"requires_php\";s:3:\"5.4\";s:13:\"compatibility\";O:8:\"stdClass\":0:{}}s:19:\"akismet/akismet.php\";O:8:\"stdClass\":12:{s:2:\"id\";s:21:\"w.org/plugins/akismet\";s:4:\"slug\";s:7:\"akismet\";s:6:\"plugin\";s:19:\"akismet/akismet.php\";s:11:\"new_version\";s:5:\"4.1.2\";s:3:\"url\";s:38:\"https://wordpress.org/plugins/akismet/\";s:7:\"package\";s:56:\"https://downloads.wordpress.org/plugin/akismet.4.1.2.zip\";s:5:\"icons\";a:2:{s:2:\"2x\";s:59:\"https://ps.w.org/akismet/assets/icon-256x256.png?rev=969272\";s:2:\"1x\";s:59:\"https://ps.w.org/akismet/assets/icon-128x128.png?rev=969272\";}s:7:\"banners\";a:1:{s:2:\"1x\";s:61:\"https://ps.w.org/akismet/assets/banner-772x250.jpg?rev=479904\";}s:11:\"banners_rtl\";a:0:{}s:6:\"tested\";s:5:\"5.2.3\";s:12:\"requires_php\";b:0;s:13:\"compatibility\";O:8:\"stdClass\":0:{}}s:36:\"contact-form-7/wp-contact-form-7.php\";O:8:\"stdClass\":12:{s:2:\"id\";s:28:\"w.org/plugins/contact-form-7\";s:4:\"slug\";s:14:\"contact-form-7\";s:6:\"plugin\";s:36:\"contact-form-7/wp-contact-form-7.php\";s:11:\"new_version\";s:5:\"5.1.4\";s:3:\"url\";s:45:\"https://wordpress.org/plugins/contact-form-7/\";s:7:\"package\";s:63:\"https://downloads.wordpress.org/plugin/contact-form-7.5.1.4.zip\";s:5:\"icons\";a:2:{s:2:\"2x\";s:66:\"https://ps.w.org/contact-form-7/assets/icon-256x256.png?rev=984007\";s:2:\"1x\";s:66:\"https://ps.w.org/contact-form-7/assets/icon-128x128.png?rev=984007\";}s:7:\"banners\";a:2:{s:2:\"2x\";s:69:\"https://ps.w.org/contact-form-7/assets/banner-1544x500.png?rev=860901\";s:2:\"1x\";s:68:\"https://ps.w.org/contact-form-7/assets/banner-772x250.png?rev=880427\";}s:11:\"banners_rtl\";a:0:{}s:6:\"tested\";s:5:\"5.2.3\";s:12:\"requires_php\";b:0;s:13:\"compatibility\";O:8:\"stdClass\":0:{}}s:43:\"custom-post-type-ui/custom-post-type-ui.php\";O:8:\"stdClass\":12:{s:2:\"id\";s:33:\"w.org/plugins/custom-post-type-ui\";s:4:\"slug\";s:19:\"custom-post-type-ui\";s:6:\"plugin\";s:43:\"custom-post-type-ui/custom-post-type-ui.php\";s:11:\"new_version\";s:5:\"1.6.2\";s:3:\"url\";s:50:\"https://wordpress.org/plugins/custom-post-type-ui/\";s:7:\"package\";s:68:\"https://downloads.wordpress.org/plugin/custom-post-type-ui.1.6.2.zip\";s:5:\"icons\";a:2:{s:2:\"2x\";s:72:\"https://ps.w.org/custom-post-type-ui/assets/icon-256x256.png?rev=1069557\";s:2:\"1x\";s:72:\"https://ps.w.org/custom-post-type-ui/assets/icon-128x128.png?rev=1069557\";}s:7:\"banners\";a:2:{s:2:\"2x\";s:75:\"https://ps.w.org/custom-post-type-ui/assets/banner-1544x500.png?rev=1069557\";s:2:\"1x\";s:74:\"https://ps.w.org/custom-post-type-ui/assets/banner-772x250.png?rev=1069557\";}s:11:\"banners_rtl\";a:0:{}s:6:\"tested\";s:5:\"5.2.3\";s:12:\"requires_php\";s:3:\"5.2\";s:13:\"compatibility\";O:8:\"stdClass\":0:{}}s:33:\"duplicate-post/duplicate-post.php\";O:8:\"stdClass\":13:{s:2:\"id\";s:28:\"w.org/plugins/duplicate-post\";s:4:\"slug\";s:14:\"duplicate-post\";s:6:\"plugin\";s:33:\"duplicate-post/duplicate-post.php\";s:11:\"new_version\";s:5:\"3.2.3\";s:3:\"url\";s:45:\"https://wordpress.org/plugins/duplicate-post/\";s:7:\"package\";s:63:\"https://downloads.wordpress.org/plugin/duplicate-post.3.2.3.zip\";s:5:\"icons\";a:2:{s:2:\"2x\";s:67:\"https://ps.w.org/duplicate-post/assets/icon-256x256.png?rev=1612753\";s:2:\"1x\";s:67:\"https://ps.w.org/duplicate-post/assets/icon-128x128.png?rev=1612753\";}s:7:\"banners\";a:1:{s:2:\"1x\";s:69:\"https://ps.w.org/duplicate-post/assets/banner-772x250.png?rev=1612986\";}s:11:\"banners_rtl\";a:0:{}s:14:\"upgrade_notice\";s:107:\"<p>Fixes some bugs and incompatibilities with CF7, WPML, and custom post types with custom capabilities</p>\";s:6:\"tested\";s:5:\"5.2.3\";s:12:\"requires_php\";s:5:\"5.2.4\";s:13:\"compatibility\";O:8:\"stdClass\":0:{}}s:9:\"hello.php\";O:8:\"stdClass\":12:{s:2:\"id\";s:25:\"w.org/plugins/hello-dolly\";s:4:\"slug\";s:11:\"hello-dolly\";s:6:\"plugin\";s:9:\"hello.php\";s:11:\"new_version\";s:5:\"1.7.2\";s:3:\"url\";s:42:\"https://wordpress.org/plugins/hello-dolly/\";s:7:\"package\";s:60:\"https://downloads.wordpress.org/plugin/hello-dolly.1.7.2.zip\";s:5:\"icons\";a:2:{s:2:\"2x\";s:64:\"https://ps.w.org/hello-dolly/assets/icon-256x256.jpg?rev=2052855\";s:2:\"1x\";s:64:\"https://ps.w.org/hello-dolly/assets/icon-128x128.jpg?rev=2052855\";}s:7:\"banners\";a:1:{s:2:\"1x\";s:66:\"https://ps.w.org/hello-dolly/assets/banner-772x250.jpg?rev=2052855\";}s:11:\"banners_rtl\";a:0:{}s:6:\"tested\";s:5:\"5.2.3\";s:12:\"requires_php\";b:0;s:13:\"compatibility\";O:8:\"stdClass\":0:{}}s:56:\"motopress-hotel-booking-lite/motopress-hotel-booking.php\";O:8:\"stdClass\":12:{s:2:\"id\";s:42:\"w.org/plugins/motopress-hotel-booking-lite\";s:4:\"slug\";s:28:\"motopress-hotel-booking-lite\";s:6:\"plugin\";s:56:\"motopress-hotel-booking-lite/motopress-hotel-booking.php\";s:11:\"new_version\";s:5:\"3.7.0\";s:3:\"url\";s:59:\"https://wordpress.org/plugins/motopress-hotel-booking-lite/\";s:7:\"package\";s:71:\"https://downloads.wordpress.org/plugin/motopress-hotel-booking-lite.zip\";s:5:\"icons\";a:1:{s:2:\"1x\";s:81:\"https://ps.w.org/motopress-hotel-booking-lite/assets/icon-128x128.png?rev=1852316\";}s:7:\"banners\";a:1:{s:2:\"1x\";s:83:\"https://ps.w.org/motopress-hotel-booking-lite/assets/banner-772x250.jpg?rev=1852316\";}s:11:\"banners_rtl\";a:0:{}s:6:\"tested\";s:5:\"5.2.3\";s:12:\"requires_php\";b:0;s:13:\"compatibility\";O:8:\"stdClass\":0:{}}s:37:\"mailchimp-for-wp/mailchimp-for-wp.php\";O:8:\"stdClass\":12:{s:2:\"id\";s:30:\"w.org/plugins/mailchimp-for-wp\";s:4:\"slug\";s:16:\"mailchimp-for-wp\";s:6:\"plugin\";s:37:\"mailchimp-for-wp/mailchimp-for-wp.php\";s:11:\"new_version\";s:5:\"4.5.5\";s:3:\"url\";s:47:\"https://wordpress.org/plugins/mailchimp-for-wp/\";s:7:\"package\";s:65:\"https://downloads.wordpress.org/plugin/mailchimp-for-wp.4.5.5.zip\";s:5:\"icons\";a:2:{s:2:\"2x\";s:69:\"https://ps.w.org/mailchimp-for-wp/assets/icon-256x256.png?rev=1224577\";s:2:\"1x\";s:69:\"https://ps.w.org/mailchimp-for-wp/assets/icon-128x128.png?rev=1224577\";}s:7:\"banners\";a:1:{s:2:\"1x\";s:71:\"https://ps.w.org/mailchimp-for-wp/assets/banner-772x250.png?rev=1184706\";}s:11:\"banners_rtl\";a:0:{}s:6:\"tested\";s:5:\"5.2.3\";s:12:\"requires_php\";s:3:\"5.3\";s:13:\"compatibility\";O:8:\"stdClass\":0:{}}s:25:\"profile-builder/index.php\";O:8:\"stdClass\":12:{s:2:\"id\";s:29:\"w.org/plugins/profile-builder\";s:4:\"slug\";s:15:\"profile-builder\";s:6:\"plugin\";s:25:\"profile-builder/index.php\";s:11:\"new_version\";s:5:\"3.0.5\";s:3:\"url\";s:46:\"https://wordpress.org/plugins/profile-builder/\";s:7:\"package\";s:64:\"https://downloads.wordpress.org/plugin/profile-builder.3.0.5.zip\";s:5:\"icons\";a:2:{s:2:\"2x\";s:68:\"https://ps.w.org/profile-builder/assets/icon-256x256.png?rev=1470754\";s:2:\"1x\";s:68:\"https://ps.w.org/profile-builder/assets/icon-128x128.png?rev=1470754\";}s:7:\"banners\";a:1:{s:2:\"1x\";s:70:\"https://ps.w.org/profile-builder/assets/banner-772x250.png?rev=1471307\";}s:11:\"banners_rtl\";a:0:{}s:6:\"tested\";s:5:\"5.2.3\";s:12:\"requires_php\";b:0;s:13:\"compatibility\";O:8:\"stdClass\":0:{}}s:37:\"user-role-editor/user-role-editor.php\";O:8:\"stdClass\":12:{s:2:\"id\";s:30:\"w.org/plugins/user-role-editor\";s:4:\"slug\";s:16:\"user-role-editor\";s:6:\"plugin\";s:37:\"user-role-editor/user-role-editor.php\";s:11:\"new_version\";s:6:\"4.51.3\";s:3:\"url\";s:47:\"https://wordpress.org/plugins/user-role-editor/\";s:7:\"package\";s:66:\"https://downloads.wordpress.org/plugin/user-role-editor.4.51.3.zip\";s:5:\"icons\";a:2:{s:2:\"2x\";s:69:\"https://ps.w.org/user-role-editor/assets/icon-256x256.jpg?rev=1020390\";s:2:\"1x\";s:69:\"https://ps.w.org/user-role-editor/assets/icon-128x128.jpg?rev=1020390\";}s:7:\"banners\";a:1:{s:2:\"1x\";s:71:\"https://ps.w.org/user-role-editor/assets/banner-772x250.png?rev=1263116\";}s:11:\"banners_rtl\";a:0:{}s:6:\"tested\";s:5:\"5.2.3\";s:12:\"requires_php\";s:3:\"5.5\";s:13:\"compatibility\";O:8:\"stdClass\":0:{}}s:27:\"woocommerce/woocommerce.php\";O:8:\"stdClass\":12:{s:2:\"id\";s:25:\"w.org/plugins/woocommerce\";s:4:\"slug\";s:11:\"woocommerce\";s:6:\"plugin\";s:27:\"woocommerce/woocommerce.php\";s:11:\"new_version\";s:5:\"3.7.0\";s:3:\"url\";s:42:\"https://wordpress.org/plugins/woocommerce/\";s:7:\"package\";s:60:\"https://downloads.wordpress.org/plugin/woocommerce.3.7.0.zip\";s:5:\"icons\";a:2:{s:2:\"2x\";s:64:\"https://ps.w.org/woocommerce/assets/icon-256x256.png?rev=2075035\";s:2:\"1x\";s:64:\"https://ps.w.org/woocommerce/assets/icon-128x128.png?rev=2075035\";}s:7:\"banners\";a:2:{s:2:\"2x\";s:67:\"https://ps.w.org/woocommerce/assets/banner-1544x500.png?rev=2075035\";s:2:\"1x\";s:66:\"https://ps.w.org/woocommerce/assets/banner-772x250.png?rev=2075035\";}s:11:\"banners_rtl\";a:0:{}s:6:\"tested\";s:5:\"5.2.3\";s:12:\"requires_php\";s:3:\"5.6\";s:13:\"compatibility\";O:8:\"stdClass\":0:{}}s:69:\"woo-gutenberg-products-block/woocommerce-gutenberg-products-block.php\";O:8:\"stdClass\":12:{s:2:\"id\";s:42:\"w.org/plugins/woo-gutenberg-products-block\";s:4:\"slug\";s:28:\"woo-gutenberg-products-block\";s:6:\"plugin\";s:69:\"woo-gutenberg-products-block/woocommerce-gutenberg-products-block.php\";s:11:\"new_version\";s:5:\"2.4.2\";s:3:\"url\";s:59:\"https://wordpress.org/plugins/woo-gutenberg-products-block/\";s:7:\"package\";s:77:\"https://downloads.wordpress.org/plugin/woo-gutenberg-products-block.2.4.2.zip\";s:5:\"icons\";a:2:{s:2:\"2x\";s:81:\"https://ps.w.org/woo-gutenberg-products-block/assets/icon-256x256.png?rev=1863757\";s:2:\"1x\";s:81:\"https://ps.w.org/woo-gutenberg-products-block/assets/icon-128x128.png?rev=1863757\";}s:7:\"banners\";a:1:{s:2:\"1x\";s:83:\"https://ps.w.org/woo-gutenberg-products-block/assets/banner-772x250.png?rev=1863757\";}s:11:\"banners_rtl\";a:0:{}s:6:\"tested\";s:5:\"5.2.3\";s:12:\"requires_php\";s:3:\"5.6\";s:13:\"compatibility\";O:8:\"stdClass\":0:{}}s:23:\"wp-travel/wp-travel.php\";O:8:\"stdClass\":12:{s:2:\"id\";s:23:\"w.org/plugins/wp-travel\";s:4:\"slug\";s:9:\"wp-travel\";s:6:\"plugin\";s:23:\"wp-travel/wp-travel.php\";s:11:\"new_version\";s:5:\"3.0.5\";s:3:\"url\";s:40:\"https://wordpress.org/plugins/wp-travel/\";s:7:\"package\";s:58:\"https://downloads.wordpress.org/plugin/wp-travel.3.0.5.zip\";s:5:\"icons\";a:2:{s:2:\"2x\";s:62:\"https://ps.w.org/wp-travel/assets/icon-256x256.png?rev=2119494\";s:2:\"1x\";s:62:\"https://ps.w.org/wp-travel/assets/icon-128x128.png?rev=2119494\";}s:7:\"banners\";a:2:{s:2:\"2x\";s:65:\"https://ps.w.org/wp-travel/assets/banner-1544x500.png?rev=2141785\";s:2:\"1x\";s:64:\"https://ps.w.org/wp-travel/assets/banner-772x250.png?rev=2141785\";}s:11:\"banners_rtl\";a:0:{}s:6:\"tested\";s:5:\"5.2.3\";s:12:\"requires_php\";s:3:\"5.5\";s:13:\"compatibility\";O:8:\"stdClass\":0:{}}s:25:\"wp-user-frontend/wpuf.php\";O:8:\"stdClass\":12:{s:2:\"id\";s:30:\"w.org/plugins/wp-user-frontend\";s:4:\"slug\";s:16:\"wp-user-frontend\";s:6:\"plugin\";s:25:\"wp-user-frontend/wpuf.php\";s:11:\"new_version\";s:6:\"3.1.11\";s:3:\"url\";s:47:\"https://wordpress.org/plugins/wp-user-frontend/\";s:7:\"package\";s:66:\"https://downloads.wordpress.org/plugin/wp-user-frontend.3.1.11.zip\";s:5:\"icons\";a:2:{s:2:\"2x\";s:69:\"https://ps.w.org/wp-user-frontend/assets/icon-256x256.png?rev=1458010\";s:2:\"1x\";s:69:\"https://ps.w.org/wp-user-frontend/assets/icon-128x128.png?rev=1458010\";}s:7:\"banners\";a:2:{s:2:\"2x\";s:72:\"https://ps.w.org/wp-user-frontend/assets/banner-1544x500.png?rev=1627560\";s:2:\"1x\";s:71:\"https://ps.w.org/wp-user-frontend/assets/banner-772x250.png?rev=1627560\";}s:11:\"banners_rtl\";a:0:{}s:6:\"tested\";s:5:\"5.2.3\";s:12:\"requires_php\";s:3:\"5.6\";s:13:\"compatibility\";O:8:\"stdClass\":0:{}}}s:12:\"translations\";a:0:{}s:9:\"no_update\";a:7:{s:19:\"bbpress/bbpress.php\";O:8:\"stdClass\":9:{s:2:\"id\";s:21:\"w.org/plugins/bbpress\";s:4:\"slug\";s:7:\"bbpress\";s:6:\"plugin\";s:19:\"bbpress/bbpress.php\";s:11:\"new_version\";s:6:\"2.5.14\";s:3:\"url\";s:38:\"https://wordpress.org/plugins/bbpress/\";s:7:\"package\";s:57:\"https://downloads.wordpress.org/plugin/bbpress.2.5.14.zip\";s:5:\"icons\";a:3:{s:2:\"2x\";s:60:\"https://ps.w.org/bbpress/assets/icon-256x256.png?rev=1534011\";s:2:\"1x\";s:51:\"https://ps.w.org/bbpress/assets/icon.svg?rev=978290\";s:3:\"svg\";s:51:\"https://ps.w.org/bbpress/assets/icon.svg?rev=978290\";}s:7:\"banners\";a:2:{s:2:\"2x\";s:62:\"https://ps.w.org/bbpress/assets/banner-1544x500.png?rev=567403\";s:2:\"1x\";s:61:\"https://ps.w.org/bbpress/assets/banner-772x250.png?rev=478663\";}s:11:\"banners_rtl\";a:2:{s:2:\"2x\";s:67:\"https://ps.w.org/bbpress/assets/banner-1544x500-rtl.png?rev=1534011\";s:2:\"1x\";s:66:\"https://ps.w.org/bbpress/assets/banner-772x250-rtl.png?rev=1534011\";}}s:37:\"bbp-shortcodes/bbpress-shortcodes.php\";O:8:\"stdClass\":9:{s:2:\"id\";s:28:\"w.org/plugins/bbp-shortcodes\";s:4:\"slug\";s:14:\"bbp-shortcodes\";s:6:\"plugin\";s:37:\"bbp-shortcodes/bbpress-shortcodes.php\";s:11:\"new_version\";s:3:\"1.0\";s:3:\"url\";s:45:\"https://wordpress.org/plugins/bbp-shortcodes/\";s:7:\"package\";s:61:\"https://downloads.wordpress.org/plugin/bbp-shortcodes.1.0.zip\";s:5:\"icons\";a:1:{s:7:\"default\";s:65:\"https://s.w.org/plugins/geopattern-icon/bbp-shortcodes_ffffff.svg\";}s:7:\"banners\";a:1:{s:2:\"1x\";s:69:\"https://ps.w.org/bbp-shortcodes/assets/banner-772x250.png?rev=1758636\";}s:11:\"banners_rtl\";a:0:{}}s:28:\"categorized-gallery/init.php\";O:8:\"stdClass\":9:{s:2:\"id\";s:33:\"w.org/plugins/categorized-gallery\";s:4:\"slug\";s:19:\"categorized-gallery\";s:6:\"plugin\";s:28:\"categorized-gallery/init.php\";s:11:\"new_version\";s:1:\"1\";s:3:\"url\";s:50:\"https://wordpress.org/plugins/categorized-gallery/\";s:7:\"package\";s:62:\"https://downloads.wordpress.org/plugin/categorized-gallery.zip\";s:5:\"icons\";a:1:{s:2:\"1x\";s:72:\"https://ps.w.org/categorized-gallery/assets/icon-128x128.png?rev=1692585\";}s:7:\"banners\";a:1:{s:2:\"1x\";s:74:\"https://ps.w.org/categorized-gallery/assets/banner-772x250.jpg?rev=1692526\";}s:11:\"banners_rtl\";a:0:{}}s:44:\"wp-custom-taxonomy-meta/wp-texonomy-meta.php\";O:8:\"stdClass\":9:{s:2:\"id\";s:37:\"w.org/plugins/wp-custom-taxonomy-meta\";s:4:\"slug\";s:23:\"wp-custom-taxonomy-meta\";s:6:\"plugin\";s:44:\"wp-custom-taxonomy-meta/wp-texonomy-meta.php\";s:11:\"new_version\";s:5:\"1.0.0\";s:3:\"url\";s:54:\"https://wordpress.org/plugins/wp-custom-taxonomy-meta/\";s:7:\"package\";s:66:\"https://downloads.wordpress.org/plugin/wp-custom-taxonomy-meta.zip\";s:5:\"icons\";a:1:{s:2:\"1x\";s:76:\"https://ps.w.org/wp-custom-taxonomy-meta/assets/icon-128x128.png?rev=1233807\";}s:7:\"banners\";a:1:{s:2:\"1x\";s:78:\"https://ps.w.org/wp-custom-taxonomy-meta/assets/banner-772x250.png?rev=1228029\";}s:11:\"banners_rtl\";a:0:{}}s:29:\"multi-rating/multi-rating.php\";O:8:\"stdClass\":9:{s:2:\"id\";s:26:\"w.org/plugins/multi-rating\";s:4:\"slug\";s:12:\"multi-rating\";s:6:\"plugin\";s:29:\"multi-rating/multi-rating.php\";s:11:\"new_version\";s:3:\"4.3\";s:3:\"url\";s:43:\"https://wordpress.org/plugins/multi-rating/\";s:7:\"package\";s:55:\"https://downloads.wordpress.org/plugin/multi-rating.zip\";s:5:\"icons\";a:2:{s:2:\"1x\";s:57:\"https://ps.w.org/multi-rating/assets/icon.svg?rev=1788531\";s:3:\"svg\";s:57:\"https://ps.w.org/multi-rating/assets/icon.svg?rev=1788531\";}s:7:\"banners\";a:1:{s:2:\"1x\";s:67:\"https://ps.w.org/multi-rating/assets/banner-772x250.png?rev=1509324\";}s:11:\"banners_rtl\";a:0:{}}s:29:\"site-reviews/site-reviews.php\";O:8:\"stdClass\":9:{s:2:\"id\";s:26:\"w.org/plugins/site-reviews\";s:4:\"slug\";s:12:\"site-reviews\";s:6:\"plugin\";s:29:\"site-reviews/site-reviews.php\";s:11:\"new_version\";s:5:\"3.5.4\";s:3:\"url\";s:43:\"https://wordpress.org/plugins/site-reviews/\";s:7:\"package\";s:61:\"https://downloads.wordpress.org/plugin/site-reviews.3.5.4.zip\";s:5:\"icons\";a:2:{s:2:\"2x\";s:65:\"https://ps.w.org/site-reviews/assets/icon-256x256.png?rev=1999252\";s:2:\"1x\";s:65:\"https://ps.w.org/site-reviews/assets/icon-256x256.png?rev=1999252\";}s:7:\"banners\";a:2:{s:2:\"2x\";s:68:\"https://ps.w.org/site-reviews/assets/banner-1544x500.png?rev=1521502\";s:2:\"1x\";s:67:\"https://ps.w.org/site-reviews/assets/banner-772x250.png?rev=1521502\";}s:11:\"banners_rtl\";a:0:{}}s:42:\"wordpress-social-login/wp-social-login.php\";O:8:\"stdClass\":9:{s:2:\"id\";s:36:\"w.org/plugins/wordpress-social-login\";s:4:\"slug\";s:22:\"wordpress-social-login\";s:6:\"plugin\";s:42:\"wordpress-social-login/wp-social-login.php\";s:11:\"new_version\";s:5:\"2.3.3\";s:3:\"url\";s:53:\"https://wordpress.org/plugins/wordpress-social-login/\";s:7:\"package\";s:65:\"https://downloads.wordpress.org/plugin/wordpress-social-login.zip\";s:5:\"icons\";a:2:{s:2:\"2x\";s:75:\"https://ps.w.org/wordpress-social-login/assets/icon-256x256.png?rev=1013188\";s:2:\"1x\";s:75:\"https://ps.w.org/wordpress-social-login/assets/icon-128x128.png?rev=1013190\";}s:7:\"banners\";a:1:{s:2:\"1x\";s:76:\"https://ps.w.org/wordpress-social-login/assets/banner-772x250.png?rev=503808\";}s:11:\"banners_rtl\";a:0:{}}}}', 'no'),
(28993, '_site_transient_timeout_community-events-d41d8cd98f00b204e9800998ecf8427e', '1570242166', 'no'),
(28994, '_site_transient_community-events-d41d8cd98f00b204e9800998ecf8427e', 'a:3:{s:9:\"sandboxed\";b:0;s:8:\"location\";a:1:{s:2:\"ip\";b:0;}s:6:\"events\";a:1:{i:0;a:7:{s:4:\"type\";s:8:\"wordcamp\";s:5:\"title\";s:23:\"WordCamp Kolkata, India\";s:3:\"url\";s:34:\"https://2020.kolkata.wordcamp.org/\";s:6:\"meetup\";N;s:10:\"meetup_url\";N;s:4:\"date\";s:19:\"2020-02-16 00:00:00\";s:8:\"location\";a:4:{s:8:\"location\";s:14:\"Kolkata, India\";s:7:\"country\";s:2:\"IN\";s:8:\"latitude\";d:22.5806455;s:9:\"longitude\";d:88.4761115;}}}}', 'no');

-- --------------------------------------------------------

--
-- Table structure for table `wp_p2p_relationshipmeta`
--

CREATE TABLE `wp_p2p_relationshipmeta` (
  `meta_id` bigint(20) UNSIGNED NOT NULL,
  `p2p_relationship_id` bigint(20) UNSIGNED NOT NULL,
  `meta_key` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `meta_value` longtext COLLATE utf8mb4_unicode_ci
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `wp_p2p_relationships`
--

CREATE TABLE `wp_p2p_relationships` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `type` varchar(42) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `rel_from` bigint(20) UNSIGNED NOT NULL,
  `rel_to` bigint(20) UNSIGNED NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `wp_postmeta`
--

CREATE TABLE `wp_postmeta` (
  `meta_id` bigint(20) UNSIGNED NOT NULL,
  `post_id` bigint(20) UNSIGNED NOT NULL DEFAULT '0',
  `meta_key` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `meta_value` longtext COLLATE utf8mb4_unicode_ci
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `wp_postmeta`
--

INSERT INTO `wp_postmeta` (`meta_id`, `post_id`, `meta_key`, `meta_value`) VALUES
(1, 2, '_wp_page_template', 'default'),
(7, 9, '_edit_lock', '1562093659:1'),
(8, 11, '_edit_lock', '1553855765:1'),
(9, 13, '_edit_lock', '1558509897:1'),
(10, 15, '_edit_lock', '1550567403:1'),
(12, 19, '_edit_lock', '1561735319:1'),
(13, 21, '_edit_lock', '1550567479:1'),
(14, 23, '_edit_lock', '1550567489:1'),
(15, 25, '_edit_lock', '1550567508:1'),
(79, 34, '_menu_item_type', 'post_type'),
(80, 34, '_menu_item_menu_item_parent', '0'),
(81, 34, '_menu_item_object_id', '11'),
(82, 34, '_menu_item_object', 'page'),
(83, 34, '_menu_item_target', ''),
(84, 34, '_menu_item_classes', 'a:1:{i:0;s:0:\"\";}'),
(85, 34, '_menu_item_xfn', ''),
(86, 34, '_menu_item_url', ''),
(88, 35, '_menu_item_type', 'post_type'),
(89, 35, '_menu_item_menu_item_parent', '0'),
(90, 35, '_menu_item_object_id', '9'),
(91, 35, '_menu_item_object', 'page'),
(92, 35, '_menu_item_target', ''),
(93, 35, '_menu_item_classes', 'a:1:{i:0;s:0:\"\";}'),
(94, 35, '_menu_item_xfn', ''),
(95, 35, '_menu_item_url', ''),
(106, 37, '_wp_attached_file', '2019/02/logo-white.png'),
(107, 37, '_wp_attachment_metadata', 'a:5:{s:5:\"width\";i:95;s:6:\"height\";i:20;s:4:\"file\";s:22:\"2019/02/logo-white.png\";s:5:\"sizes\";a:0:{}s:10:\"image_meta\";a:12:{s:8:\"aperture\";s:1:\"0\";s:6:\"credit\";s:0:\"\";s:6:\"camera\";s:0:\"\";s:7:\"caption\";s:0:\"\";s:17:\"created_timestamp\";s:1:\"0\";s:9:\"copyright\";s:0:\"\";s:12:\"focal_length\";s:1:\"0\";s:3:\"iso\";s:1:\"0\";s:13:\"shutter_speed\";s:1:\"0\";s:5:\"title\";s:0:\"\";s:11:\"orientation\";s:1:\"0\";s:8:\"keywords\";a:0:{}}}'),
(123, 50, '_edit_lock', '1550648570:1'),
(124, 52, '_edit_lock', '1550648607:1'),
(125, 52, '_wp_page_template', 'all_page/rental.search_result.php'),
(126, 54, '_edit_lock', '1550648630:1'),
(127, 54, '_wp_page_template', 'all_page/rental.map.php'),
(134, 62, '_edit_lock', '1558259497:1'),
(135, 62, '_wp_page_template', 'all_page/book-now.php'),
(136, 64, '_edit_lock', '1550648746:1'),
(137, 64, '_wp_page_template', 'all_page/hajj-package.php'),
(145, 74, '_edit_lock', '1550648918:1'),
(146, 74, '_wp_page_template', 'all_page/search.php'),
(147, 76, '_edit_lock', '1550648938:1'),
(148, 76, '_wp_page_template', 'all_page/sign-up.php'),
(153, 82, '_edit_lock', '1550649002:1'),
(154, 82, '_wp_page_template', 'all_page/umrah-package.php'),
(304, 150, '_wp_attached_file', '2019/02/30.jpg'),
(305, 150, '_wp_attachment_metadata', 'a:5:{s:5:\"width\";i:300;s:6:\"height\";i:300;s:4:\"file\";s:14:\"2019/02/30.jpg\";s:5:\"sizes\";a:1:{s:9:\"thumbnail\";a:4:{s:4:\"file\";s:14:\"30-150x150.jpg\";s:5:\"width\";i:150;s:6:\"height\";i:150;s:9:\"mime-type\";s:10:\"image/jpeg\";}}s:10:\"image_meta\";a:12:{s:8:\"aperture\";s:1:\"0\";s:6:\"credit\";s:0:\"\";s:6:\"camera\";s:0:\"\";s:7:\"caption\";s:0:\"\";s:17:\"created_timestamp\";s:1:\"0\";s:9:\"copyright\";s:0:\"\";s:12:\"focal_length\";s:1:\"0\";s:3:\"iso\";s:1:\"0\";s:13:\"shutter_speed\";s:1:\"0\";s:5:\"title\";s:0:\"\";s:11:\"orientation\";s:1:\"0\";s:8:\"keywords\";a:0:{}}}'),
(307, 151, '_wp_attached_file', '2019/02/thumb.jpg'),
(308, 151, '_wp_attachment_metadata', 'a:5:{s:5:\"width\";i:251;s:6:\"height\";i:188;s:4:\"file\";s:17:\"2019/02/thumb.jpg\";s:5:\"sizes\";a:4:{s:21:\"woocommerce_thumbnail\";a:5:{s:4:\"file\";s:17:\"thumb-250x188.jpg\";s:5:\"width\";i:250;s:6:\"height\";i:188;s:9:\"mime-type\";s:10:\"image/jpeg\";s:9:\"uncropped\";b:0;}s:29:\"woocommerce_gallery_thumbnail\";a:4:{s:4:\"file\";s:17:\"thumb-100x100.jpg\";s:5:\"width\";i:100;s:6:\"height\";i:100;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:9:\"thumbnail\";a:4:{s:4:\"file\";s:17:\"thumb-150x150.jpg\";s:5:\"width\";i:150;s:6:\"height\";i:150;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:7:\"300x300\";b:0;}s:10:\"image_meta\";a:12:{s:8:\"aperture\";s:1:\"0\";s:6:\"credit\";s:0:\"\";s:6:\"camera\";s:0:\"\";s:7:\"caption\";s:0:\"\";s:17:\"created_timestamp\";s:1:\"0\";s:9:\"copyright\";s:0:\"\";s:12:\"focal_length\";s:1:\"0\";s:3:\"iso\";s:1:\"0\";s:13:\"shutter_speed\";s:1:\"0\";s:5:\"title\";s:0:\"\";s:11:\"orientation\";s:1:\"0\";s:8:\"keywords\";a:0:{}}}'),
(319, 169, '_edit_last', '1'),
(320, 169, '_edit_lock', '1550910133:1'),
(358, 176, '_wp_attached_file', '2019/02/thumb_1537856321-package-image.jpg'),
(359, 176, '_wp_attachment_metadata', 'a:5:{s:5:\"width\";i:353;s:6:\"height\";i:221;s:4:\"file\";s:42:\"2019/02/thumb_1537856321-package-image.jpg\";s:5:\"sizes\";a:6:{s:18:\"woocommerce_single\";a:4:{s:4:\"file\";s:42:\"thumb_1537856321-package-image-300x188.jpg\";s:5:\"width\";i:300;s:6:\"height\";i:188;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:21:\"woocommerce_thumbnail\";a:5:{s:4:\"file\";s:42:\"thumb_1537856321-package-image-324x221.jpg\";s:5:\"width\";i:324;s:6:\"height\";i:221;s:9:\"mime-type\";s:10:\"image/jpeg\";s:9:\"uncropped\";b:0;}s:29:\"woocommerce_gallery_thumbnail\";a:4:{s:4:\"file\";s:42:\"thumb_1537856321-package-image-100x100.jpg\";s:5:\"width\";i:100;s:6:\"height\";i:100;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:9:\"thumbnail\";a:4:{s:4:\"file\";s:42:\"thumb_1537856321-package-image-150x150.jpg\";s:5:\"width\";i:150;s:6:\"height\";i:150;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:6:\"medium\";a:6:{s:4:\"file\";s:42:\"thumb_1537856321-package-image-300x188.jpg\";s:5:\"width\";i:300;s:6:\"height\";i:188;s:9:\"mime-type\";s:10:\"image/jpeg\";s:11:\"width_query\";s:3:\"300\";s:12:\"height_query\";s:3:\"300\";}s:7:\"300x300\";a:4:{s:4:\"file\";s:42:\"thumb_1537856321-package-image-300x221.jpg\";s:5:\"width\";i:300;s:6:\"height\";i:221;s:9:\"mime-type\";s:10:\"image/jpeg\";}}s:10:\"image_meta\";a:12:{s:8:\"aperture\";s:1:\"0\";s:6:\"credit\";s:0:\"\";s:6:\"camera\";s:0:\"\";s:7:\"caption\";s:0:\"\";s:17:\"created_timestamp\";s:1:\"0\";s:9:\"copyright\";s:0:\"\";s:12:\"focal_length\";s:1:\"0\";s:3:\"iso\";s:1:\"0\";s:13:\"shutter_speed\";s:1:\"0\";s:5:\"title\";s:0:\"\";s:11:\"orientation\";s:1:\"0\";s:8:\"keywords\";a:0:{}}}'),
(362, 177, '_wp_attached_file', '2019/02/thumb.jpg'),
(363, 177, '_wp_attachment_metadata', 'a:5:{s:5:\"width\";i:251;s:6:\"height\";i:188;s:4:\"file\";s:17:\"2019/02/thumb.jpg\";s:5:\"sizes\";a:4:{s:21:\"woocommerce_thumbnail\";a:5:{s:4:\"file\";s:17:\"thumb-250x188.jpg\";s:5:\"width\";i:250;s:6:\"height\";i:188;s:9:\"mime-type\";s:10:\"image/jpeg\";s:9:\"uncropped\";b:0;}s:29:\"woocommerce_gallery_thumbnail\";a:4:{s:4:\"file\";s:17:\"thumb-100x100.jpg\";s:5:\"width\";i:100;s:6:\"height\";i:100;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:9:\"thumbnail\";a:4:{s:4:\"file\";s:17:\"thumb-150x150.jpg\";s:5:\"width\";i:150;s:6:\"height\";i:150;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:7:\"300x300\";b:0;}s:10:\"image_meta\";a:12:{s:8:\"aperture\";s:1:\"0\";s:6:\"credit\";s:0:\"\";s:6:\"camera\";s:0:\"\";s:7:\"caption\";s:0:\"\";s:17:\"created_timestamp\";s:1:\"0\";s:9:\"copyright\";s:0:\"\";s:12:\"focal_length\";s:1:\"0\";s:3:\"iso\";s:1:\"0\";s:13:\"shutter_speed\";s:1:\"0\";s:5:\"title\";s:0:\"\";s:11:\"orientation\";s:1:\"0\";s:8:\"keywords\";a:0:{}}}'),
(413, 186, '_edit_lock', '1551248051:1'),
(414, 186, '_wp_page_template', 'umrah-result.php'),
(433, 196, '_edit_last', '1'),
(434, 196, '_edit_lock', '1559328535:1'),
(435, 196, '_thumbnail_id', '151'),
(436, 196, 'agentname', 'Lala International Travel & Tours Pvt Ltd (Group Of Companies).'),
(437, 196, 'makkahstay', '13Days'),
(438, 196, 'madinahstay', '15 Days'),
(439, 196, 'makkahhotelhame', 'Wafood Al Khair or Similar'),
(440, 196, 'Makkahoteldistance', '1200 Meters'),
(441, 196, 'madinahhotelname', 'Umer Hadi 1 or Similar'),
(442, 196, 'madinahhoteldistance', '1100 Meters'),
(443, 196, 'locationcheckins', '02/27/2019'),
(444, 196, 'locationcheckout', '02/28/2019'),
(445, 196, 'umrahroom', '5'),
(446, 196, 'umrahparson', '2'),
(447, 196, 'umrahdouble', '37,927.00'),
(448, 196, 'umrahtriplebed', '27,937.00'),
(449, 196, 'umrahfourbed', '23,941.00'),
(450, 196, 'umrahsharing', '20,944.00'),
(1115, 251, '_form', '<label> Your Name (required)\n    [text* your-name] </label>\n\n<label> Your Email (required)\n    [email* your-email] </label>\n\n<label> Subject\n    [text your-subject] </label>\n\n<label> Your Message\n    [textarea your-message] </label>\n\n[submit \"Send\"]'),
(1116, 251, '_mail', 'a:8:{s:7:\"subject\";s:39:\"projct new development \"[your-subject]\"\";s:6:\"sender\";s:29:\"[your-name] <admin@gmail.com>\";s:4:\"body\";s:185:\"From: [your-name] <[your-email]>\nSubject: [your-subject]\n\nMessage Body:\n[your-message]\n\n-- \nThis e-mail was sent from a contact form on projct new development (http://localhost/project)\";s:9:\"recipient\";s:15:\"admin@gmail.com\";s:18:\"additional_headers\";s:22:\"Reply-To: [your-email]\";s:11:\"attachments\";s:0:\"\";s:8:\"use_html\";i:0;s:13:\"exclude_blank\";i:0;}'),
(1117, 251, '_mail_2', 'a:9:{s:6:\"active\";b:0;s:7:\"subject\";s:39:\"projct new development \"[your-subject]\"\";s:6:\"sender\";s:40:\"projct new development <admin@gmail.com>\";s:4:\"body\";s:127:\"Message Body:\n[your-message]\n\n-- \nThis e-mail was sent from a contact form on projct new development (http://localhost/project)\";s:9:\"recipient\";s:12:\"[your-email]\";s:18:\"additional_headers\";s:25:\"Reply-To: admin@gmail.com\";s:11:\"attachments\";s:0:\"\";s:8:\"use_html\";i:0;s:13:\"exclude_blank\";i:0;}'),
(1118, 251, '_messages', 'a:8:{s:12:\"mail_sent_ok\";s:45:\"Thank you for your message. It has been sent.\";s:12:\"mail_sent_ng\";s:71:\"There was an error trying to send your message. Please try again later.\";s:16:\"validation_error\";s:61:\"One or more fields have an error. Please check and try again.\";s:4:\"spam\";s:71:\"There was an error trying to send your message. Please try again later.\";s:12:\"accept_terms\";s:69:\"You must accept the terms and conditions before sending your message.\";s:16:\"invalid_required\";s:22:\"The field is required.\";s:16:\"invalid_too_long\";s:22:\"The field is too long.\";s:17:\"invalid_too_short\";s:23:\"The field is too short.\";}'),
(1119, 251, '_additional_settings', NULL),
(1120, 251, '_locale', 'en_US'),
(1121, 252, '_vc_post_settings', 'a:1:{s:10:\"vc_grid_id\";a:0:{}}'),
(1190, 264, '_wc_review_count', '0'),
(1191, 264, '_wc_rating_count', 'a:0:{}'),
(1192, 264, '_wc_average_rating', '0'),
(1193, 264, '_edit_last', '1'),
(1194, 264, '_edit_lock', '1553801070:1'),
(1195, 264, '_thumbnail_id', '151'),
(1196, 264, '_sku', 'hjkhjk'),
(1197, 264, '_regular_price', '1500'),
(1198, 264, '_sale_price', '1200'),
(1199, 264, '_sale_price_dates_from', ''),
(1200, 264, '_sale_price_dates_to', ''),
(1201, 264, 'total_sales', '0'),
(1202, 264, '_tax_status', 'taxable'),
(1203, 264, '_tax_class', ''),
(1204, 264, '_manage_stock', 'yes'),
(1205, 264, '_backorders', 'no'),
(1206, 264, '_low_stock_amount', ''),
(1207, 264, '_sold_individually', 'yes'),
(1208, 264, '_weight', '12'),
(1209, 264, '_length', '15'),
(1210, 264, '_width', '5800'),
(1211, 264, '_height', '210'),
(1212, 264, '_upsell_ids', 'a:0:{}'),
(1213, 264, '_crosssell_ids', 'a:0:{}'),
(1214, 264, '_purchase_note', 'dsnmfkjgnfdsmg,dfmg,df'),
(1215, 264, '_default_attributes', 'a:0:{}'),
(1216, 264, '_virtual', 'no'),
(1217, 264, '_downloadable', 'no'),
(1218, 264, '_product_image_gallery', '151'),
(1219, 264, '_download_limit', '-1'),
(1220, 264, '_download_expiry', '-1'),
(1221, 264, '_stock', '4'),
(1222, 264, '_stock_status', 'instock'),
(1223, 264, '_product_version', '3.5.5'),
(1224, 264, '_price', '1200'),
(1264, 267, '_wc_review_count', '1'),
(1265, 267, '_wc_rating_count', 'a:1:{i:4;i:1;}'),
(1266, 267, '_wc_average_rating', '4.00'),
(1267, 267, '_edit_lock', '1553798806:1'),
(1268, 267, '_thumbnail_id', '176'),
(1269, 267, '_edit_last', '1'),
(1270, 267, '_sku', '34'),
(1271, 267, '_regular_price', '4000'),
(1272, 267, '_sale_price', '3500'),
(1273, 267, '_sale_price_dates_from', ''),
(1274, 267, '_sale_price_dates_to', ''),
(1275, 267, 'total_sales', '0'),
(1276, 267, '_tax_status', 'taxable'),
(1277, 267, '_tax_class', ''),
(1278, 267, '_manage_stock', 'no'),
(1279, 267, '_backorders', 'no'),
(1280, 267, '_low_stock_amount', ''),
(1281, 267, '_sold_individually', 'no'),
(1282, 267, '_weight', '45'),
(1283, 267, '_length', '400'),
(1284, 267, '_width', '300'),
(1285, 267, '_height', '200'),
(1286, 267, '_upsell_ids', 'a:0:{}'),
(1287, 267, '_crosssell_ids', 'a:0:{}'),
(1288, 267, '_purchase_note', 'My permalink structure might be the cause - but basically i have a formidable form creating a new post'),
(1289, 267, '_default_attributes', 'a:0:{}'),
(1290, 267, '_virtual', 'no'),
(1291, 267, '_downloadable', 'no'),
(1292, 267, '_product_image_gallery', '177,176,151'),
(1293, 267, '_download_limit', '-1'),
(1294, 267, '_download_expiry', '-1'),
(1295, 267, '_stock', NULL),
(1296, 267, '_stock_status', 'instock'),
(1297, 267, '_product_version', '3.5.5'),
(1298, 267, '_price', '3500'),
(1299, 267, 'agentname', 'Flying World Travels'),
(1300, 267, 'makkahstay', '12'),
(1301, 267, 'madinahstay', '12'),
(1302, 267, 'makkahhotelhame', 'Le Meridian Hotel 5 Star'),
(1303, 267, 'Makkahoteldistance', '600'),
(1304, 267, 'madinahhotelname', 'Le Meridian Hotel 5 Star'),
(1305, 267, 'madinahhoteldistance', '500'),
(1306, 267, 'locationcheckins', '03/03/2019'),
(1307, 267, 'locationcheckout', '03/15/2019'),
(1308, 267, 'umrahroom', '10'),
(1309, 267, 'umrahparson', '6'),
(1310, 267, 'umrahdouble', '35,000.00'),
(1311, 267, 'umrahtriplebed', '45,000.00'),
(1312, 267, 'umrahfourbed', '50,000.00'),
(1313, 267, 'umrahsharing', '60,000.00'),
(1331, 274, '_edit_last', '1'),
(1332, 274, '_edit_lock', '1551554104:1'),
(1333, 274, 'discount_type', 'fixed_cart'),
(1334, 274, 'coupon_amount', '1200'),
(1335, 274, 'individual_use', 'no'),
(1336, 274, 'product_ids', ''),
(1337, 274, 'exclude_product_ids', ''),
(1338, 274, 'usage_limit', '0'),
(1339, 274, 'usage_limit_per_user', '0'),
(1340, 274, 'limit_usage_to_x_items', '0'),
(1341, 274, 'usage_count', '0'),
(1342, 274, 'date_expires', '1552003200'),
(1343, 274, 'expiry_date', '2019-03-08'),
(1344, 274, 'free_shipping', 'yes'),
(1345, 274, 'product_categories', 'a:0:{}'),
(1346, 274, 'exclude_product_categories', 'a:0:{}'),
(1347, 274, 'exclude_sale_items', 'no'),
(1348, 274, 'minimum_amount', ''),
(1349, 274, 'maximum_amount', ''),
(1350, 274, 'customer_email', 'a:0:{}'),
(1399, 198, '_edit_lock', '1551606472:1'),
(1400, 198, '_wp_page_template', 'cart.php'),
(1421, 290, '_edit_lock', '1551612198:1'),
(1431, 290, '_wp_page_template', 'checkout.php'),
(1457, 263, '_wc_review_count', '0'),
(1458, 263, '_wc_rating_count', 'a:0:{}'),
(1459, 263, '_wc_average_rating', '0'),
(1466, 306, '_edit_last', '1'),
(1467, 306, '_edit_lock', '1553537559:1'),
(1469, 308, '_edit_lock', '1551873824:1'),
(1470, 306, '_wp_old_date', '2019-03-05'),
(1471, 324, '_edit_last', '1'),
(1472, 324, '_edit_lock', '1553775625:1'),
(1483, 328, '_wp_attached_file', '2019/03/800x600-1.jpg'),
(1484, 328, '_wp_attachment_metadata', 'a:5:{s:5:\"width\";i:800;s:6:\"height\";i:600;s:4:\"file\";s:21:\"2019/03/800x600-1.jpg\";s:5:\"sizes\";a:10:{s:21:\"woocommerce_thumbnail\";a:5:{s:4:\"file\";s:21:\"800x600-1-450x450.jpg\";s:5:\"width\";i:450;s:6:\"height\";i:450;s:9:\"mime-type\";s:10:\"image/jpeg\";s:9:\"uncropped\";b:0;}s:18:\"woocommerce_single\";a:4:{s:4:\"file\";s:21:\"800x600-1-300x225.jpg\";s:5:\"width\";i:300;s:6:\"height\";i:225;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:9:\"thumbnail\";a:4:{s:4:\"file\";s:21:\"800x600-1-150x150.jpg\";s:5:\"width\";i:150;s:6:\"height\";i:150;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:6:\"medium\";a:6:{s:4:\"file\";s:21:\"800x600-1-300x225.jpg\";s:5:\"width\";i:300;s:6:\"height\";i:225;s:9:\"mime-type\";s:10:\"image/jpeg\";s:11:\"width_query\";s:3:\"300\";s:12:\"height_query\";s:3:\"300\";}s:12:\"medium_large\";a:4:{s:4:\"file\";s:21:\"800x600-1-768x576.jpg\";s:5:\"width\";i:768;s:6:\"height\";i:576;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:29:\"woocommerce_gallery_thumbnail\";a:4:{s:4:\"file\";s:21:\"800x600-1-100x100.jpg\";s:5:\"width\";i:100;s:6:\"height\";i:100;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:12:\"shop_catalog\";a:5:{s:4:\"file\";s:21:\"800x600-1-450x450.jpg\";s:5:\"width\";i:450;s:6:\"height\";i:450;s:9:\"mime-type\";s:10:\"image/jpeg\";s:9:\"uncropped\";b:0;}s:11:\"shop_single\";a:4:{s:4:\"file\";s:21:\"800x600-1-300x225.jpg\";s:5:\"width\";i:300;s:6:\"height\";i:225;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:14:\"shop_thumbnail\";a:4:{s:4:\"file\";s:21:\"800x600-1-100x100.jpg\";s:5:\"width\";i:100;s:6:\"height\";i:100;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:7:\"300x300\";a:4:{s:4:\"file\";s:21:\"800x600-1-300x300.jpg\";s:5:\"width\";i:300;s:6:\"height\";i:300;s:9:\"mime-type\";s:10:\"image/jpeg\";}}s:10:\"image_meta\";a:12:{s:8:\"aperture\";s:1:\"0\";s:6:\"credit\";s:0:\"\";s:6:\"camera\";s:0:\"\";s:7:\"caption\";s:0:\"\";s:17:\"created_timestamp\";s:1:\"0\";s:9:\"copyright\";s:0:\"\";s:12:\"focal_length\";s:1:\"0\";s:3:\"iso\";s:1:\"0\";s:13:\"shutter_speed\";s:1:\"0\";s:5:\"title\";s:0:\"\";s:11:\"orientation\";s:1:\"0\";s:8:\"keywords\";a:0:{}}}'),
(1485, 329, '_wp_attached_file', '2019/03/orea.jpg'),
(1486, 329, '_wp_attachment_metadata', 'a:5:{s:5:\"width\";i:300;s:6:\"height\";i:145;s:4:\"file\";s:16:\"2019/03/orea.jpg\";s:5:\"sizes\";a:6:{s:9:\"thumbnail\";a:4:{s:4:\"file\";s:16:\"orea-150x145.jpg\";s:5:\"width\";i:150;s:6:\"height\";i:145;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:6:\"medium\";a:4:{s:4:\"file\";s:16:\"orea-300x145.jpg\";s:5:\"width\";i:300;s:6:\"height\";i:145;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:18:\"woocommerce_single\";a:4:{s:4:\"file\";s:16:\"orea-300x145.jpg\";s:5:\"width\";i:300;s:6:\"height\";i:145;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:29:\"woocommerce_gallery_thumbnail\";a:4:{s:4:\"file\";s:16:\"orea-100x100.jpg\";s:5:\"width\";i:100;s:6:\"height\";i:100;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:11:\"shop_single\";a:4:{s:4:\"file\";s:16:\"orea-300x145.jpg\";s:5:\"width\";i:300;s:6:\"height\";i:145;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:14:\"shop_thumbnail\";a:4:{s:4:\"file\";s:16:\"orea-100x100.jpg\";s:5:\"width\";i:100;s:6:\"height\";i:100;s:9:\"mime-type\";s:10:\"image/jpeg\";}}s:10:\"image_meta\";a:12:{s:8:\"aperture\";s:1:\"0\";s:6:\"credit\";s:0:\"\";s:6:\"camera\";s:0:\"\";s:7:\"caption\";s:0:\"\";s:17:\"created_timestamp\";s:1:\"0\";s:9:\"copyright\";s:0:\"\";s:12:\"focal_length\";s:1:\"0\";s:3:\"iso\";s:1:\"0\";s:13:\"shutter_speed\";s:1:\"0\";s:5:\"title\";s:0:\"\";s:11:\"orientation\";s:1:\"0\";s:8:\"keywords\";a:0:{}}}'),
(1487, 306, '_thumbnail_id', '328'),
(1488, 306, 'agentname', 'Maserati'),
(1489, 306, 'agentlocation', 'Mirpur, Dhaka'),
(1490, 306, 'agentemail', 'abc@domain.com'),
(1491, 306, 'agentphone', '+123456789'),
(1492, 306, 'agentlogo_id', '329'),
(1493, 306, 'agentlogo', 'http://localhost:8080/project/wp-content/uploads/2019/03/orea.jpg'),
(1494, 306, 'oldprice', '70,000.00'),
(1495, 306, 'presentprice', '60,000.00'),
(1496, 306, 'Makkahoteldistance', '5,000.00'),
(1497, 306, 'madinahhotelname', '4,000.00'),
(1498, 306, 'madinahhoteldistance', '4,500.00'),
(1499, 306, 'locationmap', '3,000.00'),
(1500, 306, 'carequipment', 'FREE'),
(1501, 306, 'cardescription', 'Arrive at your destination in style with this air-conditioned automatic. With room for 4 passengers and 2 pieces of luggage, it\'s ideal for small groups looking to get from A to B in comfort. Price can change at any moment so book now to avoid disappointment!'),
(1502, 330, '_edit_lock', '1553538192:1'),
(1503, 330, '_wp_page_template', 'advancedsearch.php'),
(1504, 337, '_edit_last', '1'),
(1505, 337, '_edit_lock', '1558757552:1'),
(1506, 338, '_wp_attached_file', '2019/03/palace-park-versailles-5-800x600.jpg'),
(1507, 338, '_wp_attachment_metadata', 'a:5:{s:5:\"width\";i:800;s:6:\"height\";i:600;s:4:\"file\";s:44:\"2019/03/palace-park-versailles-5-800x600.jpg\";s:5:\"sizes\";a:9:{s:9:\"thumbnail\";a:4:{s:4:\"file\";s:44:\"palace-park-versailles-5-800x600-150x150.jpg\";s:5:\"width\";i:150;s:6:\"height\";i:150;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:6:\"medium\";a:4:{s:4:\"file\";s:44:\"palace-park-versailles-5-800x600-300x225.jpg\";s:5:\"width\";i:300;s:6:\"height\";i:225;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:12:\"medium_large\";a:4:{s:4:\"file\";s:44:\"palace-park-versailles-5-800x600-768x576.jpg\";s:5:\"width\";i:768;s:6:\"height\";i:576;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:21:\"woocommerce_thumbnail\";a:5:{s:4:\"file\";s:44:\"palace-park-versailles-5-800x600-450x450.jpg\";s:5:\"width\";i:450;s:6:\"height\";i:450;s:9:\"mime-type\";s:10:\"image/jpeg\";s:9:\"uncropped\";b:0;}s:18:\"woocommerce_single\";a:4:{s:4:\"file\";s:44:\"palace-park-versailles-5-800x600-300x225.jpg\";s:5:\"width\";i:300;s:6:\"height\";i:225;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:29:\"woocommerce_gallery_thumbnail\";a:4:{s:4:\"file\";s:44:\"palace-park-versailles-5-800x600-100x100.jpg\";s:5:\"width\";i:100;s:6:\"height\";i:100;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:12:\"shop_catalog\";a:4:{s:4:\"file\";s:44:\"palace-park-versailles-5-800x600-450x450.jpg\";s:5:\"width\";i:450;s:6:\"height\";i:450;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:11:\"shop_single\";a:4:{s:4:\"file\";s:44:\"palace-park-versailles-5-800x600-300x225.jpg\";s:5:\"width\";i:300;s:6:\"height\";i:225;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:14:\"shop_thumbnail\";a:4:{s:4:\"file\";s:44:\"palace-park-versailles-5-800x600-100x100.jpg\";s:5:\"width\";i:100;s:6:\"height\";i:100;s:9:\"mime-type\";s:10:\"image/jpeg\";}}s:10:\"image_meta\";a:12:{s:8:\"aperture\";s:1:\"0\";s:6:\"credit\";s:0:\"\";s:6:\"camera\";s:0:\"\";s:7:\"caption\";s:0:\"\";s:17:\"created_timestamp\";s:1:\"0\";s:9:\"copyright\";s:0:\"\";s:12:\"focal_length\";s:1:\"0\";s:3:\"iso\";s:1:\"0\";s:13:\"shutter_speed\";s:1:\"0\";s:5:\"title\";s:0:\"\";s:11:\"orientation\";s:1:\"0\";s:8:\"keywords\";a:0:{}}}'),
(1508, 337, '_thumbnail_id', '351'),
(1509, 337, 'toursdeparturedate', '03/28/2019'),
(1510, 337, 'toursarrivedate', '04/24/2019'),
(1511, 337, 'toursname', 'Versailles Small Trip'),
(1512, 337, 'toursemail', 'test@gmail.com'),
(1513, 337, 'tourlocation', 'Cursus faucibus egestas rutrum mauris vulputate consequat ante'),
(1514, 337, 'toursprice', '780,000.00'),
(1515, 337, 'tourstype', 'Specific Date'),
(1516, 337, 'maximumnumberof', '3'),
(1517, 337, 'toursoverview', 'At qui elit nobis legimus, at eum partiendo disputando. Sit id dicunt viderer, animal suscipit voluptaria est te. Ad mollis scriptorem eos, pri id velit ludus. Cum minim nostro constituto in, ex vim bonorum tacimates referrentur. Eum ut quodsi regione adolescens. Vel ei partem accommodare, mucius facete atomorum ius no, cu quo sonet eligendi officiis'),
(1518, 337, 'toursdayone', 'Ridens reprimique sed ei, ei qui dicta officiis. Dicat intellegebat vim in, at fastidii prodesset gloriatur qui, sed dicam eripuit necessitatibus an. Has ex enim adolescens vituperata. Nam malorum debitis reprimique no, quaestio percipitur referrentur pro te.\r\n\r\n&nbsp;'),
(1519, 337, 'toursdaytwo', 'Ridens reprimique sed ei, ei qui dicta officiis. Dicat intellegebat vim in, at fastidii prodesset gloriatur qui, sed dicam eripuit necessitatibus an. Has ex enim adolescens vituperata. Nam malorum debitis reprimique no, quaestio percipitur referrentur pro te.\r\n\r\n&nbsp;'),
(1520, 337, 'toursdaythress', 'Ridens reprimique sed ei, ei qui dicta officiis. Dicat intellegebat vim in, at fastidii prodesset gloriatur qui, sed dicam eripuit necessitatibus an. Has ex enim adolescens vituperata. Nam malorum debitis reprimique no, quaestio percipitur referrentur pro te.\r\n\r\n&nbsp;'),
(1521, 337, 'toursdayfour', 'Ridens reprimique sed ei, ei qui dicta officiis. Dicat intellegebat vim in, at fastidii prodesset gloriatur qui, sed dicam eripuit necessitatibus an. Has ex enim adolescens vituperata. Nam malorum debitis reprimique no, quaestio percipitur referrentur pro te.\r\n\r\n&nbsp;'),
(1527, 343, '_edit_last', '1'),
(1528, 343, '_edit_lock', '1553774826:1'),
(1529, 344, '_wp_attached_file', '2019/03/demo2.png'),
(1530, 344, '_wp_attachment_metadata', 'a:5:{s:5:\"width\";i:400;s:6:\"height\";i:291;s:4:\"file\";s:17:\"2019/03/demo2.png\";s:5:\"sizes\";a:7:{s:18:\"woocommerce_single\";a:4:{s:4:\"file\";s:17:\"demo2-300x218.png\";s:5:\"width\";i:300;s:6:\"height\";i:218;s:9:\"mime-type\";s:9:\"image/png\";}s:21:\"woocommerce_thumbnail\";a:5:{s:4:\"file\";s:17:\"demo2-324x291.png\";s:5:\"width\";i:324;s:6:\"height\";i:291;s:9:\"mime-type\";s:9:\"image/png\";s:9:\"uncropped\";b:0;}s:9:\"thumbnail\";a:4:{s:4:\"file\";s:17:\"demo2-150x150.png\";s:5:\"width\";i:150;s:6:\"height\";i:150;s:9:\"mime-type\";s:9:\"image/png\";}s:6:\"medium\";a:6:{s:4:\"file\";s:17:\"demo2-300x218.png\";s:5:\"width\";i:300;s:6:\"height\";i:218;s:9:\"mime-type\";s:9:\"image/png\";s:11:\"width_query\";s:3:\"300\";s:12:\"height_query\";s:3:\"300\";}s:29:\"woocommerce_gallery_thumbnail\";a:4:{s:4:\"file\";s:17:\"demo2-100x100.png\";s:5:\"width\";i:100;s:6:\"height\";i:100;s:9:\"mime-type\";s:9:\"image/png\";}s:11:\"shop_single\";a:4:{s:4:\"file\";s:17:\"demo2-300x218.png\";s:5:\"width\";i:300;s:6:\"height\";i:218;s:9:\"mime-type\";s:9:\"image/png\";}s:14:\"shop_thumbnail\";a:4:{s:4:\"file\";s:17:\"demo2-100x100.png\";s:5:\"width\";i:100;s:6:\"height\";i:100;s:9:\"mime-type\";s:9:\"image/png\";}}s:10:\"image_meta\";a:12:{s:8:\"aperture\";s:1:\"0\";s:6:\"credit\";s:0:\"\";s:6:\"camera\";s:0:\"\";s:7:\"caption\";s:0:\"\";s:17:\"created_timestamp\";s:1:\"0\";s:9:\"copyright\";s:0:\"\";s:12:\"focal_length\";s:1:\"0\";s:3:\"iso\";s:1:\"0\";s:13:\"shutter_speed\";s:1:\"0\";s:5:\"title\";s:0:\"\";s:11:\"orientation\";s:1:\"0\";s:8:\"keywords\";a:0:{}}}'),
(1531, 345, '_wp_attached_file', '2019/03/800x600-1.jpg'),
(1532, 345, '_wp_attachment_metadata', 'a:5:{s:5:\"width\";i:800;s:6:\"height\";i:600;s:4:\"file\";s:21:\"2019/03/800x600-1.jpg\";s:5:\"sizes\";a:9:{s:21:\"woocommerce_thumbnail\";a:5:{s:4:\"file\";s:21:\"800x600-1-450x450.jpg\";s:5:\"width\";i:450;s:6:\"height\";i:450;s:9:\"mime-type\";s:10:\"image/jpeg\";s:9:\"uncropped\";b:0;}s:18:\"woocommerce_single\";a:4:{s:4:\"file\";s:21:\"800x600-1-300x225.jpg\";s:5:\"width\";i:300;s:6:\"height\";i:225;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:9:\"thumbnail\";a:4:{s:4:\"file\";s:21:\"800x600-1-150x150.jpg\";s:5:\"width\";i:150;s:6:\"height\";i:150;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:6:\"medium\";a:6:{s:4:\"file\";s:21:\"800x600-1-300x225.jpg\";s:5:\"width\";i:300;s:6:\"height\";i:225;s:9:\"mime-type\";s:10:\"image/jpeg\";s:11:\"width_query\";s:3:\"300\";s:12:\"height_query\";s:3:\"300\";}s:12:\"medium_large\";a:4:{s:4:\"file\";s:21:\"800x600-1-768x576.jpg\";s:5:\"width\";i:768;s:6:\"height\";i:576;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:29:\"woocommerce_gallery_thumbnail\";a:4:{s:4:\"file\";s:21:\"800x600-1-100x100.jpg\";s:5:\"width\";i:100;s:6:\"height\";i:100;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:12:\"shop_catalog\";a:5:{s:4:\"file\";s:21:\"800x600-1-450x450.jpg\";s:5:\"width\";i:450;s:6:\"height\";i:450;s:9:\"mime-type\";s:10:\"image/jpeg\";s:9:\"uncropped\";b:0;}s:11:\"shop_single\";a:4:{s:4:\"file\";s:21:\"800x600-1-300x225.jpg\";s:5:\"width\";i:300;s:6:\"height\";i:225;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:14:\"shop_thumbnail\";a:4:{s:4:\"file\";s:21:\"800x600-1-100x100.jpg\";s:5:\"width\";i:100;s:6:\"height\";i:100;s:9:\"mime-type\";s:10:\"image/jpeg\";}}s:10:\"image_meta\";a:12:{s:8:\"aperture\";s:1:\"0\";s:6:\"credit\";s:0:\"\";s:6:\"camera\";s:0:\"\";s:7:\"caption\";s:0:\"\";s:17:\"created_timestamp\";s:1:\"0\";s:9:\"copyright\";s:0:\"\";s:12:\"focal_length\";s:1:\"0\";s:3:\"iso\";s:1:\"0\";s:13:\"shutter_speed\";s:1:\"0\";s:5:\"title\";s:0:\"\";s:11:\"orientation\";s:1:\"0\";s:8:\"keywords\";a:0:{}}}'),
(1533, 343, '_thumbnail_id', '345'),
(1534, 343, 'agentname', 'Lorem Ipsum'),
(1535, 343, 'agentlocation', 'Dhaka'),
(1536, 343, 'agentemail', 'milon@weblinkltd.com'),
(1537, 343, 'agentphone', '01736699819'),
(1538, 343, 'agentlogo_id', '344'),
(1539, 343, 'agentlogo', 'http://localhost/project/wp-content/uploads/2019/03/demo2.png'),
(1540, 343, 'oldprice', '12,000.00'),
(1541, 343, 'presentprice', '10,000.00'),
(1542, 343, 'Makkahoteldistance', '1,523.00'),
(1543, 343, 'madinahhotelname', '1,212.00'),
(1544, 343, 'madinahhoteldistance', '12,121.00'),
(1545, 343, 'locationmap', '12.00'),
(1546, 343, 'carequipment', 'Free'),
(1547, 343, 'cardescription', '<strong>Lorem Ipsum</strong> is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry\'s standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book. It has survived not only five centuries, but also the leap into electronic typesetting, remaining essentially unchanged. It was popularised in the 1960s with the release of Letraset sheets containing Lorem Ipsum passages, and more recently with desktop publishing software like Aldus PageMaker including versions of Lorem Ipsum.'),
(1548, 346, '_wp_attached_file', '2019/03/br1-1.jpg'),
(1549, 346, '_wp_attachment_metadata', 'a:5:{s:5:\"width\";i:120;s:6:\"height\";i:120;s:4:\"file\";s:17:\"2019/03/br1-1.jpg\";s:5:\"sizes\";a:2:{s:29:\"woocommerce_gallery_thumbnail\";a:4:{s:4:\"file\";s:17:\"br1-1-100x100.jpg\";s:5:\"width\";i:100;s:6:\"height\";i:100;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:14:\"shop_thumbnail\";a:4:{s:4:\"file\";s:17:\"br1-1-100x100.jpg\";s:5:\"width\";i:100;s:6:\"height\";i:100;s:9:\"mime-type\";s:10:\"image/jpeg\";}}s:10:\"image_meta\";a:12:{s:8:\"aperture\";s:1:\"0\";s:6:\"credit\";s:0:\"\";s:6:\"camera\";s:0:\"\";s:7:\"caption\";s:0:\"\";s:17:\"created_timestamp\";s:1:\"0\";s:9:\"copyright\";s:0:\"\";s:12:\"focal_length\";s:1:\"0\";s:3:\"iso\";s:1:\"0\";s:13:\"shutter_speed\";s:1:\"0\";s:5:\"title\";s:0:\"\";s:11:\"orientation\";s:1:\"0\";s:8:\"keywords\";a:0:{}}}'),
(1550, 347, '_wp_attached_file', '2019/03/7478-143x71-1.jpg'),
(1551, 347, '_wp_attachment_metadata', 'a:5:{s:5:\"width\";i:143;s:6:\"height\";i:71;s:4:\"file\";s:25:\"2019/03/7478-143x71-1.jpg\";s:5:\"sizes\";a:2:{s:29:\"woocommerce_gallery_thumbnail\";a:4:{s:4:\"file\";s:24:\"7478-143x71-1-100x71.jpg\";s:5:\"width\";i:100;s:6:\"height\";i:71;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:14:\"shop_thumbnail\";a:4:{s:4:\"file\";s:24:\"7478-143x71-1-100x71.jpg\";s:5:\"width\";i:100;s:6:\"height\";i:71;s:9:\"mime-type\";s:10:\"image/jpeg\";}}s:10:\"image_meta\";a:12:{s:8:\"aperture\";s:1:\"0\";s:6:\"credit\";s:0:\"\";s:6:\"camera\";s:0:\"\";s:7:\"caption\";s:0:\"\";s:17:\"created_timestamp\";s:1:\"0\";s:9:\"copyright\";s:0:\"\";s:12:\"focal_length\";s:1:\"0\";s:3:\"iso\";s:1:\"0\";s:13:\"shutter_speed\";s:1:\"0\";s:5:\"title\";s:0:\"\";s:11:\"orientation\";s:1:\"0\";s:8:\"keywords\";a:0:{}}}'),
(1552, 324, '_thumbnail_id', '345'),
(1553, 324, 'agentname', 'weblink'),
(1554, 324, 'agentlocation', 'Banani'),
(1555, 324, 'agentemail', 'weblimk@gmail.com'),
(1556, 324, 'agentphone', '12345678912'),
(1557, 324, 'agentlogo_id', '346'),
(1558, 324, 'agentlogo', 'http://localhost/project/wp-content/uploads/2019/03/br1-1.jpg'),
(1559, 324, 'oldprice', '21,212.00'),
(1560, 324, 'presentprice', '12,212.00'),
(1561, 324, 'Makkahoteldistance', '21,212.00'),
(1562, 324, 'madinahhotelname', '21,212.00'),
(1563, 324, 'madinahhoteldistance', '12,212.00'),
(1564, 324, 'locationmap', '212.00'),
(1565, 324, 'carequipment', 'Free'),
(1566, 324, 'cardescription', '<strong>Lorem Ipsum</strong> is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry\'s standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book. It has survived not only five centuries, but also the leap into electronic typesetting, remaining essentially unchanged. It was popularised in the 1960s with the release of Letraset sheets containing Lorem Ipsum passages, and more recently with desktop publishing software like Aldus PageMaker including versions of Lorem Ipsum.'),
(1567, 348, '_wp_attached_file', '2019/03/3-1.jpg'),
(1568, 348, '_wp_attachment_metadata', 'a:5:{s:5:\"width\";i:263;s:6:\"height\";i:197;s:4:\"file\";s:15:\"2019/03/3-1.jpg\";s:5:\"sizes\";a:5:{s:21:\"woocommerce_thumbnail\";a:5:{s:4:\"file\";s:15:\"3-1-250x197.jpg\";s:5:\"width\";i:250;s:6:\"height\";i:197;s:9:\"mime-type\";s:10:\"image/jpeg\";s:9:\"uncropped\";b:0;}s:9:\"thumbnail\";a:4:{s:4:\"file\";s:15:\"3-1-150x150.jpg\";s:5:\"width\";i:150;s:6:\"height\";i:150;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:29:\"woocommerce_gallery_thumbnail\";a:4:{s:4:\"file\";s:15:\"3-1-100x100.jpg\";s:5:\"width\";i:100;s:6:\"height\";i:100;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:14:\"shop_thumbnail\";a:4:{s:4:\"file\";s:15:\"3-1-100x100.jpg\";s:5:\"width\";i:100;s:6:\"height\";i:100;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:7:\"266x266\";b:0;}s:10:\"image_meta\";a:12:{s:8:\"aperture\";s:1:\"0\";s:6:\"credit\";s:0:\"\";s:6:\"camera\";s:0:\"\";s:7:\"caption\";s:0:\"\";s:17:\"created_timestamp\";s:1:\"0\";s:9:\"copyright\";s:0:\"\";s:12:\"focal_length\";s:1:\"0\";s:3:\"iso\";s:1:\"0\";s:13:\"shutter_speed\";s:1:\"0\";s:5:\"title\";s:0:\"\";s:11:\"orientation\";s:1:\"0\";s:8:\"keywords\";a:0:{}}}'),
(1572, 350, '_sku', '34-1'),
(1573, 350, '_regular_price', '4000'),
(1574, 350, '_sale_price', '3500'),
(1575, 350, '_sale_price_dates_from', ''),
(1576, 350, '_sale_price_dates_to', ''),
(1577, 350, 'total_sales', '0'),
(1578, 350, '_tax_status', 'taxable'),
(1579, 350, '_tax_class', ''),
(1580, 350, '_manage_stock', 'no'),
(1581, 350, '_backorders', 'no'),
(1582, 350, '_low_stock_amount', ''),
(1583, 350, '_sold_individually', 'no'),
(1584, 350, '_weight', '45'),
(1585, 350, '_length', '400'),
(1586, 350, '_width', '300'),
(1587, 350, '_height', '200'),
(1588, 350, '_upsell_ids', 'a:0:{}'),
(1589, 350, '_crosssell_ids', 'a:0:{}'),
(1590, 350, '_purchase_note', 'My permalink structure might be the cause - but basically i have a formidable form creating a new post'),
(1591, 350, '_default_attributes', 'a:0:{}'),
(1592, 350, '_virtual', 'no'),
(1593, 350, '_downloadable', 'no'),
(1594, 350, '_product_image_gallery', '177,176,151'),
(1595, 350, '_download_limit', '-1'),
(1596, 350, '_download_expiry', '-1'),
(1597, 350, '_thumbnail_id', '345'),
(1598, 350, '_stock', NULL),
(1599, 350, '_stock_status', 'instock'),
(1600, 350, '_wc_average_rating', '0'),
(1601, 350, '_wc_rating_count', 'a:0:{}'),
(1602, 350, '_wc_review_count', '0'),
(1603, 350, '_downloadable_files', 'a:0:{}'),
(1604, 350, '_product_attributes', 'a:0:{}'),
(1605, 350, '_product_version', '3.5.5'),
(1606, 350, '_price', '3500'),
(1607, 350, 'agentname', 'Flying World Travels'),
(1608, 350, 'makkahstay', '12'),
(1609, 350, 'madinahstay', '12'),
(1610, 350, 'makkahhotelhame', 'Le Meridian Hotel 5 Star'),
(1611, 350, 'Makkahoteldistance', '600'),
(1612, 350, 'madinahhotelname', 'Le Meridian Hotel 5 Star'),
(1613, 350, 'madinahhoteldistance', '500'),
(1614, 350, 'locationcheckins', '03/03/2019'),
(1615, 350, 'locationcheckout', '03/15/2019'),
(1616, 350, 'umrahroom', '10'),
(1617, 350, 'umrahparson', '6'),
(1618, 350, 'umrahdouble', '35,000.00'),
(1619, 350, 'umrahtriplebed', '45,000.00'),
(1620, 350, 'umrahfourbed', '50,000.00'),
(1621, 350, 'umrahsharing', '60,000.00'),
(1622, 350, '_edit_lock', '1553800040:1'),
(1623, 350, '_edit_last', '1'),
(1624, 351, '_wp_attached_file', '2019/03/palace-park-versailles-5-800x600.jpg'),
(1625, 351, '_wp_attachment_metadata', 'a:5:{s:5:\"width\";i:800;s:6:\"height\";i:600;s:4:\"file\";s:44:\"2019/03/palace-park-versailles-5-800x600.jpg\";s:5:\"sizes\";a:9:{s:9:\"thumbnail\";a:4:{s:4:\"file\";s:44:\"palace-park-versailles-5-800x600-150x150.jpg\";s:5:\"width\";i:150;s:6:\"height\";i:150;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:6:\"medium\";a:4:{s:4:\"file\";s:44:\"palace-park-versailles-5-800x600-300x225.jpg\";s:5:\"width\";i:300;s:6:\"height\";i:225;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:12:\"medium_large\";a:4:{s:4:\"file\";s:44:\"palace-park-versailles-5-800x600-768x576.jpg\";s:5:\"width\";i:768;s:6:\"height\";i:576;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:21:\"woocommerce_thumbnail\";a:5:{s:4:\"file\";s:44:\"palace-park-versailles-5-800x600-450x450.jpg\";s:5:\"width\";i:450;s:6:\"height\";i:450;s:9:\"mime-type\";s:10:\"image/jpeg\";s:9:\"uncropped\";b:0;}s:18:\"woocommerce_single\";a:4:{s:4:\"file\";s:44:\"palace-park-versailles-5-800x600-300x225.jpg\";s:5:\"width\";i:300;s:6:\"height\";i:225;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:29:\"woocommerce_gallery_thumbnail\";a:4:{s:4:\"file\";s:44:\"palace-park-versailles-5-800x600-100x100.jpg\";s:5:\"width\";i:100;s:6:\"height\";i:100;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:12:\"shop_catalog\";a:4:{s:4:\"file\";s:44:\"palace-park-versailles-5-800x600-450x450.jpg\";s:5:\"width\";i:450;s:6:\"height\";i:450;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:11:\"shop_single\";a:4:{s:4:\"file\";s:44:\"palace-park-versailles-5-800x600-300x225.jpg\";s:5:\"width\";i:300;s:6:\"height\";i:225;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:14:\"shop_thumbnail\";a:4:{s:4:\"file\";s:44:\"palace-park-versailles-5-800x600-100x100.jpg\";s:5:\"width\";i:100;s:6:\"height\";i:100;s:9:\"mime-type\";s:10:\"image/jpeg\";}}s:10:\"image_meta\";a:12:{s:8:\"aperture\";s:1:\"0\";s:6:\"credit\";s:0:\"\";s:6:\"camera\";s:0:\"\";s:7:\"caption\";s:0:\"\";s:17:\"created_timestamp\";s:1:\"0\";s:9:\"copyright\";s:0:\"\";s:12:\"focal_length\";s:1:\"0\";s:3:\"iso\";s:1:\"0\";s:13:\"shutter_speed\";s:1:\"0\";s:5:\"title\";s:0:\"\";s:11:\"orientation\";s:1:\"0\";s:8:\"keywords\";a:0:{}}}'),
(1626, 352, '_edit_last', '1'),
(1627, 352, '_edit_lock', '1558757451:1'),
(1628, 352, '_thumbnail_id', '348'),
(1629, 353, '_edit_last', '1'),
(1630, 353, '_edit_lock', '1558757294:1'),
(1631, 357, 'wp_travel_payment_id', '358'),
(1632, 357, '_edit_last', '1'),
(1633, 357, '_edit_lock', '1557991084:1'),
(1634, 357, 'wp_travel_post_id', '0'),
(1635, 357, 'wp_travel_booking_status', 'booked'),
(1636, 357, 'wp_travel_fname_traveller', 'yuuyuy'),
(1637, 357, 'wp_travel_lname_traveller', 'uhuhu'),
(1638, 357, 'wp_travel_country_traveller', 'AF'),
(1639, 357, 'wp_travel_phone_traveller', '01736699819'),
(1640, 357, 'wp_travel_email_traveller', 'milon@gmail.com'),
(1641, 357, 'wp_travel_gender_traveller', 'male'),
(1642, 357, 'wp_travel_address', 'yytgh'),
(1643, 357, 'billing_city', 'gygyg'),
(1644, 357, 'wp_travel_country', 'AF'),
(1645, 357, 'billing_postal', '1216'),
(1646, 357, 'wp_travel_note', 'yytytytyt'),
(1647, 357, 'order_data', 'a:24:{s:17:\"wp_travel_post_id\";i:0;s:25:\"wp_travel_fname_traveller\";s:0:\"\";s:25:\"wp_travel_lname_traveller\";s:0:\"\";s:27:\"wp_travel_country_traveller\";s:0:\"\";s:25:\"wp_travel_phone_traveller\";s:0:\"\";s:25:\"wp_travel_email_traveller\";s:0:\"\";s:33:\"wp_travel_date_of_birth_traveller\";s:0:\"\";s:26:\"wp_travel_gender_traveller\";s:0:\"\";s:33:\"wp_travel_billing_address_heading\";s:0:\"\";s:17:\"wp_travel_address\";s:0:\"\";s:12:\"billing_city\";s:0:\"\";s:17:\"wp_travel_country\";s:0:\"\";s:14:\"billing_postal\";s:0:\"\";s:13:\"wp_travel_pax\";s:0:\"\";s:14:\"wp_travel_note\";s:0:\"\";s:9:\"price_key\";s:0:\"\";s:28:\"wp_travel_is_partial_payment\";s:0:\"\";s:25:\"wp_travel_payment_heading\";s:0:\"\";s:24:\"wp_travel_booking_option\";s:0:\"\";s:25:\"wp_travel_payment_gateway\";s:0:\"\";s:20:\"wp_travel_trip_price\";s:0:\"\";s:22:\"wp_travel_payment_mode\";s:0:\"\";s:25:\"wp_travel_trip_price_info\";s:0:\"\";s:29:\"wp_travel_payment_amount_info\";s:0:\"\";}'),
(1648, 358, 'wp_travel_payment_status', 'paid'),
(1686, 360, 'wp_travel_pricing_option_type', 'single-price'),
(1687, 360, 'wp_travel_price', '20000'),
(1688, 360, 'wp_travel_trip_price', '2000'),
(1689, 360, 'wp_travel_enable_sale', '1'),
(1690, 360, 'wp_travel_sale_price', '2000'),
(1691, 360, 'wp_travel_price_per', 'group'),
(1692, 360, 'wp_travel_group_size', '3'),
(1693, 360, 'wp_travel_trip_include', 'wewewewe'),
(1694, 360, 'wp_travel_trip_exclude', 'cvcvc'),
(1695, 360, 'wp_travel_outline', 'dffdfdfdfdfd'),
(1696, 360, 'wp_travel_start_date', '2019-03-30'),
(1697, 360, 'wp_travel_end_date', '2019-04-25'),
(1698, 360, 'wp_travel_trip_itinerary_data', 'a:1:{i:0;a:5:{s:5:\"label\";s:5:\"Day X\";s:5:\"title\";s:9:\"Your Plan\";s:4:\"date\";s:10:\"2019-03-30\";s:4:\"time\";s:8:\"04:44 pm\";s:4:\"desc\";s:15:\"fdfdfdfdfdfdfdf\";}}'),
(1699, 360, 'wp_travel_itinerary_gallery_ids', 'a:7:{i:0;s:3:\"328\";i:1;s:3:\"177\";i:2;s:3:\"176\";i:3;s:3:\"151\";i:4;s:3:\"351\";i:5;s:3:\"348\";i:6;s:3:\"338\";}'),
(1700, 360, '_thumbnail_id', '328'),
(1701, 360, 'wp_travel_location', ''),
(1702, 360, 'wp_travel_lat', ''),
(1703, 360, 'wp_travel_lng', ''),
(1704, 360, 'wp_travel_location_id', ''),
(1705, 360, 'wp_travel_fixed_departure', 'yes'),
(1706, 360, 'wp_travel_enable_pricing_options', 'no'),
(1707, 360, 'wp_travel_enable_multiple_fixed_departue', 'no'),
(1708, 360, 'wp_travel_trip_duration', '0'),
(1709, 360, 'wp_travel_trip_duration_night', '0'),
(1710, 360, 'wp_travel_use_global_tabs', 'no'),
(1711, 360, 'wp_travel_tabs', 'a:8:{s:8:\"overview\";a:2:{s:5:\"label\";s:8:\"Overview\";s:12:\"show_in_menu\";s:3:\"yes\";}s:12:\"trip_outline\";a:2:{s:5:\"label\";s:12:\"Trip Outline\";s:12:\"show_in_menu\";s:3:\"yes\";}s:13:\"trip_includes\";a:2:{s:5:\"label\";s:13:\"Trip Includes\";s:12:\"show_in_menu\";s:3:\"yes\";}s:13:\"trip_excludes\";a:2:{s:5:\"label\";s:13:\"Trip Excludes\";s:12:\"show_in_menu\";s:3:\"yes\";}s:7:\"gallery\";a:2:{s:5:\"label\";s:7:\"Gallery\";s:12:\"show_in_menu\";s:3:\"yes\";}s:7:\"reviews\";a:2:{s:5:\"label\";s:7:\"Reviews\";s:12:\"show_in_menu\";s:3:\"yes\";}s:7:\"booking\";a:2:{s:5:\"label\";s:7:\"Booking\";s:12:\"show_in_menu\";s:3:\"yes\";}s:3:\"faq\";a:2:{s:5:\"label\";s:3:\"FAQ\";s:12:\"show_in_menu\";s:3:\"yes\";}}'),
(1712, 360, 'wp_travel_use_global_trip_enquiry_option', 'yes'),
(1713, 360, 'wp_travel_enable_trip_enquiry_option', 'yes'),
(1714, 360, 'wp_travel_faq_question', 'a:2:{i:0;s:8:\"fdgfdgfd\";i:1;s:5:\"fgfgf\";}'),
(1715, 360, 'wp_travel_faq_answer', 'a:2:{i:0;s:9:\"fdgfdfddd\";i:1;s:7:\"fgfdgfd\";}'),
(1716, 360, 'wp_travel_minimum_partial_payout', '492.00'),
(1717, 360, 'wp_travel_minimum_partial_payout_percent', '24.60'),
(1718, 360, 'wp_travel_minimum_partial_payout_use_global', '1'),
(1719, 360, 'wp_travel_pricing_options', ''),
(1720, 360, 'wp_travel_multiple_trip_dates', 'a:0:{}'),
(1721, 360, 'wp_travel_trip_facts', 'a:1:{i:0;a:3:{s:5:\"label\";s:4:\"test\";s:4:\"icon\";s:0:\"\";s:4:\"type\";s:8:\"multiple\";}}'),
(1722, 360, 'wp_travel_tour_extras', 'a:0:{}'),
(1723, 360, '_edit_last', '1'),
(1724, 360, '_edit_lock', '1553856033:1'),
(1725, 360, 'wp_travel_booking_count', '0'),
(1726, 360, '_wpt_rating_count', 'a:0:{}'),
(1727, 360, '_wpt_average_rating', '0'),
(1728, 358, 'wp_travel_payment_mode', 'full'),
(1729, 360, '_wpt_review_count', '0'),
(1741, 366, '_edit_last', '1'),
(1742, 366, 'wp_travel_coupon_code', '1234'),
(1743, 366, 'wp_travel_coupon_metas', 'a:2:{s:7:\"general\";a:3:{s:11:\"coupon_type\";s:5:\"fixed\";s:12:\"coupon_value\";s:4:\"1234\";s:18:\"coupon_expiry_date\";s:10:\"2019-03-31\";}s:11:\"restriction\";a:1:{s:19:\"coupon_limit_number\";s:0:\"\";}}'),
(1744, 366, '_edit_lock', '1553855539:1'),
(1745, 367, 'wp_travel_post_id', '360'),
(1746, 367, 'wp_travel_enquiry_name', 'milon'),
(1747, 367, 'wp_travel_enquiry_email', 'milon@gmial.com'),
(1748, 367, 'wp_travel_enquiry_query', 'hwllo,test'),
(1749, 367, 'wp_travel_trip_enquiry_data', 'a:4:{s:7:\"post_id\";s:3:\"360\";s:22:\"wp_travel_enquiry_name\";s:5:\"milon\";s:23:\"wp_travel_enquiry_email\";s:15:\"milon@gmial.com\";s:23:\"wp_travel_enquiry_query\";s:10:\"hwllo,test\";}'),
(1750, 367, '_edit_last', '1'),
(1751, 367, '_edit_lock', '1553855574:1'),
(1752, 368, '_edit_last', '1'),
(1753, 368, '_thumbnail_id', '346'),
(1754, 368, 'wp_travel_tour_extras_metas', 'a:1:{s:23:\"extras_item_description\";s:23:\"ehjhrjhjhfjdfdhfdhfdhdf\";}'),
(1755, 368, '_edit_lock', '1553855601:1'),
(1756, 360, 'wp_travel_featured', 'yes'),
(1757, 353, '_thumbnail_id', '351'),
(1758, 353, 'toursdeparturedate', '03/29/2019'),
(1759, 353, 'toursarrivedate', '03/31/2019'),
(1760, 353, 'toursname', 'Cursus faucibus egestas rutrum mauris vulputate consequat ante'),
(1761, 353, 'toursemail', 'test@gmail.com'),
(1762, 353, 'tourlocation', 'Cursus faucibus egestas rutrum mauris vulputate consequat ante'),
(1763, 353, 'toursprice', '1,200.00'),
(1764, 353, 'tourstype', 'get all'),
(1765, 353, 'maximumnumberof', '012345678'),
(1766, 353, 'toursoverview', 'Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry\'s standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book. It has survived not only five centuries, but also the leap into electronic typesetting, remaining essentially unchanged. It was popularised in the 1960s with the release of Letraset sheets containing Lorem Ipsum passages, and more recently with desktop publishing software like Aldus PageMaker including versions of Lorem Ipsum.'),
(1767, 353, 'toursdayone', 'Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry\'s standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book. It has survived not only five centuries, but also the leap into electronic typesetting, remaining essentially unchanged. It was popularised in the 1960s with the release of Letraset sheets containing Lorem Ipsum passages, and more recently with desktop publishing software like Aldus PageMaker including versions of Lorem Ipsum.'),
(1768, 353, 'toursdaytwo', 'Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry\'s standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book. It has survived not only five centuries, but also the leap into electronic typesetting, remaining essentially unchanged. It was popularised in the 1960s with the release of Letraset sheets containing Lorem Ipsum passages, and more recently with desktop publishing software like Aldus PageMaker including versions of Lorem Ipsum.'),
(1769, 353, 'toursdaythress', 'Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry\'s standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book. It has survived not only five centuries, but also the leap into electronic typesetting, remaining essentially unchanged. It was popularised in the 1960s with the release of Letraset sheets containing Lorem Ipsum passages, and more recently with desktop publishing software like Aldus PageMaker including versions of Lorem Ipsum.'),
(1770, 353, 'toursdayfour', 'Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry\'s standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book. It has survived not only five centuries, but also the leap into electronic typesetting, remaining essentially unchanged. It was popularised in the 1960s with the release of Letraset sheets containing Lorem Ipsum passages, and more recently with desktop publishing software like Aldus PageMaker including versions of Lorem Ipsum.'),
(1776, 352, 'toursdeparturedate', '03/14/2019'),
(1777, 352, 'toursarrivedate', '03/15/2019'),
(1778, 352, 'tourlocation', 'faucibus egestas rutrum mauris vulputate consequat ante'),
(1779, 352, 'maximumnumberof', '5'),
(1780, 356, '_edit_lock', '1553886657:1'),
(1781, 375, '_edit_last', '1'),
(1782, 375, '_edit_lock', '1560695372:1'),
(1783, 375, 'hotellocation', 'Pierpoint Road Cairns , QLD 4870 Australia'),
(1784, 375, 'hotelemail', 'testhotel@gmail.com'),
(1785, 375, 'hotelphone', '01736699819'),
(1786, 375, 'hotelprice', '25,000.00'),
(1787, 375, 'hotelwebsite', 'kmbikroy.com'),
(1788, 375, 'hotelprepayment', 'Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry\'s standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book. It has survived not only five centuries, but also the leap into electronic typesetting, remaining essentially unchanged. It was popularised in the 1960s with the release of Letraset sheets containing Lorem Ipsum passages, and more recently with desktop publishing software like Aldus PageMaker including versions of Lorem Ipsum. '),
(1789, 375, 'hotelchildren', 'All children are wellcome\r\n\r\nFree ! Lorem Ipsum is simply dummy text of the printing and typesetting industry\r\n\r\nFree ! Lorem Ipsum is simply dummy text of the printing and typesetting industry\r\n\r\nFree ! Lorem Ipsum is simply dummy text of the printing and typesetting industry\r\n'),
(1790, 375, 'hotelpets', 'Lorem Ipsum is simply dummy text of the printing and typesetting industry '),
(1791, 375, 'hoteldescription', 'This boutique hotel in the Manhattan neighborhood of Nolita features a private rooftop and rooms with free WiFi. The Bowery subway station is 1 block from this New York hotel.\r\n\r\nGuest rooms at the Nolitan Hotel provide a 37-inch flat-screen cable TV and an iPod dock. The bathrooms provide bathrobes and slippers.\r\n\r\nThe hotel provides free bike rentals and a local gym membership for guests. There is also on-site dining at the French bistro Cantine Parisienne. A complimentary wine and cheese hour is served every Monday through Saturday.\r\n\r\nTimes Square, Rockefeller Center and Madison Square Garden are 4.8 km from The Nolitan Hotel. The hotel is bordered by SoHo, Little Italy and Chinatown.\r\n\r\nNoLita is a great choice for travelers interested in nightlife, food and culture.\r\n\r\nWe speak your language! Pierpoint Road Cairns , QLD 4870 Australia'),
(1792, 377, '_wp_attached_file', '2019/03/Barclay-400x300.jpg');
INSERT INTO `wp_postmeta` (`meta_id`, `post_id`, `meta_key`, `meta_value`) VALUES
(1793, 377, '_wp_attachment_metadata', 'a:5:{s:5:\"width\";i:400;s:6:\"height\";i:300;s:4:\"file\";s:27:\"2019/03/Barclay-400x300.jpg\";s:5:\"sizes\";a:7:{s:9:\"thumbnail\";a:4:{s:4:\"file\";s:27:\"Barclay-400x300-150x150.jpg\";s:5:\"width\";i:150;s:6:\"height\";i:150;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:6:\"medium\";a:4:{s:4:\"file\";s:27:\"Barclay-400x300-300x225.jpg\";s:5:\"width\";i:300;s:6:\"height\";i:225;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:19:\"wp_travel_thumbnail\";a:4:{s:4:\"file\";s:27:\"Barclay-400x300-365x215.jpg\";s:5:\"width\";i:365;s:6:\"height\";i:215;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:18:\"woocommerce_single\";a:4:{s:4:\"file\";s:27:\"Barclay-400x300-300x225.jpg\";s:5:\"width\";i:300;s:6:\"height\";i:225;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:29:\"woocommerce_gallery_thumbnail\";a:4:{s:4:\"file\";s:27:\"Barclay-400x300-100x100.jpg\";s:5:\"width\";i:100;s:6:\"height\";i:100;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:11:\"shop_single\";a:4:{s:4:\"file\";s:27:\"Barclay-400x300-300x225.jpg\";s:5:\"width\";i:300;s:6:\"height\";i:225;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:14:\"shop_thumbnail\";a:4:{s:4:\"file\";s:27:\"Barclay-400x300-100x100.jpg\";s:5:\"width\";i:100;s:6:\"height\";i:100;s:9:\"mime-type\";s:10:\"image/jpeg\";}}s:10:\"image_meta\";a:12:{s:8:\"aperture\";s:1:\"0\";s:6:\"credit\";s:0:\"\";s:6:\"camera\";s:0:\"\";s:7:\"caption\";s:0:\"\";s:17:\"created_timestamp\";s:1:\"0\";s:9:\"copyright\";s:0:\"\";s:12:\"focal_length\";s:1:\"0\";s:3:\"iso\";s:1:\"0\";s:13:\"shutter_speed\";s:1:\"0\";s:5:\"title\";s:0:\"\";s:11:\"orientation\";s:1:\"0\";s:8:\"keywords\";a:0:{}}}'),
(1794, 375, '_thumbnail_id', '348'),
(1796, 378, '_edit_last', '1'),
(1797, 378, '_edit_lock', '1558757921:1'),
(1798, 378, '_thumbnail_id', '348'),
(1799, 378, 'hotellocation', 'Dhaka, Mirpur'),
(1800, 378, 'hotelemail', 'test@gmail.com'),
(1801, 378, 'hotelphone', '01735669849'),
(1802, 378, 'hotelprice', '124,532.00'),
(1803, 378, 'hotelwebsite', 'weblink'),
(1804, 378, 'hotelprepayment', 'Find Bookings Hotel. Check Out 1000+ Results from Across the Web. The Complete Overview. Information 24/7. Wiki, News &amp; More. Web, Images &amp; Video. 100+ Million Visitors. Trusted by Millions. Types: pdf, doc, ppt, xls, txt.'),
(1805, 378, 'hotelchildren', 'Find Bookings Hotel. Check Out 1000+ Results from Across the Web. The Complete Overview. Information 24/7. Wiki, News &amp; More. Web, Images &amp; Video. 100+ Million Visitors. Trusted by Millions. Types: pdf, doc, ppt, xls, txt.'),
(1806, 378, 'hotelpets', 'Find Bookings Hotel. Check Out 1000+ Results from Across the Web. The Complete Overview. Information 24/7. Wiki, News &amp; More. Web, Images &amp; Video. 100+ Million Visitors. Trusted by Millions. Types: pdf, doc, ppt, xls, txt.'),
(1807, 378, 'hoteldescription', '<span id=\"e197\" class=\"qc_ si29 \">Find Bookings <b>Hotel</b>. Check Out 1000+ Results from Across the Web. The Complete Overview. Information 24/7. Wiki, News &amp; More. Web, Images &amp; Video. 100+ Million Visitors. Trusted by Millions. Types: pdf, doc, ppt, xls, txt.</span>\r\n\r\n<span id=\"e197\" class=\"qc_ si29 \">Find Bookings <b>Hotel</b>. Check Out 1000+ Results from Across the Web. The Complete Overview. Information 24/7. Wiki, News &amp; More. Web, Images &amp; Video. 100+ Million Visitors. Trusted by Millions. Types: pdf, doc, ppt, xls, txt.</span>'),
(1808, 379, '_edit_last', '1'),
(1809, 379, '_edit_lock', '1560529423:1'),
(1810, 379, '_thumbnail_id', '604'),
(1811, 379, 'hotellocation', 'Dhaka, Banani'),
(1812, 379, 'hotelemail', 'testhotel@gmail.com'),
(1813, 379, 'hotelphone', '01735669849'),
(1814, 379, 'hotelprice', '1,452,310.00'),
(1815, 379, 'hotelwebsite', 'weblink'),
(1816, 379, 'hotelprepayment', 'HotelsCombined. Compare 1000+ Booking Sites At Once. Best Price Guaranteed. 5 Million Hotel Deals. 100% Free to Use. Travellers Love Us. 1000’s Sites Compared. 800,000+ Hotels Worldwide. Hotels up to 80% Off. No Booking Fee. Types: Hotels, Apartments, Resorts, Villas, Hostels, Guest Houses, B&amp;Bs, Vacation Rentals, Motels, Serviced Apartments.'),
(1817, 379, 'hotelchildren', 'HotelsCombined. Compare 1000+ Booking Sites At Once. Best Price Guaranteed. 5 Million Hotel Deals. 100% Free to Use. Travellers Love Us. 1000’s Sites Compared. 800,000+ Hotels Worldwide. Hotels up to 80% Off. No Booking Fee. Types: Hotels, Apartments, Resorts, Villas, Hostels, Guest Houses, B&amp;Bs, Vacation Rentals, Motels, Serviced Apartments.'),
(1818, 379, 'hotelpets', 'HotelsCombined. Compare 1000+ Booking Sites At Once. Best Price Guaranteed. 5 Million Hotel Deals. 100% Free to Use. Travellers Love Us. 1000’s Sites Compared. 800,000+ Hotels Worldwide. Hotels up to 80% Off. No Booking Fee. Types: Hotels, Apartments, Resorts, Villas, Hostels, Guest Houses, B&amp;Bs, Vacation Rentals, Motels, Serviced Apartments.'),
(1819, 379, 'hoteldescription', '<span id=\"e231\" class=\"qc_ si29 \">HotelsCombined. Compare 1000+ Booking Sites At Once. Best Price Guaranteed. 5 Million <b>Hotel</b> Deals. 100% Free to Use. Travellers Love Us. 1000’s Sites Compared. 800,000+ <b>Hotels</b> Worldwide. <b>Hotels</b> up to 80% Off. No Booking Fee. Types: <b>Hotels</b>, Apartments, Resorts, Villas, Hostels, Guest Houses, B&amp;Bs, Vacation Rentals, Motels, Serviced Apartments.</span>'),
(1820, 380, '_edit_last', '1'),
(1821, 380, '_edit_lock', '1560695339:1'),
(1822, 380, '_thumbnail_id', '176'),
(1823, 380, 'hotellocation', 'Pierpoint Road Cairns , QLD 4870 Australia'),
(1824, 380, 'hotelemail', 'testhotel@gmail.com'),
(1825, 380, 'hotelphone', '01735669849'),
(1826, 380, 'hotelprice', '12,505.00'),
(1827, 380, 'hotelwebsite', 'weblink'),
(1828, 380, 'hotelprepayment', 'HotelsCombined. Compare 1000+ Booking Sites At Once. Best Price Guaranteed. 5 Million Hotel Deals. 100% Free to Use. Travellers Love Us. 1000’s Sites Compared. 800,000+ Hotels Worldwide. Hotels up to 80% Off. No Booking Fee. Types: Hotels, Apartments, Resorts, Villas, Hostels, Guest Houses, B&amp;Bs, Vacation Rentals, Motels, Serviced Apartments.'),
(1829, 380, 'hotelchildren', 'HotelsCombined. Compare 1000+ Booking Sites At Once. Best Price Guaranteed. 5 Million Hotel Deals. 100% Free to Use. Travellers Love Us. 1000’s Sites Compared. 800,000+ Hotels Worldwide. Hotels up to 80% Off. No Booking Fee. Types: Hotels, Apartments, Resorts, Villas, Hostels, Guest Houses, B&amp;Bs, Vacation Rentals, Motels, Serviced Apartments.'),
(1830, 380, 'hotelpets', 'HotelsCombined. Compare 1000+ Booking Sites At Once. Best Price Guaranteed. 5 Million Hotel Deals. 100% Free to Use. Travellers Love Us. 1000’s Sites Compared. 800,000+ Hotels Worldwide. Hotels up to 80% Off. No Booking Fee. Types: Hotels, Apartments, Resorts, Villas, Hostels, Guest Houses, B&amp;Bs, Vacation Rentals, Motels, Serviced Apartments.'),
(1831, 380, 'hoteldescription', '<span id=\"e231\" class=\"qc_ si29 \">HotelsCombined. Compare 1000+ Booking Sites At Once. Best Price Guaranteed. 5 Million <b>Hotel</b> Deals. 100% Free to Use. Travellers Love Us. 1000’s Sites Compared. 800,000+ <b>Hotels</b> Worldwide. <b>Hotels</b> up to 80% Off. No Booking Fee. Types: <b>Hotels</b>, Apartments, Resorts, Villas, Hostels, Guest Houses, B&amp;Bs, Vacation Rentals, Motels, Serviced Apartments.</span>'),
(1832, 390, '_edit_last', '1'),
(1833, 390, 'mphb_start_date', '2019-04-03'),
(1834, 390, 'mphb_end_date', '2019-05-10'),
(1835, 390, 'mphb_days', 'a:7:{i:0;s:1:\"0\";i:1;s:1:\"1\";i:2;s:1:\"2\";i:3;s:1:\"3\";i:4;s:1:\"4\";i:5;s:1:\"5\";i:6;s:1:\"6\";}'),
(1836, 390, '_edit_lock', '1554264289:1'),
(1837, 391, '_edit_last', '1'),
(1838, 391, '_edit_lock', '1554192230:1'),
(1839, 392, '_edit_last', '1'),
(1840, 392, '_edit_lock', '1554264525:1'),
(1841, 392, 'mphb_price', '150'),
(1842, 392, 'mphb_price_periodicity', 'per_night'),
(1843, 392, 'mphb_min_quantity', '1'),
(1844, 392, 'mphb_is_auto_limit', '0'),
(1845, 392, 'mphb_max_quantity', ''),
(1846, 392, 'mphb_price_quantity', 'per_adult'),
(1847, 392, '_thumbnail_id', '151'),
(1848, 393, '_edit_last', '1'),
(1849, 393, '_edit_lock', '1554181141:1'),
(1850, 394, '_edit_lock', '1554264120:1'),
(1851, 394, '_thumbnail_id', '348'),
(1852, 394, '_edit_last', '1'),
(1853, 394, 'mphb_adults_capacity', '3'),
(1854, 394, 'mphb_children_capacity', '2'),
(1855, 394, 'mphb_size', '1'),
(1856, 394, 'mphb_view', 'Text messaging, or texting, is the act of composing and sending electronic messages, typically consisting of alphabetic and numeric characters,'),
(1857, 394, 'mphb_bed', '1 Bed, 2 Bed, 3 Bed'),
(1858, 394, 'mphb_gallery', '348,151,176,177'),
(1859, 394, 'mphb_services', 'a:1:{i:0;s:3:\"392\";}'),
(1860, 395, 'mphb_room_type_id', '394'),
(1861, 396, 'mphb_room_type_id', '394'),
(1864, 391, 'mphb_season_prices', 'a:1:{i:0;a:2:{s:6:\"season\";s:3:\"390\";s:5:\"price\";a:4:{s:7:\"periods\";a:3:{i:0;i:1;i:1;i:2;i:2;i:2;}s:6:\"prices\";a:3:{i:0;d:1200;i:1;s:0:\"\";i:2;s:0:\"\";}s:17:\"enable_variations\";b:0;s:10:\"variations\";a:0:{}}}}'),
(1865, 391, 'mphb_description', ''),
(1866, 398, '_edit_last', '1'),
(1867, 398, 'mphb_room_type_id', '394'),
(1868, 398, 'mphb_description', 'Please select Accommodation Type and click Create Rate button to continue'),
(1869, 398, '_edit_lock', '1554264354:1'),
(1870, 399, 'mphb_room_type_id', '394'),
(1873, 398, 'mphb_season_prices', 'a:2:{i:0;a:2:{s:6:\"season\";s:3:\"390\";s:5:\"price\";a:4:{s:7:\"periods\";a:1:{i:0;i:1;}s:6:\"prices\";a:1:{i:0;d:1520;}s:17:\"enable_variations\";b:0;s:10:\"variations\";a:0:{}}}i:1;a:2:{s:6:\"season\";s:3:\"390\";s:5:\"price\";a:4:{s:7:\"periods\";a:1:{i:0;i:1;}s:6:\"prices\";a:1:{i:0;d:1400;}s:17:\"enable_variations\";b:0;s:10:\"variations\";a:0:{}}}}'),
(1874, 399, '_edit_lock', '1554264419:1'),
(1875, 399, '_edit_last', '1'),
(1876, 409, 'mphb_room_type_id', '394'),
(1877, 410, 'mphb_room_type_id', '394'),
(1878, 411, 'mphb_room_type_id', '394'),
(1879, 412, 'mphb_room_type_id', '394'),
(1882, 416, '_edit_last', '1'),
(1883, 416, '_edit_lock', '1554265599:1'),
(1884, 416, '_thumbnail_id', '348'),
(1885, 416, '_hb_num_of_rooms', '5'),
(1886, 416, '_hb_room_extra', ''),
(1887, 416, '_hb_room_capacity', '150'),
(1888, 416, '_hb_room_origin_capacity', '150'),
(1889, 416, '_hb_max_child_per_room', '2'),
(1890, 416, '_hb_room_addition_information', '<strong>Lorem Ipsum</strong> is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry\'s standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book. It has survived not only five centuries, but also the leap into electronic typesetting, remaining essentially unchanged. It was popularised in the 1960s with the release of Letraset sheets containing Lorem Ipsum passages, and more recently with desktop publishing software like Aldus PageMaker including versions of Lorem Ipsum.'),
(1891, 416, '_hb_gallery', 'a:4:{i:0;s:3:\"348\";i:1;s:3:\"151\";i:2;s:3:\"176\";i:3;s:3:\"177\";}'),
(1892, 418, '_edit_last', '1'),
(1893, 418, 'tp_hb_extra_room_price', '1000'),
(1894, 418, 'tp_hb_extra_room_room_extra', ''),
(1895, 418, 'tp_hb_extra_room_respondent_name', '5'),
(1896, 418, 'tp_hb_extra_room_respondent', 'trip'),
(1897, 418, 'tp_hb_extra_room_required', '0'),
(1898, 418, '_edit_lock', '1554265665:1'),
(2033, 1, '_edit_lock', '1554274796:1'),
(2034, 386, '_edit_lock', '1554274829:1'),
(2035, 434, '_edit_lock', '1554274912:1'),
(2036, 434, '_wp_page_template', 'all_page/book-now.php'),
(2037, 405, '_edit_lock', '1554274964:1'),
(2038, 439, '_edit_last', '1'),
(2039, 439, '_edit_lock', '1554283079:1'),
(2040, 439, 'service_type', 'accommodation'),
(2041, 439, 'checkin_from', '01:00'),
(2042, 439, 'checkin_to', '04:00'),
(2043, 439, 'checkout_from', '05:30'),
(2044, 439, 'checkout_to', '07:30'),
(2045, 439, 'wpbooking_select_amenity', 'a:1:{i:0;s:3:\"159\";}'),
(2046, 439, 'creditcard_accepted', 'a:2:{s:15:\"americanexpress\";s:2:\"on\";s:4:\"visa\";s:2:\"on\";}'),
(2047, 439, 'allow_cancel', 'off'),
(2048, 439, 'deposit_payment_amount', '1'),
(2049, 439, 'cancel_free_days_prior', 'day_of_arrival'),
(2050, 439, 'cancel_guest_payment', 'first_night'),
(2051, 439, 'vat_excluded', 'yes_included'),
(2052, 439, 'vat_amount', '10'),
(2053, 439, 'vat_unit', 'percent'),
(2054, 439, 'citytax_excluded', ''),
(2055, 439, 'citytax_amount', ''),
(2056, 439, 'citytax_unit', 'stay'),
(2057, 439, 'minimum_stay', '1'),
(2058, 439, 'terms_conditions', 'Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry\'s standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book. It has survived not only five centuries, but also the leap into electronic typesetting, remaining essentially unchanged. It was popularised in the 1960s with the release of Letraset sheets containing Lorem Ipsum passages, and more recently with desktop publishing software like Aldus PageMaker including versions of Lorem Ipsum.'),
(2059, 439, 'gallery', 'a:2:{s:7:\"gallery\";s:15:\"328,177,176,151\";s:9:\"room_data\";s:0:\"\";}'),
(2060, 439, '_thumbnail_id', '348'),
(2061, 439, 'price', '0'),
(2062, 441, '_edit_lock', '1554284896:1'),
(2063, 441, '_edit_last', '1'),
(2064, 441, 'gallery', 'a:4:{i:177;s:61:\"http://localhost/project/wp-content/uploads/2019/02/thumb.jpg\";i:176;s:86:\"http://localhost/project/wp-content/uploads/2019/02/thumb_1537856321-package-image.jpg\";i:151;s:61:\"http://localhost/project/wp-content/uploads/2019/02/thumb.jpg\";i:348;s:59:\"http://localhost/project/wp-content/uploads/2019/03/3-1.jpg\";}'),
(2065, 441, '_bedrooms', '3'),
(2066, 441, '_beds', 'a:1:{i:0;a:2:{s:4:\"type\";s:5:\"hgjgh\";s:6:\"number\";s:1:\"1\";}}'),
(2067, 441, '_room_view', 'jhgj'),
(2068, 441, '_area_size', 'hgjhg'),
(2069, 441, '_maximum_occupancy', '2'),
(2070, 441, 'number_adults', '2'),
(2071, 441, 'base_price', '120'),
(2072, 441, '_rate_inclusions', 'a:1:{i:0;s:5:\"ghjhj\";}'),
(2073, 441, '_rate_policies', 'a:1:{i:0;s:4:\"hgjh\";}'),
(2074, 441, 'minimum_night', '1'),
(2075, 441, '_cache_total_rooms', '0'),
(2076, 442, '_edit_last', '1'),
(2077, 442, '_operation', 'add'),
(2078, 442, '_amount', '1500'),
(2079, 442, '_quantity_selectable', 'on'),
(2080, 442, '_edit_lock', '1554284819:1'),
(2081, 442, '_thumbnail_id', '348'),
(2082, 443, '_edit_last', '1'),
(2083, 443, '_arrival_time', '0'),
(2084, 443, '_customer_title', 'mr'),
(2085, 443, '_customer_first_name', 'dsfdsf'),
(2086, 443, '_customer_last_name', 'dsfds'),
(2087, 443, '_customer_address', 'dsfds'),
(2088, 443, '_customer_address_2', 'dsfds'),
(2089, 443, '_customer_company', 'dsfdsf'),
(2090, 443, '_edit_lock', '1554285221:1'),
(2095, 459, '_sku', '34-1-1'),
(2096, 459, '_regular_price', '4000'),
(2097, 459, '_sale_price', '3500'),
(2098, 459, '_sale_price_dates_from', ''),
(2099, 459, '_sale_price_dates_to', ''),
(2100, 459, 'total_sales', '0'),
(2101, 459, '_tax_status', 'taxable'),
(2102, 459, '_tax_class', ''),
(2103, 459, '_manage_stock', 'no'),
(2104, 459, '_backorders', 'no'),
(2105, 459, '_low_stock_amount', ''),
(2106, 459, '_sold_individually', 'no'),
(2107, 459, '_weight', '45'),
(2108, 459, '_length', '400'),
(2109, 459, '_width', '300'),
(2110, 459, '_height', '200'),
(2111, 459, '_upsell_ids', 'a:0:{}'),
(2112, 459, '_crosssell_ids', 'a:0:{}'),
(2113, 459, '_purchase_note', 'My permalink structure might be the cause - but basically i have a formidable form creating a new post'),
(2114, 459, '_default_attributes', 'a:0:{}'),
(2115, 459, '_virtual', 'no'),
(2116, 459, '_downloadable', 'no'),
(2117, 459, '_product_image_gallery', '177,176,151'),
(2118, 459, '_download_limit', '-1'),
(2119, 459, '_download_expiry', '-1'),
(2120, 459, '_thumbnail_id', '345'),
(2121, 459, '_stock', NULL),
(2122, 459, '_stock_status', 'instock'),
(2123, 459, '_wc_average_rating', '0'),
(2124, 459, '_wc_rating_count', 'a:0:{}'),
(2125, 459, '_wc_review_count', '0'),
(2126, 459, '_downloadable_files', 'a:0:{}'),
(2127, 459, '_product_attributes', 'a:0:{}'),
(2128, 459, '_product_version', '3.5.5'),
(2129, 459, '_price', '3500'),
(2130, 459, 'agentname', 'Flying World Travels'),
(2131, 459, 'makkahstay', '12'),
(2132, 459, 'madinahstay', '12'),
(2133, 459, 'makkahhotelhame', 'Le Meridian Hotel 5 Star'),
(2134, 459, 'Makkahoteldistance', '600'),
(2135, 459, 'madinahhotelname', 'Le Meridian Hotel 5 Star'),
(2136, 459, 'madinahhoteldistance', '500'),
(2137, 459, 'locationcheckins', '03/03/2019'),
(2138, 459, 'locationcheckout', '03/15/2019'),
(2139, 459, 'umrahroom', '10'),
(2140, 459, 'umrahparson', '6'),
(2141, 459, 'umrahdouble', '35,000.00'),
(2142, 459, 'umrahtriplebed', '45,000.00'),
(2143, 459, 'umrahfourbed', '50,000.00'),
(2144, 459, 'umrahsharing', '60,000.00'),
(2145, 459, '_edit_lock', '1554371734:1'),
(2146, 459, '_edit_last', '1'),
(2147, 460, '_sku', '34-1-1-1'),
(2148, 460, '_regular_price', '4000'),
(2149, 460, '_sale_price', '3500'),
(2150, 460, '_sale_price_dates_from', ''),
(2151, 460, '_sale_price_dates_to', ''),
(2152, 460, 'total_sales', '0'),
(2153, 460, '_tax_status', 'taxable'),
(2154, 460, '_tax_class', ''),
(2155, 460, '_manage_stock', 'no'),
(2156, 460, '_backorders', 'no'),
(2157, 460, '_low_stock_amount', ''),
(2158, 460, '_sold_individually', 'no'),
(2159, 460, '_weight', '45'),
(2160, 460, '_length', '400'),
(2161, 460, '_width', '300'),
(2162, 460, '_height', '200'),
(2163, 460, '_upsell_ids', 'a:0:{}'),
(2164, 460, '_crosssell_ids', 'a:0:{}'),
(2165, 460, '_purchase_note', 'My permalink structure might be the cause - but basically i have a formidable form creating a new post'),
(2166, 460, '_default_attributes', 'a:0:{}'),
(2167, 460, '_virtual', 'no'),
(2168, 460, '_downloadable', 'no'),
(2169, 460, '_product_image_gallery', '177,176,151'),
(2170, 460, '_download_limit', '-1'),
(2171, 460, '_download_expiry', '-1'),
(2172, 460, '_thumbnail_id', '345'),
(2173, 460, '_stock', NULL),
(2174, 460, '_stock_status', 'instock'),
(2175, 460, '_wc_average_rating', '0'),
(2176, 460, '_wc_rating_count', 'a:0:{}'),
(2177, 460, '_wc_review_count', '0'),
(2178, 460, '_downloadable_files', 'a:0:{}'),
(2179, 460, '_product_attributes', 'a:0:{}'),
(2180, 460, '_product_version', '3.5.5'),
(2181, 460, '_price', '3500'),
(2182, 460, 'agentname', 'Flying World Travels'),
(2183, 460, 'makkahstay', '12'),
(2184, 460, 'madinahstay', '12'),
(2185, 460, 'makkahhotelhame', 'Le Meridian Hotel 5 Star'),
(2186, 460, 'Makkahoteldistance', '600'),
(2187, 460, 'madinahhotelname', 'Le Meridian Hotel 5 Star'),
(2188, 460, 'madinahhoteldistance', '500'),
(2189, 460, 'locationcheckins', '03/03/2019'),
(2190, 460, 'locationcheckout', '03/15/2019'),
(2191, 460, 'umrahroom', '10'),
(2192, 460, 'umrahparson', '6'),
(2193, 460, 'umrahdouble', '35,000.00'),
(2194, 460, 'umrahtriplebed', '45,000.00'),
(2195, 460, 'umrahfourbed', '50,000.00'),
(2196, 460, 'umrahsharing', '60,000.00'),
(2197, 460, '_edit_lock', '1554371753:1'),
(2198, 460, '_edit_last', '1'),
(2199, 461, '_sku', '34-1-1-1-1'),
(2200, 461, '_regular_price', '4000'),
(2201, 461, '_sale_price', '3500'),
(2202, 461, '_sale_price_dates_from', ''),
(2203, 461, '_sale_price_dates_to', ''),
(2204, 461, 'total_sales', '0'),
(2205, 461, '_tax_status', 'taxable'),
(2206, 461, '_tax_class', ''),
(2207, 461, '_manage_stock', 'no'),
(2208, 461, '_backorders', 'no'),
(2209, 461, '_low_stock_amount', ''),
(2210, 461, '_sold_individually', 'no'),
(2211, 461, '_weight', '45'),
(2212, 461, '_length', '400'),
(2213, 461, '_width', '300'),
(2214, 461, '_height', '200'),
(2215, 461, '_upsell_ids', 'a:0:{}'),
(2216, 461, '_crosssell_ids', 'a:0:{}'),
(2217, 461, '_purchase_note', 'My permalink structure might be the cause - but basically i have a formidable form creating a new post'),
(2218, 461, '_default_attributes', 'a:0:{}'),
(2219, 461, '_virtual', 'no'),
(2220, 461, '_downloadable', 'no'),
(2221, 461, '_product_image_gallery', '177,176,151'),
(2222, 461, '_download_limit', '-1'),
(2223, 461, '_download_expiry', '-1'),
(2224, 461, '_thumbnail_id', '345'),
(2225, 461, '_stock', NULL),
(2226, 461, '_stock_status', 'instock'),
(2227, 461, '_wc_average_rating', '0'),
(2228, 461, '_wc_rating_count', 'a:0:{}'),
(2229, 461, '_wc_review_count', '0'),
(2230, 461, '_downloadable_files', 'a:0:{}'),
(2231, 461, '_product_attributes', 'a:0:{}'),
(2232, 461, '_product_version', '3.5.5'),
(2233, 461, '_price', '3500'),
(2234, 461, 'agentname', 'Flying World Travels'),
(2235, 461, 'makkahstay', '12'),
(2236, 461, 'madinahstay', '12'),
(2237, 461, 'makkahhotelhame', 'Le Meridian Hotel 5 Star'),
(2238, 461, 'Makkahoteldistance', '600'),
(2239, 461, 'madinahhotelname', 'Le Meridian Hotel 5 Star'),
(2240, 461, 'madinahhoteldistance', '500'),
(2241, 461, 'locationcheckins', '03/03/2019'),
(2242, 461, 'locationcheckout', '03/15/2019'),
(2243, 461, 'umrahroom', '10'),
(2244, 461, 'umrahparson', '6'),
(2245, 461, 'umrahdouble', '35,000.00'),
(2246, 461, 'umrahtriplebed', '45,000.00'),
(2247, 461, 'umrahfourbed', '50,000.00'),
(2248, 461, 'umrahsharing', '60,000.00'),
(2249, 461, '_edit_lock', '1554371789:1'),
(2250, 461, '_edit_last', '1'),
(2251, 462, '_sku', 'hjkhjk-1'),
(2252, 462, '_regular_price', '1500'),
(2253, 462, '_sale_price', '1200'),
(2254, 462, '_sale_price_dates_from', ''),
(2255, 462, '_sale_price_dates_to', ''),
(2256, 462, 'total_sales', '0'),
(2257, 462, '_tax_status', 'taxable'),
(2258, 462, '_tax_class', ''),
(2259, 462, '_manage_stock', 'yes'),
(2260, 462, '_backorders', 'no'),
(2261, 462, '_low_stock_amount', ''),
(2262, 462, '_sold_individually', 'yes'),
(2263, 462, '_weight', '12'),
(2264, 462, '_length', '15'),
(2265, 462, '_width', '5800'),
(2266, 462, '_height', '210'),
(2267, 462, '_upsell_ids', 'a:0:{}'),
(2268, 462, '_crosssell_ids', 'a:0:{}'),
(2269, 462, '_purchase_note', 'dsnmfkjgnfdsmg,dfmg,df'),
(2270, 462, '_default_attributes', 'a:0:{}'),
(2271, 462, '_virtual', 'no'),
(2272, 462, '_downloadable', 'no'),
(2273, 462, '_product_image_gallery', '151'),
(2274, 462, '_download_limit', '-1'),
(2275, 462, '_download_expiry', '-1'),
(2276, 462, '_thumbnail_id', '151'),
(2277, 462, '_stock', '4'),
(2278, 462, '_stock_status', 'instock'),
(2279, 462, '_wc_average_rating', '0'),
(2280, 462, '_wc_rating_count', 'a:0:{}'),
(2281, 462, '_wc_review_count', '0'),
(2282, 462, '_downloadable_files', 'a:0:{}'),
(2283, 462, '_product_attributes', 'a:0:{}'),
(2284, 462, '_product_version', '3.5.5'),
(2285, 462, '_price', '1200'),
(2286, 462, '_edit_lock', '1554371820:1'),
(2287, 462, '_edit_last', '1'),
(2288, 463, '_sku', 'hjkhjk-2'),
(2289, 463, '_regular_price', '1500'),
(2290, 463, '_sale_price', '1200'),
(2291, 463, '_sale_price_dates_from', ''),
(2292, 463, '_sale_price_dates_to', ''),
(2293, 463, 'total_sales', '0'),
(2294, 463, '_tax_status', 'taxable'),
(2295, 463, '_tax_class', ''),
(2296, 463, '_manage_stock', 'yes'),
(2297, 463, '_backorders', 'no'),
(2298, 463, '_low_stock_amount', ''),
(2299, 463, '_sold_individually', 'yes'),
(2300, 463, '_weight', '12'),
(2301, 463, '_length', '15'),
(2302, 463, '_width', '5800'),
(2303, 463, '_height', '210'),
(2304, 463, '_upsell_ids', 'a:0:{}'),
(2305, 463, '_crosssell_ids', 'a:0:{}'),
(2306, 463, '_purchase_note', 'dsnmfkjgnfdsmg,dfmg,df'),
(2307, 463, '_default_attributes', 'a:0:{}'),
(2308, 463, '_virtual', 'no'),
(2309, 463, '_downloadable', 'no'),
(2310, 463, '_product_image_gallery', '151'),
(2311, 463, '_download_limit', '-1'),
(2312, 463, '_download_expiry', '-1'),
(2313, 463, '_thumbnail_id', '151'),
(2314, 463, '_stock', '4'),
(2315, 463, '_stock_status', 'instock'),
(2316, 463, '_wc_average_rating', '0'),
(2317, 463, '_wc_rating_count', 'a:0:{}'),
(2318, 463, '_wc_review_count', '0'),
(2319, 463, '_downloadable_files', 'a:0:{}'),
(2320, 463, '_product_attributes', 'a:0:{}'),
(2321, 463, '_product_version', '3.5.5'),
(2322, 463, '_price', '1200'),
(2323, 463, '_edit_lock', '1554371845:1'),
(2324, 463, '_edit_last', '1'),
(2325, 464, '_sku', 'hjkhjk-3'),
(2326, 464, '_regular_price', '1500'),
(2327, 464, '_sale_price', '1200'),
(2328, 464, '_sale_price_dates_from', ''),
(2329, 464, '_sale_price_dates_to', ''),
(2330, 464, 'total_sales', '0'),
(2331, 464, '_tax_status', 'taxable'),
(2332, 464, '_tax_class', ''),
(2333, 464, '_manage_stock', 'yes'),
(2334, 464, '_backorders', 'no'),
(2335, 464, '_low_stock_amount', ''),
(2336, 464, '_sold_individually', 'yes'),
(2337, 464, '_weight', '12'),
(2338, 464, '_length', '15'),
(2339, 464, '_width', '5800'),
(2340, 464, '_height', '210'),
(2341, 464, '_upsell_ids', 'a:0:{}'),
(2342, 464, '_crosssell_ids', 'a:0:{}'),
(2343, 464, '_purchase_note', 'dsnmfkjgnfdsmg,dfmg,df'),
(2344, 464, '_default_attributes', 'a:0:{}'),
(2345, 464, '_virtual', 'no'),
(2346, 464, '_downloadable', 'no'),
(2347, 464, '_product_image_gallery', '151'),
(2348, 464, '_download_limit', '-1'),
(2349, 464, '_download_expiry', '-1'),
(2350, 464, '_thumbnail_id', '151'),
(2351, 464, '_stock', '4'),
(2352, 464, '_stock_status', 'instock'),
(2353, 464, '_wc_average_rating', '0'),
(2354, 464, '_wc_rating_count', 'a:0:{}'),
(2355, 464, '_wc_review_count', '0'),
(2356, 464, '_downloadable_files', 'a:0:{}'),
(2357, 464, '_product_attributes', 'a:0:{}'),
(2358, 464, '_product_version', '3.5.5'),
(2359, 464, '_price', '1200'),
(2360, 464, '_edit_lock', '1554371868:1'),
(2361, 464, '_edit_last', '1'),
(2362, 465, '_sku', 'hjkhjk-3-1'),
(2363, 465, '_regular_price', '1500'),
(2364, 465, '_sale_price', '1200'),
(2365, 465, '_sale_price_dates_from', ''),
(2366, 465, '_sale_price_dates_to', ''),
(2367, 465, 'total_sales', '0'),
(2368, 465, '_tax_status', 'taxable'),
(2369, 465, '_tax_class', ''),
(2370, 465, '_manage_stock', 'yes'),
(2371, 465, '_backorders', 'no'),
(2372, 465, '_low_stock_amount', ''),
(2373, 465, '_sold_individually', 'yes'),
(2374, 465, '_weight', '12'),
(2375, 465, '_length', '15'),
(2376, 465, '_width', '5800'),
(2377, 465, '_height', '210'),
(2378, 465, '_upsell_ids', 'a:0:{}'),
(2379, 465, '_crosssell_ids', 'a:0:{}'),
(2380, 465, '_purchase_note', 'dsnmfkjgnfdsmg,dfmg,df'),
(2381, 465, '_default_attributes', 'a:0:{}'),
(2382, 465, '_virtual', 'no'),
(2383, 465, '_downloadable', 'no'),
(2384, 465, '_product_image_gallery', '151'),
(2385, 465, '_download_limit', '-1'),
(2386, 465, '_download_expiry', '-1'),
(2387, 465, '_thumbnail_id', '151'),
(2388, 465, '_stock', '4'),
(2389, 465, '_stock_status', 'instock'),
(2390, 465, '_wc_average_rating', '0'),
(2391, 465, '_wc_rating_count', 'a:0:{}'),
(2392, 465, '_wc_review_count', '0'),
(2393, 465, '_downloadable_files', 'a:0:{}'),
(2394, 465, '_product_attributes', 'a:0:{}'),
(2395, 465, '_product_version', '3.5.5'),
(2396, 465, '_price', '1200'),
(2397, 465, '_edit_lock', '1554371911:1'),
(2398, 465, '_edit_last', '1'),
(2399, 466, '_sku', 'hjkhjk-4'),
(2400, 466, '_regular_price', '1500'),
(2401, 466, '_sale_price', '1200'),
(2402, 466, '_sale_price_dates_from', ''),
(2403, 466, '_sale_price_dates_to', ''),
(2404, 466, 'total_sales', '0'),
(2405, 466, '_tax_status', 'taxable'),
(2406, 466, '_tax_class', ''),
(2407, 466, '_manage_stock', 'yes'),
(2408, 466, '_backorders', 'no'),
(2409, 466, '_low_stock_amount', ''),
(2410, 466, '_sold_individually', 'yes'),
(2411, 466, '_weight', '12'),
(2412, 466, '_length', '15'),
(2413, 466, '_width', '5800'),
(2414, 466, '_height', '210'),
(2415, 466, '_upsell_ids', 'a:0:{}'),
(2416, 466, '_crosssell_ids', 'a:0:{}'),
(2417, 466, '_purchase_note', 'dsnmfkjgnfdsmg,dfmg,df'),
(2418, 466, '_default_attributes', 'a:0:{}'),
(2419, 466, '_virtual', 'no'),
(2420, 466, '_downloadable', 'no'),
(2421, 466, '_product_image_gallery', '151'),
(2422, 466, '_download_limit', '-1'),
(2423, 466, '_download_expiry', '-1'),
(2424, 466, '_thumbnail_id', '151'),
(2425, 466, '_stock', '4'),
(2426, 466, '_stock_status', 'instock'),
(2427, 466, '_wc_average_rating', '0'),
(2428, 466, '_wc_rating_count', 'a:0:{}'),
(2429, 466, '_wc_review_count', '0'),
(2430, 466, '_downloadable_files', 'a:0:{}'),
(2431, 466, '_product_attributes', 'a:0:{}'),
(2432, 466, '_product_version', '3.5.5'),
(2433, 466, '_price', '1200'),
(2434, 466, '_edit_lock', '1554371929:1'),
(2435, 466, '_edit_last', '1'),
(2436, 467, '_sku', 'hjkhjk-5'),
(2437, 467, '_regular_price', '1500'),
(2438, 467, '_sale_price', '1200'),
(2439, 467, '_sale_price_dates_from', ''),
(2440, 467, '_sale_price_dates_to', ''),
(2441, 467, 'total_sales', '0'),
(2442, 467, '_tax_status', 'taxable'),
(2443, 467, '_tax_class', ''),
(2444, 467, '_manage_stock', 'yes'),
(2445, 467, '_backorders', 'no'),
(2446, 467, '_low_stock_amount', ''),
(2447, 467, '_sold_individually', 'yes'),
(2448, 467, '_weight', '12'),
(2449, 467, '_length', '15'),
(2450, 467, '_width', '5800'),
(2451, 467, '_height', '210'),
(2452, 467, '_upsell_ids', 'a:0:{}'),
(2453, 467, '_crosssell_ids', 'a:0:{}'),
(2454, 467, '_purchase_note', 'dsnmfkjgnfdsmg,dfmg,df'),
(2455, 467, '_default_attributes', 'a:0:{}'),
(2456, 467, '_virtual', 'no'),
(2457, 467, '_downloadable', 'no'),
(2458, 467, '_product_image_gallery', '151'),
(2459, 467, '_download_limit', '-1'),
(2460, 467, '_download_expiry', '-1'),
(2461, 467, '_thumbnail_id', '151'),
(2462, 467, '_stock', '4'),
(2463, 467, '_stock_status', 'instock'),
(2464, 467, '_wc_average_rating', '0'),
(2465, 467, '_wc_rating_count', 'a:0:{}'),
(2466, 467, '_wc_review_count', '0'),
(2467, 467, '_downloadable_files', 'a:0:{}'),
(2468, 467, '_product_attributes', 'a:0:{}'),
(2469, 467, '_product_version', '3.5.5'),
(2470, 467, '_price', '1200'),
(2471, 467, '_edit_lock', '1557991140:1'),
(2472, 467, '_edit_last', '1'),
(2475, 337, 'wiki_status', 'internal'),
(2476, 353, 'wiki_status', 'external'),
(2514, 352, 'wiki_status', 'internal'),
(2515, 475, '_edit_last', '1'),
(2516, 475, '_edit_lock', '1554882011:1'),
(2517, 475, '_thumbnail_id', '348'),
(2518, 475, 'fprice', '1,820.00'),
(2519, 475, 'ftax', '50.00'),
(2520, 476, '_edit_last', '1'),
(2521, 476, '_edit_lock', '1554898117:1'),
(2522, 476, '_thumbnail_id', '177'),
(2523, 476, 'fprice', '1,520.00'),
(2524, 476, 'ftax', '45.00'),
(2525, 476, 'businessclass', '1,200.00'),
(2526, 476, 'economyclass', '1,500.00'),
(2527, 476, 'businessclassdate', '04/10/2019'),
(2528, 476, 'businessclasstime', '12:00 AM'),
(2529, 476, 'economyclassdate', '04/09/2019'),
(2530, 476, 'economyclasstime', '11:00 AM'),
(2531, 479, '_wp_attached_file', '2019/04/air-berlin-128x50.png'),
(2532, 479, '_wp_attachment_metadata', 'a:5:{s:5:\"width\";i:128;s:6:\"height\";i:50;s:4:\"file\";s:29:\"2019/04/air-berlin-128x50.png\";s:5:\"sizes\";a:2:{s:29:\"woocommerce_gallery_thumbnail\";a:4:{s:4:\"file\";s:28:\"air-berlin-128x50-100x50.png\";s:5:\"width\";i:100;s:6:\"height\";i:50;s:9:\"mime-type\";s:9:\"image/png\";}s:14:\"shop_thumbnail\";a:4:{s:4:\"file\";s:28:\"air-berlin-128x50-100x50.png\";s:5:\"width\";i:100;s:6:\"height\";i:50;s:9:\"mime-type\";s:9:\"image/png\";}}s:10:\"image_meta\";a:12:{s:8:\"aperture\";s:1:\"0\";s:6:\"credit\";s:0:\"\";s:6:\"camera\";s:0:\"\";s:7:\"caption\";s:0:\"\";s:17:\"created_timestamp\";s:1:\"0\";s:9:\"copyright\";s:0:\"\";s:12:\"focal_length\";s:1:\"0\";s:3:\"iso\";s:1:\"0\";s:13:\"shutter_speed\";s:1:\"0\";s:5:\"title\";s:0:\"\";s:11:\"orientation\";s:1:\"0\";s:8:\"keywords\";a:0:{}}}'),
(2533, 476, 'flogo_id', '479'),
(2534, 476, 'flogo', 'http://localhost/project/wp-content/uploads/2019/04/air-berlin-128x50.png'),
(2536, 482, '_wp_attached_file', '2019/04/hotel-logo.jpg'),
(2537, 482, '_wp_attachment_metadata', 'a:5:{s:5:\"width\";i:160;s:6:\"height\";i:101;s:4:\"file\";s:22:\"2019/04/hotel-logo.jpg\";s:5:\"sizes\";a:3:{s:9:\"thumbnail\";a:4:{s:4:\"file\";s:22:\"hotel-logo-150x101.jpg\";s:5:\"width\";i:150;s:6:\"height\";i:101;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:29:\"woocommerce_gallery_thumbnail\";a:4:{s:4:\"file\";s:22:\"hotel-logo-100x100.jpg\";s:5:\"width\";i:100;s:6:\"height\";i:100;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:14:\"shop_thumbnail\";a:4:{s:4:\"file\";s:22:\"hotel-logo-100x100.jpg\";s:5:\"width\";i:100;s:6:\"height\";i:100;s:9:\"mime-type\";s:10:\"image/jpeg\";}}s:10:\"image_meta\";a:12:{s:8:\"aperture\";s:1:\"0\";s:6:\"credit\";s:0:\"\";s:6:\"camera\";s:0:\"\";s:7:\"caption\";s:0:\"\";s:17:\"created_timestamp\";s:1:\"0\";s:9:\"copyright\";s:0:\"\";s:12:\"focal_length\";s:1:\"0\";s:3:\"iso\";s:1:\"0\";s:13:\"shutter_speed\";s:1:\"0\";s:5:\"title\";s:0:\"\";s:11:\"orientation\";s:1:\"0\";s:8:\"keywords\";a:0:{}}}'),
(2538, 475, 'flogo_id', '482'),
(2539, 475, 'flogo', 'http://localhost/project/wp-content/uploads/2019/04/hotel-logo.jpg'),
(2540, 475, 'businessclass', '15,200.00'),
(2541, 475, 'economyclass', '14,300.00'),
(2542, 475, 'businessclassdate', '04/02/2019'),
(2543, 475, 'businessclasstime', '12:00 AM'),
(2544, 475, 'economyclassdate', '04/01/2019'),
(2545, 475, 'economyclasstime', '04:00 AM'),
(2546, 483, '_edit_last', '1'),
(2547, 483, '_edit_lock', '1554901538:1'),
(2548, 484, '_wp_attached_file', '2019/04/mastercard.png'),
(2549, 484, '_wp_attachment_metadata', 'a:5:{s:5:\"width\";i:45;s:6:\"height\";i:28;s:4:\"file\";s:22:\"2019/04/mastercard.png\";s:5:\"sizes\";a:0:{}s:10:\"image_meta\";a:12:{s:8:\"aperture\";s:1:\"0\";s:6:\"credit\";s:0:\"\";s:6:\"camera\";s:0:\"\";s:7:\"caption\";s:0:\"\";s:17:\"created_timestamp\";s:1:\"0\";s:9:\"copyright\";s:0:\"\";s:12:\"focal_length\";s:1:\"0\";s:3:\"iso\";s:1:\"0\";s:13:\"shutter_speed\";s:1:\"0\";s:5:\"title\";s:0:\"\";s:11:\"orientation\";s:1:\"0\";s:8:\"keywords\";a:0:{}}}'),
(2550, 483, 'flogo_id', '484'),
(2551, 483, 'flogo', 'http://localhost/project/wp-content/uploads/2019/04/mastercard.png'),
(2552, 483, 'fprice', '212.00'),
(2553, 483, 'ftax', '21,212.00'),
(2554, 483, 'businessclass', '212.00'),
(2555, 483, 'economyclass', '212.00'),
(2556, 483, 'businessclassdate', '04/10/2019'),
(2557, 483, 'businessclasstime', '12:00 AM'),
(2558, 483, 'economyclassdate', '04/08/2019'),
(2559, 483, 'economyclasstime', '12:00 AM'),
(2560, 491, '_edit_lock', '1557991096:1'),
(2561, 491, '_wp_page_template', 'admin-page/form_leads.php'),
(2607, 496, 'assigned_to', '460'),
(2608, 496, 'author', 'admin'),
(2609, 496, 'avatar', 'http://2.gravatar.com/avatar/?s=96&d=mm&r=g'),
(2610, 496, 'content', ''),
(2611, 496, 'custom', 'a:0:{}'),
(2612, 496, 'date', '2019-05-19 06:38:13'),
(2613, 496, 'email', 'admin@gmail.com'),
(2614, 496, 'ip_address', '127.0.0.1'),
(2615, 496, 'pinned', ''),
(2616, 496, 'rating', '4'),
(2617, 496, 'response', ''),
(2618, 496, 'review_id', 'f462632a5987bb5d13d7d648ef13d15b'),
(2619, 496, 'review_type', 'local'),
(2620, 496, 'title', ''),
(2621, 496, 'url', ''),
(2622, 460, '_glsr_count', 'a:1:{s:5:\"local\";a:6:{i:0;i:0;i:1;i:0;i:2;i:0;i:3;i:0;i:4;i:3;i:5;i:0;}}'),
(2623, 460, '_glsr_average', '4'),
(2624, 460, '_glsr_ranking', '3.6153846153846'),
(2640, 466, '_glsr_count', 'a:1:{s:5:\"local\";a:6:{i:0;i:0;i:1;i:0;i:2;i:1;i:3;i:0;i:4;i:0;i:5;i:0;}}'),
(2641, 466, '_glsr_average', '2'),
(2642, 466, '_glsr_ranking', '3.3636363636364'),
(2643, 498, 'assigned_to', '466'),
(2644, 498, 'author', 'admin'),
(2645, 498, 'avatar', 'http://1.gravatar.com/avatar/?s=96&d=mm&r=g'),
(2646, 498, 'content', 'milon'),
(2647, 498, 'custom', 'a:0:{}'),
(2648, 498, 'date', '2019-05-19 06:43:14'),
(2649, 498, 'email', 'admin@gmail.com'),
(2650, 498, 'ip_address', '127.0.0.1'),
(2651, 498, 'pinned', ''),
(2652, 498, 'rating', '2'),
(2653, 498, 'response', ''),
(2654, 498, 'review_id', 'ec50cc4f2bddc1f01b11425b8e076b8e'),
(2655, 498, 'review_type', 'local'),
(2656, 498, 'title', ''),
(2657, 498, 'url', ''),
(2685, 465, '_glsr_count', 'a:1:{s:5:\"local\";a:6:{i:0;i:0;i:1;i:0;i:2;i:0;i:3;i:0;i:4;i:0;i:5;i:0;}}'),
(2686, 465, '_glsr_average', '0'),
(2687, 465, '_glsr_ranking', '0'),
(2691, 500, 'assigned_to', '267'),
(2692, 500, 'author', 'admin'),
(2693, 500, 'avatar', 'http://2.gravatar.com/avatar/?s=96&d=mm&r=g'),
(2694, 500, 'content', 'test golobal'),
(2695, 500, 'custom', 'a:0:{}'),
(2696, 500, 'date', '2019-05-19 06:50:26'),
(2697, 500, 'email', 'admin@gmail.com'),
(2698, 500, 'ip_address', '127.0.0.1'),
(2699, 500, 'pinned', ''),
(2700, 500, 'rating', '2'),
(2701, 500, 'response', ''),
(2702, 500, 'review_id', 'b4c6a596ebe34f9f9a3ddd80cbc61931'),
(2703, 500, 'review_type', 'local'),
(2704, 500, 'title', ''),
(2705, 500, 'url', ''),
(2706, 267, '_glsr_count', 'a:1:{s:5:\"local\";a:6:{i:0;i:0;i:1;i:0;i:2;i:1;i:3;i:0;i:4;i:0;i:5;i:0;}}'),
(2707, 267, '_glsr_average', '2'),
(2708, 267, '_glsr_ranking', '3.3636363636364'),
(2709, 501, 'assigned_to', '460'),
(2710, 501, 'author', 'admin'),
(2711, 501, 'avatar', 'http://1.gravatar.com/avatar/?s=96&d=mm&r=g'),
(2712, 501, 'content', 'besto achi'),
(2713, 501, 'custom', 'a:0:{}'),
(2714, 501, 'date', '2019-05-19 06:52:20'),
(2715, 501, 'email', 'admin@gmail.com'),
(2716, 501, 'ip_address', '127.0.0.1'),
(2717, 501, 'pinned', ''),
(2718, 501, 'rating', '4'),
(2719, 501, 'response', ''),
(2720, 501, 'review_id', '37dc86524a3bb6447c782ad2e4af14fe'),
(2721, 501, 'review_type', 'local'),
(2722, 501, 'title', ''),
(2723, 501, 'url', ''),
(2724, 502, 'assigned_to', '460'),
(2725, 502, 'author', 'admin'),
(2726, 502, 'avatar', 'http://2.gravatar.com/avatar/?s=96&d=mm&r=g'),
(2727, 502, 'content', 'main'),
(2728, 502, 'custom', 'a:0:{}'),
(2729, 502, 'date', '2019-05-19 06:54:16'),
(2730, 502, 'email', 'admin@gmail.com'),
(2731, 502, 'ip_address', '127.0.0.1'),
(2732, 502, 'pinned', ''),
(2733, 502, 'rating', '4'),
(2734, 502, 'response', ''),
(2735, 502, 'review_id', 'd98e5b82cbac9ebb037f810360364f6a'),
(2736, 502, 'review_type', 'local'),
(2737, 502, 'title', ''),
(2738, 502, 'url', ''),
(2739, 503, 'assigned_to', '459'),
(2740, 503, 'author', 'admin'),
(2741, 503, 'avatar', 'http://0.gravatar.com/avatar/?s=96&d=mm&r=g'),
(2742, 503, 'content', 'hello bangladesh'),
(2743, 503, 'custom', 'a:0:{}'),
(2744, 503, 'date', '2019-05-19 07:24:30'),
(2745, 503, 'email', 'admin@gmail.com'),
(2746, 503, 'ip_address', '127.0.0.1'),
(2747, 503, 'pinned', ''),
(2748, 503, 'rating', '3'),
(2749, 503, 'response', ''),
(2750, 503, 'review_id', 'f51338724f78cebbe16c7d7fed0ecbef'),
(2751, 503, 'review_type', 'local'),
(2752, 503, 'title', ''),
(2753, 503, 'url', ''),
(2754, 459, '_glsr_count', 'a:1:{s:5:\"local\";a:6:{i:0;i:0;i:1;i:0;i:2;i:0;i:3;i:2;i:4;i:1;i:5;i:1;}}'),
(2755, 459, '_glsr_average', '3.8'),
(2756, 459, '_glsr_ranking', '3.5857142857143'),
(2757, 504, 'assigned_to', '459'),
(2758, 504, 'author', 'admin'),
(2759, 504, 'avatar', 'http://2.gravatar.com/avatar/?s=96&d=mm&r=g'),
(2760, 504, 'content', 'ami valo achi'),
(2761, 504, 'custom', 'a:0:{}'),
(2762, 504, 'date', '2019-05-19 07:25:03'),
(2763, 504, 'email', 'admin@gmail.com'),
(2764, 504, 'ip_address', '127.0.0.1'),
(2765, 504, 'pinned', ''),
(2766, 504, 'rating', '4'),
(2767, 504, 'response', ''),
(2768, 504, 'review_id', '770d1ba070d5ddc2007e1fcc258a2241'),
(2769, 504, 'review_type', 'local'),
(2770, 504, 'title', ''),
(2771, 504, 'url', ''),
(2772, 505, 'assigned_to', '459'),
(2773, 505, 'author', 'admin'),
(2774, 505, 'avatar', 'http://1.gravatar.com/avatar/?s=96&d=mm&r=g'),
(2775, 505, 'content', 'tomar ei na valo vasa'),
(2776, 505, 'custom', 'a:0:{}'),
(2777, 505, 'date', '2019-05-19 07:25:57'),
(2778, 505, 'email', 'admin@gmail.com'),
(2779, 505, 'ip_address', '127.0.0.1'),
(2780, 505, 'pinned', ''),
(2781, 505, 'rating', '5'),
(2782, 505, 'response', ''),
(2783, 505, 'review_id', '154e4f1c7e4883dc447e04691f43cdde'),
(2784, 505, 'review_type', 'local'),
(2785, 505, 'title', ''),
(2786, 505, 'url', ''),
(2787, 506, 'assigned_to', '459'),
(2788, 506, 'author', 'admin'),
(2789, 506, 'avatar', 'http://2.gravatar.com/avatar/?s=96&d=mm&r=g'),
(2790, 506, 'content', 'kire ki'),
(2791, 506, 'custom', 'a:0:{}'),
(2792, 506, 'date', '2019-05-19 07:26:25'),
(2793, 506, 'email', 'admin@gmail.com'),
(2794, 506, 'ip_address', '127.0.0.1'),
(2795, 506, 'pinned', ''),
(2796, 506, 'rating', '3'),
(2797, 506, 'response', ''),
(2798, 506, 'review_id', 'e7ae27dae4ac4b01a42cb746a5a3010b'),
(2799, 506, 'review_type', 'local'),
(2800, 506, 'title', ''),
(2801, 506, 'url', ''),
(2802, 507, 'assigned_to', '196'),
(2803, 507, 'author', 'admin'),
(2804, 507, 'avatar', 'http://0.gravatar.com/avatar/?s=96&d=mm&r=g'),
(2805, 507, 'content', 'hello'),
(2806, 507, 'custom', 'a:0:{}'),
(2807, 507, 'date', '2019-05-21 05:30:48'),
(2808, 507, 'email', 'admin@gmail.com'),
(2809, 507, 'ip_address', '127.0.0.1'),
(2810, 507, 'pinned', ''),
(2811, 507, 'rating', '4'),
(2812, 507, 'response', ''),
(2813, 507, 'review_id', '3d1483ebb27d308c71feb1243ef1334d'),
(2814, 507, 'review_type', 'local'),
(2815, 507, 'title', ''),
(2816, 507, 'url', ''),
(2817, 196, '_glsr_count', 'a:1:{s:5:\"local\";a:6:{i:0;i:0;i:1;i:0;i:2;i:0;i:3;i:0;i:4;i:1;i:5;i:0;}}'),
(2818, 196, '_glsr_average', '4'),
(2819, 196, '_glsr_ranking', '3.5454545454545'),
(2821, 196, 'wpuser_user_role', 'milon'),
(2822, 514, 'wpuf_form_settings', 'a:24:{s:9:\"post_type\";s:4:\"post\";s:11:\"post_status\";s:7:\"publish\";s:11:\"post_format\";s:1:\"0\";s:11:\"default_cat\";s:2:\"-1\";s:10:\"guest_post\";s:5:\"false\";s:13:\"guest_details\";s:4:\"true\";s:10:\"name_label\";s:4:\"Name\";s:11:\"email_label\";s:5:\"Email\";s:16:\"message_restrict\";s:68:\"This page is restricted. Please Log in / Register to view this page.\";s:11:\"redirect_to\";s:4:\"post\";s:7:\"message\";s:10:\"Post saved\";s:7:\"page_id\";s:0:\"\";s:3:\"url\";s:0:\"\";s:14:\"comment_status\";s:4:\"open\";s:11:\"submit_text\";s:6:\"Submit\";s:10:\"draft_post\";s:5:\"false\";s:16:\"edit_post_status\";s:7:\"publish\";s:16:\"edit_redirect_to\";s:4:\"same\";s:14:\"update_message\";s:25:\"Post updated successfully\";s:12:\"edit_page_id\";s:0:\"\";s:8:\"edit_url\";s:0:\"\";s:12:\"subscription\";s:10:\"- Select -\";s:11:\"update_text\";s:6:\"Update\";s:12:\"notification\";a:8:{s:3:\"new\";s:2:\"on\";s:6:\"new_to\";s:15:\"admin@gmail.com\";s:11:\"new_subject\";s:16:\"New post created\";s:8:\"new_body\";s:222:\"Hi Admin, \r\n\r\nA new post has been created in your site %sitename% (%siteurl%). \r\n\r\nHere is the details: \r\nPost Title: %post_title% \r\nContent: %post_content% \r\nAuthor: %author% \r\nPost URL: %permalink% \r\nEdit URL: %editlink%\";s:4:\"edit\";s:3:\"off\";s:7:\"edit_to\";s:15:\"admin@gmail.com\";s:12:\"edit_subject\";s:22:\"A post has been edited\";s:9:\"edit_body\";s:199:\"Hi Admin, \r\n\r\nThe post \"%post_title%\" has been updated. \r\n\r\nHere is the details: \r\nPost Title: %post_title% \r\nContent: %post_content% \r\nAuthor: %author% \r\nPost URL: %permalink% \r\nEdit URL: %editlink%\";}}'),
(2823, 514, 'wpuf_form_version', '2.8.7'),
(2824, 525, 'wpuf_form_settings', 'a:24:{s:9:\"post_type\";s:4:\"post\";s:11:\"post_status\";s:7:\"publish\";s:11:\"post_format\";s:1:\"0\";s:11:\"default_cat\";s:2:\"-1\";s:10:\"guest_post\";s:5:\"false\";s:13:\"guest_details\";s:4:\"true\";s:10:\"name_label\";s:4:\"Name\";s:11:\"email_label\";s:5:\"Email\";s:16:\"message_restrict\";s:68:\"This page is restricted. Please Log in / Register to view this page.\";s:11:\"redirect_to\";s:4:\"post\";s:7:\"message\";s:10:\"Post saved\";s:7:\"page_id\";s:0:\"\";s:3:\"url\";s:0:\"\";s:14:\"comment_status\";s:4:\"open\";s:11:\"submit_text\";s:6:\"Submit\";s:10:\"draft_post\";s:5:\"false\";s:16:\"edit_post_status\";s:7:\"publish\";s:16:\"edit_redirect_to\";s:4:\"same\";s:14:\"update_message\";s:25:\"Post updated successfully\";s:12:\"edit_page_id\";s:0:\"\";s:8:\"edit_url\";s:0:\"\";s:12:\"subscription\";s:10:\"- Select -\";s:11:\"update_text\";s:6:\"Update\";s:12:\"notification\";a:8:{s:3:\"new\";s:2:\"on\";s:6:\"new_to\";s:15:\"admin@gmail.com\";s:11:\"new_subject\";s:16:\"New post created\";s:8:\"new_body\";s:222:\"Hi Admin, \r\n\r\nA new post has been created in your site %sitename% (%siteurl%). \r\n\r\nHere is the details: \r\nPost Title: %post_title% \r\nContent: %post_content% \r\nAuthor: %author% \r\nPost URL: %permalink% \r\nEdit URL: %editlink%\";s:4:\"edit\";s:3:\"off\";s:7:\"edit_to\";s:15:\"admin@gmail.com\";s:12:\"edit_subject\";s:22:\"A post has been edited\";s:9:\"edit_body\";s:199:\"Hi Admin, \r\n\r\nThe post \"%post_title%\" has been updated. \r\n\r\nHere is the details: \r\nPost Title: %post_title% \r\nContent: %post_content% \r\nAuthor: %author% \r\nPost URL: %permalink% \r\nEdit URL: %editlink%\";}}'),
(2825, 525, 'wpuf_form_version', '2.8.7'),
(2826, 532, 'wpuf_form_settings', 'a:8:{s:4:\"role\";s:10:\"subscriber\";s:11:\"redirect_to\";s:4:\"same\";s:7:\"message\";s:23:\"Registration successful\";s:14:\"update_message\";s:28:\"Profile updated successfully\";s:7:\"page_id\";s:1:\"0\";s:3:\"url\";s:0:\"\";s:11:\"submit_text\";s:8:\"Register\";s:11:\"update_text\";s:14:\"Update Profile\";}'),
(2827, 532, 'wpuf_form_version', '2.8.7'),
(2828, 13, '_edit_last', '1'),
(2829, 13, '_wpuf_form_id', ''),
(2830, 13, '_wpuf_res_display', 'all'),
(2831, 538, 'wpuf_form_settings', 'a:48:{s:11:\"redirect_to\";s:4:\"same\";s:7:\"message\";s:64:\"Thanks for contacting us! We will get in touch with you shortly.\";s:7:\"page_id\";s:0:\"\";s:3:\"url\";s:0:\"\";s:11:\"submit_text\";s:12:\"Submit Query\";s:18:\"submit_button_cond\";O:8:\"stdClass\":3:{s:16:\"condition_status\";s:2:\"no\";s:10:\"cond_logic\";s:3:\"any\";s:10:\"conditions\";a:1:{i:0;O:8:\"stdClass\":3:{s:4:\"name\";s:0:\"\";s:8:\"operator\";s:1:\"=\";s:6:\"option\";s:0:\"\";}}}s:13:\"schedule_form\";s:5:\"false\";s:14:\"schedule_start\";s:0:\"\";s:12:\"schedule_end\";s:0:\"\";s:18:\"sc_pending_message\";s:39:\"Form submission hasn\'t been started yet\";s:18:\"sc_expired_message\";s:30:\"Form submission is now closed.\";s:13:\"require_login\";s:5:\"false\";s:17:\"req_login_message\";s:36:\"You need to login to submit a query.\";s:13:\"limit_entries\";s:5:\"false\";s:12:\"limit_number\";s:3:\"100\";s:13:\"limit_message\";s:57:\"Sorry, we have reached the maximum number of submissions.\";s:14:\"label_position\";s:5:\"above\";s:13:\"use_theme_css\";s:10:\"wpuf-style\";s:9:\"quiz_form\";s:2:\"no\";s:22:\"shuffle_question_order\";s:2:\"no\";s:13:\"release_grade\";s:16:\"after_submission\";s:18:\"respondent_can_see\";a:3:{i:0;s:16:\"missed_questions\";i:1;s:15:\"correct_answers\";i:2;s:12:\"point_values\";}s:12:\"total_points\";i:0;s:16:\"enable_multistep\";b:0;s:26:\"multistep_progressbar_type\";s:11:\"progressive\";s:21:\"payment_paypal_images\";s:68:\"https://www.paypalobjects.com/webstatic/mktg/logo/AM_mc_vs_dc_ae.jpg\";s:20:\"payment_paypal_label\";s:6:\"PayPal\";s:20:\"payment_stripe_label\";s:11:\"Credit Card\";s:21:\"payment_stripe_images\";a:4:{i:0;s:4:\"visa\";i:1;s:10:\"mastercard\";i:2;s:4:\"amex\";i:3;s:8:\"discover\";}s:25:\"payment_stripe_deactivate\";s:0:\"\";s:11:\"stripe_mode\";s:4:\"live\";s:14:\"stripe_page_id\";s:0:\"\";s:20:\"stripe_override_keys\";s:0:\"\";s:12:\"stripe_email\";s:0:\"\";s:10:\"stripe_key\";s:0:\"\";s:17:\"stripe_secret_key\";s:0:\"\";s:15:\"stripe_key_test\";s:0:\"\";s:22:\"stripe_secret_key_test\";s:0:\"\";s:20:\"stripe_prefill_email\";s:0:\"\";s:23:\"stripe_user_email_field\";s:0:\"\";s:25:\"payment_paypal_deactivate\";s:0:\"\";s:11:\"paypal_mode\";s:4:\"live\";s:11:\"paypal_type\";s:5:\"_cart\";s:15:\"paypal_override\";s:0:\"\";s:12:\"paypal_email\";s:0:\"\";s:14:\"paypal_page_id\";s:0:\"\";s:20:\"paypal_prefill_email\";s:0:\"\";s:23:\"paypal_user_email_field\";s:0:\"\";}'),
(2832, 538, 'notifications', 'a:1:{i:0;a:14:{s:6:\"active\";s:4:\"true\";s:4:\"type\";s:5:\"email\";s:5:\"smsTo\";s:0:\"\";s:7:\"smsText\";s:45:\"[{form_name}] New Form Submission #{entry_id}\";s:4:\"name\";s:18:\"Admin Notification\";s:7:\"subject\";s:45:\"[{form_name}] New Form Submission #{entry_id}\";s:2:\"to\";s:13:\"{admin_email}\";s:7:\"replyTo\";s:13:\"{field:email}\";s:7:\"message\";s:19:\"<p>{all_fields}</p>\";s:8:\"fromName\";s:11:\"{site_name}\";s:11:\"fromAddress\";s:13:\"{admin_email}\";s:2:\"cc\";s:0:\"\";s:3:\"bcc\";s:0:\"\";s:12:\"weforms_cond\";a:3:{s:16:\"condition_status\";s:2:\"no\";s:10:\"cond_logic\";s:3:\"any\";s:10:\"conditions\";a:1:{i:0;a:3:{s:4:\"name\";s:0:\"\";s:8:\"operator\";s:1:\"=\";s:6:\"option\";s:0:\"\";}}}}}'),
(2833, 538, 'integrations', 'a:1:{s:5:\"slack\";O:8:\"stdClass\":2:{s:7:\"enabled\";b:0;s:3:\"url\";s:0:\"\";}}'),
(2835, 548, '_edit_lock', '1558510345:1'),
(2836, 551, 'wppb_role_slug', 'administrator'),
(2837, 552, 'wppb_role_slug', 'author'),
(2838, 553, 'wppb_role_slug', 'bbp_blocked'),
(2839, 554, 'wppb_role_slug', 'wphb_booking_editor'),
(2840, 555, 'wppb_role_slug', 'booking_package_member'),
(2841, 556, 'wppb_role_slug', 'contributor'),
(2842, 557, 'wppb_role_slug', 'customer'),
(2843, 558, 'wppb_role_slug', 'editor'),
(2844, 559, 'wppb_role_slug', 'awebooking_customer'),
(2845, 560, 'wppb_role_slug', 'wphb_hotel_manager'),
(2846, 561, 'wppb_role_slug', 'awebooking_manager'),
(2847, 562, 'wppb_role_slug', 'awebooking_receptionist'),
(2848, 563, 'wppb_role_slug', 'bbp_keymaster'),
(2849, 564, 'wppb_role_slug', 'bbp_moderator'),
(2850, 565, 'wppb_role_slug', 'bbp_participant'),
(2851, 566, 'wppb_role_slug', 'shop_manager'),
(2852, 567, 'wppb_role_slug', 'bbp_spectator'),
(2853, 568, 'wppb_role_slug', 'subscriber'),
(2854, 569, 'wppb_role_slug', 'wp-travel-customer'),
(2855, 570, 'wppb_role_slug', 'milon'),
(2856, 571, 'wppb_role_slug', 'taibur'),
(2857, 571, '_edit_lock', '1559119807:1'),
(2858, 571, '_edit_last', '1'),
(2895, 576, '_menu_item_type', 'post_type'),
(2896, 576, '_menu_item_menu_item_parent', '34'),
(2897, 576, '_menu_item_object_id', '186'),
(2898, 576, '_menu_item_object', 'page'),
(2899, 576, '_menu_item_target', ''),
(2900, 576, '_menu_item_classes', 'a:1:{i:0;s:0:\"\";}'),
(2901, 576, '_menu_item_xfn', ''),
(2902, 576, '_menu_item_url', ''),
(2913, 578, '_edit_lock', '1558586678:1'),
(2914, 580, '_edit_lock', '1558811748:1'),
(2915, 582, '_edit_lock', '1558586742:1'),
(2916, 584, '_menu_item_type', 'post_type'),
(2917, 584, '_menu_item_menu_item_parent', '0'),
(2918, 584, '_menu_item_object_id', '582'),
(2919, 584, '_menu_item_object', 'page'),
(2920, 584, '_menu_item_target', ''),
(2921, 584, '_menu_item_classes', 'a:1:{i:0;s:0:\"\";}'),
(2922, 584, '_menu_item_xfn', ''),
(2923, 584, '_menu_item_url', ''),
(2925, 585, '_menu_item_type', 'post_type'),
(2926, 585, '_menu_item_menu_item_parent', '0'),
(2927, 585, '_menu_item_object_id', '580'),
(2928, 585, '_menu_item_object', 'page'),
(2929, 585, '_menu_item_target', ''),
(2930, 585, '_menu_item_classes', 'a:1:{i:0;s:0:\"\";}'),
(2931, 585, '_menu_item_xfn', ''),
(2932, 585, '_menu_item_url', ''),
(2934, 586, '_menu_item_type', 'post_type'),
(2935, 586, '_menu_item_menu_item_parent', '0'),
(2936, 586, '_menu_item_object_id', '578'),
(2937, 586, '_menu_item_object', 'page'),
(2938, 586, '_menu_item_target', ''),
(2939, 586, '_menu_item_classes', 'a:1:{i:0;s:0:\"\";}'),
(2940, 586, '_menu_item_xfn', ''),
(2941, 586, '_menu_item_url', ''),
(2943, 587, '_menu_item_type', 'post_type'),
(2944, 587, '_menu_item_menu_item_parent', '0'),
(2945, 587, '_menu_item_object_id', '582'),
(2946, 587, '_menu_item_object', 'page'),
(2947, 587, '_menu_item_target', ''),
(2948, 587, '_menu_item_classes', 'a:1:{i:0;s:0:\"\";}'),
(2949, 587, '_menu_item_xfn', ''),
(2950, 587, '_menu_item_url', ''),
(2952, 588, '_menu_item_type', 'post_type'),
(2953, 588, '_menu_item_menu_item_parent', '0'),
(2954, 588, '_menu_item_object_id', '580'),
(2955, 588, '_menu_item_object', 'page'),
(2956, 588, '_menu_item_target', ''),
(2957, 588, '_menu_item_classes', 'a:1:{i:0;s:0:\"\";}'),
(2958, 588, '_menu_item_xfn', ''),
(2959, 588, '_menu_item_url', ''),
(2961, 589, '_menu_item_type', 'post_type');
INSERT INTO `wp_postmeta` (`meta_id`, `post_id`, `meta_key`, `meta_value`) VALUES
(2962, 589, '_menu_item_menu_item_parent', '0'),
(2963, 589, '_menu_item_object_id', '578'),
(2964, 589, '_menu_item_object', 'page'),
(2965, 589, '_menu_item_target', ''),
(2966, 589, '_menu_item_classes', 'a:1:{i:0;s:0:\"\";}'),
(2967, 589, '_menu_item_xfn', ''),
(2968, 589, '_menu_item_url', ''),
(2970, 590, '_menu_item_type', 'post_type'),
(2971, 590, '_menu_item_menu_item_parent', '0'),
(2972, 590, '_menu_item_object_id', '529'),
(2973, 590, '_menu_item_object', 'page'),
(2974, 590, '_menu_item_target', ''),
(2975, 590, '_menu_item_classes', 'a:1:{i:0;s:0:\"\";}'),
(2976, 590, '_menu_item_xfn', ''),
(2977, 590, '_menu_item_url', ''),
(2979, 591, '_menu_item_type', 'post_type'),
(2980, 591, '_menu_item_menu_item_parent', '0'),
(2981, 591, '_menu_item_object_id', '528'),
(2982, 591, '_menu_item_object', 'page'),
(2983, 591, '_menu_item_target', ''),
(2984, 591, '_menu_item_classes', 'a:1:{i:0;s:0:\"\";}'),
(2985, 591, '_menu_item_xfn', ''),
(2986, 591, '_menu_item_url', ''),
(2988, 592, '_menu_item_type', 'post_type'),
(2989, 592, '_menu_item_menu_item_parent', '0'),
(2990, 592, '_menu_item_object_id', '522'),
(2991, 592, '_menu_item_object', 'page'),
(2992, 592, '_menu_item_target', ''),
(2993, 592, '_menu_item_classes', 'a:1:{i:0;s:0:\"\";}'),
(2994, 592, '_menu_item_xfn', ''),
(2995, 592, '_menu_item_url', ''),
(3003, 595, '_edit_lock', '1558725710:1'),
(3004, 595, '_edit_last', '1'),
(3005, 595, '_thumbnail_id', '176'),
(3006, 595, 'agentname', 'Bangladeshi Service Team and Guide'),
(3007, 595, 'makkahstay', '10'),
(3008, 595, 'madinahstay', '6'),
(3009, 595, 'makkahhotelhame', 'Sheraton Makkah Jabal Al Kaaba Hotel'),
(3010, 595, 'Makkahoteldistance', '26'),
(3011, 595, 'madinahhotelname', 'Grand Madina Hotel'),
(3012, 595, 'madinahhoteldistance', '30'),
(3013, 595, 'locationcheckins', '05/25/2019'),
(3014, 595, 'locationcheckout', '05/30/2019'),
(3015, 595, 'umrahroom', '16'),
(3016, 595, 'umrahparson', '32'),
(3017, 595, 'umrahdouble', '6,000.00'),
(3018, 595, 'umrahtriplebed', '8,000.00'),
(3019, 595, 'umrahfourbed', '10,000.00'),
(3020, 595, 'umrahsharing', '13,000.00'),
(3021, 595, 'umrahpolicies', '<span id=\"e18\" class=\"qc_ si29 \">Lowest Prices &amp; Latest Reviews on TripAdvisor®. Cheap Flights. Millions of hotel reviews. Best Places to Eat. Amazing Experiences. Hidden Gems. Candid traveler photos. Vacation Rentals. Easy <b>price</b> comparison. Tours, Attractions + More. Fun Things to Do.</span>\r\n<div id=\"e19\" class=\"kc_  \"></div>\r\n<div id=\"e24\" class=\"kc_  \"></div>\r\n<div id=\"e25\" class=\"kc_  \"></div>\r\n<div id=\"e30\" class=\"kc_  \">\r\n<div id=\"e31\" class=\"kc_  \">\r\n<div id=\"e33\" class=\"kc_ si17 \"><a id=\"e34\" class=\"nc_ pc_ si18 \" href=\"https://www.google.com/aclk?sa=l&amp;ai=DChcSEwjNldaT8bTiAhXDIysKHQSuBCQYABAFGgJzZg&amp;sig=AOD64_1Ok09ghUaiTYFtB7XaitM975pYzQ&amp;adurl=&amp;nb=13&amp;res_url=https%3A%2F%2Fbd.zapmeta.ws%2Fws%3Fq%3Dhajj%2520and%2520umrah%2520package%26asid%3Dzm_bd_gb_2_cg1_05%26mt%3Db%26nw%3Ds%26de%3Dc%26ap%3D1t2%26ac%3D2037%26gclid%3DCj0KCQjwrJ7nBRD5ARIsAATMxstyQyUan_-lnALUqbMj1yXRUvQbacW7Pda7jf6_ziyOH6EjbCfCDlcaAsPFEALw_wcB&amp;rurl=https%3A%2F%2Fwww.google.com%2F&amp;nm=73\" target=\"_blank\" rel=\"noopener\" data-lines=\"1\" data-truncate=\"0\" data-nb=\"13\">Hotels</a><span id=\"e36\" class=\"qc_ priceExtensionChipsExpandoPriceHyphen \">-</span><span id=\"e37\" class=\"nc_ pc_ priceExtensionChipsPrice \" data-lines=\"1\" data-truncate=\"0\">from $50.00/night</span><span id=\"e38\" class=\"nc_ pc_ si19 \" data-lines=\"1\" data-truncate=\"0\">Compare Prices</span></div>\r\n</div>\r\n</div>'),
(3022, 595, 'umrahfacilites', '<span id=\"e18\" class=\"qc_ si29 \">Lowest Prices &amp; Latest Reviews on TripAdvisor®. Cheap Flights. Millions of hotel reviews. Best Places to Eat. Amazing Experiences. Hidden Gems. Candid traveler photos. Vacation Rentals. Easy <b>price</b> comparison. Tours, Attractions + More. Fun Things to Do.</span>\r\n<div id=\"e19\" class=\"kc_  \"></div>\r\n<div id=\"e24\" class=\"kc_  \"></div>\r\n<div id=\"e25\" class=\"kc_  \"></div>\r\n<div id=\"e30\" class=\"kc_  \">\r\n<div id=\"e31\" class=\"kc_  \">\r\n<div id=\"e33\" class=\"kc_ si17 \"><a id=\"e34\" class=\"nc_ pc_ si18 \" href=\"https://www.google.com/aclk?sa=l&amp;ai=DChcSEwjNldaT8bTiAhXDIysKHQSuBCQYABAFGgJzZg&amp;sig=AOD64_1Ok09ghUaiTYFtB7XaitM975pYzQ&amp;adurl=&amp;nb=13&amp;res_url=https%3A%2F%2Fbd.zapmeta.ws%2Fws%3Fq%3Dhajj%2520and%2520umrah%2520package%26asid%3Dzm_bd_gb_2_cg1_05%26mt%3Db%26nw%3Ds%26de%3Dc%26ap%3D1t2%26ac%3D2037%26gclid%3DCj0KCQjwrJ7nBRD5ARIsAATMxstyQyUan_-lnALUqbMj1yXRUvQbacW7Pda7jf6_ziyOH6EjbCfCDlcaAsPFEALw_wcB&amp;rurl=https%3A%2F%2Fwww.google.com%2F&amp;nm=73\" target=\"_blank\" rel=\"noopener\" data-lines=\"1\" data-truncate=\"0\" data-nb=\"13\">Hotels</a><span id=\"e36\" class=\"qc_ priceExtensionChipsExpandoPriceHyphen \">-</span><span id=\"e37\" class=\"nc_ pc_ priceExtensionChipsPrice \" data-lines=\"1\" data-truncate=\"0\">from $50.00/night</span><span id=\"e38\" class=\"nc_ pc_ si19 \" data-lines=\"1\" data-truncate=\"0\">Compare Prices</span></div>\r\n</div>\r\n</div>'),
(3023, 596, 'assigned_to', '595'),
(3024, 596, 'author', 'admin'),
(3025, 596, 'avatar', 'https://secure.gravatar.com/avatar/?s=96&d=mm&r=g'),
(3026, 596, 'content', ''),
(3027, 596, 'custom', 'a:0:{}'),
(3028, 596, 'date', '2019-05-24 19:23:54'),
(3029, 596, 'email', 'admin@gmail.com'),
(3030, 596, 'ip_address', '103.127.176.78'),
(3031, 596, 'pinned', ''),
(3032, 596, 'rating', '3'),
(3033, 596, 'response', ''),
(3034, 596, 'review_id', 'f32e2b9a7df30121f83ee14e50c4f667'),
(3035, 596, 'review_type', 'local'),
(3036, 596, 'title', ''),
(3037, 596, 'url', ''),
(3038, 595, '_glsr_count', 'a:1:{s:5:\"local\";a:6:{i:0;i:0;i:1;i:0;i:2;i:0;i:3;i:1;i:4;i:0;i:5;i:0;}}'),
(3039, 595, '_glsr_average', '3'),
(3040, 595, '_glsr_ranking', '3.4545454545455'),
(3041, 597, '_edit_lock', '1558777179:1'),
(3042, 597, '_edit_last', '1'),
(3043, 597, '_thumbnail_id', '348'),
(3044, 597, 'agentname', 'Bangladeshi Service Team and Guide'),
(3045, 597, 'makkahstay', '8'),
(3046, 597, 'madinahstay', '5'),
(3047, 597, 'makkahhotelhame', 'Sheraton Makkah Jabal Al Kaaba Hotel'),
(3048, 597, 'Makkahoteldistance', '26'),
(3049, 597, 'madinahhotelname', 'Grand Madina Hotel'),
(3050, 597, 'madinahhoteldistance', '30'),
(3051, 597, 'locationcheckins', '05/25/2019'),
(3052, 597, 'locationcheckout', '05/30/2019'),
(3053, 597, 'umrahroom', '16'),
(3054, 597, 'umrahparson', '32'),
(3055, 597, 'umrahdouble', '6,000.00'),
(3056, 597, 'umrahtriplebed', '8,000.00'),
(3057, 597, 'umrahfourbed', '10,000.00'),
(3058, 597, 'umrahsharing', '13,000.00'),
(3059, 597, 'umrahpolicies', 'Travel offers, with the best hotels, transfers and tours. Book your holidays. Access the best hotel deals and customized travel <b>packages</b> for your Cuba trip. Circuitos por Cuba. Paquetes a la medida. Havanatur Celimar. Lodging in Cuba. Alojamiento en Cuba. Havanatur Cuba. Transfer in Cuba. Conventions in Cuba. Excursiones por Cuba. Offers in Cuba.'),
(3060, 597, 'umrahfacilites', 'Travel offers, with the best hotels, transfers and tours. Book your holidays. Access the best hotel deals and customized travel <b>packages</b> for your Cuba trip. Circuitos por Cuba. Paquetes a la medida. Havanatur Celimar. Lodging in Cuba. Alojamiento en Cuba. Havanatur Cuba. Transfer in Cuba. Conventions in Cuba. Excursiones por Cuba. Offers in Cuba.'),
(3061, 598, 'assigned_to', '597'),
(3062, 598, 'author', 'admin'),
(3063, 598, 'avatar', 'https://secure.gravatar.com/avatar/?s=96&d=mm&r=g'),
(3064, 598, 'content', ''),
(3065, 598, 'custom', 'a:0:{}'),
(3066, 598, 'date', '2019-05-24 19:33:10'),
(3067, 598, 'email', 'admin@gmail.com'),
(3068, 598, 'ip_address', '103.127.176.78'),
(3069, 598, 'pinned', ''),
(3070, 598, 'rating', '4'),
(3071, 598, 'response', ''),
(3072, 598, 'review_id', '9671663c0ebd768ec56cea070b5d7a61'),
(3073, 598, 'review_type', 'local'),
(3074, 598, 'title', ''),
(3075, 598, 'url', ''),
(3076, 597, '_glsr_count', 'a:1:{s:5:\"local\";a:6:{i:0;i:0;i:1;i:0;i:2;i:0;i:3;i:0;i:4;i:1;i:5;i:0;}}'),
(3077, 597, '_glsr_average', '4'),
(3078, 597, '_glsr_ranking', '3.5454545454545'),
(3079, 352, 'toursname', 'faucibus egestas rutrum mauris vulputate consequat ante'),
(3080, 352, 'toursemail', 'admin@admin.com'),
(3081, 352, 'toursprice', '20,000.00'),
(3082, 352, 'tourstype', 'Free'),
(3083, 352, 'toursoverview', 'faucibus egestas rutrum mauris vulputate consequat antefaucibus egestas rutrum mauris vulputate consequat antefaucibus egestas rutrum mauris vulputate consequat antefaucibus egestas rutrum mauris vulputate consequat ante'),
(3084, 352, 'toursmap', 'faucibus egestas rutrum mauris vulputate consequat antefaucibus egestas rutrum mauris vulputate consequat antefaucibus egestas rutrum mauris vulputate consequat ante'),
(3085, 352, 'toursdayone', 'faucibus egestas rutrum mauris vulputate consequat antefaucibus egestas rutrum mauris vulputate consequat antefaucibus egestas rutrum mauris vulputate consequat antefaucibus egestas rutrum mauris vulputate consequat antefaucibus egestas rutrum mauris vulputate consequat antefaucibus egestas rutrum mauris vulputate consequat antefaucibus egestas rutrum mauris vulputate consequat antefaucibus egestas rutrum mauris vulputate consequat antefaucibus egestas rutrum mauris vulputate consequat antefaucibus egestas rutrum mauris vulputate consequat antefaucibus egestas rutrum mauris vulputate consequat antefaucibus egestas rutrum mauris vulputate consequat antefaucibus egestas rutrum mauris vulputate consequat antefaucibus egestas rutrum mauris vulputate consequat ante'),
(3086, 352, 'toursdaytwo', 'faucibus egestas rutrum mauris vulputate consequat antefaucibus egestas rutrum mauris vulputate consequat antefaucibus egestas rutrum mauris vulputate consequat antefaucibus egestas rutrum mauris vulputate consequat antefaucibus egestas rutrum mauris vulputate consequat antefaucibus egestas rutrum mauris vulputate consequat antefaucibus egestas rutrum mauris vulputate consequat antefaucibus egestas rutrum mauris vulputate consequat antefaucibus egestas rutrum mauris vulputate consequat antefaucibus egestas rutrum mauris vulputate consequat antefaucibus egestas rutrum mauris vulputate consequat antefaucibus egestas rutrum mauris vulputate consequat ante'),
(3087, 352, 'toursdaythress', 'faucibus egestas rutrum mauris vulputate consequat antefaucibus egestas rutrum mauris vulputate consequat antefaucibus egestas rutrum mauris vulputate consequat antefaucibus egestas rutrum mauris vulputate consequat antefaucibus egestas rutrum mauris vulputate consequat antefaucibus egestas rutrum mauris vulputate consequat antefaucibus egestas rutrum mauris vulputate consequat antefaucibus egestas rutrum mauris vulputate consequat antefaucibus egestas rutrum mauris vulputate consequat antefaucibus egestas rutrum mauris vulputate consequat antefaucibus egestas rutrum mauris vulputate consequat antefaucibus egestas rutrum mauris vulputate consequat ante'),
(3088, 352, 'toursdayfour', 'faucibus egestas rutrum mauris vulputate consequat antefaucibus egestas rutrum mauris vulputate consequat antefaucibus egestas rutrum mauris vulputate consequat antefaucibus egestas rutrum mauris vulputate consequat antefaucibus egestas rutrum mauris vulputate consequat antefaucibus egestas rutrum mauris vulputate consequat antefaucibus egestas rutrum mauris vulputate consequat antefaucibus egestas rutrum mauris vulputate consequat antefaucibus egestas rutrum mauris vulputate consequat antefaucibus egestas rutrum mauris vulputate consequat antefaucibus egestas rutrum mauris vulputate consequat antefaucibus egestas rutrum mauris vulputate consequat antefaucibus egestas rutrum mauris vulputate consequat antefaucibus egestas rutrum mauris vulputate consequat antefaucibus egestas rutrum mauris vulputate consequat antefaucibus egestas rutrum mauris vulputate consequat ante'),
(3089, 602, '_edit_lock', '1558757823:1'),
(3090, 602, '_edit_last', '1'),
(3091, 603, '_wp_attached_file', '2019/05/2.jpg'),
(3092, 603, '_wp_attachment_metadata', 'a:5:{s:5:\"width\";i:263;s:6:\"height\";i:197;s:4:\"file\";s:13:\"2019/05/2.jpg\";s:5:\"sizes\";a:1:{s:9:\"thumbnail\";a:4:{s:4:\"file\";s:13:\"2-150x150.jpg\";s:5:\"width\";i:150;s:6:\"height\";i:150;s:9:\"mime-type\";s:10:\"image/jpeg\";}}s:10:\"image_meta\";a:12:{s:8:\"aperture\";s:1:\"0\";s:6:\"credit\";s:0:\"\";s:6:\"camera\";s:0:\"\";s:7:\"caption\";s:0:\"\";s:17:\"created_timestamp\";s:1:\"0\";s:9:\"copyright\";s:0:\"\";s:12:\"focal_length\";s:1:\"0\";s:3:\"iso\";s:1:\"0\";s:13:\"shutter_speed\";s:1:\"0\";s:5:\"title\";s:0:\"\";s:11:\"orientation\";s:1:\"0\";s:8:\"keywords\";a:0:{}}}'),
(3093, 602, '_thumbnail_id', '603'),
(3094, 602, 'toursdeparturedate', '05/25/2019'),
(3095, 602, 'toursarrivedate', '05/30/2019'),
(3096, 602, 'toursname', 'Cursus faucibus egestas rutrum mauris vulputate consequat ante'),
(3097, 602, 'toursemail', 'milondiucse@gmail.com'),
(3098, 602, 'tourlocation', 'Cursus faucibus egestas rutrum mauris vulputate consequat ante'),
(3099, 602, 'toursprice', '50,000.00'),
(3100, 602, 'tourstype', 'Free'),
(3101, 602, 'maximumnumberof', '6'),
(3102, 602, 'toursoverview', 'Cursus faucibus egestas rutrum mauris vulputate consequat anteCursus faucibus egestas rutrum mauris vulputate consequat anteCursus faucibus egestas rutrum mauris vulputate consequat anteCursus faucibus egestas rutrum mauris vulputate consequat ante'),
(3103, 602, 'toursdayone', 'Cursus faucibus egestas rutrum mauris vulputate consequat anteCursus faucibus egestas rutrum mauris vulputate consequat anteCursus faucibus egestas rutrum mauris vulputate consequat anteCursus faucibus egestas rutrum mauris vulputate consequat anteCursus faucibus egestas rutrum mauris vulputate consequat anteCursus faucibus egestas rutrum mauris vulputate consequat anteCursus faucibus egestas rutrum mauris vulputate consequat anteCursus faucibus egestas rutrum mauris vulputate consequat ante'),
(3104, 602, 'toursdaytwo', 'Cursus faucibus egestas rutrum mauris vulputate consequat anteCursus faucibus egestas rutrum mauris vulputate consequat anteCursus faucibus egestas rutrum mauris vulputate consequat anteCursus faucibus egestas rutrum mauris vulputate consequat anteCursus faucibus egestas rutrum mauris vulputate consequat anteCursus faucibus egestas rutrum mauris vulputate consequat anteCursus faucibus egestas rutrum mauris vulputate consequat anteCursus faucibus egestas rutrum mauris vulputate consequat ante'),
(3105, 602, 'toursdaythress', 'Cursus faucibus egestas rutrum mauris vulputate consequat anteCursus faucibus egestas rutrum mauris vulputate consequat anteCursus faucibus egestas rutrum mauris vulputate consequat anteCursus faucibus egestas rutrum mauris vulputate consequat anteCursus faucibus egestas rutrum mauris vulputate consequat anteCursus faucibus egestas rutrum mauris vulputate consequat anteCursus faucibus egestas rutrum mauris vulputate consequat anteCursus faucibus egestas rutrum mauris vulputate consequat ante'),
(3106, 602, 'toursdayfour', 'Cursus faucibus egestas rutrum mauris vulputate consequat anteCursus faucibus egestas rutrum mauris vulputate consequat anteCursus faucibus egestas rutrum mauris vulputate consequat anteCursus faucibus egestas rutrum mauris vulputate consequat anteCursus faucibus egestas rutrum mauris vulputate consequat anteCursus faucibus egestas rutrum mauris vulputate consequat anteCursus faucibus egestas rutrum mauris vulputate consequat anteCursus faucibus egestas rutrum mauris vulputate consequat anteCursus faucibus egestas rutrum mauris vulputate consequat anteCursus faucibus egestas rutrum mauris vulputate consequat anteCursus faucibus egestas rutrum mauris vulputate consequat anteCursus faucibus egestas rutrum mauris vulputate consequat anteCursus faucibus egestas rutrum mauris vulputate consequat ante'),
(3107, 379, 'hotelcheckin', '05/25/2019'),
(3108, 378, 'hotelcheckin', '05/25/2019'),
(3109, 380, 'hotelcheckin', '05/25/2019'),
(3110, 604, '_wp_attached_file', '2019/04/o-RUSSIA-VIRTUALPRIDE-facebook-263x197.jpg'),
(3111, 604, '_wp_attachment_metadata', 'a:5:{s:5:\"width\";i:263;s:6:\"height\";i:197;s:4:\"file\";s:50:\"2019/04/o-RUSSIA-VIRTUALPRIDE-facebook-263x197.jpg\";s:5:\"sizes\";a:1:{s:9:\"thumbnail\";a:4:{s:4:\"file\";s:50:\"o-RUSSIA-VIRTUALPRIDE-facebook-263x197-150x150.jpg\";s:5:\"width\";i:150;s:6:\"height\";i:150;s:9:\"mime-type\";s:10:\"image/jpeg\";}}s:10:\"image_meta\";a:12:{s:8:\"aperture\";s:1:\"0\";s:6:\"credit\";s:0:\"\";s:6:\"camera\";s:0:\"\";s:7:\"caption\";s:0:\"\";s:17:\"created_timestamp\";s:1:\"0\";s:9:\"copyright\";s:0:\"\";s:12:\"focal_length\";s:1:\"0\";s:3:\"iso\";s:1:\"0\";s:13:\"shutter_speed\";s:1:\"0\";s:5:\"title\";s:0:\"\";s:11:\"orientation\";s:1:\"0\";s:8:\"keywords\";a:0:{}}}'),
(3112, 196, 'umrahpolicies', '28 Days Umrah Silver-Package28 Days Umrah Silver-Package28 Days Umrah Silver-Package28 Days Umrah Silver-Package28 Days Umrah Silver-Package28 Days Umrah Silver-Package28 Days Umrah Silver-Package28 Days Umrah Silver-Package28 Days Umrah Silver-Package28 Days Umrah Silver-Package28 Days Umrah Silver-Package28 Days Umrah Silver-Package28 Days Umrah Silver-Package28 Days Umrah Silver-Package28 Days Umrah Silver-Package28 Days Umrah Silver-Package28 Days Umrah Silver-Package28 Days Umrah Silver-Package28 Days Umrah Silver-Package28 Days Umrah Silver-Package28 Days Umrah Silver-Package'),
(3113, 196, 'umrahfacilites', '28 Days Umrah Silver-Package28 Days Umrah Silver-Package28 Days Umrah Silver-Package28 Days Umrah Silver-Package28 Days Umrah Silver-Package28 Days Umrah Silver-Package28 Days Umrah Silver-Package28 Days Umrah Silver-Package28 Days Umrah Silver-Package28 Days Umrah Silver-Package28 Days Umrah Silver-Package28 Days Umrah Silver-Package28 Days Umrah Silver-Package28 Days Umrah Silver-Package28 Days Umrah Silver-Package28 Days Umrah Silver-Package28 Days Umrah Silver-Package28 Days Umrah Silver-Package28 Days Umrah Silver-Package28 Days Umrah Silver-Package28 Days Umrah Silver-Package28 Days Umrah Silver-Package28 Days Umrah Silver-Package28 Days Umrah Silver-Package28 Days Umrah Silver-Package28 Days Umrah Silver-Package'),
(3124, 607, '_menu_item_type', 'custom'),
(3125, 607, '_menu_item_menu_item_parent', '34'),
(3126, 607, '_menu_item_object_id', '607'),
(3127, 607, '_menu_item_object', 'custom'),
(3128, 607, '_menu_item_target', ''),
(3129, 607, '_menu_item_classes', 'a:1:{i:0;s:0:\"\";}'),
(3130, 607, '_menu_item_xfn', ''),
(3131, 607, '_menu_item_url', '#'),
(3133, 608, '_menu_item_type', 'custom'),
(3134, 608, '_menu_item_menu_item_parent', '34'),
(3135, 608, '_menu_item_object_id', '608'),
(3136, 608, '_menu_item_object', 'custom'),
(3137, 608, '_menu_item_target', ''),
(3138, 608, '_menu_item_classes', 'a:1:{i:0;s:0:\"\";}'),
(3139, 608, '_menu_item_xfn', ''),
(3140, 608, '_menu_item_url', '#'),
(3151, 610, '_menu_item_type', 'custom'),
(3152, 610, '_menu_item_menu_item_parent', '34'),
(3153, 610, '_menu_item_object_id', '610'),
(3154, 610, '_menu_item_object', 'custom'),
(3155, 610, '_menu_item_target', ''),
(3156, 610, '_menu_item_classes', 'a:1:{i:0;s:0:\"\";}'),
(3157, 610, '_menu_item_xfn', ''),
(3158, 610, '_menu_item_url', '#'),
(3163, 611, '_edit_lock', '1559412478:1'),
(3165, 614, '_edit_lock', '1558867788:1'),
(3166, 614, '_edit_last', '2'),
(3167, 614, 'agentname', 'test agent'),
(3168, 614, 'makkahstay', '2 days'),
(3169, 614, 'madinahstay', '3 days'),
(3170, 614, 'makkahhotelhame', 'test makkah hotel'),
(3171, 614, 'Makkahoteldistance', '1 km'),
(3172, 614, 'madinahhotelname', 'test madinah hotel'),
(3173, 614, 'madinahhoteldistance', '2 km'),
(3174, 614, 'locationcheckins', '05/30/2019'),
(3175, 614, 'locationcheckout', '06/30/2019'),
(3176, 614, 'umrahroom', '10'),
(3177, 614, 'umrahparson', '20'),
(3178, 614, 'umrahdouble', '1,000.00'),
(3179, 614, 'umrahtriplebed', '1,100.00'),
(3180, 614, 'umrahfourbed', '1,200.00'),
(3181, 614, 'umrahsharing', '500.00'),
(3182, 614, 'umrahpolicies', 'policy texts'),
(3183, 614, 'umrahfacilites', 'facilities texts'),
(3184, 615, 'assigned_to', '614'),
(3185, 615, 'author', ''),
(3186, 615, 'avatar', 'https://secure.gravatar.com/avatar/?s=96&d=mm&r=g'),
(3187, 615, 'content', '4 star'),
(3188, 615, 'custom', 'a:0:{}'),
(3189, 615, 'date', '2019-05-26 10:14:28'),
(3190, 615, 'email', ''),
(3191, 615, 'ip_address', '45.251.228.217'),
(3192, 615, 'pinned', ''),
(3193, 615, 'rating', '4'),
(3194, 615, 'response', ''),
(3195, 615, 'review_id', 'ba0e6727ff3ac048b55dfaba52657cbd'),
(3196, 615, 'review_type', 'local'),
(3197, 615, 'title', ''),
(3198, 615, 'url', ''),
(3199, 614, '_glsr_count', 'a:1:{s:5:\"local\";a:6:{i:0;i:0;i:1;i:0;i:2;i:2;i:3;i:0;i:4;i:1;i:5;i:0;}}'),
(3200, 614, '_glsr_average', '2.7'),
(3201, 614, '_glsr_ranking', '3.3153846153846'),
(3202, 616, 'assigned_to', '614'),
(3203, 616, 'author', ''),
(3204, 616, 'avatar', 'https://secure.gravatar.com/avatar/?s=96&d=mm&r=g'),
(3205, 616, 'content', '2 star'),
(3206, 616, 'custom', 'a:0:{}'),
(3207, 616, 'date', '2019-05-26 10:14:42'),
(3208, 616, 'email', ''),
(3209, 616, 'ip_address', '45.251.228.217'),
(3210, 616, 'pinned', ''),
(3211, 616, 'rating', '2'),
(3212, 616, 'response', ''),
(3213, 616, 'review_id', '721a0f8552b4fd7fa2a3884efcaae4a3'),
(3214, 616, 'review_type', 'local'),
(3215, 616, 'title', ''),
(3216, 616, 'url', ''),
(3217, 617, 'assigned_to', '614'),
(3218, 617, 'author', ''),
(3219, 617, 'avatar', 'https://secure.gravatar.com/avatar/?s=96&d=mm&r=g'),
(3220, 617, 'content', '2 star'),
(3221, 617, 'custom', 'a:0:{}'),
(3222, 617, 'date', '2019-05-27 04:06:12'),
(3223, 617, 'email', ''),
(3224, 617, 'ip_address', '58.84.34.233'),
(3225, 617, 'pinned', ''),
(3226, 617, 'rating', '2'),
(3227, 617, 'response', ''),
(3228, 617, 'review_id', '27a7cc1c4e09c1ad311947b66dbc2e7c'),
(3229, 617, 'review_type', 'local'),
(3230, 617, 'title', ''),
(3231, 617, 'url', ''),
(3232, 623, '_edit_lock', '1559246995:1'),
(3233, 623, '_wp_page_template', 'hajj.php'),
(3234, 625, '_edit_lock', '1559247024:1'),
(3235, 625, '_wp_page_template', 'restaurant.php'),
(3237, 628, '_menu_item_type', 'post_type'),
(3238, 628, '_menu_item_menu_item_parent', '34'),
(3239, 628, '_menu_item_object_id', '625'),
(3240, 628, '_menu_item_object', 'page'),
(3241, 628, '_menu_item_target', ''),
(3242, 628, '_menu_item_classes', 'a:1:{i:0;s:0:\"\";}'),
(3243, 628, '_menu_item_xfn', ''),
(3244, 628, '_menu_item_url', ''),
(3246, 629, '_menu_item_type', 'post_type'),
(3247, 629, '_menu_item_menu_item_parent', '34'),
(3248, 629, '_menu_item_object_id', '623'),
(3249, 629, '_menu_item_object', 'page'),
(3250, 629, '_menu_item_target', ''),
(3251, 629, '_menu_item_classes', 'a:1:{i:0;s:0:\"\";}'),
(3252, 629, '_menu_item_xfn', ''),
(3253, 629, '_menu_item_url', ''),
(3255, 630, '_edit_lock', '1559247236:1'),
(3256, 630, '_edit_last', '1'),
(3257, 631, '_wp_attached_file', '2019/05/star-kabab-restaurant.jpg'),
(3258, 631, '_wp_attachment_metadata', 'a:5:{s:5:\"width\";i:550;s:6:\"height\";i:322;s:4:\"file\";s:33:\"2019/05/star-kabab-restaurant.jpg\";s:5:\"sizes\";a:2:{s:9:\"thumbnail\";a:4:{s:4:\"file\";s:33:\"star-kabab-restaurant-150x150.jpg\";s:5:\"width\";i:150;s:6:\"height\";i:150;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:6:\"medium\";a:4:{s:4:\"file\";s:33:\"star-kabab-restaurant-300x176.jpg\";s:5:\"width\";i:300;s:6:\"height\";i:176;s:9:\"mime-type\";s:10:\"image/jpeg\";}}s:10:\"image_meta\";a:12:{s:8:\"aperture\";s:1:\"0\";s:6:\"credit\";s:0:\"\";s:6:\"camera\";s:0:\"\";s:7:\"caption\";s:0:\"\";s:17:\"created_timestamp\";s:1:\"0\";s:9:\"copyright\";s:0:\"\";s:12:\"focal_length\";s:1:\"0\";s:3:\"iso\";s:1:\"0\";s:13:\"shutter_speed\";s:1:\"0\";s:5:\"title\";s:0:\"\";s:11:\"orientation\";s:1:\"0\";s:8:\"keywords\";a:0:{}}}'),
(3259, 630, '_thumbnail_id', '631'),
(3260, 630, 'restaurantphone', '+880 1511-932681'),
(3261, 630, 'restaurantemail', 'info@gmail.com'),
(3262, 630, 'restaurantaddress', 'Banani, Dhaka City 1213, Bangladesh'),
(3263, 630, 'restaurantopentime', '1559206800'),
(3264, 630, 'restaurantclosetime', '1559250000'),
(3265, 632, '_edit_lock', '1559247513:1'),
(3266, 632, '_edit_last', '1'),
(3267, 633, '_wp_attached_file', '2019/05/1494489629-hajjpackages-image.jpg'),
(3268, 633, '_wp_attachment_metadata', 'a:5:{s:5:\"width\";i:2480;s:6:\"height\";i:3507;s:4:\"file\";s:41:\"2019/05/1494489629-hajjpackages-image.jpg\";s:5:\"sizes\";a:4:{s:9:\"thumbnail\";a:4:{s:4:\"file\";s:41:\"1494489629-hajjpackages-image-150x150.jpg\";s:5:\"width\";i:150;s:6:\"height\";i:150;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:6:\"medium\";a:4:{s:4:\"file\";s:41:\"1494489629-hajjpackages-image-212x300.jpg\";s:5:\"width\";i:212;s:6:\"height\";i:300;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:12:\"medium_large\";a:4:{s:4:\"file\";s:42:\"1494489629-hajjpackages-image-768x1086.jpg\";s:5:\"width\";i:768;s:6:\"height\";i:1086;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:5:\"large\";a:4:{s:4:\"file\";s:42:\"1494489629-hajjpackages-image-724x1024.jpg\";s:5:\"width\";i:724;s:6:\"height\";i:1024;s:9:\"mime-type\";s:10:\"image/jpeg\";}}s:10:\"image_meta\";a:12:{s:8:\"aperture\";s:1:\"0\";s:6:\"credit\";s:11:\"Matee Ullah\";s:6:\"camera\";s:0:\"\";s:7:\"caption\";s:0:\"\";s:17:\"created_timestamp\";s:1:\"0\";s:9:\"copyright\";s:0:\"\";s:12:\"focal_length\";s:1:\"0\";s:3:\"iso\";s:1:\"0\";s:13:\"shutter_speed\";s:1:\"0\";s:5:\"title\";s:0:\"\";s:11:\"orientation\";s:1:\"1\";s:8:\"keywords\";a:0:{}}}'),
(3269, 632, '_thumbnail_id', '633'),
(3280, 650, '_edit_lock', '1560529241:1'),
(3282, 650, '_edit_last', '1'),
(3302, 663, '_edit_lock', '1560529233:1'),
(3316, 684, '_wp_types_group_fields', ',hotel_gallery_1,hotel_gallery_2,hotel_gallery_3,hotel_gallery_4,hotel_gallery_5,hotel_gallery_6,'),
(3350, 685, '_wp_types_group_fields', ',main_hotel_image,check_in,check_out,hotel_location,hotel_email,hotel_phone_no,hotel_price,hotel_website,cancelled_prepayment,children_and_extrabed,hotel_pets,'),
(3352, 685, '_toolset_edit_last', '1560700504'),
(3354, 688, '_edit_lock', '1560787040:1'),
(3355, 688, '_edit_last', '1'),
(3356, 689, '_wp_attached_file', '2019/06/242-150x150.jpg'),
(3357, 689, '_wp_attachment_metadata', 'a:5:{s:5:\"width\";i:150;s:6:\"height\";i:150;s:4:\"file\";s:23:\"2019/06/242-150x150.jpg\";s:5:\"sizes\";a:0:{}s:10:\"image_meta\";a:12:{s:8:\"aperture\";s:1:\"0\";s:6:\"credit\";s:0:\"\";s:6:\"camera\";s:0:\"\";s:7:\"caption\";s:0:\"\";s:17:\"created_timestamp\";s:1:\"0\";s:9:\"copyright\";s:0:\"\";s:12:\"focal_length\";s:1:\"0\";s:3:\"iso\";s:1:\"0\";s:13:\"shutter_speed\";s:1:\"0\";s:5:\"title\";s:0:\"\";s:11:\"orientation\";s:1:\"0\";s:8:\"keywords\";a:0:{}}}'),
(3358, 688, '_thumbnail_id', '689'),
(3364, 699, '_edit_lock', '1562253794:1'),
(3365, 699, '_wp_page_template', 'main-hotel-search-template.php'),
(3366, 702, '_edit_lock', '1562267286:1'),
(3367, 702, '_wp_page_template', 'hotel-details-template.php'),
(3368, 702, '_edit_last', '1'),
(3393, 699, '_edit_last', '1'),
(3394, 19, '_edit_last', '1'),
(3395, 19, '_wp_page_template', 'default'),
(3396, 713, '_edit_lock', '1562253202:1'),
(3397, 713, '_wp_page_template', 'hotel-booking-form-template.php'),
(3401, 713, '_edit_last', '1'),
(3403, 716, '_edit_lock', '1562253653:1'),
(3404, 716, '_wp_page_template', 'room-details-template.php'),
(3405, 716, '_edit_last', '1'),
(3427, 725, '_edit_lock', '1562607941:1'),
(3428, 725, '_wp_page_template', 'car-details-template.php'),
(3429, 725, '_edit_last', '1'),
(3430, 727, '_edit_lock', '1562610778:1'),
(3431, 727, '_wp_page_template', 'car-search-template.php'),
(3432, 729, '_edit_lock', '1562610513:1'),
(3433, 729, '_wp_page_template', 'car-booking-form-template.php'),
(3434, 729, '_edit_last', '1'),
(3435, 727, '_edit_last', '1'),
(3436, 732, '_edit_lock', '1562696155:1'),
(3437, 732, '_wp_page_template', 'paypal-payment-status.php'),
(3438, 732, '_edit_last', '1'),
(3439, 735, '_edit_lock', '1562955671:1'),
(3440, 735, '_wp_page_template', 'tour-result-template.php'),
(3456, 735, '_edit_last', '1'),
(3457, 737, '_edit_lock', '1562957100:1'),
(3458, 737, '_wp_page_template', 'tour-details-template.php'),
(3459, 737, '_edit_last', '1'),
(3484, 742, '_edit_lock', '1563299856:1'),
(3485, 742, '_wp_page_template', 'tour-booking-form-template.php'),
(3486, 742, '_edit_last', '1'),
(3487, 744, '_edit_lock', '1563812852:1'),
(3488, 744, '_wp_page_template', 'activity-details-template.php'),
(3489, 744, '_edit_last', '1'),
(3491, 747, '_edit_lock', '1563812991:1'),
(3492, 747, '_wp_page_template', 'activity-result-template.php'),
(3493, 750, '_edit_lock', '1563824670:1'),
(3494, 750, '_wp_page_template', 'activity-booking-form-template.php'),
(3495, 752, '_edit_lock', '1564075668:1'),
(3496, 752, '_wp_page_template', 'guide-details-template.php'),
(3497, 752, '_edit_last', '1'),
(3498, 754, '_edit_lock', '1564082178:1'),
(3499, 754, '_wp_page_template', 'guide-result-template.php'),
(3500, 1045, '_edit_lock', '1564084210:1'),
(3501, 1045, '_wp_page_template', 'guide-booking-form-template.php'),
(3502, 1047, '_edit_lock', '1564342917:1'),
(3503, 1047, '_wp_page_template', 'transport-details-template.php'),
(3504, 1049, '_edit_lock', '1564343534:1'),
(3505, 1049, '_wp_page_template', 'transport-result-template.php'),
(3506, 1052, '_edit_lock', '1564410658:1'),
(3507, 1052, '_wp_page_template', 'transport-booking-form-template.php'),
(3508, 1054, '_edit_lock', '1564423989:1'),
(3509, 1054, '_wp_page_template', 'restaurant-details-template.php'),
(3510, 1054, '_edit_last', '1'),
(3511, 1056, '_edit_lock', '1564427575:1'),
(3512, 1056, '_wp_page_template', 'restaurant-result-template.php');

-- --------------------------------------------------------

--
-- Table structure for table `wp_posts`
--

CREATE TABLE `wp_posts` (
  `ID` bigint(20) UNSIGNED NOT NULL,
  `post_author` bigint(20) UNSIGNED NOT NULL DEFAULT '0',
  `post_date` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `post_date_gmt` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `post_content` longtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `post_title` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `post_excerpt` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `post_status` varchar(20) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'publish',
  `comment_status` varchar(20) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'open',
  `ping_status` varchar(20) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'open',
  `post_password` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `post_name` varchar(200) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `to_ping` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `pinged` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `post_modified` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `post_modified_gmt` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `post_content_filtered` longtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `post_parent` bigint(20) UNSIGNED NOT NULL DEFAULT '0',
  `guid` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `menu_order` int(11) NOT NULL DEFAULT '0',
  `post_type` varchar(20) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'post',
  `post_mime_type` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `comment_count` bigint(20) NOT NULL DEFAULT '0'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `wp_posts`
--

INSERT INTO `wp_posts` (`ID`, `post_author`, `post_date`, `post_date_gmt`, `post_content`, `post_title`, `post_excerpt`, `post_status`, `comment_status`, `ping_status`, `post_password`, `post_name`, `to_ping`, `pinged`, `post_modified`, `post_modified_gmt`, `post_content_filtered`, `post_parent`, `guid`, `menu_order`, `post_type`, `post_mime_type`, `comment_count`) VALUES
(1, 1, '2019-02-19 05:37:27', '2019-02-19 05:37:27', '<!-- wp:paragraph -->\n<p>Welcome to WordPress. This is your first post. Edit or delete it, then start writing!</p>\n<!-- /wp:paragraph -->', 'Hello world!', '', 'publish', 'open', 'open', '', 'hello-world', '', '', '2019-02-19 05:37:27', '2019-02-19 05:37:27', '', 0, 'http://localhost/project/?p=1', 0, 'post', '', 1),
(2, 1, '2019-02-19 05:37:27', '2019-02-19 05:37:27', '<!-- wp:paragraph -->\n<p>This is an example page. It\'s different from a blog post because it will stay in one place and will show up in your site navigation (in most themes). Most people start with an About page that introduces them to potential site visitors. It might say something like this:</p>\n<!-- /wp:paragraph -->\n\n<!-- wp:quote -->\n<blockquote class=\"wp-block-quote\"><p>Hi there! I\'m a bike messenger by day, aspiring actor by night, and this is my website. I live in Los Angeles, have a great dog named Jack, and I like pi&#241;a coladas. (And gettin\' caught in the rain.)</p></blockquote>\n<!-- /wp:quote -->\n\n<!-- wp:paragraph -->\n<p>...or something like this:</p>\n<!-- /wp:paragraph -->\n\n<!-- wp:quote -->\n<blockquote class=\"wp-block-quote\"><p>The XYZ Doohickey Company was founded in 1971, and has been providing quality doohickeys to the public ever since. Located in Gotham City, XYZ employs over 2,000 people and does all kinds of awesome things for the Gotham community.</p></blockquote>\n<!-- /wp:quote -->\n\n<!-- wp:paragraph -->\n<p>As a new WordPress user, you should go to <a href=\"http://localhost/project/wp-admin/\">your dashboard</a> to delete this page and create new pages for your content. Have fun!</p>\n<!-- /wp:paragraph -->', 'Sample Page', '', 'publish', 'closed', 'open', '', 'sample-page', '', '', '2019-02-19 05:37:27', '2019-02-19 05:37:27', '', 0, 'http://localhost/project/?page_id=2', 0, 'page', '', 0),
(9, 1, '2019-02-19 09:11:24', '2019-02-19 09:11:24', '', 'Home', '', 'publish', 'closed', 'closed', '', 'home', '', '', '2019-02-19 09:11:24', '2019-02-19 09:11:24', '', 0, 'http://localhost/project/?page_id=9', 0, 'page', '', 0),
(10, 1, '2019-02-19 09:11:24', '2019-02-19 09:11:24', '', 'Home', '', 'inherit', 'closed', 'closed', '', '9-revision-v1', '', '', '2019-02-19 09:11:24', '2019-02-19 09:11:24', '', 9, 'http://localhost/project/2019/02/19/9-revision-v1/', 0, 'revision', '', 0),
(11, 1, '2019-02-19 09:11:48', '2019-02-19 09:11:48', '', 'Projects', '', 'publish', 'closed', 'closed', '', 'projects', '', '', '2019-02-19 09:11:48', '2019-02-19 09:11:48', '', 0, 'http://localhost/project/?page_id=11', 0, 'page', '', 0),
(12, 1, '2019-02-19 09:11:48', '2019-02-19 09:11:48', '', 'Projects', '', 'inherit', 'closed', 'closed', '', '11-revision-v1', '', '', '2019-02-19 09:11:48', '2019-02-19 09:11:48', '', 11, 'http://localhost/project/2019/02/19/11-revision-v1/', 0, 'revision', '', 0),
(13, 1, '2019-02-19 09:12:05', '2019-02-19 09:12:05', '[weforms id=\"538\"]', 'Activities', '', 'publish', 'closed', 'closed', '', 'activities', '', '', '2019-05-22 06:16:25', '2019-05-22 06:16:25', '', 0, 'http://localhost/project/?page_id=13', 0, 'page', '', 0),
(14, 1, '2019-02-19 09:12:05', '2019-02-19 09:12:05', '', 'Activities', '', 'inherit', 'closed', 'closed', '', '13-revision-v1', '', '', '2019-02-19 09:12:05', '2019-02-19 09:12:05', '', 13, 'http://localhost/project/2019/02/19/13-revision-v1/', 0, 'revision', '', 0),
(15, 1, '2019-02-19 09:12:24', '2019-02-19 09:12:24', '', 'Total Jobs', '', 'publish', 'closed', 'closed', '', 'total-jobs', '', '', '2019-02-19 09:12:24', '2019-02-19 09:12:24', '', 0, 'http://localhost/project/?page_id=15', 0, 'page', '', 0),
(16, 1, '2019-02-19 09:12:24', '2019-02-19 09:12:24', '', 'Total Jobs', '', 'inherit', 'closed', 'closed', '', '15-revision-v1', '', '', '2019-02-19 09:12:24', '2019-02-19 09:12:24', '', 15, 'http://localhost/project/2019/02/19/15-revision-v1/', 0, 'revision', '', 0),
(19, 1, '2019-02-19 09:13:15', '2019-02-19 09:13:15', '', 'List Of Hotels', '', 'publish', 'closed', 'closed', '', 'list-of-hotels', '', '', '2019-06-28 15:21:59', '2019-06-28 15:21:59', '', 0, 'http://localhost/project/?page_id=19', 0, 'page', '', 0),
(20, 1, '2019-02-19 09:13:15', '2019-02-19 09:13:15', '', 'Hotels', '', 'inherit', 'closed', 'closed', '', '19-revision-v1', '', '', '2019-02-19 09:13:15', '2019-02-19 09:13:15', '', 19, 'http://localhost/project/2019/02/19/19-revision-v1/', 0, 'revision', '', 0),
(21, 1, '2019-02-19 09:13:33', '2019-02-19 09:13:33', '', 'Sub Item', '', 'publish', 'closed', 'closed', '', 'sub-item', '', '', '2019-02-19 09:13:33', '2019-02-19 09:13:33', '', 0, 'http://localhost/project/?page_id=21', 0, 'page', '', 0),
(22, 1, '2019-02-19 09:13:33', '2019-02-19 09:13:33', '', 'Sub Item', '', 'inherit', 'closed', 'closed', '', '21-revision-v1', '', '', '2019-02-19 09:13:33', '2019-02-19 09:13:33', '', 21, 'http://localhost/project/2019/02/19/21-revision-v1/', 0, 'revision', '', 0),
(23, 1, '2019-02-19 09:13:51', '2019-02-19 09:13:51', '', 'Sub Item1', '', 'publish', 'closed', 'closed', '', 'sub-item1', '', '', '2019-02-19 09:13:51', '2019-02-19 09:13:51', '', 0, 'http://localhost/project/?page_id=23', 0, 'page', '', 0),
(24, 1, '2019-02-19 09:13:51', '2019-02-19 09:13:51', '', 'Sub Item1', '', 'inherit', 'closed', 'closed', '', '23-revision-v1', '', '', '2019-02-19 09:13:51', '2019-02-19 09:13:51', '', 23, 'http://localhost/project/2019/02/19/23-revision-v1/', 0, 'revision', '', 0),
(25, 1, '2019-02-19 09:14:09', '2019-02-19 09:14:09', '', 'Sub Item2', '', 'publish', 'closed', 'closed', '', 'sub-item2', '', '', '2019-02-19 09:14:09', '2019-02-19 09:14:09', '', 0, 'http://localhost/project/?page_id=25', 0, 'page', '', 0),
(26, 1, '2019-02-19 09:14:09', '2019-02-19 09:14:09', '', 'Sub Item2', '', 'inherit', 'closed', 'closed', '', '25-revision-v1', '', '', '2019-02-19 09:14:09', '2019-02-19 09:14:09', '', 25, 'http://localhost/project/2019/02/19/25-revision-v1/', 0, 'revision', '', 0),
(34, 1, '2019-02-19 09:15:35', '2019-02-19 09:15:35', '', 'Packages', '', 'publish', 'closed', 'closed', '', '34', '', '', '2019-05-30 20:13:49', '2019-05-30 20:13:49', '', 0, 'http://localhost/project/?p=34', 2, 'nav_menu_item', '', 0),
(35, 1, '2019-02-19 09:15:34', '2019-02-19 09:15:34', ' ', '', '', 'publish', 'closed', 'closed', '', '35', '', '', '2019-05-30 20:13:49', '2019-05-30 20:13:49', '', 0, 'http://localhost/project/?p=35', 1, 'nav_menu_item', '', 0),
(37, 1, '2019-02-19 11:30:27', '2019-02-19 11:30:27', '', 'logo-white', '', 'inherit', 'open', 'closed', '', 'logo-white', '', '', '2019-02-19 11:30:27', '2019-02-19 11:30:27', '', 0, 'http://localhost/project/wp-content/uploads/2019/02/logo-white.png', 0, 'attachment', 'image/png', 0),
(50, 1, '2019-02-20 07:45:12', '2019-02-20 07:45:12', '', 'rental.search', '', 'publish', 'closed', 'closed', '', 'rental-search', '', '', '2019-02-20 07:45:12', '2019-02-20 07:45:12', '', 0, 'http://localhost/project/?page_id=50', 0, 'page', '', 0),
(51, 1, '2019-02-20 07:45:12', '2019-02-20 07:45:12', '', 'rental.search', '', 'inherit', 'closed', 'closed', '', '50-revision-v1', '', '', '2019-02-20 07:45:12', '2019-02-20 07:45:12', '', 50, 'http://localhost/project/2019/02/20/50-revision-v1/', 0, 'revision', '', 0),
(52, 1, '2019-02-20 07:45:43', '2019-02-20 07:45:43', '', 'rental.search-result', '', 'publish', 'closed', 'closed', '', 'rental-search-result', '', '', '2019-02-20 07:45:43', '2019-02-20 07:45:43', '', 0, 'http://localhost/project/?page_id=52', 0, 'page', '', 0),
(53, 1, '2019-02-20 07:45:43', '2019-02-20 07:45:43', '', 'rental.search-result', '', 'inherit', 'closed', 'closed', '', '52-revision-v1', '', '', '2019-02-20 07:45:43', '2019-02-20 07:45:43', '', 52, 'http://localhost/project/2019/02/20/52-revision-v1/', 0, 'revision', '', 0),
(54, 1, '2019-02-20 07:46:06', '2019-02-20 07:46:06', '', 'rental-map', '', 'publish', 'closed', 'closed', '', 'rental-map', '', '', '2019-02-20 07:46:06', '2019-02-20 07:46:06', '', 0, 'http://localhost/project/?page_id=54', 0, 'page', '', 0),
(55, 1, '2019-02-20 07:46:06', '2019-02-20 07:46:06', '', 'rental-map', '', 'inherit', 'closed', 'closed', '', '54-revision-v1', '', '', '2019-02-20 07:46:06', '2019-02-20 07:46:06', '', 54, 'http://localhost/project/2019/02/20/54-revision-v1/', 0, 'revision', '', 0),
(62, 1, '2019-02-20 07:47:38', '2019-02-20 07:47:38', '<!-- wp:paragraph -->\n<p> <br>[booking_package id=5]<br></p>\n<!-- /wp:paragraph -->', 'book-now', '', 'publish', 'closed', 'closed', '', 'book-now', '', '', '2019-05-19 08:35:58', '2019-05-19 08:35:58', '', 0, 'http://localhost/project/?page_id=62', 0, 'page', '', 0),
(63, 1, '2019-02-20 07:47:38', '2019-02-20 07:47:38', '', 'book-now', '', 'inherit', 'closed', 'closed', '', '62-revision-v1', '', '', '2019-02-20 07:47:38', '2019-02-20 07:47:38', '', 62, 'http://localhost/project/2019/02/20/62-revision-v1/', 0, 'revision', '', 0),
(64, 1, '2019-02-20 07:48:01', '2019-02-20 07:48:01', '', 'hajj-package', '', 'publish', 'closed', 'closed', '', 'hajj-package', '', '', '2019-02-20 07:48:01', '2019-02-20 07:48:01', '', 0, 'http://localhost/project/?page_id=64', 0, 'page', '', 0),
(65, 1, '2019-02-20 07:48:01', '2019-02-20 07:48:01', '', 'hajj-package', '', 'inherit', 'closed', 'closed', '', '64-revision-v1', '', '', '2019-02-20 07:48:01', '2019-02-20 07:48:01', '', 64, 'http://localhost/project/2019/02/20/64-revision-v1/', 0, 'revision', '', 0),
(74, 1, '2019-02-20 07:51:00', '2019-02-20 07:51:00', '', 'search', '', 'publish', 'closed', 'closed', '', 'search', '', '', '2019-02-20 07:51:00', '2019-02-20 07:51:00', '', 0, 'http://localhost/project/?page_id=74', 0, 'page', '', 0),
(75, 1, '2019-02-20 07:51:00', '2019-02-20 07:51:00', '', 'search', '', 'inherit', 'closed', 'closed', '', '74-revision-v1', '', '', '2019-02-20 07:51:00', '2019-02-20 07:51:00', '', 74, 'http://localhost/project/2019/02/20/74-revision-v1/', 0, 'revision', '', 0),
(76, 1, '2019-02-20 07:51:15', '2019-02-20 07:51:15', '', 'sign-up', '', 'publish', 'closed', 'closed', '', 'sign-up', '', '', '2019-02-20 07:51:15', '2019-02-20 07:51:15', '', 0, 'http://localhost/project/?page_id=76', 0, 'page', '', 0),
(77, 1, '2019-02-20 07:51:15', '2019-02-20 07:51:15', '', 'sign-up', '', 'inherit', 'closed', 'closed', '', '76-revision-v1', '', '', '2019-02-20 07:51:15', '2019-02-20 07:51:15', '', 76, 'http://localhost/project/2019/02/20/76-revision-v1/', 0, 'revision', '', 0),
(82, 1, '2019-02-20 07:52:17', '2019-02-20 07:52:17', '', 'umrah-package', '', 'publish', 'closed', 'closed', '', 'umrah-package', '', '', '2019-02-20 07:52:17', '2019-02-20 07:52:17', '', 0, 'http://localhost/project/?page_id=82', 0, 'page', '', 0),
(83, 1, '2019-02-20 07:52:17', '2019-02-20 07:52:17', '', 'umrah-package', '', 'inherit', 'closed', 'closed', '', '82-revision-v1', '', '', '2019-02-20 07:52:17', '2019-02-20 07:52:17', '', 82, 'http://localhost/project/2019/02/20/82-revision-v1/', 0, 'revision', '', 0),
(150, 1, '2019-02-23 04:59:00', '2019-02-23 04:59:00', '', '30', '', 'inherit', 'open', 'closed', '', '30-2', '', '', '2019-02-23 04:59:00', '2019-02-23 04:59:00', '', 0, 'http://localhost/project/wp-content/uploads/2019/02/30.jpg', 0, 'attachment', 'image/jpeg', 0),
(151, 1, '2019-02-23 05:00:25', '2019-02-23 05:00:25', '', 'thumb', '', 'inherit', 'open', 'closed', '', 'thumb', '', '', '2019-02-23 05:00:25', '2019-02-23 05:00:25', '', 0, 'http://localhost/project/wp-content/uploads/2019/02/thumb.jpg', 0, 'attachment', 'image/jpeg', 0),
(169, 1, '2019-02-23 08:24:33', '2019-02-23 08:24:33', 'ytryrtyrty', 'tryrtyrty', '', 'publish', 'open', 'closed', '', 'tryrtyrty', '', '', '2019-02-23 08:24:33', '2019-02-23 08:24:33', '', 0, 'http://localhost/project/?post_type=movies&#038;p=169', 0, 'movies', '', 0),
(170, 1, '2019-02-23 08:24:33', '2019-02-23 08:24:33', 'ytryrtyrty', 'tryrtyrty', '', 'inherit', 'closed', 'closed', '', '169-revision-v1', '', '', '2019-02-23 08:24:33', '2019-02-23 08:24:33', '', 169, 'http://localhost/project/archives/170', 0, 'revision', '', 0),
(176, 1, '2019-02-23 17:29:42', '2019-02-23 17:29:42', '', 'thumb_1537856321-package-image', '', 'inherit', 'open', 'closed', '', 'thumb_1537856321-package-image', '', '', '2019-03-01 19:38:52', '2019-03-01 19:38:52', '', 0, 'http://localhost:8080/project19/wp-content/uploads/2019/02/thumb_1537856321-package-image.jpg', 0, 'attachment', 'image/jpeg', 0),
(177, 1, '2019-02-23 17:50:02', '2019-02-23 17:50:02', '', 'thumb', '', 'inherit', 'open', 'closed', '', 'thumb-2', '', '', '2019-02-23 17:50:02', '2019-02-23 17:50:02', '', 0, 'http://localhost:8080/project19/wp-content/uploads/2019/02/thumb.jpg', 0, 'attachment', 'image/jpeg', 0),
(186, 1, '2019-02-27 06:05:34', '2019-02-27 06:05:34', '', 'umrah-result', '', 'publish', 'closed', 'closed', '', 'umrah-result', '', '', '2019-02-27 06:06:06', '2019-02-27 06:06:06', '', 0, 'http://localhost/project/?page_id=186', 0, 'page', '', 0),
(187, 1, '2019-02-27 06:05:34', '2019-02-27 06:05:34', '', 'umrah-result', '', 'inherit', 'closed', 'closed', '', '186-revision-v1', '', '', '2019-02-27 06:05:34', '2019-02-27 06:05:34', '', 186, 'http://localhost/project/archives/187', 0, 'revision', '', 0),
(196, 1, '2019-02-27 12:01:21', '2019-02-27 12:01:21', '28 Days Umrah Silver-Package28 Days Umrah Silver-Package28 Days Umrah Silver-Package28 Days Umrah Silver-Package28 Days Umrah Silver-Package28 Days Umrah Silver-Package28 Days Umrah Silver-Package28 Days Umrah Silver-Package', '28 Days Umrah Silver-Package', '', 'publish', 'open', 'closed', '', '28-days-umrah-silver-package', '', '', '2019-05-25 04:31:05', '2019-05-25 04:31:05', '', 0, 'http://localhost/project/?post_type=umrah&#038;p=196', 0, 'umrah', '', 0),
(197, 1, '2019-03-01 18:35:33', '2019-03-01 18:35:33', '', 'Shop', '', 'publish', 'closed', 'closed', '', 'shop', '', '', '2019-03-01 18:35:33', '2019-03-01 18:35:33', '', 0, 'http://localhost:8080/project19/shop', 0, 'page', '', 0),
(198, 1, '2019-03-01 18:35:33', '2019-03-01 18:35:33', '[woocommerce_cart]', 'Cart', '', 'publish', 'closed', 'closed', '', 'cart', '', '', '2019-03-03 09:02:57', '2019-03-03 09:02:57', '', 0, 'http://localhost:8080/project19/cart', 0, 'page', '', 0),
(200, 1, '2019-03-01 18:35:33', '2019-03-01 18:35:33', '[woocommerce_my_account]', 'My account', '', 'publish', 'closed', 'closed', '', 'my-account', '', '', '2019-03-01 18:35:33', '2019-03-01 18:35:33', '', 0, 'http://localhost:8080/project19/my-account', 0, 'page', '', 0),
(251, 1, '2019-03-02 10:37:24', '2019-03-02 10:37:24', '<label> Your Name (required)\n    [text* your-name] </label>\n\n<label> Your Email (required)\n    [email* your-email] </label>\n\n<label> Subject\n    [text your-subject] </label>\n\n<label> Your Message\n    [textarea your-message] </label>\n\n[submit \"Send\"]\nprojct new development \"[your-subject]\"\n[your-name] <admin@gmail.com>\nFrom: [your-name] <[your-email]>\nSubject: [your-subject]\n\nMessage Body:\n[your-message]\n\n-- \nThis e-mail was sent from a contact form on projct new development (http://localhost/project)\nadmin@gmail.com\nReply-To: [your-email]\n\n0\n0\n\nprojct new development \"[your-subject]\"\nprojct new development <admin@gmail.com>\nMessage Body:\n[your-message]\n\n-- \nThis e-mail was sent from a contact form on projct new development (http://localhost/project)\n[your-email]\nReply-To: admin@gmail.com\n\n0\n0\nThank you for your message. It has been sent.\nThere was an error trying to send your message. Please try again later.\nOne or more fields have an error. Please check and try again.\nThere was an error trying to send your message. Please try again later.\nYou must accept the terms and conditions before sending your message.\nThe field is required.\nThe field is too long.\nThe field is too short.', 'Contact form 1', '', 'publish', 'closed', 'closed', '', 'contact-form-1', '', '', '2019-03-02 10:37:24', '2019-03-02 10:37:24', '', 0, '', 0, 'wpcf7_contact_form', '', 0),
(252, 1, '2019-03-02 10:37:41', '2019-03-02 10:37:41', '', 'Media', '', 'private', 'closed', 'closed', '', 'media', '', '', '2019-03-02 10:37:41', '2019-03-02 10:37:41', '', 0, 'http://localhost/project/?option-tree=media', 0, 'option-tree', '', 0),
(264, 1, '2019-03-02 17:34:50', '2019-03-02 17:34:50', 'get all golobal', 'global test', '', 'publish', 'open', 'closed', '', 'global-test', '', '', '2019-03-28 19:10:16', '2019-03-28 19:10:16', '', 0, 'http://localhost:8080/project19/?post_type=product&#038;p=264', 125, 'product', '', 0),
(267, 1, '2019-03-02 18:56:25', '2019-03-02 18:56:25', '<!-- wp:paragraph -->\r\n<p><br />Hi, Amit here, I am the WPML Support Manager, our current ticket queue is quite calm and I\'d like to encourage you to use our new <strong>chat support</strong> option --&gt; Please do not open multiple tickets for the same issue, it adds unneeded load to our queue and ends up in longer waiting time for you <a href=\"http://localhost:8080/project19/projects#\">F</a></p>\r\n<!-- /wp:paragraph -->', '7 Days Star Umrah Package-03', '<p><span class=\"st\">My permalink structure <em>might</em> be the cause - but basically i have a formidable form creating a new post ( custom ... [Closed] Catchable <em>fatal error</em>: <em>Object</em> of <em>class WP_Error could not</em> be <em>converted</em> to <em>string</em> ... With <em>WordPress</em> 3.5.1, edit <em>wp</em>-<wbr />includes/formatting.php and in line 509 add this: ... Skip to main <em>content</em>.</span></p>', 'publish', 'open', 'closed', '', '7-days-star-umrah-package-03', '', '', '2019-03-28 18:49:00', '2019-03-28 18:49:00', '', 0, 'http://localhost:8080/project19/?post_type=product&#038;p=267', 8, 'product', '', 1),
(274, 1, '2019-03-02 19:16:37', '2019-03-02 19:16:37', '', '123456', 'Check this box if the coupon grants free shipping. A free shipping method must be enabled in your shipping zone and be set to require \"a valid free shipping coupon', 'publish', 'closed', 'closed', '', '123456', '', '', '2019-03-02 19:17:18', '2019-03-02 19:17:18', '', 0, 'http://localhost:8080/project19/?post_type=shop_coupon&#038;p=274', 0, 'shop_coupon', '', 0),
(283, 1, '2019-03-03 09:02:57', '2019-03-03 09:02:57', '[woocommerce_cart]', 'Cart', '', 'inherit', 'closed', 'closed', '', '198-revision-v1', '', '', '2019-03-03 09:02:57', '2019-03-03 09:02:57', '', 198, 'http://localhost/project/archives/283', 0, 'revision', '', 0),
(290, 1, '2019-03-03 11:06:37', '2019-03-03 11:06:37', '<!-- wp:paragraph -->\n<p> [woocommerce_checkout] </p>\n<!-- /wp:paragraph -->', 'checkout', '', 'publish', 'closed', 'closed', '', 'checkout', '', '', '2019-03-03 11:09:14', '2019-03-03 11:09:14', '', 0, 'http://localhost/project/?page_id=290', 0, 'page', '', 0),
(291, 1, '2019-03-03 11:06:37', '2019-03-03 11:06:37', '', 'checkout', '', 'inherit', 'closed', 'closed', '', '290-revision-v1', '', '', '2019-03-03 11:06:37', '2019-03-03 11:06:37', '', 290, 'http://localhost/project/archives/291', 0, 'revision', '', 0),
(293, 1, '2019-03-03 11:08:49', '2019-03-03 11:08:49', '<!-- wp:paragraph -->\n<p>\n\n[woocommerce_one_page_checkout]\n\n</p>\n<!-- /wp:paragraph -->', 'checkout', '', 'inherit', 'closed', 'closed', '', '290-revision-v1', '', '', '2019-03-03 11:08:49', '2019-03-03 11:08:49', '', 290, 'http://localhost/project/archives/293', 0, 'revision', '', 0),
(294, 1, '2019-03-03 11:09:14', '2019-03-03 11:09:14', '<!-- wp:paragraph -->\n<p> [woocommerce_checkout] </p>\n<!-- /wp:paragraph -->', 'checkout', '', 'inherit', 'closed', 'closed', '', '290-revision-v1', '', '', '2019-03-03 11:09:14', '2019-03-03 11:09:14', '', 290, 'http://localhost/project/archives/294', 0, 'revision', '', 0),
(306, 1, '2019-03-06 11:23:16', '2019-03-06 11:23:16', '<div class=\"table-responsive\">\r\n<div class=\"disc-info\">\r\n<div class=\"table-responsive\">\r\n<table class=\"table table-bordered\">\r\n<tbody>\r\n<tr>\r\n<th>#</th>\r\n<th>Title</th>\r\n<th>Number (Day)</th>\r\n<th>Price</th>\r\n</tr>\r\n<tr>\r\n<td>1</td>\r\n<td>Package 1</td>\r\n<td>3 – 5</td>\r\n<td>$70,00\r\n<i class=\"fa fa-arrow-right\" style=\"padding: 3px;\"></i>\r\n$60,00</td>\r\n</tr>\r\n<tr>\r\n<td>2</td>\r\n<td>Package 2</td>\r\n<td>6 – 12</td>\r\n<td>$70,00\r\n<i class=\"fa fa-arrow-right\" style=\"padding: 3px;\"></i>\r\n$55,00</td>\r\n</tr>\r\n<tr>\r\n<td>3</td>\r\n<td>Package 3</td>\r\n<td>13 – 20</td>\r\n<td>$70,00\r\n<i class=\"fa fa-arrow-right\" style=\"padding: 3px;\"></i>\r\n$45,00</td>\r\n</tr>\r\n</tbody>\r\n</table>\r\n</div>\r\n</div>\r\n</div>', 'Maserati GranTurismo', '', 'publish', 'closed', 'closed', '', 'maserati-granturismo', '', '', '2019-03-25 18:11:31', '2019-03-25 18:11:31', '', 0, 'http://localhost/project/?post_type=cars&#038;p=306', 0, 'cars', '', 0),
(308, 1, '2019-03-06 05:37:05', '2019-03-06 05:37:05', '<!-- wp:paragraph -->\n<p><code>[wpbs id=\"1\" form=\"1\" legend=\"yes\" </code> start=\'1\' display=\'1\' <code> language=\"auto\"]</code></p>\n<!-- /wp:paragraph -->', 'Bookingwp', '', 'publish', 'closed', 'closed', '', 'bookingwp', '', '', '2019-03-06 08:19:18', '2019-03-06 08:19:18', '', 0, 'http://localhost/project/?page_id=308', 0, 'page', '', 0),
(309, 1, '2019-03-06 05:37:05', '2019-03-06 05:37:05', '<!-- wp:paragraph -->\n<p>[\'wpbs\']</p>\n<!-- /wp:paragraph -->', 'Bookingwp', '', 'inherit', 'closed', 'closed', '', '308-revision-v1', '', '', '2019-03-06 05:37:05', '2019-03-06 05:37:05', '', 308, 'http://localhost/project/archives/309', 0, 'revision', '', 0),
(310, 1, '2019-03-06 05:39:57', '2019-03-06 05:39:57', '<!-- wp:paragraph -->\n<p>[wpbs]</p>\n<!-- /wp:paragraph -->', 'Bookingwp', '', 'inherit', 'closed', 'closed', '', '308-revision-v1', '', '', '2019-03-06 05:39:57', '2019-03-06 05:39:57', '', 308, 'http://localhost/project/archives/310', 0, 'revision', '', 0),
(311, 1, '2019-03-06 05:41:02', '2019-03-06 05:41:02', '<!-- wp:paragraph -->\n<p>[wpbs id=\'1\' form=\'1\']</p>\n<!-- /wp:paragraph -->', 'Bookingwp', '', 'inherit', 'closed', 'closed', '', '308-revision-v1', '', '', '2019-03-06 05:41:02', '2019-03-06 05:41:02', '', 308, 'http://localhost/project/archives/311', 0, 'revision', '', 0),
(312, 1, '2019-03-06 05:51:53', '2019-03-06 05:51:53', '<!-- wp:paragraph -->\n<p> [wpbs id=\'1\' form=\'1\' title=\'yes\' leged=\'yes\' start=\'1\' display=\'1\' language=\'auto\']</p>\n<!-- /wp:paragraph -->', 'Bookingwp', '', 'inherit', 'closed', 'closed', '', '308-revision-v1', '', '', '2019-03-06 05:51:53', '2019-03-06 05:51:53', '', 308, 'http://localhost/project/archives/312', 0, 'revision', '', 0),
(313, 1, '2019-03-06 06:26:45', '2019-03-06 06:26:45', '<!-- wp:paragraph -->\n<p> [wpbs id=\'1\' form=\'1\' title=\'yes\' leged=\'yes\' start=\'1\' display=\'1\' language=\'auto\']</p>\n<!-- /wp:paragraph -->\n\n<!-- wp:button -->\n<div class=\"wp-block-button\"><a class=\"wp-block-button__link\" href=\"testget\"></a></div>\n<!-- /wp:button -->', 'Bookingwp', '', 'inherit', 'closed', 'closed', '', '308-revision-v1', '', '', '2019-03-06 06:26:45', '2019-03-06 06:26:45', '', 308, 'http://localhost/project/archives/313', 0, 'revision', '', 0),
(314, 1, '2019-03-06 06:32:24', '2019-03-06 06:32:24', '<!-- wp:paragraph -->\n<p> [wpbs id=\'1\' form=\'1\' title=\'yes\' leged=\'yes\' start=\'1\' display=\'1\' language=\'auto\']</p>\n<!-- /wp:paragraph -->\n\n<!-- wp:paragraph -->\n<p><code>[wpbs id=\"1\" form=\"2\" title=\"yes\" legend=\"yes\" language=\"auto\"]</code></p>\n<!-- /wp:paragraph -->\n\n<!-- wp:button -->\n<div class=\"wp-block-button\"><a class=\"wp-block-button__link\" href=\"testget\"></a></div>\n<!-- /wp:button -->', 'Bookingwp', '', 'inherit', 'closed', 'closed', '', '308-revision-v1', '', '', '2019-03-06 06:32:24', '2019-03-06 06:32:24', '', 308, 'http://localhost/project/archives/314', 0, 'revision', '', 0),
(316, 1, '2019-03-06 06:33:45', '2019-03-06 06:33:45', '<!-- wp:paragraph -->\n<p></p>\n<!-- /wp:paragraph -->\n\n<!-- wp:paragraph -->\n<p><code>[wpbs id=\"1\" form=\"2\" title=\"yes\" legend=\"yes\" </code> start=\'1\' display=\'1\' <code> language=\"auto\"]</code></p>\n<!-- /wp:paragraph -->\n\n<!-- wp:button -->\n<div class=\"wp-block-button\"><a class=\"wp-block-button__link\" href=\"testget\"></a></div>\n<!-- /wp:button -->', 'Bookingwp', '', 'inherit', 'closed', 'closed', '', '308-revision-v1', '', '', '2019-03-06 06:33:45', '2019-03-06 06:33:45', '', 308, 'http://localhost/project/archives/316', 0, 'revision', '', 0),
(317, 1, '2019-03-06 06:34:11', '2019-03-06 06:34:11', '<!-- wp:paragraph -->\n<p><code>[wpbs id=\"1\" form=\"2\" title=\"yes\" legend=\"yes\" </code> start=\'1\' display=\'1\' <code> language=\"auto\"]</code></p>\n<!-- /wp:paragraph -->', 'Bookingwp', '', 'inherit', 'closed', 'closed', '', '308-revision-v1', '', '', '2019-03-06 06:34:11', '2019-03-06 06:34:11', '', 308, 'http://localhost/project/archives/317', 0, 'revision', '', 0),
(318, 1, '2019-03-06 06:34:35', '2019-03-06 06:34:35', '<!-- wp:paragraph -->\n<p><code>[wpbs id=\"1\" form=\"1\" title=\"yes\" legend=\"yes\" </code> start=\'1\' display=\'1\' <code> language=\"auto\"]</code></p>\n<!-- /wp:paragraph -->', 'Bookingwp', '', 'inherit', 'closed', 'closed', '', '308-revision-v1', '', '', '2019-03-06 06:34:35', '2019-03-06 06:34:35', '', 308, 'http://localhost/project/archives/318', 0, 'revision', '', 0),
(319, 1, '2019-03-06 06:35:59', '2019-03-06 06:35:59', '<!-- wp:paragraph -->\n<p><code>[wpbs id=\"1\" form=\"1\" title=\"yes\" legend=\"yes\" </code> start=\'1\' display=\'1\' <code> language=\"auto\"]</code></p>\n<!-- /wp:paragraph -->\n\n<!-- wp:paragraph -->\n<p></p>\n<!-- /wp:paragraph -->\n\n<!-- wp:preformatted -->\n<pre class=\"wp-block-preformatted\">[dopbsp item=search-widget id=1 redirect_id=123]</pre>\n<!-- /wp:preformatted -->', 'Bookingwp', '', 'inherit', 'closed', 'closed', '', '308-revision-v1', '', '', '2019-03-06 06:35:59', '2019-03-06 06:35:59', '', 308, 'http://localhost/project/archives/319', 0, 'revision', '', 0),
(320, 1, '2019-03-06 06:57:29', '2019-03-06 06:57:29', '<!-- wp:paragraph -->\n<p><code>[wpbs id=\"1\" form=\"1\" title=\"yes\" legend=\"yes\" </code> start=\'1\' display=\'1\' <code> language=\"auto\"]</code></p>\n<!-- /wp:paragraph -->', 'Bookingwp', '', 'inherit', 'closed', 'closed', '', '308-revision-v1', '', '', '2019-03-06 06:57:29', '2019-03-06 06:57:29', '', 308, 'http://localhost/project/archives/320', 0, 'revision', '', 0),
(321, 1, '2019-03-06 06:58:02', '2019-03-06 06:58:02', '<!-- wp:paragraph -->\n<p>[wpbs id=\"1\" form=\"1\" title=\"yes\" legend=\"yes\" </code> start=\'1\' display=\'1\' <code> language=\"auto\"]</p>\n<!-- /wp:paragraph -->', 'Bookingwp', '', 'inherit', 'closed', 'closed', '', '308-revision-v1', '', '', '2019-03-06 06:58:02', '2019-03-06 06:58:02', '', 308, 'http://localhost/project/archives/321', 0, 'revision', '', 0),
(322, 1, '2019-03-06 06:58:21', '2019-03-06 06:58:21', '<!-- wp:paragraph -->\n<p><code>[wpbs id=\"1\" form=\"1\" title=\"yes\" legend=\"yes\" </code> start=\'1\' display=\'1\' <code> language=\"auto\"]</code></p>\n<!-- /wp:paragraph -->', 'Bookingwp', '', 'inherit', 'closed', 'closed', '', '308-revision-v1', '', '', '2019-03-06 06:58:21', '2019-03-06 06:58:21', '', 308, 'http://localhost/project/archives/322', 0, 'revision', '', 0),
(323, 1, '2019-03-06 08:19:18', '2019-03-06 08:19:18', '<!-- wp:paragraph -->\n<p><code>[wpbs id=\"1\" form=\"1\" legend=\"yes\" </code> start=\'1\' display=\'1\' <code> language=\"auto\"]</code></p>\n<!-- /wp:paragraph -->', 'Bookingwp', '', 'inherit', 'closed', 'closed', '', '308-revision-v1', '', '', '2019-03-06 08:19:18', '2019-03-06 08:19:18', '', 308, 'http://localhost/project/archives/323', 0, 'revision', '', 0),
(324, 1, '2019-03-06 12:02:59', '2019-03-06 12:02:59', '<strong>Lorem Ipsum</strong> is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry\'s standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book. It has survived not only five centuries, but also the leap into electronic typesetting, remaining essentially unchanged. It was popularised in the 1960s with the release of Letraset sheets containing Lorem Ipsum passages, and more recently with desktop publishing software like Aldus PageMaker including versions of Lorem Ipsum.', 'simply', '', 'publish', 'closed', 'closed', '', 'test', '', '', '2019-03-28 12:14:45', '2019-03-28 12:14:45', '', 0, 'http://localhost/project/?post_type=cars&#038;p=324', 0, 'cars', '', 0),
(328, 1, '2019-03-25 18:07:10', '2019-03-25 18:07:10', '', '800x600', '', 'inherit', 'open', 'closed', '', '800x600', '', '', '2019-03-25 18:07:10', '2019-03-25 18:07:10', '', 306, 'http://localhost:8080/project/wp-content/uploads/2019/03/800x600-1.jpg', 0, 'attachment', 'image/jpeg', 0),
(329, 1, '2019-03-25 18:09:31', '2019-03-25 18:09:31', '', 'orea', '', 'inherit', 'open', 'closed', '', 'orea', '', '', '2019-03-25 18:09:31', '2019-03-25 18:09:31', '', 306, 'http://localhost:8080/project/wp-content/uploads/2019/03/orea.jpg', 0, 'attachment', 'image/jpeg', 0),
(330, 1, '2019-03-25 18:16:59', '2019-03-25 18:16:59', '', 'advanced search', '', 'publish', 'closed', 'closed', '', 'advanced-search', '', '', '2019-03-25 18:16:59', '2019-03-25 18:16:59', '', 0, 'http://localhost:8080/project/?page_id=330', 0, 'page', '', 0),
(331, 1, '2019-03-25 18:16:59', '2019-03-25 18:16:59', '', 'advanced search', '', 'inherit', 'closed', 'closed', '', '330-revision-v1', '', '', '2019-03-25 18:16:59', '2019-03-25 18:16:59', '', 330, 'http://localhost:8080/project/archives/331', 0, 'revision', '', 0),
(337, 1, '2019-03-27 19:01:38', '2019-03-27 19:01:38', 'Cursus faucibus egestas rutrum mauris vulputate consequat anteCursus faucibus egestas rutrum mauris vulputate consequat ante', 'Russia', '', 'publish', 'closed', 'closed', '', 'versailles-small-trip', '', '', '2019-05-25 04:14:37', '2019-05-25 04:14:37', '', 0, 'http://localhost:8080/project/?post_type=tours&#038;p=337', 0, 'tours', '', 0),
(338, 1, '2019-03-27 19:01:31', '2019-03-27 19:01:31', '', 'palace-park-versailles-5-800x600', '', 'inherit', 'open', 'closed', '', 'palace-park-versailles-5-800x600', '', '', '2019-03-27 19:01:31', '2019-03-27 19:01:31', '', 337, 'http://localhost:8080/project/wp-content/uploads/2019/03/palace-park-versailles-5-800x600.jpg', 0, 'attachment', 'image/jpeg', 0),
(343, 1, '2019-03-28 12:04:53', '2019-03-28 12:04:53', '<strong>Lorem Ipsum</strong> is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry\'s standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book. It has survived not only five centuries, but also the leap into electronic typesetting, remaining essentially unchanged. It was popularised in the 1960s with the release of Letraset sheets containing Lorem Ipsum passages, and more recently with desktop publishing software like Aldus PageMaker including versions of Lorem Ipsum.', 'test', '', 'publish', 'closed', 'closed', '', 'test-2', '', '', '2019-03-28 12:05:03', '2019-03-28 12:05:03', '', 0, 'http://localhost/project/?post_type=cars&#038;p=343', 0, 'cars', '', 0),
(344, 1, '2019-03-28 12:03:10', '2019-03-28 12:03:10', '', 'demo2', '', 'inherit', 'open', 'closed', '', 'demo2', '', '', '2019-03-28 12:03:10', '2019-03-28 12:03:10', '', 343, 'http://localhost/project/wp-content/uploads/2019/03/demo2.png', 0, 'attachment', 'image/png', 0),
(345, 1, '2019-03-28 12:04:47', '2019-03-28 12:04:47', '', '800x600', '', 'inherit', 'open', 'closed', '', '800x600-2', '', '', '2019-03-28 12:04:47', '2019-03-28 12:04:47', '', 343, 'http://localhost/project/wp-content/uploads/2019/03/800x600-1.jpg', 0, 'attachment', 'image/jpeg', 0),
(346, 1, '2019-03-28 12:10:29', '2019-03-28 12:10:29', '', 'br1', '', 'inherit', 'open', 'closed', '', 'br1', '', '', '2019-03-28 12:10:29', '2019-03-28 12:10:29', '', 324, 'http://localhost/project/wp-content/uploads/2019/03/br1-1.jpg', 0, 'attachment', 'image/jpeg', 0),
(347, 1, '2019-03-28 12:13:32', '2019-03-28 12:13:32', '', '7478-143x71', '', 'inherit', 'open', 'closed', '', '7478-143x71', '', '', '2019-03-28 12:13:32', '2019-03-28 12:13:32', '', 324, 'http://localhost/project/wp-content/uploads/2019/03/7478-143x71-1.jpg', 0, 'attachment', 'image/jpeg', 0),
(348, 1, '2019-03-28 12:23:11', '2019-03-28 12:23:11', '', '_3', '', 'inherit', 'open', 'closed', '', '_3', '', '', '2019-03-28 12:23:11', '2019-03-28 12:23:11', '', 337, 'http://localhost/project/wp-content/uploads/2019/03/3-1.jpg', 0, 'attachment', 'image/jpeg', 0),
(350, 1, '2019-03-28 19:07:01', '2019-03-28 19:07:01', '<!-- wp:paragraph -->\r\n<p><br />Hi, Amit here, I am the WPML Support Manager, our current ticket queue is quite calm and I\'d like to encourage you to use our new <strong>chat support</strong> option --&gt; Please do not open multiple tickets for the same issue, it adds unneeded load to our queue and ends up in longer waiting time for you <a href=\"http://localhost:8080/project19/projects#\">F</a></p>\r\n<!-- /wp:paragraph -->', '7 Days Star Umrah Package-03 (Copy)', '<p><span class=\"st\">My permalink structure <em>might</em> be the cause - but basically i have a formidable form creating a new post ( custom ... [Closed] Catchable <em>fatal error</em>: <em>Object</em> of <em>class WP_Error could not</em> be <em>converted</em> to <em>string</em> ... With <em>WordPress</em> 3.5.1, edit <em>wp</em>-<wbr />includes/formatting.php and in line 509 add this: ... Skip to main <em>content</em>.</span></p>', 'publish', 'open', 'closed', '', '7-days-star-umrah-package-03-copy', '', '', '2019-03-28 19:08:06', '2019-03-28 19:08:06', '', 0, 'http://localhost:8080/hajjproject/?post_type=product&#038;p=350', 8, 'product', '', 0),
(351, 1, '2019-03-28 19:28:42', '2019-03-28 19:28:42', '', 'palace-park-versailles-5-800x600', '', 'inherit', 'open', 'closed', '', 'palace-park-versailles-5-800x600-2', '', '', '2019-03-28 19:28:42', '2019-03-28 19:28:42', '', 337, 'http://localhost:8080/hajjproject/wp-content/uploads/2019/03/palace-park-versailles-5-800x600.jpg', 0, 'attachment', 'image/jpeg', 0),
(352, 1, '2019-03-28 19:30:09', '2019-03-28 19:30:09', 'faucibus egestas rutrum mauris vulputate consequat ante', 'Newziland', '', 'publish', 'closed', 'closed', '', 'trhtrh', '', '', '2019-05-25 04:12:37', '2019-05-25 04:12:37', '', 0, 'http://localhost:8080/hajjproject/?post_type=tours&#038;p=352', 0, 'tours', '', 0),
(353, 1, '2019-03-28 19:30:22', '2019-03-28 19:30:22', 'Cursus faucibus egestas rutrum mauris vulputate consequat ante', 'England, UK', '', 'publish', 'closed', 'closed', '', 'dfhggf', '', '', '2019-05-25 04:10:18', '2019-05-25 04:10:18', '', 0, 'http://localhost:8080/hajjproject/?post_type=tours&#038;p=353', 0, 'tours', '', 0),
(355, 1, '2019-03-29 09:44:36', '2019-03-29 09:44:36', '[wp_travel_checkout]', 'WP Travel Checkout', '', 'publish', 'closed', 'closed', '', 'wp-travel-checkout', '', '', '2019-03-29 09:44:36', '2019-03-29 09:44:36', '', 0, 'http://localhost:8080/hajjproject/wp-travel-checkout', 0, 'page', '', 0),
(356, 1, '2019-03-29 09:44:36', '2019-03-29 09:44:36', '[wp_travel_user_account]', 'WP Travel Dashboard', '', 'publish', 'closed', 'closed', '', 'wp-travel-dashboard', '', '', '2019-03-29 09:44:36', '2019-03-29 09:44:36', '', 0, 'http://localhost:8080/hajjproject/wp-travel-dashboard', 0, 'page', '', 0),
(357, 1, '2019-03-29 09:51:00', '2019-03-29 09:51:00', '', 'Milonbooking', '', 'publish', 'closed', 'closed', '', 'milonbooking', '', '', '2019-03-29 10:43:59', '2019-03-29 10:43:59', '', 0, 'http://localhost:8080/hajjproject/?post_type=itinerary-booking&#038;p=357', 0, 'itinerary-booking', '', 0),
(358, 1, '2019-03-29 09:49:20', '2019-03-29 09:49:20', '', 'Payment - #357', '', 'publish', 'open', 'closed', '', 'payment-357', '', '', '2019-03-29 09:49:20', '2019-03-29 09:49:20', '', 0, 'http://localhost:8080/hajjproject/archives/itinerary-payment/payment-357', 0, 'wp-travel-payment', '', 0),
(360, 1, '2019-03-29 09:53:11', '2019-03-29 09:53:11', 'gyhghghgh', 'milontravel', '', 'publish', 'open', 'closed', '', 'milontravel', '', '', '2019-03-29 10:42:46', '2019-03-29 10:42:46', '', 0, 'http://localhost:8080/hajjproject/?post_type=itineraries&#038;p=360', 0, 'itineraries', '', 0),
(366, 1, '2019-03-29 10:34:38', '2019-03-29 10:34:38', '', '', '', 'publish', 'closed', 'closed', '', '366', '', '', '2019-03-29 10:34:38', '2019-03-29 10:34:38', '', 0, 'http://localhost:8080/hajjproject/?post_type=wp-travel-coupons&#038;p=366', 0, 'wp-travel-coupons', '', 0),
(367, 1, '2019-03-29 10:35:14', '2019-03-29 10:35:14', '', '', '', 'publish', 'closed', 'closed', '', '367', '', '', '2019-03-29 10:35:14', '2019-03-29 10:35:14', '', 0, 'http://localhost:8080/hajjproject/?post_type=itinerary-enquiries&#038;p=367', 0, 'itinerary-enquiries', '', 0),
(368, 1, '2019-03-29 10:35:39', '2019-03-29 10:35:39', '', '', '', 'publish', 'closed', 'closed', '', '368', '', '', '2019-03-29 10:35:39', '2019-03-29 10:35:39', '', 0, 'http://localhost:8080/hajjproject/?post_type=tour-extras&#038;p=368', 0, 'tour-extras', '', 0),
(375, 1, '2019-03-30 19:58:57', '2019-03-30 19:58:57', '<b>Lorem Ipsum is simply dummy text of the printing and typesetting industry.</b> Lorem Ipsum has been the industry\'s standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book. It has survived not only five centuries, but also the leap into electronic typesetting, <a href=\"http://localhost:8080/project/hotel-details#\">remaining essentially unchanged</a>. It was popularised in the 1960s with the release of Letraset sheets containing Lorem Ipsum passages, and more recently with desktop publishing software like Aldus PageMaker including versions of Lorem Ipsum.', 'Shangri-La International Hotel', '', 'publish', 'open', 'closed', '', 'shangri-la-international-hotel', '', '', '2019-04-03 11:12:09', '2019-04-03 11:12:09', '', 0, 'http://localhost:8080/hajjproject/?post_type=hotelhajj&#038;p=375', 0, 'hotelhajj', '', 0),
(377, 1, '2019-04-01 18:21:11', '2019-04-01 18:21:11', '', 'Barclay-400x300', '', 'inherit', 'open', 'closed', '', 'barclay-400x300', '', '', '2019-04-01 18:21:11', '2019-04-01 18:21:11', '', 375, 'http://localhost:8080/hajjproject/wp-content/uploads/2019/03/Barclay-400x300.jpg', 0, 'attachment', 'image/jpeg', 0),
(378, 1, '2019-04-01 19:37:24', '2019-04-01 19:37:24', '<span id=\"e197\" class=\"qc_ si29 \">Find Bookings <b>Hotel</b>. Check Out 1000+ Results from Across the Web. The Complete Overview. Information 24/7. Wiki, News &amp; More. Web, Images &amp; Video. 100+ Million Visitors. Trusted by Millions. Types: pdf, doc, ppt, xls, txt.</span>', 'Hotel Tours: Seeing a Hotel Star', '', 'publish', 'open', 'closed', '', 'hotel-tours-seeing-a-hotel-star', '', '', '2019-05-25 04:20:51', '2019-05-25 04:20:51', '', 0, 'http://localhost:8080/hajjproject/?post_type=hotelhajj&#038;p=378', 0, 'hotelhajj', '', 0),
(379, 1, '2019-04-01 19:43:10', '2019-04-01 19:43:10', '<span id=\"e231\" class=\"qc_ si29 \">HotelsCombined. Compare 1000+ Booking Sites At Once. Best Price Guaranteed. 5 Million <b>Hotel</b> Deals. 100% Free to Use. Travellers Love Us. 1000’s Sites Compared. 800,000+ <b>Hotels</b> Worldwide. <b>Hotels</b> up to 80% Off. No Booking Fee. Types: <b>Hotels</b>, Apartments, Resorts, Villas, Hostels, Guest Houses, B&amp;Bs, Vacation Rentals, Motels, Serviced Apartments.</span>', 'Hotel The Cox Today, Cox\'s Bazar - Compare Deal', '', 'publish', 'open', 'closed', '', 'hotel-the-cox-today-coxs-bazar-compare-deal', '', '', '2019-05-25 04:22:06', '2019-05-25 04:22:06', '', 0, 'http://localhost:8080/hajjproject/?post_type=hotelhajj&#038;p=379', 0, 'hotelhajj', '', 0),
(380, 1, '2019-04-01 19:44:58', '2019-04-01 19:44:58', '<span id=\"e231\" class=\"qc_ si29 \">HotelsCombined. Compare 1000+ Booking Sites At Once. Best Price Guaranteed. 5 Million <b>Hotel</b> Deals. 100% Free to Use. Travellers Love Us. 1000’s Sites Compared. 800,000+ <b>Hotels</b> Worldwide. <b>Hotels</b> up to 80% Off. No Booking Fee. Types: <b>Hotels</b>, Apartments, Resorts, Villas, Hostels, Guest Houses, B&amp;Bs, Vacation Rentals, Motels, Serviced Apartments.</span>', 'HotelsCombined. Compare', '', 'publish', 'open', 'closed', '', 'hotelscombined-compare', '', '', '2019-05-25 04:21:26', '2019-05-25 04:21:26', '', 0, 'http://localhost:8080/hajjproject/?post_type=hotelhajj&#038;p=380', 0, 'hotelhajj', '', 0),
(382, 1, '2019-04-02 04:55:01', '2019-04-02 04:55:01', '[mphb_rooms]', 'Accommodations', '', 'publish', 'closed', 'closed', '', 'accommodations', '', '', '2019-04-02 04:55:01', '2019-04-02 04:55:01', '', 0, 'http://localhost/project/accommodations', 0, 'page', '', 0),
(383, 1, '2019-04-02 04:55:01', '2019-04-02 04:55:01', '[mphb_availability_search]', 'Search Availability', '', 'publish', 'closed', 'closed', '', 'search-availability', '', '', '2019-04-02 04:55:01', '2019-04-02 04:55:01', '', 0, 'http://localhost/project/search-availability', 0, 'page', '', 0),
(384, 1, '2019-04-02 04:55:01', '2019-04-02 04:55:01', '[mphb_search_results]', 'Search Results', '', 'publish', 'closed', 'closed', '', 'search-results', '', '', '2019-04-02 04:55:01', '2019-04-02 04:55:01', '', 0, 'http://localhost/project/search-results', 0, 'page', '', 0),
(385, 1, '2019-04-02 04:55:01', '2019-04-02 04:55:01', '[mphb_checkout]', 'Booking Confirmation', '', 'publish', 'closed', 'closed', '', 'booking-confirmation', '', '', '2019-04-02 04:55:01', '2019-04-02 04:55:01', '', 0, 'http://localhost/project/booking-confirmation', 0, 'page', '', 0),
(386, 1, '2019-04-02 04:55:01', '2019-04-02 04:55:01', 'We are pleased to inform you that your reservation request has been received and confirmed.', 'Booking Confirmed', '', 'publish', 'closed', 'closed', '', 'booking-confirmed', '', '', '2019-04-02 04:55:01', '2019-04-02 04:55:01', '', 385, 'http://localhost/project/booking-confirmation/booking-confirmed', 0, 'page', '', 0),
(387, 1, '2019-04-02 04:55:01', '2019-04-02 04:55:01', 'Your reservation is canceled.', 'Booking Canceled', '', 'publish', 'closed', 'closed', '', 'booking-canceled', '', '', '2019-04-02 04:55:01', '2019-04-02 04:55:01', '', 385, 'http://localhost/project/booking-confirmation/booking-canceled', 0, 'page', '', 0),
(388, 1, '2019-04-02 04:55:02', '2019-04-02 04:55:02', 'Thank you for your payment. Your transaction has been completed and a receipt for your purchase has been emailed to you.', 'Payment Success', '', 'publish', 'closed', 'closed', '', 'payment-success', '', '', '2019-04-02 04:55:02', '2019-04-02 04:55:02', '', 385, 'http://localhost/project/booking-confirmation/payment-success', 0, 'page', '', 0),
(389, 1, '2019-04-02 04:55:02', '2019-04-02 04:55:02', 'Unfortunately, your transaction cannot be completed at this time. Please try again or contact us.', 'Transaction Failed', '', 'publish', 'closed', 'closed', '', 'transaction-failed', '', '', '2019-04-02 04:55:02', '2019-04-02 04:55:02', '', 385, 'http://localhost/project/booking-confirmation/transaction-failed', 0, 'page', '', 0),
(390, 1, '2019-04-02 04:55:41', '2019-04-02 04:55:41', '', 'Hotel Booking', '', 'publish', 'closed', 'closed', '', '390', '', '', '2019-04-03 04:07:08', '2019-04-03 04:07:08', '', 0, 'http://localhost/project/?post_type=mphb_season&#038;p=390', 0, 'mphb_season', '', 0),
(391, 1, '2019-04-02 08:06:10', '0000-00-00 00:00:00', '', 'onester', '', 'draft', 'closed', 'closed', '', '', '', '', '2019-04-02 08:06:10', '2019-04-02 08:06:10', '', 0, 'http://localhost/project/?post_type=mphb_rate&#038;p=391', 0, 'mphb_rate', '', 0),
(392, 0, '2019-04-02 04:58:04', '2019-04-02 04:58:04', '<strong>Lorem Ipsum</strong> is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry\'s standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book. It has survived not only five centuries, but also the leap into electronic typesetting, remaining essentially unchanged. It was popularised in the 1960s with the release of Letraset sheets containing Lorem Ipsum passages, and more recently with desktop publishing software like Aldus PageMaker including versions of Lorem Ipsum.', 'room service', '', 'publish', 'open', 'closed', '', 'room-service', '', '', '2019-04-03 04:08:43', '2019-04-03 04:08:43', '', 0, 'http://localhost/project/?post_type=mphb_room_service&#038;p=392', 0, 'mphb_room_service', '', 0),
(393, 1, '2019-04-02 04:59:01', '0000-00-00 00:00:00', '', 'Accommodation one', '', 'draft', 'closed', 'closed', '', '', '', '', '2019-04-02 04:59:01', '2019-04-02 04:59:01', '', 0, 'http://localhost/project/?post_type=mphb_room&#038;p=393', 0, 'mphb_room', '', 0),
(394, 0, '2019-04-02 06:05:04', '2019-04-02 06:05:04', '', 'test', 'dsfgsdfdsfdsf', 'publish', 'open', 'closed', '', 'test', '', '', '2019-04-03 04:03:38', '2019-04-03 04:03:38', '', 0, 'http://localhost/project/?post_type=mphb_room_type&#038;p=394', 3, 'mphb_room_type', '', 0),
(395, 1, '2019-04-02 06:05:06', '2019-04-02 06:05:06', '', 'test 1', '', 'publish', 'closed', 'closed', '', 'test-1', '', '', '2019-04-02 06:05:06', '2019-04-02 06:05:06', '', 0, 'http://localhost/project/archives/mphb_room/test-1', 0, 'mphb_room', '', 0),
(396, 1, '2019-04-02 06:05:06', '2019-04-02 06:05:06', '', 'test 2', '', 'publish', 'closed', 'closed', '', 'test-2', '', '', '2019-04-02 06:05:06', '2019-04-02 06:05:06', '', 0, 'http://localhost/project/archives/mphb_room/test-2', 0, 'mphb_room', '', 0),
(398, 1, '2019-04-02 08:06:29', '2019-04-02 08:06:29', '', '3 Star', '', 'publish', 'closed', 'closed', '', '398', '', '', '2019-04-03 04:08:12', '2019-04-03 04:08:12', '', 0, 'http://localhost/project/?post_type=mphb_rate&#038;p=398', 0, 'mphb_rate', '', 0),
(399, 1, '2019-04-02 08:12:12', '2019-04-02 08:12:12', '', 'getall 1', 'Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry\'s standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book. It has survived not only five centuries, but also the leap into electronic typesetting, remaining essentially unchanged. It was popularised in the 1960s with the release of Letraset sheets containing Lorem Ipsum passages, and more recently with desktop publishing software like Aldus PageMaker including versions of Lorem Ipsum.', 'publish', 'closed', 'closed', '', 'getall-1', '', '', '2019-04-03 04:09:15', '2019-04-03 04:09:15', '', 0, 'http://localhost/project/archives/mphb_room/getall-1', 0, 'mphb_room', '', 0),
(402, 1, '2019-04-02 08:36:33', '2019-04-02 08:36:33', '[hotel_booking_checkout]', 'Hotel Checkout', '', 'publish', 'closed', 'closed', '', 'hotel-checkout', '', '', '2019-04-02 08:36:33', '2019-04-02 08:36:33', '', 0, 'http://localhost/project/hotel-checkout', 0, 'page', '', 0),
(404, 1, '2019-04-02 08:36:33', '2019-04-02 08:36:33', '[hotel_booking_account]', 'Hotel Account', '', 'publish', 'closed', 'closed', '', 'hotel-account', '', '', '2019-04-02 08:36:33', '2019-04-02 08:36:33', '', 0, 'http://localhost/project/hotel-account', 0, 'page', '', 0),
(405, 1, '2019-04-02 08:36:33', '2019-04-02 08:36:33', 'Something notices', 'Terms and Conditions', '', 'publish', 'closed', 'closed', '', 'hotel-term-condition', '', '', '2019-04-02 08:36:33', '2019-04-02 08:36:33', '', 0, 'http://localhost/project/hotel-term-condition', 0, 'page', '', 0),
(409, 1, '2019-04-03 04:09:33', '2019-04-03 04:09:33', '', 'test 1', '', 'publish', 'closed', 'closed', '', 'test-1-2', '', '', '2019-04-03 04:09:33', '2019-04-03 04:09:33', '', 0, 'http://localhost/project/archives/mphb_room/test-1-2', 0, 'mphb_room', '', 0),
(410, 1, '2019-04-03 04:09:33', '2019-04-03 04:09:33', '', 'test 2', '', 'publish', 'closed', 'closed', '', 'test-2-2', '', '', '2019-04-03 04:09:33', '2019-04-03 04:09:33', '', 0, 'http://localhost/project/archives/mphb_room/test-2-2', 0, 'mphb_room', '', 0),
(411, 1, '2019-04-03 04:09:33', '2019-04-03 04:09:33', '', 'test 3', '', 'publish', 'closed', 'closed', '', 'test-3', '', '', '2019-04-03 04:09:33', '2019-04-03 04:09:33', '', 0, 'http://localhost/project/archives/mphb_room/test-3', 0, 'mphb_room', '', 0),
(412, 1, '2019-04-03 04:09:33', '2019-04-03 04:09:33', '', 'test 4', '', 'publish', 'closed', 'closed', '', 'test-4', '', '', '2019-04-03 04:09:33', '2019-04-03 04:09:33', '', 0, 'http://localhost/project/archives/mphb_room/test-4', 0, 'mphb_room', '', 0),
(416, 1, '2019-04-03 04:28:55', '2019-04-03 04:28:55', '<strong>Lorem Ipsum</strong> is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry\'s standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book. It has survived not only five centuries, but also the leap into electronic typesetting, remaining essentially unchanged. It was popularised in the 1960s with the release of Letraset sheets containing Lorem Ipsum passages, and more recently with desktop publishing software like Aldus PageMaker including versions of Lorem Ipsum.', 'Luxury Room', '', 'publish', 'open', 'closed', '', 'luxury-room', '', '', '2019-04-03 04:28:55', '2019-04-03 04:28:55', '', 0, 'http://localhost/project/?post_type=hb_room&#038;p=416', 0, 'hb_room', '', 0);
INSERT INTO `wp_posts` (`ID`, `post_author`, `post_date`, `post_date_gmt`, `post_content`, `post_title`, `post_excerpt`, `post_status`, `comment_status`, `ping_status`, `post_password`, `post_name`, `to_ping`, `pinged`, `post_modified`, `post_modified_gmt`, `post_content_filtered`, `post_parent`, `guid`, `menu_order`, `post_type`, `post_mime_type`, `comment_count`) VALUES
(417, 1, '2019-04-03 04:28:55', '2019-04-03 04:28:55', '<strong>Lorem Ipsum</strong> is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry\'s standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book. It has survived not only five centuries, but also the leap into electronic typesetting, remaining essentially unchanged. It was popularised in the 1960s with the release of Letraset sheets containing Lorem Ipsum passages, and more recently with desktop publishing software like Aldus PageMaker including versions of Lorem Ipsum.', 'Luxury Room', '', 'inherit', 'closed', 'closed', '', '416-revision-v1', '', '', '2019-04-03 04:28:55', '2019-04-03 04:28:55', '', 416, 'http://localhost/project/archives/417', 0, 'revision', '', 0),
(418, 1, '2019-04-03 04:30:04', '2019-04-03 04:30:04', '<strong>Lorem Ipsum</strong> is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry\'s standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book. It has survived not only five centuries, but also the leap into electronic typesetting, remaining essentially unchanged. It was popularised in the 1960s with the release of Letraset sheets containing Lorem Ipsum passages, and more recently with desktop publishing software like Aldus PageMaker including versions of Lorem Ipsum.', 'Extra Room', '', 'publish', 'closed', 'closed', '', 'extra-room', '', '', '2019-04-03 04:30:04', '2019-04-03 04:30:04', '', 0, 'http://localhost/project/?post_type=hb_extra_room&#038;p=418', 0, 'hb_extra_room', '', 0),
(434, 1, '2019-04-03 07:03:53', '2019-04-03 07:03:53', '', 'New Booking', '', 'publish', 'closed', 'closed', '', 'new-booking', '', '', '2019-04-03 07:03:53', '2019-04-03 07:03:53', '', 0, 'http://localhost/project/?page_id=434', 0, 'page', '', 0),
(435, 1, '2019-04-03 07:03:53', '2019-04-03 07:03:53', '', 'New Booking', '', 'inherit', 'closed', 'closed', '', '434-revision-v1', '', '', '2019-04-03 07:03:53', '2019-04-03 07:03:53', '', 434, 'http://localhost/project/archives/435', 0, 'revision', '', 0),
(437, 1, '2019-04-03 07:05:41', '2019-04-03 07:05:41', '<!-- wp:paragraph -->\n<p><em>[lang=fr_FR]</em></p>\n<!-- /wp:paragraph -->', 'book-now', '', 'inherit', 'closed', 'closed', '', '62-revision-v1', '', '', '2019-04-03 07:05:41', '2019-04-03 07:05:41', '', 62, 'http://localhost/project/archives/437', 0, 'revision', '', 0),
(438, 1, '2019-04-03 07:10:13', '2019-04-03 07:10:13', '<!-- wp:paragraph -->\n<p> <br> <strong>[sbc title=\"yes\"]</strong> or <strong>[sbc title=\"no\"]</strong> </p>\n<!-- /wp:paragraph -->', 'book-now', '', 'inherit', 'closed', 'closed', '', '62-revision-v1', '', '', '2019-04-03 07:10:13', '2019-04-03 07:10:13', '', 62, 'http://localhost/project/archives/438', 0, 'revision', '', 0),
(439, 1, '2019-04-03 08:30:46', '2019-04-03 08:30:46', '<strong>Lorem Ipsum</strong> is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry\'s standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book. It has survived not only five centuries, but also the leap into electronic typesetting, remaining essentially unchanged. It was popularised in the 1960s with the release of Letraset sheets containing Lorem Ipsum passages, and more recently with desktop publishing software like Aldus PageMaker including versions of Lorem Ipsum.', 'Lorem Ipsum', '', 'publish', 'open', 'closed', '', 'lorem-ipsum', '', '', '2019-04-03 08:30:46', '2019-04-03 08:30:46', '', 0, 'http://localhost/project/?post_type=wpbooking_service&#038;p=439', 0, 'wpbooking_service', '', 0),
(440, 1, '2019-04-03 08:29:33', '2019-04-03 08:29:33', '', 'sonar bangla', '', 'publish', 'open', 'closed', '', 'sonar-bangla', '', '', '2019-04-03 08:29:33', '2019-04-03 08:29:33', '', 439, 'http://localhost/project/?post_type=wpbooking_hotel_room&#038;p=440', 0, 'wpbooking_hotel_room', '', 0),
(441, 0, '2019-04-03 09:48:12', '2019-04-03 09:48:12', '', 'testttt', '<p>jhgjhgjhgjhgjhgjhg</p>', 'publish', 'closed', 'closed', '', 'testttt', '', '', '2019-04-03 09:48:13', '2019-04-03 09:48:13', '', 0, 'http://localhost/project/?post_type=room_type&#038;p=441', 0, 'room_type', '', 0),
(442, 1, '2019-04-03 09:49:02', '2019-04-03 09:49:02', '', 'What\'s new in Duplicate', 'What\\\\\\\'s new in Duplicate Post version 3.2.2:\r\nSimple compatibility with Gutenberg user interface: enable \\\\\\\"Admin bar\\\\\\\" under the Settings — \\\\\\\"Slug\\\\\\\" option unset by default on new installations\r\nCheck out the documentation — Please review the settings to make sure it works as you expect.\r\nServing the WordPress community since November 2007. Help me develop the plugin and provide support by donating even a small sum.', 'publish', 'closed', 'closed', '', 'whats-new-in-duplicate', '', '', '2019-04-03 09:49:14', '2019-04-03 09:49:14', '', 0, 'http://localhost/project/?post_type=hotel_service&#038;p=442', 0, 'hotel_service', '', 0),
(443, 1, '2019-04-03 09:49:00', '0000-00-00 00:00:00', '', 'Booking', 'What\\\'s new in Duplicate What\\\'s new in Duplicate What\\\'s new in Duplicate What\\\'s new in Duplicate What\\\'s new in Duplicate What\\\'s new in Duplicate What\\\'s new in Duplicate What\\\'s new in Duplicate What\\\'s new in Duplicate', 'awebooking-pending', 'closed', 'closed', '', '', '', '', '2019-04-03 09:50:07', '2019-04-03 09:50:07', '', 0, 'http://localhost/project/?post_type=awebooking&#038;p=443', 0, 'awebooking', '', 2),
(445, 1, '2019-04-03 10:10:43', '2019-04-03 10:10:43', '<!-- wp:paragraph -->\n<p> <br> <strong>[s</strong>[booking_package id=2]</p>\n<!-- /wp:paragraph -->', 'book-now', '', 'inherit', 'closed', 'closed', '', '62-revision-v1', '', '', '2019-04-03 10:10:43', '2019-04-03 10:10:43', '', 62, 'http://localhost/project/archives/445', 0, 'revision', '', 0),
(446, 1, '2019-04-03 10:11:20', '2019-04-03 10:11:20', '<!-- wp:paragraph -->\n<p> <br> <strong>[</strong>[booking_package id=2]</p>\n<!-- /wp:paragraph -->', 'book-now', '', 'inherit', 'closed', 'closed', '', '62-revision-v1', '', '', '2019-04-03 10:11:20', '2019-04-03 10:11:20', '', 62, 'http://localhost/project/archives/446', 0, 'revision', '', 0),
(447, 1, '2019-04-03 10:11:45', '2019-04-03 10:11:45', '<!-- wp:paragraph -->\n<p> <br>[booking_package id=2]</p>\n<!-- /wp:paragraph -->', 'book-now', '', 'inherit', 'closed', 'closed', '', '62-revision-v1', '', '', '2019-04-03 10:11:45', '2019-04-03 10:11:45', '', 62, 'http://localhost/project/archives/447', 0, 'revision', '', 0),
(448, 1, '2019-04-03 10:12:50', '2019-04-03 10:12:50', '<!-- wp:paragraph -->\n<p> <br>[booking_package id=3]<br></p>\n<!-- /wp:paragraph -->', 'book-now', '', 'inherit', 'closed', 'closed', '', '62-revision-v1', '', '', '2019-04-03 10:12:50', '2019-04-03 10:12:50', '', 62, 'http://localhost/project/archives/448', 0, 'revision', '', 0),
(449, 1, '2019-04-03 10:20:00', '2019-04-03 10:20:00', '<!-- wp:paragraph -->\n<p> <br>[booking_package id=4]<br></p>\n<!-- /wp:paragraph -->', 'book-now', '', 'inherit', 'closed', 'closed', '', '62-revision-v1', '', '', '2019-04-03 10:20:00', '2019-04-03 10:20:00', '', 62, 'http://localhost/project/archives/449', 0, 'revision', '', 0),
(450, 1, '2019-04-03 10:26:38', '2019-04-03 10:26:38', '<!-- wp:paragraph -->\n<p> <br>[booking_package id=5]<br></p>\n<!-- /wp:paragraph -->', 'book-now', '', 'inherit', 'closed', 'closed', '', '62-revision-v1', '', '', '2019-04-03 10:26:38', '2019-04-03 10:26:38', '', 62, 'http://localhost/project/archives/450', 0, 'revision', '', 0),
(459, 1, '2019-04-04 09:57:39', '2019-04-04 09:57:39', '<!-- wp:paragraph -->\r\n<p><br />Hi, Amit here, I am the WPML Support Manager, our current ticket queue is quite calm and I\'d like to encourage you to use our new <strong>chat support</strong> option --&gt; Please do not open multiple tickets for the same issue, it adds unneeded load to our queue and ends up in longer waiting time for you <a href=\"http://localhost:8080/project19/projects#\">F</a></p>\r\n<!-- /wp:paragraph -->', '7 Days Star Umrah Package-03 (Copy) (Copy)', '<p><span class=\"st\">My permalink structure <em>might</em> be the cause - but basically i have a formidable form creating a new post ( custom ... [Closed] Catchable <em>fatal error</em>: <em>Object</em> of <em>class WP_Error could not</em> be <em>converted</em> to <em>string</em> ... With <em>WordPress</em> 3.5.1, edit <em>wp</em>-<wbr />includes/formatting.php and in line 509 add this: ... Skip to main <em>content</em>.</span></p>', 'publish', 'open', 'closed', '', '7-days-star-umrah-package-03-copy-copy', '', '', '2019-04-04 09:57:52', '2019-04-04 09:57:52', '', 0, 'http://localhost/project/?post_type=product&#038;p=459', 8, 'product', '', 0),
(460, 1, '2019-04-04 09:58:02', '2019-04-04 09:58:02', '<!-- wp:paragraph -->\r\n<p><br />Hi, Amit here, I am the WPML Support Manager, our current ticket queue is quite calm and I\'d like to encourage you to use our new <strong>chat support</strong> option --&gt; Please do not open multiple tickets for the same issue, it adds unneeded load to our queue and ends up in longer waiting time for you <a href=\"http://localhost:8080/project19/projects#\">F</a></p>\r\n<!-- /wp:paragraph -->', '7 Days Star Umrah Package-03 (Copy) (Copy) (Copy)', '<p><span class=\"st\">My permalink structure <em>might</em> be the cause - but basically i have a formidable form creating a new post ( custom ... [Closed] Catchable <em>fatal error</em>: <em>Object</em> of <em>class WP_Error could not</em> be <em>converted</em> to <em>string</em> ... With <em>WordPress</em> 3.5.1, edit <em>wp</em>-<wbr />includes/formatting.php and in line 509 add this: ... Skip to main <em>content</em>.</span></p>', 'publish', 'open', 'closed', '', '7-days-star-umrah-package-03-copy-copy-copy', '', '', '2019-04-04 09:58:11', '2019-04-04 09:58:11', '', 0, 'http://localhost/project/?post_type=product&#038;p=460', 8, 'product', '', 0),
(461, 1, '2019-04-04 09:58:23', '2019-04-04 09:58:23', '<!-- wp:paragraph -->\r\n<p><br />Hi, Amit here, I am the WPML Support Manager, our current ticket queue is quite calm and I\'d like to encourage you to use our new <strong>chat support</strong> option --&gt; Please do not open multiple tickets for the same issue, it adds unneeded load to our queue and ends up in longer waiting time for you <a href=\"http://localhost:8080/project19/projects#\">F</a></p>\r\n<!-- /wp:paragraph -->', '7 Days Star Umrah Package-03 (Copy) (Copy) (Copy) (Copy)', '<p><span class=\"st\">My permalink structure <em>might</em> be the cause - but basically i have a formidable form creating a new post ( custom ... [Closed] Catchable <em>fatal error</em>: <em>Object</em> of <em>class WP_Error could not</em> be <em>converted</em> to <em>string</em> ... With <em>WordPress</em> 3.5.1, edit <em>wp</em>-<wbr />includes/formatting.php and in line 509 add this: ... Skip to main <em>content</em>.</span></p>', 'publish', 'open', 'closed', '', '7-days-star-umrah-package-03-copy-copy-copy-copy', '', '', '2019-04-04 09:58:45', '2019-04-04 09:58:45', '', 0, 'http://localhost/project/?post_type=product&#038;p=461', 8, 'product', '', 0),
(462, 1, '2019-04-04 09:59:05', '2019-04-04 09:59:05', 'get all golobal', 'global test (Copy)', '', 'publish', 'open', 'closed', '', 'global-test-copy', '', '', '2019-04-04 09:59:17', '2019-04-04 09:59:17', '', 0, 'http://localhost/project/?post_type=product&#038;p=462', 125, 'product', '', 0),
(463, 1, '2019-04-04 09:59:30', '2019-04-04 09:59:30', 'get all golobal', 'global test (Copy)', '', 'publish', 'open', 'closed', '', 'global-test-copy-2', '', '', '2019-04-04 09:59:41', '2019-04-04 09:59:41', '', 0, 'http://localhost/project/?post_type=product&#038;p=463', 125, 'product', '', 0),
(464, 1, '2019-04-04 09:59:53', '2019-04-04 09:59:53', 'get all golobal', 'global test (Copy)', '', 'publish', 'open', 'closed', '', 'global-test-copy-3', '', '', '2019-04-04 10:00:02', '2019-04-04 10:00:02', '', 0, 'http://localhost/project/?post_type=product&#038;p=464', 125, 'product', '', 0),
(465, 1, '2019-04-04 10:00:19', '2019-04-04 10:00:19', 'get all golobal', 'global test (Copy) (Copy)', '', 'publish', 'open', 'closed', '', 'global-test-copy-copy', '', '', '2019-04-04 10:00:49', '2019-04-04 10:00:49', '', 0, 'http://localhost/project/?post_type=product&#038;p=465', 125, 'product', '', 0),
(466, 1, '2019-04-04 10:00:59', '2019-04-04 10:00:59', 'get all golobal', 'global test (Copy)', '', 'publish', 'open', 'closed', '', 'global-test-copy-4', '', '', '2019-04-04 10:01:06', '2019-04-04 10:01:06', '', 0, 'http://localhost/project/?post_type=product&#038;p=466', 125, 'product', '', 0),
(467, 1, '2019-04-04 10:01:17', '2019-04-04 10:01:17', 'get all golobal', 'global test (Copy)', '', 'publish', 'open', 'closed', '', 'global-test-copy-5', '', '', '2019-04-04 10:01:35', '2019-04-04 10:01:35', '', 0, 'http://localhost/project/?post_type=product&#038;p=467', 125, 'product', '', 0),
(475, 1, '2019-04-09 08:19:57', '2019-04-09 08:19:57', 'Let\'s say you have two pages, About Us (page ID - 50) and Contact Us (page ID - 24). You created a Contact Information metabox that you want only displaying on these two pages. Here\'s what the beginning of your metabox might look like.', 'test2', '', 'publish', 'open', 'closed', '', 'rtyrty', '', '', '2019-04-10 07:42:17', '2019-04-10 07:42:17', '', 0, 'http://localhost/project/?post_type=flights&#038;p=475', 0, 'flights', '', 0),
(476, 1, '2019-04-09 08:24:17', '2019-04-09 08:24:17', 'Excerpts are optional hand-crafted summaries of your content that can be used in your theme.', 'test1', '', 'publish', 'open', 'closed', '', 'dfgjfdghfdjgh', '', '', '2019-04-10 05:23:57', '2019-04-10 05:23:57', '', 0, 'http://localhost/project/?post_type=flights&#038;p=476', 0, 'flights', '', 0),
(479, 1, '2019-04-10 05:09:52', '2019-04-10 05:09:52', '', 'air-berlin-128x50', '', 'inherit', 'open', 'closed', '', 'air-berlin-128x50', '', '', '2019-04-10 05:09:52', '2019-04-10 05:09:52', '', 476, 'http://localhost/project/wp-content/uploads/2019/04/air-berlin-128x50.png', 0, 'attachment', 'image/png', 0),
(481, 1, '2019-04-10 06:02:07', '2019-04-10 06:02:07', 'Let\'s say you have two pages, About Us (page ID - 50) and Contact Us (page ID - 24). You created a Contact Information metabox that you want only displaying on these two pages. Here\'s what the beginning of your metabox might look like.', 'test2', '', 'inherit', 'closed', 'closed', '', '475-autosave-v1', '', '', '2019-04-10 06:02:07', '2019-04-10 06:02:07', '', 475, 'http://localhost/project/archives/481', 0, 'revision', '', 0),
(482, 1, '2019-04-10 06:02:17', '2019-04-10 06:02:17', '', 'hotel-logo', '', 'inherit', 'open', 'closed', '', 'hotel-logo', '', '', '2019-04-10 06:02:17', '2019-04-10 06:02:17', '', 475, 'http://localhost/project/wp-content/uploads/2019/04/hotel-logo.jpg', 0, 'attachment', 'image/jpeg', 0),
(483, 1, '2019-04-10 12:12:42', '2019-04-10 12:12:42', 'sttdsrt', 'test3', '', 'publish', 'open', 'closed', '', 'test3', '', '', '2019-04-10 12:12:56', '2019-04-10 12:12:56', '', 0, 'http://localhost/project/?post_type=flights&#038;p=483', 0, 'flights', '', 0),
(484, 1, '2019-04-10 12:11:39', '2019-04-10 12:11:39', '', 'mastercard', '', 'inherit', 'open', 'closed', '', 'mastercard', '', '', '2019-04-10 12:11:39', '2019-04-10 12:11:39', '', 483, 'http://localhost/project/wp-content/uploads/2019/04/mastercard.png', 0, 'attachment', 'image/png', 0),
(491, 1, '2019-05-16 06:13:08', '2019-05-16 06:13:08', '', 'form_leads', '', 'publish', 'closed', 'closed', '', 'form_leads', '', '', '2019-05-16 06:30:47', '2019-05-16 06:30:47', '', 0, 'http://localhost/project/?page_id=491', 0, 'page', '', 0),
(492, 1, '2019-05-16 06:13:08', '2019-05-16 06:13:08', '', 'form_leads', '', 'inherit', 'closed', 'closed', '', '491-revision-v1', '', '', '2019-05-16 06:13:08', '2019-05-16 06:13:08', '', 491, 'http://localhost/project/archives/492', 0, 'revision', '', 0),
(496, 1, '2019-05-19 06:38:13', '2019-05-19 06:38:13', '', '', '', 'publish', 'closed', 'closed', '', 'local-f462632a5987bb5d13d7d648ef13d15b', '', '', '2019-05-19 06:38:13', '2019-05-19 06:38:13', '', 0, 'http://localhost/project/site-review/local-f462632a5987bb5d13d7d648ef13d15b', 0, 'site-review', '', 0),
(498, 1, '2019-05-19 06:43:14', '2019-05-19 06:43:14', 'milon', '', '', 'publish', 'closed', 'closed', '', 'local-ec50cc4f2bddc1f01b11425b8e076b8e', '', '', '2019-05-19 06:43:14', '2019-05-19 06:43:14', '', 0, 'http://localhost/project/site-review/local-ec50cc4f2bddc1f01b11425b8e076b8e', 0, 'site-review', '', 0),
(500, 1, '2019-05-19 06:50:26', '2019-05-19 06:50:26', 'test golobal', '', '', 'publish', 'closed', 'closed', '', 'local-b4c6a596ebe34f9f9a3ddd80cbc61931', '', '', '2019-05-19 06:50:26', '2019-05-19 06:50:26', '', 0, 'http://localhost/project/site-review/local-b4c6a596ebe34f9f9a3ddd80cbc61931', 0, 'site-review', '', 0),
(501, 1, '2019-05-19 06:52:20', '2019-05-19 06:52:20', 'besto achi', '', '', 'publish', 'closed', 'closed', '', 'local-37dc86524a3bb6447c782ad2e4af14fe', '', '', '2019-05-19 06:52:20', '2019-05-19 06:52:20', '', 0, 'http://localhost/project/site-review/local-37dc86524a3bb6447c782ad2e4af14fe', 0, 'site-review', '', 0),
(502, 1, '2019-05-19 06:54:16', '2019-05-19 06:54:16', 'main', '', '', 'publish', 'closed', 'closed', '', 'local-d98e5b82cbac9ebb037f810360364f6a', '', '', '2019-05-19 06:54:16', '2019-05-19 06:54:16', '', 0, 'http://localhost/project/site-review/local-d98e5b82cbac9ebb037f810360364f6a', 0, 'site-review', '', 0),
(503, 1, '2019-05-19 07:24:30', '2019-05-19 07:24:30', 'hello bangladesh', '', '', 'publish', 'closed', 'closed', '', 'local-f51338724f78cebbe16c7d7fed0ecbef', '', '', '2019-05-19 07:24:30', '2019-05-19 07:24:30', '', 0, 'http://localhost/project/site-review/local-f51338724f78cebbe16c7d7fed0ecbef', 0, 'site-review', '', 0),
(504, 1, '2019-05-19 07:25:03', '2019-05-19 07:25:03', 'ami valo achi', '', '', 'publish', 'closed', 'closed', '', 'local-770d1ba070d5ddc2007e1fcc258a2241', '', '', '2019-05-19 07:25:03', '2019-05-19 07:25:03', '', 0, 'http://localhost/project/site-review/local-770d1ba070d5ddc2007e1fcc258a2241', 0, 'site-review', '', 0),
(505, 1, '2019-05-19 07:25:57', '2019-05-19 07:25:57', 'tomar ei na valo vasa', '', '', 'publish', 'closed', 'closed', '', 'local-154e4f1c7e4883dc447e04691f43cdde', '', '', '2019-05-19 07:25:57', '2019-05-19 07:25:57', '', 0, 'http://localhost/project/site-review/local-154e4f1c7e4883dc447e04691f43cdde', 0, 'site-review', '', 0),
(506, 1, '2019-05-19 07:26:25', '2019-05-19 07:26:25', 'kire ki', '', '', 'publish', 'closed', 'closed', '', 'local-e7ae27dae4ac4b01a42cb746a5a3010b', '', '', '2019-05-19 07:26:25', '2019-05-19 07:26:25', '', 0, 'http://localhost/project/site-review/local-e7ae27dae4ac4b01a42cb746a5a3010b', 0, 'site-review', '', 0),
(507, 1, '2019-05-21 05:30:48', '2019-05-21 05:30:48', 'hello', '', '', 'publish', 'closed', 'closed', '', 'local-3d1483ebb27d308c71feb1243ef1334d', '', '', '2019-05-21 05:30:48', '2019-05-21 05:30:48', '', 0, 'http://localhost/project/site-review/local-3d1483ebb27d308c71feb1243ef1334d', 0, 'site-review', '', 0),
(508, 1, '2019-05-22 04:27:08', '2019-05-22 04:27:08', '[wp_user]', 'User', '', 'publish', 'closed', 'closed', '', 'user', '', '', '2019-05-22 04:27:08', '2019-05-22 04:27:08', '', 0, 'http://localhost/project/user/', 0, 'page', '', 0),
(510, 1, '2019-05-22 06:00:40', '2019-05-22 06:00:40', '[wpuf_dashboard]', 'Dashboard', '', 'publish', 'closed', 'closed', '', 'dashboard', '', '', '2019-05-22 06:00:40', '2019-05-22 06:00:40', '', 0, 'http://localhost/project/dashboard/', 0, 'page', '', 0),
(511, 1, '2019-05-22 06:00:41', '2019-05-22 06:00:41', '[wpuf_account]', 'Account', '', 'publish', 'closed', 'closed', '', 'account', '', '', '2019-05-22 06:00:41', '2019-05-22 06:00:41', '', 0, 'http://localhost/project/account/', 0, 'page', '', 0),
(514, 1, '2019-05-22 06:00:41', '2019-05-22 06:00:41', '', 'Sample Form', '', 'publish', 'closed', 'closed', '', 'sample-form', '', '', '2019-05-22 06:00:41', '2019-05-22 06:00:41', '', 0, 'http://localhost/project/wpuf_forms/sample-form/', 0, 'wpuf_forms', '', 0),
(515, 1, '2019-05-22 06:00:41', '2019-05-22 06:00:41', 'a:12:{s:10:\"input_type\";s:4:\"text\";s:8:\"template\";s:10:\"post_title\";s:8:\"required\";s:3:\"yes\";s:5:\"label\";s:10:\"Post Title\";s:4:\"name\";s:10:\"post_title\";s:7:\"is_meta\";s:2:\"no\";s:4:\"help\";s:0:\"\";s:3:\"css\";s:0:\"\";s:11:\"placeholder\";s:0:\"\";s:7:\"default\";s:0:\"\";s:4:\"size\";s:2:\"40\";s:9:\"wpuf_cond\";a:0:{}}', '', '', 'publish', 'closed', 'closed', '', '515', '', '', '2019-05-22 06:00:41', '2019-05-22 06:00:41', '', 514, 'http://localhost/project/wpuf_input/515/', 0, 'wpuf_input', '', 0),
(516, 1, '2019-05-22 06:00:41', '2019-05-22 06:00:41', 'a:15:{s:10:\"input_type\";s:8:\"textarea\";s:8:\"template\";s:12:\"post_content\";s:8:\"required\";s:3:\"yes\";s:5:\"label\";s:12:\"Post Content\";s:4:\"name\";s:12:\"post_content\";s:7:\"is_meta\";s:2:\"no\";s:4:\"help\";s:0:\"\";s:3:\"css\";s:0:\"\";s:4:\"rows\";s:1:\"5\";s:4:\"cols\";s:2:\"25\";s:11:\"placeholder\";s:0:\"\";s:7:\"default\";s:0:\"\";s:4:\"rich\";s:5:\"teeny\";s:12:\"insert_image\";s:3:\"yes\";s:9:\"wpuf_cond\";a:0:{}}', '', '', 'publish', 'closed', 'closed', '', '516', '', '', '2019-05-22 06:00:41', '2019-05-22 06:00:41', '', 514, 'http://localhost/project/wpuf_input/516/', 1, 'wpuf_input', '', 0),
(517, 1, '2019-05-22 06:00:41', '2019-05-22 06:00:41', '[wpuf_sub_pack]', 'Subscription', '', 'publish', 'closed', 'closed', '', 'subscription', '', '', '2019-05-22 06:00:41', '2019-05-22 06:00:41', '', 0, 'http://localhost/project/subscription/', 0, 'page', '', 0),
(518, 1, '2019-05-22 06:00:41', '2019-05-22 06:00:41', 'Please select a gateway for payment', 'Payment', '', 'publish', 'closed', 'closed', '', 'payment', '', '', '2019-05-22 06:00:41', '2019-05-22 06:00:41', '', 0, 'http://localhost/project/payment/', 0, 'page', '', 0),
(519, 1, '2019-05-22 06:00:41', '2019-05-22 06:00:41', '<h1>Payment is complete</h1><p>Congratulations, your payment has been completed!</p>', 'Thank You', '', 'publish', 'closed', 'closed', '', 'thank-you', '', '', '2019-05-22 06:00:41', '2019-05-22 06:00:41', '', 0, 'http://localhost/project/thank-you/', 0, 'page', '', 0),
(520, 1, '2019-05-22 06:00:42', '2019-05-22 06:00:42', 'Hi, we have received your order. We will validate the order and will take necessary steps to move forward.', 'Order Received', '', 'publish', 'closed', 'closed', '', 'order-received', '', '', '2019-05-22 06:00:42', '2019-05-22 06:00:42', '', 0, 'http://localhost/project/order-received/', 0, 'page', '', 0),
(521, 1, '2019-05-22 06:05:42', '2019-05-22 06:05:42', '[wpuf_dashboard]', 'Dashboard', '', 'publish', 'closed', 'closed', '', 'dashboard-2', '', '', '2019-05-22 06:05:42', '2019-05-22 06:05:42', '', 0, 'http://localhost/project/dashboard-2/', 0, 'page', '', 0),
(522, 1, '2019-05-22 06:05:42', '2019-05-22 06:05:42', '[wpuf_account]', 'Account', '', 'publish', 'closed', 'closed', '', 'account-2', '', '', '2019-05-22 06:05:42', '2019-05-22 06:05:42', '', 0, 'http://localhost/project/account-2/', 0, 'page', '', 0),
(524, 1, '2019-05-22 06:05:42', '2019-05-22 06:05:42', '[wpuf-login]', 'Login', '', 'publish', 'closed', 'closed', '', 'login-2', '', '', '2019-05-22 06:05:42', '2019-05-22 06:05:42', '', 0, 'http://localhost/project/login-2/', 0, 'page', '', 0),
(525, 1, '2019-05-22 06:05:42', '2019-05-22 06:05:42', '', 'Sample Form', '', 'publish', 'closed', 'closed', '', 'sample-form-2', '', '', '2019-05-22 06:05:42', '2019-05-22 06:05:42', '', 0, 'http://localhost/project/wpuf_forms/sample-form-2/', 0, 'wpuf_forms', '', 0),
(526, 1, '2019-05-22 06:05:42', '2019-05-22 06:05:42', 'a:12:{s:10:\"input_type\";s:4:\"text\";s:8:\"template\";s:10:\"post_title\";s:8:\"required\";s:3:\"yes\";s:5:\"label\";s:10:\"Post Title\";s:4:\"name\";s:10:\"post_title\";s:7:\"is_meta\";s:2:\"no\";s:4:\"help\";s:0:\"\";s:3:\"css\";s:0:\"\";s:11:\"placeholder\";s:0:\"\";s:7:\"default\";s:0:\"\";s:4:\"size\";s:2:\"40\";s:9:\"wpuf_cond\";a:0:{}}', '', '', 'publish', 'closed', 'closed', '', '526', '', '', '2019-05-22 06:05:42', '2019-05-22 06:05:42', '', 525, 'http://localhost/project/wpuf_input/526/', 0, 'wpuf_input', '', 0),
(527, 1, '2019-05-22 06:05:42', '2019-05-22 06:05:42', 'a:15:{s:10:\"input_type\";s:8:\"textarea\";s:8:\"template\";s:12:\"post_content\";s:8:\"required\";s:3:\"yes\";s:5:\"label\";s:12:\"Post Content\";s:4:\"name\";s:12:\"post_content\";s:7:\"is_meta\";s:2:\"no\";s:4:\"help\";s:0:\"\";s:3:\"css\";s:0:\"\";s:4:\"rows\";s:1:\"5\";s:4:\"cols\";s:2:\"25\";s:11:\"placeholder\";s:0:\"\";s:7:\"default\";s:0:\"\";s:4:\"rich\";s:5:\"teeny\";s:12:\"insert_image\";s:3:\"yes\";s:9:\"wpuf_cond\";a:0:{}}', '', '', 'publish', 'closed', 'closed', '', '527', '', '', '2019-05-22 06:05:42', '2019-05-22 06:05:42', '', 525, 'http://localhost/project/wpuf_input/527/', 1, 'wpuf_input', '', 0),
(528, 1, '2019-05-22 06:05:42', '2019-05-22 06:05:42', '[wpuf_sub_pack]', 'Subscription', '', 'publish', 'closed', 'closed', '', 'subscription-2', '', '', '2019-05-22 06:05:42', '2019-05-22 06:05:42', '', 0, 'http://localhost/project/subscription-2/', 0, 'page', '', 0),
(529, 1, '2019-05-22 06:05:43', '2019-05-22 06:05:43', 'Please select a gateway for payment', 'Payment', '', 'publish', 'closed', 'closed', '', 'payment-2', '', '', '2019-05-22 06:05:43', '2019-05-22 06:05:43', '', 0, 'http://localhost/project/payment-2/', 0, 'page', '', 0),
(530, 1, '2019-05-22 06:05:43', '2019-05-22 06:05:43', '<h1>Payment is complete</h1><p>Congratulations, your payment has been completed!</p>', 'Thank You', '', 'publish', 'closed', 'closed', '', 'thank-you-2', '', '', '2019-05-22 06:05:43', '2019-05-22 06:05:43', '', 0, 'http://localhost/project/thank-you-2/', 0, 'page', '', 0),
(531, 1, '2019-05-22 06:05:43', '2019-05-22 06:05:43', 'Hi, we have received your order. We will validate the order and will take necessary steps to move forward.', 'Order Received', '', 'publish', 'closed', 'closed', '', 'order-received-2', '', '', '2019-05-22 06:05:43', '2019-05-22 06:05:43', '', 0, 'http://localhost/project/order-received-2/', 0, 'page', '', 0),
(532, 1, '2019-05-22 06:05:43', '2019-05-22 06:05:43', '', 'Registration', '', 'publish', 'closed', 'closed', '', 'registration', '', '', '2019-05-22 06:05:43', '2019-05-22 06:05:43', '', 0, 'http://localhost/project/wpuf_profile/registration/', 0, 'wpuf_profile', '', 0),
(533, 1, '2019-05-22 06:05:43', '2019-05-22 06:05:43', 'a:12:{s:10:\"input_type\";s:5:\"email\";s:8:\"template\";s:10:\"user_email\";s:8:\"required\";s:3:\"yes\";s:5:\"label\";s:5:\"Email\";s:4:\"name\";s:10:\"user_email\";s:7:\"is_meta\";s:2:\"no\";s:4:\"help\";s:0:\"\";s:3:\"css\";s:0:\"\";s:11:\"placeholder\";s:0:\"\";s:7:\"default\";s:0:\"\";s:4:\"size\";s:2:\"40\";s:9:\"wpuf_cond\";N;}', '', '', 'publish', 'closed', 'closed', '', '533', '', '', '2019-05-22 06:05:43', '2019-05-22 06:05:43', '', 532, 'http://localhost/project/wpuf_input/533/', 0, 'wpuf_input', '', 0),
(534, 1, '2019-05-22 06:05:43', '2019-05-22 06:05:43', 'a:16:{s:10:\"input_type\";s:8:\"password\";s:8:\"template\";s:8:\"password\";s:8:\"required\";s:3:\"yes\";s:5:\"label\";s:8:\"Password\";s:4:\"name\";s:8:\"password\";s:7:\"is_meta\";s:2:\"no\";s:4:\"help\";s:0:\"\";s:3:\"css\";s:0:\"\";s:11:\"placeholder\";s:0:\"\";s:7:\"default\";s:0:\"\";s:4:\"size\";s:2:\"40\";s:10:\"min_length\";s:1:\"5\";s:11:\"repeat_pass\";s:3:\"yes\";s:13:\"re_pass_label\";s:16:\"Confirm Password\";s:13:\"pass_strength\";s:3:\"yes\";s:9:\"wpuf_cond\";N;}', '', '', 'publish', 'closed', 'closed', '', '534', '', '', '2019-05-22 06:05:43', '2019-05-22 06:05:43', '', 532, 'http://localhost/project/wpuf_input/534/', 1, 'wpuf_input', '', 0),
(535, 1, '2019-05-22 06:05:43', '2019-05-22 06:05:43', '[wpuf_profile type=\"registration\" id=\"532\"]', 'Registration', '', 'publish', 'closed', 'closed', '', 'registration', '', '', '2019-05-22 06:05:43', '2019-05-22 06:05:43', '', 0, 'http://localhost/project/registration/', 0, 'page', '', 0),
(536, 1, '2019-05-22 06:07:29', '2019-05-22 06:07:29', '[wpuf-login]', 'Activities', '', 'inherit', 'closed', 'closed', '', '13-revision-v1', '', '', '2019-05-22 06:07:29', '2019-05-22 06:07:29', '', 13, 'http://localhost/project/13-revision-v1/', 0, 'revision', '', 0),
(537, 1, '2019-05-22 06:14:15', '2019-05-22 06:14:15', '[wpuf_profile type=\"registration\" id=\"532\"]', 'Activities', '', 'inherit', 'closed', 'closed', '', '13-revision-v1', '', '', '2019-05-22 06:14:15', '2019-05-22 06:14:15', '', 13, 'http://localhost/project/13-revision-v1/', 0, 'revision', '', 0),
(538, 1, '2019-05-22 06:15:12', '2019-05-22 06:15:12', '', 'Contact Form', '', 'publish', 'closed', 'closed', '', 'contact-form', '', '', '2019-05-22 06:15:46', '2019-05-22 06:15:46', '', 0, 'http://localhost/project/contact-form/', 0, 'wpuf_contact_form', '', 0),
(542, 1, '2019-05-22 06:15:46', '2019-05-22 06:15:46', 'a:18:{s:8:\"template\";s:10:\"name_field\";s:4:\"name\";s:4:\"name\";s:5:\"label\";s:4:\"Name\";s:8:\"required\";s:3:\"yes\";s:5:\"width\";s:5:\"large\";s:3:\"css\";s:0:\"\";s:11:\"placeholder\";s:0:\"\";s:7:\"default\";s:0:\"\";s:4:\"size\";i:40;s:4:\"help\";s:0:\"\";s:7:\"is_meta\";s:3:\"yes\";s:9:\"wpuf_cond\";a:5:{s:16:\"condition_status\";s:2:\"no\";s:10:\"cond_field\";a:0:{}s:13:\"cond_operator\";a:1:{i:0;s:1:\"=\";}s:11:\"cond_option\";a:1:{i:0;s:10:\"- select -\";}s:10:\"cond_logic\";s:3:\"all\";}s:6:\"format\";s:10:\"first-last\";s:10:\"first_name\";a:3:{s:11:\"placeholder\";s:0:\"\";s:7:\"default\";s:0:\"\";s:3:\"sub\";s:5:\"First\";}s:11:\"middle_name\";a:3:{s:11:\"placeholder\";s:0:\"\";s:7:\"default\";s:0:\"\";s:3:\"sub\";s:6:\"Middle\";}s:9:\"last_name\";a:3:{s:11:\"placeholder\";s:0:\"\";s:7:\"default\";s:0:\"\";s:3:\"sub\";s:4:\"Last\";}s:6:\"inline\";s:3:\"yes\";s:9:\"hide_subs\";b:0;}', '', '', 'publish', 'closed', 'closed', '', '542', '', '', '2019-05-22 06:15:46', '2019-05-22 06:15:46', '', 538, 'http://localhost/project/wpuf_input/542/', 0, 'wpuf_input', '', 0),
(543, 1, '2019-05-22 06:15:46', '2019-05-22 06:15:46', 'a:13:{s:8:\"template\";s:13:\"email_address\";s:4:\"name\";s:5:\"email\";s:5:\"label\";s:13:\"Email Address\";s:8:\"required\";s:3:\"yes\";s:5:\"width\";s:5:\"large\";s:3:\"css\";s:0:\"\";s:11:\"placeholder\";s:0:\"\";s:7:\"default\";s:0:\"\";s:4:\"size\";i:40;s:4:\"help\";s:0:\"\";s:7:\"is_meta\";s:3:\"yes\";s:9:\"wpuf_cond\";a:5:{s:16:\"condition_status\";s:2:\"no\";s:10:\"cond_field\";a:0:{}s:13:\"cond_operator\";a:1:{i:0;s:1:\"=\";}s:11:\"cond_option\";a:1:{i:0;s:10:\"- select -\";}s:10:\"cond_logic\";s:3:\"all\";}s:9:\"duplicate\";s:0:\"\";}', '', '', 'publish', 'closed', 'closed', '', '543', '', '', '2019-05-22 06:15:46', '2019-05-22 06:15:46', '', 538, 'http://localhost/project/wpuf_input/543/', 1, 'wpuf_input', '', 0),
(544, 1, '2019-05-22 06:15:46', '2019-05-22 06:15:46', 'a:16:{s:8:\"template\";s:14:\"textarea_field\";s:4:\"name\";s:7:\"message\";s:5:\"label\";s:7:\"Message\";s:8:\"required\";s:3:\"yes\";s:5:\"width\";s:5:\"large\";s:3:\"css\";s:0:\"\";s:11:\"placeholder\";s:0:\"\";s:7:\"default\";s:0:\"\";s:4:\"size\";i:40;s:4:\"help\";s:0:\"\";s:7:\"is_meta\";s:3:\"yes\";s:9:\"wpuf_cond\";a:5:{s:16:\"condition_status\";s:2:\"no\";s:10:\"cond_field\";a:0:{}s:13:\"cond_operator\";a:1:{i:0;s:1:\"=\";}s:11:\"cond_option\";a:1:{i:0;s:10:\"- select -\";}s:10:\"cond_logic\";s:3:\"all\";}s:16:\"word_restriction\";s:0:\"\";s:4:\"rows\";i:5;s:4:\"cols\";i:25;s:4:\"rich\";s:2:\"no\";}', '', '', 'publish', 'closed', 'closed', '', '544', '', '', '2019-05-22 06:15:46', '2019-05-22 06:15:46', '', 538, 'http://localhost/project/wpuf_input/544/', 2, 'wpuf_input', '', 0),
(545, 1, '2019-05-22 06:16:24', '2019-05-22 06:16:24', '[weforms id=\"538\"]', 'Activities', '', 'inherit', 'closed', 'closed', '', '13-revision-v1', '', '', '2019-05-22 06:16:24', '2019-05-22 06:16:24', '', 13, 'http://localhost/project/13-revision-v1/', 0, 'revision', '', 0),
(547, 1, '2019-05-22 07:32:33', '2019-05-22 07:32:33', '[wppb-register]', 'Register', '', 'publish', 'closed', 'closed', '', 'register', '', '', '2019-05-22 07:32:33', '2019-05-22 07:32:33', '', 0, 'http://localhost/project/register/', 0, 'page', '', 0),
(548, 1, '2019-05-22 07:32:33', '2019-05-22 07:32:33', '[wppb-edit-profile]', 'Edit Profile', '', 'publish', 'closed', 'closed', '', 'edit-profile', '', '', '2019-05-22 07:32:33', '2019-05-22 07:32:33', '', 0, 'http://localhost/project/edit-profile/', 0, 'page', '', 0),
(551, 1, '2019-05-22 07:37:32', '2019-05-22 07:37:32', '', 'Administrator', '', 'publish', 'closed', 'closed', '', 'administrator', '', '', '2019-05-22 07:37:32', '2019-05-22 07:37:32', '', 0, 'http://localhost/project/wppb-roles-editor/administrator/', 0, 'wppb-roles-editor', '', 0),
(552, 1, '2019-05-22 07:37:32', '2019-05-22 07:37:32', '', 'Author', '', 'publish', 'closed', 'closed', '', 'author', '', '', '2019-05-22 07:37:32', '2019-05-22 07:37:32', '', 0, 'http://localhost/project/wppb-roles-editor/author/', 0, 'wppb-roles-editor', '', 0),
(553, 1, '2019-05-22 07:37:32', '2019-05-22 07:37:32', '', 'Blocked', '', 'publish', 'closed', 'closed', '', 'blocked', '', '', '2019-05-22 07:37:32', '2019-05-22 07:37:32', '', 0, 'http://localhost/project/wppb-roles-editor/blocked/', 0, 'wppb-roles-editor', '', 0),
(554, 1, '2019-05-22 07:37:32', '2019-05-22 07:37:32', '', 'Booking Editor', '', 'publish', 'closed', 'closed', '', 'booking-editor', '', '', '2019-05-22 07:37:32', '2019-05-22 07:37:32', '', 0, 'http://localhost/project/wppb-roles-editor/booking-editor/', 0, 'wppb-roles-editor', '', 0),
(555, 1, '2019-05-22 07:37:32', '2019-05-22 07:37:32', '', 'Booking Package', '', 'publish', 'closed', 'closed', '', 'booking-package', '', '', '2019-05-22 07:37:32', '2019-05-22 07:37:32', '', 0, 'http://localhost/project/wppb-roles-editor/booking-package/', 0, 'wppb-roles-editor', '', 0),
(556, 1, '2019-05-22 07:37:33', '2019-05-22 07:37:33', '', 'Contributor', '', 'publish', 'closed', 'closed', '', 'contributor', '', '', '2019-05-22 07:37:33', '2019-05-22 07:37:33', '', 0, 'http://localhost/project/wppb-roles-editor/contributor/', 0, 'wppb-roles-editor', '', 0),
(557, 1, '2019-05-22 07:37:33', '2019-05-22 07:37:33', '', 'Customer', '', 'publish', 'closed', 'closed', '', 'customer', '', '', '2019-05-22 07:37:33', '2019-05-22 07:37:33', '', 0, 'http://localhost/project/wppb-roles-editor/customer/', 0, 'wppb-roles-editor', '', 0),
(558, 1, '2019-05-22 07:37:33', '2019-05-22 07:37:33', '', 'Editor', '', 'publish', 'closed', 'closed', '', 'editor', '', '', '2019-05-22 07:37:33', '2019-05-22 07:37:33', '', 0, 'http://localhost/project/wppb-roles-editor/editor/', 0, 'wppb-roles-editor', '', 0),
(559, 1, '2019-05-22 07:37:33', '2019-05-22 07:37:33', '', 'Hotel Customer', '', 'publish', 'closed', 'closed', '', 'hotel-customer', '', '', '2019-05-22 07:37:33', '2019-05-22 07:37:33', '', 0, 'http://localhost/project/wppb-roles-editor/hotel-customer/', 0, 'wppb-roles-editor', '', 0),
(560, 1, '2019-05-22 07:37:33', '2019-05-22 07:37:33', '', 'Hotel Manager', '', 'publish', 'closed', 'closed', '', 'hotel-manager', '', '', '2019-05-22 07:37:33', '2019-05-22 07:37:33', '', 0, 'http://localhost/project/wppb-roles-editor/hotel-manager/', 0, 'wppb-roles-editor', '', 0),
(561, 1, '2019-05-22 07:37:33', '2019-05-22 07:37:33', '', 'Hotel Manager', '', 'publish', 'closed', 'closed', '', 'hotel-manager-2', '', '', '2019-05-22 07:37:33', '2019-05-22 07:37:33', '', 0, 'http://localhost/project/wppb-roles-editor/hotel-manager-2/', 0, 'wppb-roles-editor', '', 0),
(562, 1, '2019-05-22 07:37:33', '2019-05-22 07:37:33', '', 'Hotel Receptionist', '', 'publish', 'closed', 'closed', '', 'hotel-receptionist', '', '', '2019-05-22 07:37:33', '2019-05-22 07:37:33', '', 0, 'http://localhost/project/wppb-roles-editor/hotel-receptionist/', 0, 'wppb-roles-editor', '', 0),
(563, 1, '2019-05-22 07:37:33', '2019-05-22 07:37:33', '', 'Keymaster', '', 'publish', 'closed', 'closed', '', 'keymaster', '', '', '2019-05-22 07:37:33', '2019-05-22 07:37:33', '', 0, 'http://localhost/project/wppb-roles-editor/keymaster/', 0, 'wppb-roles-editor', '', 0),
(564, 1, '2019-05-22 07:37:34', '2019-05-22 07:37:34', '', 'Moderator', '', 'publish', 'closed', 'closed', '', 'moderator', '', '', '2019-05-22 07:37:34', '2019-05-22 07:37:34', '', 0, 'http://localhost/project/wppb-roles-editor/moderator/', 0, 'wppb-roles-editor', '', 0),
(565, 1, '2019-05-22 07:37:34', '2019-05-22 07:37:34', '', 'Participant', '', 'publish', 'closed', 'closed', '', 'participant', '', '', '2019-05-22 07:37:34', '2019-05-22 07:37:34', '', 0, 'http://localhost/project/wppb-roles-editor/participant/', 0, 'wppb-roles-editor', '', 0),
(566, 1, '2019-05-22 07:37:34', '2019-05-22 07:37:34', '', 'Shop manager', '', 'publish', 'closed', 'closed', '', 'shop-manager', '', '', '2019-05-22 07:37:34', '2019-05-22 07:37:34', '', 0, 'http://localhost/project/wppb-roles-editor/shop-manager/', 0, 'wppb-roles-editor', '', 0),
(567, 1, '2019-05-22 07:37:34', '2019-05-22 07:37:34', '', 'Spectator', '', 'publish', 'closed', 'closed', '', 'spectator', '', '', '2019-05-22 07:37:34', '2019-05-22 07:37:34', '', 0, 'http://localhost/project/wppb-roles-editor/spectator/', 0, 'wppb-roles-editor', '', 0),
(568, 1, '2019-05-22 07:37:34', '2019-05-22 07:37:34', '', 'Subscriber', '', 'publish', 'closed', 'closed', '', 'subscriber', '', '', '2019-05-22 07:37:34', '2019-05-22 07:37:34', '', 0, 'http://localhost/project/wppb-roles-editor/subscriber/', 0, 'wppb-roles-editor', '', 0),
(569, 1, '2019-05-22 07:37:34', '2019-05-22 07:37:34', '', 'WP Travel Customer', '', 'publish', 'closed', 'closed', '', 'wp-travel-customer', '', '', '2019-05-22 07:37:34', '2019-05-22 07:37:34', '', 0, 'http://localhost/project/wppb-roles-editor/wp-travel-customer/', 0, 'wppb-roles-editor', '', 0),
(570, 1, '2019-05-22 07:37:34', '2019-05-22 07:37:34', '', 'milon', '', 'publish', 'closed', 'closed', '', 'milon', '', '', '2019-05-22 07:37:34', '2019-05-22 07:37:34', '', 0, 'http://localhost/project/wppb-roles-editor/milon/', 0, 'wppb-roles-editor', '', 0),
(571, 1, '2019-05-22 07:37:34', '2019-05-22 07:37:34', '', 'taibur', '', 'publish', 'closed', 'closed', '', 'taibur', '', '', '2019-05-22 10:31:44', '2019-05-22 10:31:44', '', 0, 'http://localhost/project/wppb-roles-editor/taibur/', 0, 'wppb-roles-editor', '', 0),
(576, 1, '2019-05-23 04:43:59', '2019-05-23 04:43:59', '', 'Umrah', '', 'publish', 'closed', 'closed', '', 'umrah', '', '', '2019-05-30 20:13:49', '2019-05-30 20:13:49', '', 0, 'https://technovicinity.com/development/wordpress/milon/travel/?p=576', 3, 'nav_menu_item', '', 0),
(578, 1, '2019-05-23 04:45:12', '2019-05-23 04:45:12', '', 'Travel Agency', '', 'publish', 'closed', 'closed', '', 'travel-agency', '', '', '2019-05-23 04:45:12', '2019-05-23 04:45:12', '', 0, 'https://technovicinity.com/development/wordpress/milon/travel/?page_id=578', 0, 'page', '', 0),
(579, 1, '2019-05-23 04:45:12', '2019-05-23 04:45:12', '', 'Travel Agency', '', 'inherit', 'closed', 'closed', '', '578-revision-v1', '', '', '2019-05-23 04:45:12', '2019-05-23 04:45:12', '', 578, 'https://technovicinity.com/development/wordpress/milon/travel/578-revision-v1/', 0, 'revision', '', 0),
(580, 1, '2019-05-23 04:45:36', '2019-05-23 04:45:36', '<!-- wp:paragraph -->\n<p>\n\n[gdgallery_gallery id_gallery=\"1\"]\n\n</p>\n<!-- /wp:paragraph -->', 'Gallery', '', 'publish', 'closed', 'closed', '', 'gallery', '', '', '2019-05-25 19:18:07', '2019-05-25 19:18:07', '', 0, 'https://technovicinity.com/development/wordpress/milon/travel/?page_id=580', 0, 'page', '', 0),
(581, 1, '2019-05-23 04:45:36', '2019-05-23 04:45:36', '', 'Gallery', '', 'inherit', 'closed', 'closed', '', '580-revision-v1', '', '', '2019-05-23 04:45:36', '2019-05-23 04:45:36', '', 580, 'https://technovicinity.com/development/wordpress/milon/travel/580-revision-v1/', 0, 'revision', '', 0),
(582, 1, '2019-05-23 04:45:52', '2019-05-23 04:45:52', '', 'Blog', '', 'publish', 'closed', 'closed', '', 'blog', '', '', '2019-05-23 04:45:52', '2019-05-23 04:45:52', '', 0, 'https://technovicinity.com/development/wordpress/milon/travel/?page_id=582', 0, 'page', '', 0),
(583, 1, '2019-05-23 04:45:52', '2019-05-23 04:45:52', '', 'Blog', '', 'inherit', 'closed', 'closed', '', '582-revision-v1', '', '', '2019-05-23 04:45:52', '2019-05-23 04:45:52', '', 582, 'https://technovicinity.com/development/wordpress/milon/travel/582-revision-v1/', 0, 'revision', '', 0),
(584, 1, '2019-05-23 04:46:41', '2019-05-23 04:46:41', ' ', '', '', 'publish', 'closed', 'closed', '', '584', '', '', '2019-05-30 20:13:49', '2019-05-30 20:13:49', '', 0, 'https://technovicinity.com/development/wordpress/milon/travel/?p=584', 15, 'nav_menu_item', '', 0),
(585, 1, '2019-05-23 04:46:41', '2019-05-23 04:46:41', ' ', '', '', 'publish', 'closed', 'closed', '', '585', '', '', '2019-05-30 20:13:49', '2019-05-30 20:13:49', '', 0, 'https://technovicinity.com/development/wordpress/milon/travel/?p=585', 14, 'nav_menu_item', '', 0),
(586, 1, '2019-05-23 04:46:41', '2019-05-23 04:46:41', ' ', '', '', 'publish', 'closed', 'closed', '', '586', '', '', '2019-05-30 20:13:49', '2019-05-30 20:13:49', '', 0, 'https://technovicinity.com/development/wordpress/milon/travel/?p=586', 13, 'nav_menu_item', '', 0),
(587, 1, '2019-05-23 04:49:05', '2019-05-23 04:49:05', ' ', '', '', 'publish', 'closed', 'closed', '', '587', '', '', '2019-05-23 04:49:05', '2019-05-23 04:49:05', '', 0, 'https://technovicinity.com/development/wordpress/milon/travel/?p=587', 1, 'nav_menu_item', '', 0),
(588, 1, '2019-05-23 04:49:05', '2019-05-23 04:49:05', ' ', '', '', 'publish', 'closed', 'closed', '', '588', '', '', '2019-05-23 04:49:05', '2019-05-23 04:49:05', '', 0, 'https://technovicinity.com/development/wordpress/milon/travel/?p=588', 2, 'nav_menu_item', '', 0),
(589, 1, '2019-05-23 04:49:05', '2019-05-23 04:49:05', ' ', '', '', 'publish', 'closed', 'closed', '', '589', '', '', '2019-05-23 04:49:05', '2019-05-23 04:49:05', '', 0, 'https://technovicinity.com/development/wordpress/milon/travel/?p=589', 3, 'nav_menu_item', '', 0),
(590, 1, '2019-05-23 04:49:05', '2019-05-23 04:49:05', ' ', '', '', 'publish', 'closed', 'closed', '', '590', '', '', '2019-05-23 04:49:05', '2019-05-23 04:49:05', '', 0, 'https://technovicinity.com/development/wordpress/milon/travel/?p=590', 4, 'nav_menu_item', '', 0),
(591, 1, '2019-05-23 04:49:05', '2019-05-23 04:49:05', ' ', '', '', 'publish', 'closed', 'closed', '', '591', '', '', '2019-05-23 04:49:05', '2019-05-23 04:49:05', '', 0, 'https://technovicinity.com/development/wordpress/milon/travel/?p=591', 5, 'nav_menu_item', '', 0),
(592, 1, '2019-05-23 04:49:05', '2019-05-23 04:49:05', ' ', '', '', 'publish', 'closed', 'closed', '', '592', '', '', '2019-05-23 04:49:05', '2019-05-23 04:49:05', '', 0, 'https://technovicinity.com/development/wordpress/milon/travel/?p=592', 6, 'nav_menu_item', '', 0),
(595, 1, '2019-05-24 19:23:17', '2019-05-24 19:23:17', '<span id=\"e18\" class=\"qc_ si29 \">Lowest Prices &amp; Latest Reviews on TripAdvisor®. Cheap Flights. Millions of hotel reviews. Best Places to Eat. Amazing Experiences. Hidden Gems. Candid traveler photos. Vacation Rentals. Easy <b>price</b> comparison. Tours, Attractions + More. Fun Things to Do.</span>\r\n<div id=\"e30\" class=\"kc_  \">\r\n<div id=\"e31\" class=\"kc_  \">\r\n<div id=\"e33\" class=\"kc_ si17 \"></div>\r\n</div>\r\n</div>', 'The 10 BEST Hotels (2019) - Hajj And Umrah', '', 'publish', 'open', 'closed', '', 'the-10-best-hotels-2019-hajj-and-umrah', '', '', '2019-05-24 19:23:17', '2019-05-24 19:23:17', '', 0, 'https://technovicinity.com/development/wordpress/milon/travel/?post_type=umrah&#038;p=595', 0, 'umrah', '', 0),
(596, 1, '2019-05-24 19:23:54', '2019-05-24 19:23:54', '', '', '', 'publish', 'closed', 'closed', '', 'local-f32e2b9a7df30121f83ee14e50c4f667', '', '', '2019-05-24 19:23:54', '2019-05-24 19:23:54', '', 0, 'https://technovicinity.com/development/wordpress/milon/travel/site-review/local-f32e2b9a7df30121f83ee14e50c4f667/', 0, 'site-review', '', 0),
(597, 1, '2019-05-24 19:29:58', '2019-05-24 19:29:58', 'Travel offers, with the best hotels, transfers and tours. Book your holidays. Access the best hotel deals and customized travel <b>packages</b> for your Cuba trip. Circuitos por Cuba. Paquetes a la medida. Havanatur Celimar. Lodging in Cuba. Alojamiento en Cuba. Havanatur Cuba. Transfer in Cuba. Conventions in Cuba. Excursiones por Cuba. Offers in Cuba.', 'Havanatur Cuba - Tour operator Cuba - Tours in Cuba', '', 'publish', 'open', 'closed', '', 'havanatur-cuba-tour-operator-cuba-tours-in-cuba', '', '', '2019-05-24 19:29:58', '2019-05-24 19:29:58', '', 0, 'https://technovicinity.com/development/wordpress/milon/travel/?post_type=umrah&#038;p=597', 0, 'umrah', '', 0),
(598, 1, '2019-05-24 19:33:10', '2019-05-24 19:33:10', '', '', '', 'publish', 'closed', 'closed', '', 'local-9671663c0ebd768ec56cea070b5d7a61', '', '', '2019-05-24 19:33:10', '2019-05-24 19:33:10', '', 0, 'https://technovicinity.com/development/wordpress/milon/travel/site-review/local-9671663c0ebd768ec56cea070b5d7a61/', 0, 'site-review', '', 0),
(599, 1, '2019-05-25 04:08:53', '2019-05-25 04:08:53', 'Cursus faucibus egestas rutrum mauris vulputate consequat ante', 'England, UK', '', 'inherit', 'closed', 'closed', '', '353-autosave-v1', '', '', '2019-05-25 04:08:53', '2019-05-25 04:08:53', '', 353, 'https://technovicinity.com/development/wordpress/milon/travel/353-autosave-v1/', 0, 'revision', '', 0),
(600, 1, '2019-05-25 04:11:43', '2019-05-25 04:11:43', 'faucibus egestas rutrum mauris vulputate consequat ante', 'Newziland', '', 'inherit', 'closed', 'closed', '', '352-autosave-v1', '', '', '2019-05-25 04:11:43', '2019-05-25 04:11:43', '', 352, 'https://technovicinity.com/development/wordpress/milon/travel/352-autosave-v1/', 0, 'revision', '', 0),
(601, 1, '2019-05-25 04:14:21', '2019-05-25 04:14:21', 'Cursus faucibus egestas rutrum mauris vulputate consequat anteCursus faucibus egestas rutrum mauris vulputate consequat ante', 'Russia', '', 'inherit', 'closed', 'closed', '', '337-autosave-v1', '', '', '2019-05-25 04:14:21', '2019-05-25 04:14:21', '', 337, 'https://technovicinity.com/development/wordpress/milon/travel/337-autosave-v1/', 0, 'revision', '', 0),
(602, 1, '2019-05-25 04:17:26', '2019-05-25 04:17:26', 'Cursus faucibus egestas rutrum mauris vulputate consequat anteCursus faucibus egestas rutrum mauris vulputate consequat anteCursus faucibus egestas rutrum mauris vulputate consequat ante', 'Germany', '', 'publish', 'open', 'closed', '', 'germany', '', '', '2019-05-25 04:17:26', '2019-05-25 04:17:26', '', 0, 'https://technovicinity.com/development/wordpress/milon/travel/?post_type=tours&#038;p=602', 0, 'tours', '', 0),
(603, 1, '2019-05-25 04:17:17', '2019-05-25 04:17:17', '', '_2', '', 'inherit', 'open', 'closed', '', '_2', '', '', '2019-05-25 04:17:17', '2019-05-25 04:17:17', '', 602, 'https://technovicinity.com/development/wordpress/milon/travel/wp-content/uploads/2019/05/2.jpg', 0, 'attachment', 'image/jpeg', 0),
(604, 1, '2019-05-25 04:22:02', '2019-05-25 04:22:02', '', 'o-RUSSIA-VIRTUALPRIDE-facebook-263x197', '', 'inherit', 'open', 'closed', '', 'o-russia-virtualpride-facebook-263x197', '', '', '2019-05-25 04:22:02', '2019-05-25 04:22:02', '', 379, 'https://technovicinity.com/development/wordpress/milon/travel/wp-content/uploads/2019/04/o-RUSSIA-VIRTUALPRIDE-facebook-263x197.jpg', 0, 'attachment', 'image/jpeg', 0),
(607, 1, '2019-05-25 18:10:28', '2019-05-25 18:10:28', '', 'Transportation', '', 'publish', 'closed', 'closed', '', 'transportation', '', '', '2019-05-30 20:13:49', '2019-05-30 20:13:49', '', 0, 'https://technovicinity.com/development/wordpress/milon/travel/?p=607', 10, 'nav_menu_item', '', 0),
(608, 1, '2019-05-25 18:10:28', '2019-05-25 18:10:28', '', 'Guide', '', 'publish', 'closed', 'closed', '', 'guide', '', '', '2019-05-30 20:13:49', '2019-05-30 20:13:49', '', 0, 'https://technovicinity.com/development/wordpress/milon/travel/?p=608', 11, 'nav_menu_item', '', 0),
(610, 1, '2019-05-25 18:10:28', '2019-05-25 18:10:28', '', 'Ziyarat', '', 'publish', 'closed', 'closed', '', 'ziyarat', '', '', '2019-05-30 20:13:49', '2019-05-30 20:13:49', '', 0, 'https://technovicinity.com/development/wordpress/milon/travel/?p=610', 12, 'nav_menu_item', '', 0),
(611, 1, '2019-05-25 19:16:33', '2019-05-25 19:16:33', '<!-- wp:paragraph -->\n<p>\n\nManage your hotel booking services. Perfect for hotels, villas, guest houses, hostels, and apartments of all sizes.\n\n</p>\n<!-- /wp:paragraph -->', 'Manage your hotel booking services', '', 'publish', 'open', 'open', '', 'manage-your-hotel-booking-services', '', '', '2019-05-25 19:16:33', '2019-05-25 19:16:33', '', 0, 'https://technovicinity.com/development/wordpress/milon/travel/?p=611', 0, 'post', '', 0),
(612, 1, '2019-05-25 19:16:33', '2019-05-25 19:16:33', '<!-- wp:paragraph -->\n<p>\n\nManage your hotel booking services. Perfect for hotels, villas, guest houses, hostels, and apartments of all sizes.\n\n</p>\n<!-- /wp:paragraph -->', 'Manage your hotel booking services', '', 'inherit', 'closed', 'closed', '', '611-revision-v1', '', '', '2019-05-25 19:16:33', '2019-05-25 19:16:33', '', 611, 'https://technovicinity.com/development/wordpress/milon/travel/611-revision-v1/', 0, 'revision', '', 0);
INSERT INTO `wp_posts` (`ID`, `post_author`, `post_date`, `post_date_gmt`, `post_content`, `post_title`, `post_excerpt`, `post_status`, `comment_status`, `ping_status`, `post_password`, `post_name`, `to_ping`, `pinged`, `post_modified`, `post_modified_gmt`, `post_content_filtered`, `post_parent`, `guid`, `menu_order`, `post_type`, `post_mime_type`, `comment_count`) VALUES
(613, 1, '2019-05-25 19:18:07', '2019-05-25 19:18:07', '<!-- wp:paragraph -->\n<p>\n\n[gdgallery_gallery id_gallery=\"1\"]\n\n</p>\n<!-- /wp:paragraph -->', 'Gallery', '', 'inherit', 'closed', 'closed', '', '580-revision-v1', '', '', '2019-05-25 19:18:07', '2019-05-25 19:18:07', '', 580, 'https://technovicinity.com/development/wordpress/milon/travel/580-revision-v1/', 0, 'revision', '', 0),
(614, 2, '2019-05-25 21:07:50', '2019-05-25 21:07:50', 'lorem ipsum. lorem ipsum. lorem ipsum. lorem ipsum. lorem ipsum. lorem ipsum. lorem ipsum. lorem ipsum. lorem ipsum. lorem ipsum. lorem ipsum. lorem ipsum. lorem ipsum.', 'test umrah package', '', 'publish', 'closed', 'closed', '', 'test-umrah-package', '', '', '2019-05-25 21:07:50', '2019-05-25 21:07:50', '', 0, 'https://technovicinity.com/development/wordpress/milon/travel/?post_type=umrah&#038;p=614', 0, 'umrah', '', 0),
(615, 0, '2019-05-26 10:14:28', '2019-05-26 10:14:28', '4 star', '', '', 'publish', 'closed', 'closed', '', 'local-ba0e6727ff3ac048b55dfaba52657cbd', '', '', '2019-05-26 10:14:28', '2019-05-26 10:14:28', '', 0, 'https://technovicinity.com/development/wordpress/milon/travel/site-review/local-ba0e6727ff3ac048b55dfaba52657cbd/', 0, 'site-review', '', 0),
(616, 0, '2019-05-26 10:14:42', '2019-05-26 10:14:42', '2 star', '', '', 'publish', 'closed', 'closed', '', 'local-721a0f8552b4fd7fa2a3884efcaae4a3', '', '', '2019-05-26 10:14:42', '2019-05-26 10:14:42', '', 0, 'https://technovicinity.com/development/wordpress/milon/travel/site-review/local-721a0f8552b4fd7fa2a3884efcaae4a3/', 0, 'site-review', '', 0),
(617, 0, '2019-05-27 04:06:12', '2019-05-27 04:06:12', '2 star', '', '', 'publish', 'closed', 'closed', '', 'local-27a7cc1c4e09c1ad311947b66dbc2e7c', '', '', '2019-05-27 04:06:12', '2019-05-27 04:06:12', '', 0, 'https://technovicinity.com/development/wordpress/milon/travel/site-review/local-27a7cc1c4e09c1ad311947b66dbc2e7c/', 0, 'site-review', '', 0),
(623, 1, '2019-05-30 20:11:51', '2019-05-30 20:11:51', '', 'Hajj', '', 'publish', 'closed', 'closed', '', 'hajj', '', '', '2019-05-30 20:11:51', '2019-05-30 20:11:51', '', 0, 'https://technovicinity.com/development/wordpress/milon/travel/?page_id=623', 0, 'page', '', 0),
(624, 1, '2019-05-30 20:11:51', '2019-05-30 20:11:51', '', 'Hajj', '', 'inherit', 'closed', 'closed', '', '623-revision-v1', '', '', '2019-05-30 20:11:51', '2019-05-30 20:11:51', '', 623, 'https://technovicinity.com/development/wordpress/milon/travel/623-revision-v1/', 0, 'revision', '', 0),
(625, 1, '2019-05-30 20:12:44', '2019-05-30 20:12:44', '', 'Restaurant', '', 'publish', 'closed', 'closed', '', 'restaurant', '', '', '2019-05-30 20:12:44', '2019-05-30 20:12:44', '', 0, 'https://technovicinity.com/development/wordpress/milon/travel/?page_id=625', 0, 'page', '', 0),
(626, 1, '2019-05-30 20:12:44', '2019-05-30 20:12:44', '', 'Restaurant', '', 'inherit', 'closed', 'closed', '', '625-revision-v1', '', '', '2019-05-30 20:12:44', '2019-05-30 20:12:44', '', 625, 'https://technovicinity.com/development/wordpress/milon/travel/625-revision-v1/', 0, 'revision', '', 0),
(628, 1, '2019-05-30 20:13:49', '2019-05-30 20:13:49', ' ', '', '', 'publish', 'closed', 'closed', '', '628', '', '', '2019-05-30 20:13:49', '2019-05-30 20:13:49', '', 0, 'https://technovicinity.com/development/wordpress/milon/travel/?p=628', 8, 'nav_menu_item', '', 0),
(629, 1, '2019-05-30 20:13:49', '2019-05-30 20:13:49', ' ', '', '', 'publish', 'closed', 'closed', '', '629', '', '', '2019-05-30 20:13:49', '2019-05-30 20:13:49', '', 0, 'https://technovicinity.com/development/wordpress/milon/travel/?p=629', 9, 'nav_menu_item', '', 0),
(630, 1, '2019-05-30 20:15:38', '2019-05-30 20:15:38', '21-23 Days Tentative Hajj Package with Fairmont Clock Tower hotel accommodation (Half Board) in Makkah. Hotel Dar Al Hijra Intercon will be the hotel in Madinah. In Azizia Markaz 2 building with sharing four to six people and 3-time dish meal will be provided as well. Air Ticket is not included in the package.', 'Star Kabab & Restaurant', '', 'publish', 'closed', 'closed', '', 'star-kabab-restaurant', '', '', '2019-05-30 20:15:38', '2019-05-30 20:15:38', '', 0, 'https://technovicinity.com/development/wordpress/milon/travel/?post_type=restaurant&#038;p=630', 0, 'restaurant', '', 0),
(631, 1, '2019-05-30 20:15:33', '2019-05-30 20:15:33', '', 'star-kabab-restaurant', '', 'inherit', 'open', 'closed', '', 'star-kabab-restaurant', '', '', '2019-05-30 20:15:33', '2019-05-30 20:15:33', '', 630, 'https://technovicinity.com/development/wordpress/milon/travel/wp-content/uploads/2019/05/star-kabab-restaurant.jpg', 0, 'attachment', 'image/jpeg', 0),
(632, 1, '2019-05-30 20:17:29', '2019-05-30 20:17:29', '21-23 Days Tentative Hajj Package with Fairmont Clock Tower hotel accommodation (Half Board) in Makkah. Hotel Dar Al Hijra Intercon will be the hotel in Madinah. In Azizia Markaz 2 building with sharing four to six people and 3-time dish meal will be provided as well. Air Ticket is not included in the package.', '21-23 Days Hajj Package', '', 'publish', 'open', 'closed', '', '21-23-days-hajj-package', '', '', '2019-05-30 20:17:29', '2019-05-30 20:17:29', '', 0, 'https://technovicinity.com/development/wordpress/milon/travel/?post_type=hajj&#038;p=632', 0, 'hajj', '', 0),
(633, 1, '2019-05-30 20:17:19', '2019-05-30 20:17:19', '', '1494489629-hajjpackages-image', '', 'inherit', 'open', 'closed', '', '1494489629-hajjpackages-image', '', '', '2019-05-30 20:17:19', '2019-05-30 20:17:19', '', 632, 'https://technovicinity.com/development/wordpress/milon/travel/wp-content/uploads/2019/05/1494489629-hajjpackages-image.jpg', 0, 'attachment', 'image/jpeg', 0),
(650, 1, '2019-06-02 20:06:56', '2019-06-02 20:06:56', '', 'test', '', 'publish', 'open', 'open', '', 'test', '', '', '2019-06-02 20:07:39', '2019-06-02 20:07:39', '', 0, 'http://localhost/lipan/wordpress/milonvi/?p=650', 0, 'post', '', 0),
(651, 1, '2019-06-02 20:06:56', '2019-06-02 20:06:56', '', 'test', '', 'inherit', 'closed', 'closed', '', '650-revision-v1', '', '', '2019-06-02 20:06:56', '2019-06-02 20:06:56', '', 650, 'http://localhost/lipan/wordpress/milonvi/650-revision-v1/', 0, 'revision', '', 0),
(663, 1, '2019-06-14 16:02:56', '2019-06-14 16:02:56', '', 'aaaaa', '', 'publish', 'open', 'open', '', 'aaaaa', '', '', '2019-06-14 16:02:56', '2019-06-14 16:02:56', '', 0, 'http://localhost/lipan/wordpress/milonvi/?p=663', 0, 'post', '', 0),
(668, 1, '2019-06-14 16:02:56', '2019-06-14 16:02:56', '', 'aaaaa', '', 'inherit', 'closed', 'closed', '', '663-revision-v1', '', '', '2019-06-14 16:02:56', '2019-06-14 16:02:56', '', 663, 'https://localhost/lipan/wordpress/milonvi/663-revision-v1/', 0, 'revision', '', 0),
(670, 1, '2019-06-14 16:12:52', '2019-06-14 16:12:52', '', 'test', '', 'inherit', 'closed', 'closed', '', '650-autosave-v1', '', '', '2019-06-14 16:12:52', '2019-06-14 16:12:52', '', 650, 'https://localhost/lipan/wordpress/milonvi/650-autosave-v1/', 0, 'revision', '', 0),
(684, 1, '2019-06-16 15:32:12', '2019-06-16 15:32:12', '', 'Gallery', '', 'publish', 'closed', 'closed', '', 'gallery', '', '', '2019-06-16 15:32:12', '2019-06-16 15:32:12', '', 0, 'http://localhost/lipan/wordpress/milonvi/wp-types-term-group/gallery/', 0, 'wp-types-term-group', '', 0),
(685, 1, '2019-06-16 15:38:46', '2019-06-16 15:38:46', '', 'Main Hotel Fields', '', 'publish', 'closed', 'closed', '', 'main-hotel-fields', '', '', '2019-06-16 15:55:04', '2019-06-16 15:55:04', '', 0, 'http://localhost/lipan/wordpress/milonvi/wp-types-term-group/main-hotel-fields/', 0, 'wp-types-term-group', '', 0),
(688, 1, '2019-06-16 16:02:23', '2019-06-16 16:02:23', 'Executive Room With Lake ViewExecutive Room With Lake ViewExecutive Room With Lake ViewExecutive Room With Lake ViewExecutive Room With Lake ViewExecutive Room With Lake ViewExecutive Room With Lake ViewExecutive Room With Lake View', 'Executive Room With Lake View', '', 'publish', 'open', 'open', '', 'executive-room-with-lake-view', '', '', '2019-06-16 16:17:41', '2019-06-16 16:17:41', '', 0, 'http://localhost/lipan/wordpress/milonvi/?post_type=available-rooms&#038;p=688', 0, 'available-rooms', '', 0),
(689, 1, '2019-06-16 16:02:17', '2019-06-16 16:02:17', '', '242-150x150', '', 'inherit', 'open', 'closed', '', '242-150x150', '', '', '2019-06-16 16:02:17', '2019-06-16 16:02:17', '', 688, 'http://localhost/lipan/wordpress/milonvi/wp-content/uploads/2019/06/242-150x150.jpg', 0, 'attachment', 'image/jpeg', 0),
(690, 1, '2019-06-16 16:02:23', '2019-06-16 16:02:23', 'Executive Room With Lake ViewExecutive Room With Lake ViewExecutive Room With Lake ViewExecutive Room With Lake ViewExecutive Room With Lake ViewExecutive Room With Lake ViewExecutive Room With Lake ViewExecutive Room With Lake View', 'Executive Room With Lake View', '', 'inherit', 'closed', 'closed', '', '688-revision-v1', '', '', '2019-06-16 16:02:23', '2019-06-16 16:02:23', '', 688, 'http://localhost/lipan/wordpress/milonvi/688-revision-v1/', 0, 'revision', '', 0),
(699, 1, '2019-06-24 17:15:40', '2019-06-24 17:15:40', '', 'Main Hotel Search', '', 'publish', 'closed', 'closed', '', 'main-hotel-search', '', '', '2019-07-04 15:23:12', '2019-07-04 15:23:12', '', 0, 'http://localhost/lipan/wordpress/milonvi/?page_id=699', 0, 'page', '', 0),
(700, 1, '2019-06-24 17:15:40', '2019-06-24 17:15:40', '', 'Hotel details', '', 'inherit', 'closed', 'closed', '', '699-revision-v1', '', '', '2019-06-24 17:15:40', '2019-06-24 17:15:40', '', 699, 'http://localhost/lipan/wordpress/milonvi/699-revision-v1/', 0, 'revision', '', 0),
(702, 1, '2019-06-28 15:07:46', '2019-06-28 15:07:46', '', 'Hotel Details', '', 'publish', 'closed', 'closed', '', 'hotel-details', '', '', '2019-07-04 16:15:07', '2019-07-04 16:15:07', '', 0, 'http://localhost/lipan/wordpress/milonvi/?page_id=702', 0, 'page', '', 0),
(703, 1, '2019-06-28 15:07:46', '2019-06-28 15:07:46', '', 'Hotel Search', '', 'inherit', 'closed', 'closed', '', '702-revision-v1', '', '', '2019-06-28 15:07:46', '2019-06-28 15:07:46', '', 702, 'http://localhost/lipan/wordpress/milonvi/702-revision-v1/', 0, 'revision', '', 0),
(709, 1, '2019-06-28 15:21:35', '2019-06-28 15:21:35', '', 'Main Hotel Search', '', 'inherit', 'closed', 'closed', '', '699-revision-v1', '', '', '2019-06-28 15:21:35', '2019-06-28 15:21:35', '', 699, 'http://localhost/lipan/wordpress/milonvi/699-revision-v1/', 0, 'revision', '', 0),
(710, 1, '2019-06-28 15:21:59', '2019-06-28 15:21:59', '', 'List Of Hotels', '', 'inherit', 'closed', 'closed', '', '19-revision-v1', '', '', '2019-06-28 15:21:59', '2019-06-28 15:21:59', '', 19, 'http://localhost/lipan/wordpress/milonvi/19-revision-v1/', 0, 'revision', '', 0),
(712, 1, '2019-06-28 15:23:53', '2019-06-28 15:23:53', '', 'Available Room Search Templates', '', 'inherit', 'closed', 'closed', '', '702-revision-v1', '', '', '2019-06-28 15:23:53', '2019-06-28 15:23:53', '', 702, 'http://localhost/lipan/wordpress/milonvi/702-revision-v1/', 0, 'revision', '', 0),
(713, 1, '2019-06-30 17:56:56', '2019-06-30 17:56:56', '', 'Hotel Booking', '', 'publish', 'closed', 'closed', '', 'hotel-booking', '', '', '2019-07-04 15:10:04', '2019-07-04 15:10:04', '', 0, 'http://localhost/lipan/wordpress/milonvi/?page_id=713', 0, 'page', '', 0),
(714, 1, '2019-06-30 17:56:56', '2019-06-30 17:56:56', '', 'Hotel Booking', '', 'inherit', 'closed', 'closed', '', '713-revision-v1', '', '', '2019-06-30 17:56:56', '2019-06-30 17:56:56', '', 713, 'http://localhost/lipan/wordpress/milonvi/713-revision-v1/', 0, 'revision', '', 0),
(716, 1, '2019-07-04 14:30:21', '2019-07-04 14:30:21', '', 'Room details', '', 'publish', 'closed', 'closed', '', 'room-details', '', '', '2019-07-04 15:15:43', '2019-07-04 15:15:43', '', 0, 'http://localhost/lipan/wordpress/milonvi/?page_id=716', 0, 'page', '', 0),
(717, 1, '2019-07-04 14:30:21', '2019-07-04 14:30:21', '', 'Room details', '', 'inherit', 'closed', 'closed', '', '716-revision-v1', '', '', '2019-07-04 14:30:21', '2019-07-04 14:30:21', '', 716, 'http://localhost/lipan/wordpress/milonvi/716-revision-v1/', 0, 'revision', '', 0),
(721, 1, '2019-07-04 15:00:17', '2019-07-04 15:00:17', '', 'Hotel Details', '', 'inherit', 'closed', 'closed', '', '702-revision-v1', '', '', '2019-07-04 15:00:17', '2019-07-04 15:00:17', '', 702, 'http://localhost/lipan/wordpress/milonvi/702-revision-v1/', 0, 'revision', '', 0),
(725, 1, '2019-07-08 17:45:11', '2019-07-08 17:45:11', '', 'Car Details', '', 'publish', 'closed', 'closed', '', 'car-details', '', '', '2019-07-08 17:45:13', '2019-07-08 17:45:13', '', 0, 'http://localhost/lipan/wordpress/milonvi/?page_id=725', 0, 'page', '', 0),
(726, 1, '2019-07-08 17:45:11', '2019-07-08 17:45:11', '', 'Car Details', '', 'inherit', 'closed', 'closed', '', '725-revision-v1', '', '', '2019-07-08 17:45:11', '2019-07-08 17:45:11', '', 725, 'http://localhost/lipan/wordpress/milonvi/725-revision-v1/', 0, 'revision', '', 0),
(727, 1, '2019-07-08 17:48:22', '2019-07-08 17:48:22', '', 'Car Result', '', 'publish', 'closed', 'closed', '', 'car-result', '', '', '2019-07-08 18:32:58', '2019-07-08 18:32:58', '', 0, 'http://localhost/lipan/wordpress/milonvi/?page_id=727', 0, 'page', '', 0),
(728, 1, '2019-07-08 17:48:22', '2019-07-08 17:48:22', '', 'Car Search', '', 'inherit', 'closed', 'closed', '', '727-revision-v1', '', '', '2019-07-08 17:48:22', '2019-07-08 17:48:22', '', 727, 'http://localhost/lipan/wordpress/milonvi/727-revision-v1/', 0, 'revision', '', 0),
(729, 1, '2019-07-08 17:52:44', '2019-07-08 17:52:44', '', 'Car Booking', '', 'publish', 'closed', 'closed', '', 'car-booking', '', '', '2019-07-08 17:53:11', '2019-07-08 17:53:11', '', 0, 'http://localhost/lipan/wordpress/milonvi/?page_id=729', 0, 'page', '', 0),
(730, 1, '2019-07-08 17:52:44', '2019-07-08 17:52:44', '', 'Car Booking', '', 'inherit', 'closed', 'closed', '', '729-revision-v1', '', '', '2019-07-08 17:52:44', '2019-07-08 17:52:44', '', 729, 'http://localhost/lipan/wordpress/milonvi/729-revision-v1/', 0, 'revision', '', 0),
(731, 1, '2019-07-08 18:32:58', '2019-07-08 18:32:58', '', 'Car Result', '', 'inherit', 'closed', 'closed', '', '727-revision-v1', '', '', '2019-07-08 18:32:58', '2019-07-08 18:32:58', '', 727, 'http://localhost/lipan/wordpress/milonvi/727-revision-v1/', 0, 'revision', '', 0),
(732, 1, '2019-07-09 15:21:37', '2019-07-09 15:21:37', '', 'Paypal', '', 'publish', 'closed', 'closed', '', 'paypal', '', '', '2019-07-09 15:22:21', '2019-07-09 15:22:21', '', 0, 'http://localhost/lipan/wordpress/milonvi/?page_id=732', 0, 'page', '', 0),
(733, 1, '2019-07-09 15:21:37', '2019-07-09 15:21:37', '', 'Paypal', '', 'inherit', 'closed', 'closed', '', '732-revision-v1', '', '', '2019-07-09 15:21:37', '2019-07-09 15:21:37', '', 732, 'http://localhost/lipan/wordpress/milonvi/732-revision-v1/', 0, 'revision', '', 0),
(735, 1, '2019-07-12 17:40:04', '2019-07-12 17:40:04', '', 'Tour Result', '', 'publish', 'closed', 'closed', '', 'tour-result', '', '', '2019-07-12 17:49:33', '2019-07-12 17:49:33', '', 0, 'http://localhost/lipan/wordpress/milonvi/?page_id=735', 0, 'page', '', 0),
(736, 1, '2019-07-12 17:40:04', '2019-07-12 17:40:04', '', 'Tour Result', '', 'inherit', 'closed', 'closed', '', '735-revision-v1', '', '', '2019-07-12 17:40:04', '2019-07-12 17:40:04', '', 735, 'http://localhost/lipan/wordpress/milonvi/735-revision-v1/', 0, 'revision', '', 0),
(737, 1, '2019-07-12 18:24:52', '2019-07-12 18:24:52', '', 'Tour Details', '', 'publish', 'closed', 'closed', '', 'tour-details', '', '', '2019-07-12 18:25:23', '2019-07-12 18:25:23', '', 0, 'http://localhost/lipan/wordpress/milonvi/?page_id=737', 0, 'page', '', 0),
(738, 1, '2019-07-12 18:24:52', '2019-07-12 18:24:52', '', 'Tour Details', '', 'inherit', 'closed', 'closed', '', '737-revision-v1', '', '', '2019-07-12 18:24:52', '2019-07-12 18:24:52', '', 737, 'http://localhost/lipan/wordpress/milonvi/737-revision-v1/', 0, 'revision', '', 0),
(742, 1, '2019-07-16 15:47:44', '2019-07-16 15:47:44', '', 'Tour Booking', '', 'publish', 'closed', 'closed', '', 'tour-booking', '', '', '2019-07-16 15:50:03', '2019-07-16 15:50:03', '', 0, 'http://localhost/lipan/wordpress/milonvi/?page_id=742', 0, 'page', '', 0),
(743, 1, '2019-07-16 15:47:44', '2019-07-16 15:47:44', '', 'Tour Booking', '', 'inherit', 'closed', 'closed', '', '742-revision-v1', '', '', '2019-07-16 15:47:44', '2019-07-16 15:47:44', '', 742, 'http://localhost/lipan/wordpress/milonvi/742-revision-v1/', 0, 'revision', '', 0),
(744, 1, '2019-07-22 16:28:54', '2019-07-22 16:28:54', '', 'Activity details', '', 'publish', 'closed', 'closed', '', 'activity-details', '', '', '2019-07-22 16:29:37', '2019-07-22 16:29:37', '', 0, 'http://localhost/lipan/wordpress/milonvi/?page_id=744', 0, 'page', '', 0),
(745, 1, '2019-07-22 16:28:54', '2019-07-22 16:28:54', '', 'Activity details', '', 'inherit', 'closed', 'closed', '', '744-revision-v1', '', '', '2019-07-22 16:28:54', '2019-07-22 16:28:54', '', 744, 'http://localhost/lipan/wordpress/milonvi/744-revision-v1/', 0, 'revision', '', 0),
(747, 1, '2019-07-22 16:30:43', '2019-07-22 16:30:43', '', 'Activity result', '', 'publish', 'closed', 'closed', '', 'activity-result', '', '', '2019-07-22 16:30:43', '2019-07-22 16:30:43', '', 0, 'http://localhost/lipan/wordpress/milonvi/?page_id=747', 0, 'page', '', 0),
(748, 1, '2019-07-22 16:30:43', '2019-07-22 16:30:43', '', 'Activity result', '', 'inherit', 'closed', 'closed', '', '747-revision-v1', '', '', '2019-07-22 16:30:43', '2019-07-22 16:30:43', '', 747, 'http://localhost/lipan/wordpress/milonvi/747-revision-v1/', 0, 'revision', '', 0),
(750, 1, '2019-07-22 18:03:40', '2019-07-22 18:03:40', '', 'Activity booking', '', 'publish', 'closed', 'closed', '', 'activity-booking', '', '', '2019-07-22 18:03:40', '2019-07-22 18:03:40', '', 0, 'http://localhost/lipan/wordpress/milonvi/?page_id=750', 0, 'page', '', 0),
(751, 1, '2019-07-22 18:03:40', '2019-07-22 18:03:40', '', 'Activity booking', '', 'inherit', 'closed', 'closed', '', '750-revision-v1', '', '', '2019-07-22 18:03:40', '2019-07-22 18:03:40', '', 750, 'http://localhost/lipan/wordpress/milonvi/750-revision-v1/', 0, 'revision', '', 0),
(752, 1, '2019-07-25 17:25:57', '2019-07-25 17:25:57', '', 'Guide Details', '', 'publish', 'closed', 'closed', '', 'guide-details', '', '', '2019-07-25 17:27:46', '2019-07-25 17:27:46', '', 0, 'http://localhost/lipan/wordpress/milonvi/?page_id=752', 0, 'page', '', 0),
(753, 1, '2019-07-25 17:25:57', '2019-07-25 17:25:57', '', 'Guide Details', '', 'inherit', 'closed', 'closed', '', '752-revision-v1', '', '', '2019-07-25 17:25:57', '2019-07-25 17:25:57', '', 752, 'http://localhost/lipan/wordpress/milonvi/752-revision-v1/', 0, 'revision', '', 0),
(754, 1, '2019-07-25 17:29:02', '2019-07-25 17:29:02', '', 'Guide result', '', 'publish', 'closed', 'closed', '', 'guide-result', '', '', '2019-07-25 17:29:02', '2019-07-25 17:29:02', '', 0, 'http://localhost/lipan/wordpress/milonvi/?page_id=754', 0, 'page', '', 0),
(755, 1, '2019-07-25 17:29:02', '2019-07-25 17:29:02', '', 'Guide result', '', 'inherit', 'closed', 'closed', '', '754-revision-v1', '', '', '2019-07-25 17:29:02', '2019-07-25 17:29:02', '', 754, 'http://localhost/lipan/wordpress/milonvi/754-revision-v1/', 0, 'revision', '', 0),
(1045, 1, '2019-07-25 19:19:59', '2019-07-25 19:19:59', '', 'Guide Booking', '', 'publish', 'closed', 'closed', '', 'guide-booking', '', '', '2019-07-25 19:19:59', '2019-07-25 19:19:59', '', 0, 'http://localhost/lipan/wordpress/milonvi/?page_id=1045', 0, 'page', '', 0),
(1046, 1, '2019-07-25 19:19:59', '2019-07-25 19:19:59', '', 'Guide Booking', '', 'inherit', 'closed', 'closed', '', '1045-revision-v1', '', '', '2019-07-25 19:19:59', '2019-07-25 19:19:59', '', 1045, 'http://localhost/lipan/wordpress/milonvi/1045-revision-v1/', 0, 'revision', '', 0),
(1047, 1, '2019-07-28 19:39:48', '2019-07-28 19:39:48', '', 'Transport Details', '', 'publish', 'closed', 'closed', '', 'transport-details', '', '', '2019-07-28 19:39:48', '2019-07-28 19:39:48', '', 0, 'http://localhost/lipan/wordpress/milonvi/?page_id=1047', 0, 'page', '', 0),
(1048, 1, '2019-07-28 19:39:48', '2019-07-28 19:39:48', '', 'Transport Details', '', 'inherit', 'closed', 'closed', '', '1047-revision-v1', '', '', '2019-07-28 19:39:48', '2019-07-28 19:39:48', '', 1047, 'http://localhost/lipan/wordpress/milonvi/1047-revision-v1/', 0, 'revision', '', 0),
(1049, 1, '2019-07-28 19:44:53', '2019-07-28 19:44:53', '', 'Transport results', '', 'publish', 'closed', 'closed', '', 'transport-results', '', '', '2019-07-28 19:45:07', '2019-07-28 19:45:07', '', 0, 'http://localhost/lipan/wordpress/milonvi/?page_id=1049', 0, 'page', '', 0),
(1050, 1, '2019-07-28 19:44:53', '2019-07-28 19:44:53', '', 'Transport results', '', 'inherit', 'closed', 'closed', '', '1049-revision-v1', '', '', '2019-07-28 19:44:53', '2019-07-28 19:44:53', '', 1049, 'http://localhost/lipan/wordpress/milonvi/1049-revision-v1/', 0, 'revision', '', 0),
(1052, 1, '2019-07-29 14:33:12', '2019-07-29 14:33:12', '', 'transport booking', '', 'publish', 'closed', 'closed', '', 'transport-booking', '', '', '2019-07-29 14:33:12', '2019-07-29 14:33:12', '', 0, 'http://localhost/lipan/wordpress/milonvi/?page_id=1052', 0, 'page', '', 0),
(1053, 1, '2019-07-29 14:33:12', '2019-07-29 14:33:12', '', 'transport booking', '', 'inherit', 'closed', 'closed', '', '1052-revision-v1', '', '', '2019-07-29 14:33:12', '2019-07-29 14:33:12', '', 1052, 'http://localhost/lipan/wordpress/milonvi/1052-revision-v1/', 0, 'revision', '', 0),
(1054, 1, '2019-07-29 18:12:04', '2019-07-29 18:12:04', '', 'Restaurant Details', '', 'publish', 'closed', 'closed', '', 'restaurant-details', '', '', '2019-07-29 18:13:06', '2019-07-29 18:13:06', '', 0, 'http://localhost/lipan/wordpress/milonvi/?page_id=1054', 0, 'page', '', 0),
(1055, 1, '2019-07-29 18:12:04', '2019-07-29 18:12:04', '', 'Restaurant Details', '', 'inherit', 'closed', 'closed', '', '1054-revision-v1', '', '', '2019-07-29 18:12:04', '2019-07-29 18:12:04', '', 1054, 'http://localhost/lipan/wordpress/milonvi/1054-revision-v1/', 0, 'revision', '', 0),
(1056, 1, '2019-07-29 18:13:33', '2019-07-29 18:13:33', '', 'restaurant results', '', 'publish', 'closed', 'closed', '', 'restaurant-results', '', '', '2019-07-29 18:13:33', '2019-07-29 18:13:33', '', 0, 'http://localhost/lipan/wordpress/milonvi/?page_id=1056', 0, 'page', '', 0),
(1057, 1, '2019-07-29 18:13:33', '2019-07-29 18:13:33', '', 'restaurant results', '', 'inherit', 'closed', 'closed', '', '1056-revision-v1', '', '', '2019-07-29 18:13:33', '2019-07-29 18:13:33', '', 1056, 'http://localhost/lipan/wordpress/milonvi/1056-revision-v1/', 0, 'revision', '', 0),
(1059, 1, '2019-09-27 18:02:13', '0000-00-00 00:00:00', '', 'Auto Draft', '', 'auto-draft', 'open', 'open', '', '', '', '', '2019-09-27 18:02:13', '0000-00-00 00:00:00', '', 0, 'http://localhost/lipan/wordpress/milonvi/?p=1059', 0, 'post', '', 0);

-- --------------------------------------------------------

--
-- Table structure for table `wp_termmeta`
--

CREATE TABLE `wp_termmeta` (
  `meta_id` bigint(20) UNSIGNED NOT NULL,
  `term_id` bigint(20) UNSIGNED NOT NULL DEFAULT '0',
  `meta_key` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `meta_value` longtext COLLATE utf8mb4_unicode_ci
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `wp_termmeta`
--

INSERT INTO `wp_termmeta` (`meta_id`, `term_id`, `meta_key`, `meta_value`) VALUES
(7, 73, 'product_count_product_cat', '7'),
(8, 85, 'order', '0'),
(9, 85, 'display_type', ''),
(10, 85, 'thumbnail_id', '0'),
(11, 86, 'order', '0'),
(12, 86, 'display_type', ''),
(13, 86, 'thumbnail_id', '0'),
(14, 87, 'order', '0'),
(15, 87, 'display_type', ''),
(16, 87, 'thumbnail_id', '0'),
(17, 88, 'order', '0'),
(18, 88, 'display_type', ''),
(19, 88, 'thumbnail_id', '0'),
(20, 100, 'product_count_no_of_days', '2'),
(21, 99, 'product_count_package_class', '3'),
(22, 89, 'product_count_package_city', '2'),
(23, 94, 'product_count_price_range', '0'),
(24, 101, 'product_count_no_of_days', '1'),
(25, 98, 'product_count_package_class', '0'),
(26, 91, 'product_count_package_city', '1'),
(27, 104, 'product_count_product_tag', '0'),
(28, 95, 'product_count_price_range', '1'),
(29, 87, 'product_count_product_cat', '5'),
(30, 116, 'product_count_hotel_name', '1'),
(31, 115, 'product_count_hotel_name', '1'),
(32, 96, 'product_count_price_range', '2'),
(33, 119, 'wp_travel_trip_type_image_id', '351'),
(34, 120, 'wp_travel_trip_type_image_id', '348'),
(35, 121, 'wp_travel_trip_type_image_id', '338'),
(36, 122, 'wp_travel_trip_type_image_id', '328'),
(37, 151, 'hb_max_number_of_adults', '2'),
(38, 150, 'hb_max_number_of_adults', '1'),
(39, 160, 'service_type', 'accommodation'),
(40, 212, 'checkintest', 'aaaa'),
(41, 212, '_checkintest', 'field_5cf2c0a34fdc6'),
(42, 212, 'checkouttest', '631'),
(43, 212, '_checkouttest', 'field_5cf2c0edc08bc'),
(44, 213, 'hotels_image', '631'),
(45, 213, '_hotels_image', 'field_5cf40b564a434'),
(46, 213, 'hotels_check_in', '20190606'),
(47, 213, '_hotels_check_in', 'field_5cf4184eb20be'),
(48, 213, 'hotels_check_out', '6:00 AM - 12:00 AM'),
(49, 213, '_hotels_check_out', 'field_5cf41874b20bf'),
(50, 213, 'cancelled_prepayment', 'Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry\'s standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book. It has survived not only five centuries, but also the leap into electronic typesetting, remaining essentially unchanged. It was popularised in the 1960s with the release of Letraset sheets containing Lorem Ipsum passages, and more recently with desktop publishing software like Aldus PageMaker including versions of Lorem Ipsum.'),
(51, 213, '_cancelled_prepayment', 'field_5cf418c3b20c0'),
(52, 213, 'children_and_extrabed', 'All children are wellcome\r\nFree ! Lorem Ipsum is simply dummy text of the printing and typesetting industry\r\n\r\n\r\nFree ! Lorem Ipsum is simply dummy text of the printing and typesetting industry\r\n\r\n\r\nFree ! Lorem Ipsum is simply dummy text of the printing and typesetting industry'),
(53, 213, '_children_and_extrabed', 'field_5cf418f5b20c1'),
(54, 213, 'pets', 'Lorem Ipsum is simply dummy text of the printing and typesetting industry'),
(55, 213, '_pets', 'field_5cf41909b20c2'),
(56, 213, 'card_eccepted_at_this_property', '347'),
(57, 213, '_card_eccepted_at_this_property', 'field_5cf4191ab20c3'),
(58, 214, 'hotels_image', ''),
(59, 214, '_hotels_image', 'field_5cf40b564a434'),
(60, 214, 'hotels_check_in', ''),
(61, 214, '_hotels_check_in', 'field_5cf4184eb20be'),
(62, 214, 'hotels_check_out', ''),
(63, 214, '_hotels_check_out', 'field_5cf41874b20bf'),
(64, 214, 'cancelled_prepayment', ''),
(65, 214, '_cancelled_prepayment', 'field_5cf418c3b20c0'),
(66, 214, 'children_and_extrabed', ''),
(67, 214, '_children_and_extrabed', 'field_5cf418f5b20c1'),
(68, 214, 'pets', ''),
(69, 214, '_pets', 'field_5cf41909b20c2'),
(70, 214, 'card_eccepted_at_this_property', ''),
(71, 214, '_card_eccepted_at_this_property', 'field_5cf4191ab20c3'),
(72, 215, 'hotels_image', ''),
(73, 215, '_hotels_image', 'field_5cf40b564a434'),
(74, 215, 'hotels_check_in', ''),
(75, 215, '_hotels_check_in', 'field_5cf4184eb20be'),
(76, 215, 'hotels_check_out', ''),
(77, 215, '_hotels_check_out', 'field_5cf41874b20bf'),
(78, 215, 'cancelled_prepayment', ''),
(79, 215, '_cancelled_prepayment', 'field_5cf418c3b20c0'),
(80, 215, 'children_and_extrabed', ''),
(81, 215, '_children_and_extrabed', 'field_5cf418f5b20c1'),
(82, 215, 'pets', ''),
(83, 215, '_pets', 'field_5cf41909b20c2'),
(84, 215, 'card_eccepted_at_this_property', ''),
(85, 215, '_card_eccepted_at_this_property', 'field_5cf4191ab20c3'),
(86, 216, 'hotels_image', ''),
(87, 216, '_hotels_image', 'field_5cf40b564a434'),
(88, 216, 'hotels_check_in', ''),
(89, 216, '_hotels_check_in', 'field_5cf4184eb20be'),
(90, 216, 'hotels_check_out', ''),
(91, 216, '_hotels_check_out', 'field_5cf41874b20bf'),
(92, 216, 'cancelled_prepayment', ''),
(93, 216, '_cancelled_prepayment', 'field_5cf418c3b20c0'),
(94, 216, 'children_and_extrabed', ''),
(95, 216, '_children_and_extrabed', 'field_5cf418f5b20c1'),
(96, 216, 'pets', ''),
(97, 216, '_pets', 'field_5cf41909b20c2'),
(98, 216, 'card_eccepted_at_this_property', ''),
(99, 216, '_card_eccepted_at_this_property', 'field_5cf4191ab20c3'),
(100, 216, 'hotel_price', ''),
(101, 216, '_hotel_price', 'field_5d03caa6a5bf3'),
(102, 216, 'hotel_ratings', ''),
(103, 216, '_hotel_ratings', 'field_5d03e21e2b599'),
(104, 216, 'hotel_locations', ''),
(105, 216, '_hotel_locations', 'field_5d03e2522b59a'),
(123, 216, 'wpcf-main_hotel_image', 'http://localhost/lipan/wordpress/milonvi/wp-content/uploads/2019/05/star-kabab-restaurant.jpg'),
(124, 216, 'wpcf-check_in', '1559347200'),
(125, 216, 'wpcf-check_out', '1559433600'),
(126, 216, 'wpcf-hotel_location', 'DHaka'),
(127, 216, 'wpcf-hotel_email', 'm.rabiul09@gmail.com'),
(128, 216, 'wpcf-hotel_phone_no', '01717677966'),
(129, 216, 'wpcf-hotel_price', '450'),
(130, 216, 'wpcf-hotel_website', 'www.radison.com'),
(131, 216, 'wpcf-cancelled_prepayment', 'Assign a parent term to create a hierarchy. The term Jazz, for example, would be the parent of Bebop and Big Band.'),
(132, 216, 'wpcf-children_and_extrabed', 'Assign a parent term to create a hierarchy. The term Jazz, for example, would be the parent of Bebop and Big Band.'),
(133, 216, 'wpcf-hotel_pets', 'www'),
(134, 216, 'wpcf-hotel_gallery_1', 'http://localhost/lipan/wordpress/milonvi/wp-content/uploads/2019/03/800x600-1.jpg'),
(135, 216, 'wpcf-hotel_gallery_2', 'http://localhost/lipan/wordpress/milonvi/wp-content/uploads/2019/03/7478-143x71-1.jpg'),
(136, 216, 'wpcf-hotel_gallery_3', 'http://localhost/lipan/wordpress/milonvi/wp-content/uploads/2019/03/br1-1.jpg'),
(137, 216, 'wpcf-hotel_gallery_4', 'http://localhost/lipan/wordpress/milonvi/wp-content/uploads/2019/03/800x600-1.jpg'),
(138, 216, 'wpcf-hotel_gallery_5', 'http://localhost/lipan/wordpress/milonvi/wp-content/uploads/2019/02/thumb.jpg'),
(139, 216, 'wpcf-hotel_gallery_6', 'http://localhost/lipan/wordpress/milonvi/wp-content/uploads/2019/04/air-berlin-128x50.png');

-- --------------------------------------------------------

--
-- Table structure for table `wp_terms`
--

CREATE TABLE `wp_terms` (
  `term_id` bigint(20) UNSIGNED NOT NULL,
  `name` varchar(200) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `slug` varchar(200) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `term_group` bigint(10) NOT NULL DEFAULT '0'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `wp_terms`
--

INSERT INTO `wp_terms` (`term_id`, `name`, `slug`, `term_group`) VALUES
(1, 'Uncategorized', 'uncategorized', 0),
(2, 'main_menu', 'main_menu', 0),
(4, 'test', 'test', 0),
(5, 'fgff', 'fgfdg', 0),
(6, 'ghgfhgfh', 'hghg', 0),
(7, 'dsfdfsd', 'fdgfdg', 0),
(8, '5 Star', '5-star', 0),
(9, '4 Star', '4-star', 0),
(10, '3 Star', '3-star', 0),
(11, '2 Star', '2-star', 0),
(12, '1 Star', '1star', 0),
(13, 'Rating 1', 'rating-1', 0),
(14, 'Rating 2', 'rating-2', 0),
(15, 'Rating 3', 'rating-3', 0),
(16, 'Rating 4', 'rating-4', 0),
(17, 'Rating 5', 'rating-5', 0),
(18, 'Ziyarat', 'ziyarat', 0),
(19, 'Transport', 'transport', 0),
(20, 'Visa', 'visa', 0),
(21, 'Ticket', 'ticket', 0),
(22, 'Best Price', 'best-price', 0),
(23, 'Discount', 'discount', 0),
(24, 'BMU Selected', 'bmu-selected', 0),
(25, 'Premium Packages', 'premium-packages', 0),
(26, 'test', 'test', 0),
(27, 'fghfgh', 'fghfgh', 0),
(28, 'kjkdzvxc', 'vcxvxcv', 0),
(29, 'mmjjj', 'mmjjj', 0),
(30, 'Lahore', 'lahore', 0),
(31, 'Karachi', 'karachi', 0),
(32, 'Peshawar', 'peshawar', 0),
(33, 'Gujranwala', 'gujranwala', 0),
(34, 'Faisalabad', 'faisalabad', 0),
(35, 'Sonar Bangla', 'sonar-bangla', 0),
(36, 'Boishakhi', 'boishakhi', 0),
(37, 'Rupali', 'rupali', 0),
(38, '15000-20000', '15000-20000', 0),
(39, '25000-30000', '25000-30000', 0),
(40, '35000-40000', '35000-40000', 0),
(41, '0 to 7 days', '0-to-7-days', 0),
(42, '8 to 15 days', '8-to-15-days', 0),
(43, '16 to 21 days', '16-to-21-days', 0),
(44, '22 to 28 days', '22-to-28-days', 0),
(45, 'Sonarbangla', 'sonarbangla', 0),
(46, 'Bisakhi', 'bisakhi', 0),
(47, '10000-15000', '10000-15000', 0),
(48, '15000-20000', '15000-20000', 0),
(49, '20000-25000', '20000-25000', 0),
(50, 'test', 'test', 0),
(51, '0 to 7 days', '0-to-7-days', 0),
(52, '8 to 15 days', '8-to-15-days', 0),
(53, '16 to 21 days', '16-to-21-days', 0),
(54, '22 to 28 days', '22-to-28-days', 0),
(55, '5 Star', '5-star', 0),
(56, '4 Star', '4-star', 0),
(57, '3 Star', '3-star', 0),
(58, '2 Star', '2-star', 0),
(59, 'Economy', 'economy', 0),
(60, 'simple', 'simple', 0),
(61, 'grouped', 'grouped', 0),
(62, 'variable', 'variable', 0),
(63, 'external', 'external', 0),
(64, 'exclude-from-search', 'exclude-from-search', 0),
(65, 'exclude-from-catalog', 'exclude-from-catalog', 0),
(66, 'featured', 'featured', 0),
(67, 'outofstock', 'outofstock', 0),
(68, 'rated-1', 'rated-1', 0),
(69, 'rated-2', 'rated-2', 0),
(70, 'rated-3', 'rated-3', 0),
(71, 'rated-4', 'rated-4', 0),
(72, 'rated-5', 'rated-5', 0),
(73, 'Uncategorized', 'uncategorized', 0),
(81, '0 to 7 days', '0-to-7-days', 0),
(82, '8 to 15 days', '8-to-15-days', 0),
(83, '16 to 21 days', '16-to-21-days', 0),
(84, '22 to 28 days', '22-to-28-days', 0),
(85, '4 Star', '4-star', 0),
(86, '5 Star', '5-star', 0),
(87, '3 Star', '3-star', 0),
(88, 'Economy', 'economy', 0),
(89, 'Lahore', 'lahore', 0),
(90, 'Karachi', 'karachi', 0),
(91, 'Islamabad', 'islamabad', 0),
(92, 'Peshawar', 'peshawar', 0),
(93, 'Gujranwala', 'gujranwala', 0),
(94, '3016-5012', '3016-5012', 0),
(95, '6000-7050', '6000-7050', 0),
(96, '7500-10000', '7500-10000', 0),
(97, '5 Star', '5-star', 0),
(98, '4 Star', '4-star', 0),
(99, '3 Star', '3-star', 0),
(100, '0 to 7 days', '0-to-7-days', 0),
(101, '16 to 21 days', '16-to-21-days', 0),
(102, '22 to 28 days', '22-to-28-days', 0),
(103, '8 to 15 days', '8-to-15-days', 0),
(104, 'test', 'test', 0),
(105, 'Premium ,Standard', 'premium-standard', 0),
(106, 'InterContinental New', 'intercontinental-new', 0),
(107, '2 Pieces of Luggage', '2-pieces-of-luggage', 0),
(108, '3 Doors', '3-doors', 0),
(109, 'India', 'india', 0),
(110, 'Usa', 'usa', 0),
(111, 'Dhaka', 'dhaka', 0),
(112, 'Usa', 'usa', 0),
(113, 'India', 'india', 0),
(114, 'Uk', 'uk', 0),
(115, 'Hotel Ibis Yanbu Saudi Arabia', 'hotel-ibis-yanbu-saudi-arabia', 0),
(116, 'Fairmont Makkah Clock Royal Tower', 'fairmont-makkah-clock-royal-tower', 0),
(117, 'Hotel Pullman Zamzam Makkah', 'hotel-pullman-zamzam-makkah', 0),
(118, 'Makkah Millennium Hotel', 'makkah-millennium-hotel', 0),
(119, 'test', 'test', 0),
(120, 'test1', 'test1', 0),
(121, 'test3', 'test3', 0),
(122, 'test4', 'test4', 0),
(123, 'dfdfd', 'dfdfd', 0),
(124, 'dfdf', 'dfdf', 0),
(125, '20000-30000', '20000-30000', 0),
(126, '30000-40000', '30000-40000', 0),
(127, '40000-50000', '40000-50000', 0),
(130, '3 Star', '3-star', 0),
(131, '4 Star', '4-star', 0),
(132, '5 Star', '5-star', 0),
(133, 'Non-stop', 'non-stop', 0),
(134, '1 Stop', '1-stop', 0),
(135, '2 Stop', '2-stop', 0),
(136, '1 Stop', '1-stop', 0),
(137, '2 Stop', '2-stop', 0),
(138, 'Non-stop', 'non-stop', 0),
(139, 'Airport Transport', 'airport-transport', 0),
(140, 'Outdoor pool (all year)', 'outdoor-pool-all-year', 0),
(141, 'Shuttle Bus Service', 'shuttle-bus-service', 0),
(142, '1 Star', '1-star', 0),
(143, '2 Star', '2-star', 0),
(144, '3 Star', '3-star', 0),
(145, '4 Star', '4-star', 0),
(146, '5 Star', '5-star', 0),
(147, 'Banglar alo', 'banglar-alo', 0),
(148, 'Lorem Ipsum', 'lorem-ipsum', 0),
(149, 'super', 'super', 0),
(150, 'Single', 'single', 0),
(151, 'Double', 'double', 0),
(152, '1 type Room', '1-type-room', 0),
(153, '2 Type room', '2-type-room', 0),
(154, '1 type Room', '1-type-room', 0),
(155, '2 Type room', '2-type-room', 0),
(156, 'Banglar alo', 'banglar-alo', 0),
(157, 'Double', 'double', 0),
(158, 'Single', 'single', 0),
(159, 'lakzary', 'lakzary', 0),
(160, 'lakzary', 'lakzary', 0),
(161, '1 type Room', '1-type-room', 0),
(162, 'Afghanistan', 'afghanistan', 0),
(163, 'Albania', 'albania', 0),
(164, 'Australia', 'australia', 0),
(165, 'Bangladesh', 'bangladesh', 0),
(166, 'Brazil', 'brazil', 0),
(167, 'Canada', 'canada', 0),
(168, 'Afghanistan', 'afghanistan', 0),
(169, 'Albania', 'albania', 0),
(170, 'Australia', 'australia', 0),
(171, 'Bangladesh', 'bangladesh', 0),
(172, 'Brazil', 'brazil', 0),
(173, '1', '1', 0),
(174, '2', '2', 0),
(175, '3', '3', 0),
(176, '4', '4', 0),
(177, '5', '5', 0),
(178, '6', '6', 0),
(179, '7', '7', 0),
(180, '8', '8', 0),
(181, '9', '9', 0),
(182, '10', '10', 0),
(183, 'Round Trip', 'round-trip', 0),
(184, '04/09/2019', '04-09-2019', 0),
(185, '04/08/2019', '04-08-2019', 0),
(186, '04/07/2019', '04-07-2019', 0),
(187, '04/06/2019', '04-06-2019', 0),
(188, '04/05/2019', '04-05-2019', 0),
(190, '04/10/2019', '04-10-2019', 0),
(191, '1stop', '1stop', 0),
(192, 'bangladesh', 'bangladesh', 0),
(193, 'india', 'india', 0),
(194, '2stop', '2stop', 0),
(195, 'One Way', 'one-way', 0),
(196, '10000-20000', '10000-20000', 0),
(197, '2000-30000', '2000-30000', 0),
(198, '30000-40000', '30000-40000', 0),
(199, 'Afghanistan', 'afghanistan', 0),
(200, 'Albania', 'albania', 0),
(201, 'Canada', 'canada', 0),
(202, 'Brazil', 'brazil', 0),
(203, 'Bangladesh', 'bangladesh', 0),
(204, 'footer_menu', 'footer_menu', 0),
(205, 'India', 'india', 0),
(206, '20000-30000', '20000-30000', 0),
(207, 'Newziland', 'newziland', 0),
(208, 'Russia', 'russia', 0),
(209, '25000-30000', '25000-30000', 0),
(210, 'Germany', 'germany', 0),
(211, '30000-40000', '30000-40000', 0),
(212, 'aaaa', 'aaa', 0),
(213, 'Holiday Inn Melbourne', 'holiday-inn-melbourne', 0),
(214, 'hotel taxonomy', 'hotel-taxonomy', 0),
(215, 'newtax', 'newtax', 0),
(216, 'Main Hotels Details', 'main-hotels-1', 0);

-- --------------------------------------------------------

--
-- Table structure for table `wp_termsmeta`
--

CREATE TABLE `wp_termsmeta` (
  `meta_id` bigint(20) NOT NULL,
  `terms_id` bigint(20) NOT NULL DEFAULT '0',
  `meta_key` varchar(255) DEFAULT NULL,
  `meta_value` longtext
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Table structure for table `wp_term_relationships`
--

CREATE TABLE `wp_term_relationships` (
  `object_id` bigint(20) UNSIGNED NOT NULL DEFAULT '0',
  `term_taxonomy_id` bigint(20) UNSIGNED NOT NULL DEFAULT '0',
  `term_order` int(11) NOT NULL DEFAULT '0'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `wp_term_relationships`
--

INSERT INTO `wp_term_relationships` (`object_id`, `term_taxonomy_id`, `term_order`) VALUES
(1, 1, 0),
(34, 2, 0),
(35, 2, 0),
(169, 7, 0),
(169, 27, 0),
(181, 10, 0),
(181, 15, 0),
(181, 20, 0),
(181, 22, 0),
(188, 30, 0),
(188, 45, 0),
(188, 47, 0),
(188, 50, 0),
(188, 51, 0),
(188, 58, 0),
(191, 30, 0),
(191, 47, 0),
(191, 51, 0),
(191, 58, 0),
(196, 30, 0),
(196, 46, 0),
(196, 47, 0),
(196, 51, 0),
(196, 57, 0),
(196, 90, 0),
(196, 95, 0),
(196, 98, 0),
(196, 101, 0),
(196, 118, 0),
(264, 33, 0),
(264, 60, 0),
(264, 73, 0),
(264, 89, 0),
(264, 96, 0),
(264, 99, 0),
(264, 100, 0),
(264, 115, 0),
(267, 34, 0),
(267, 60, 0),
(267, 71, 0),
(267, 87, 0),
(267, 91, 0),
(267, 95, 0),
(267, 99, 0),
(267, 101, 0),
(267, 116, 0),
(306, 106, 0),
(306, 107, 0),
(306, 109, 0),
(324, 106, 0),
(324, 107, 0),
(324, 110, 0),
(337, 111, 0),
(337, 125, 0),
(337, 130, 0),
(337, 131, 0),
(337, 134, 0),
(337, 137, 0),
(337, 208, 0),
(337, 209, 0),
(343, 106, 0),
(343, 107, 0),
(343, 109, 0),
(350, 60, 0),
(350, 87, 0),
(350, 89, 0),
(350, 96, 0),
(350, 99, 0),
(350, 100, 0),
(352, 113, 0),
(352, 127, 0),
(352, 132, 0),
(352, 134, 0),
(352, 135, 0),
(352, 207, 0),
(353, 114, 0),
(353, 126, 0),
(353, 131, 0),
(353, 133, 0),
(353, 205, 0),
(353, 206, 0),
(360, 119, 0),
(360, 120, 0),
(360, 122, 0),
(360, 123, 0),
(360, 124, 0),
(375, 34, 0),
(375, 136, 0),
(375, 139, 0),
(375, 140, 0),
(375, 141, 0),
(375, 142, 0),
(378, 33, 0),
(378, 137, 0),
(378, 139, 0),
(378, 144, 0),
(378, 146, 0),
(378, 196, 0),
(378, 201, 0),
(379, 31, 0),
(379, 138, 0),
(379, 140, 0),
(379, 145, 0),
(379, 146, 0),
(379, 196, 0),
(379, 203, 0),
(380, 30, 0),
(380, 137, 0),
(380, 140, 0),
(380, 144, 0),
(394, 149, 0),
(416, 152, 0),
(439, 154, 0),
(439, 159, 0),
(459, 60, 0),
(459, 87, 0),
(460, 60, 0),
(460, 87, 0),
(461, 60, 0),
(461, 87, 0),
(462, 60, 0),
(462, 73, 0),
(463, 60, 0),
(463, 73, 0),
(464, 60, 0),
(464, 73, 0),
(465, 60, 0),
(465, 73, 0),
(466, 60, 0),
(466, 73, 0),
(467, 60, 0),
(467, 73, 0),
(475, 125, 0),
(475, 162, 0),
(475, 171, 0),
(475, 174, 0),
(475, 188, 0),
(475, 193, 0),
(475, 194, 0),
(475, 195, 0),
(476, 126, 0),
(476, 165, 0),
(476, 172, 0),
(476, 174, 0),
(476, 183, 0),
(476, 190, 0),
(476, 191, 0),
(476, 192, 0),
(483, 166, 0),
(483, 171, 0),
(483, 174, 0),
(483, 185, 0),
(483, 191, 0),
(483, 192, 0),
(483, 195, 0),
(576, 2, 0),
(584, 2, 0),
(585, 2, 0),
(586, 2, 0),
(587, 204, 0),
(588, 204, 0),
(589, 204, 0),
(590, 204, 0),
(591, 204, 0),
(592, 204, 0),
(595, 91, 0),
(595, 95, 0),
(595, 97, 0),
(595, 100, 0),
(595, 115, 0),
(597, 89, 0),
(597, 96, 0),
(597, 99, 0),
(597, 103, 0),
(597, 116, 0),
(602, 131, 0),
(602, 135, 0),
(602, 210, 0),
(602, 211, 0),
(607, 2, 0),
(608, 2, 0),
(610, 2, 0),
(611, 1, 0),
(614, 92, 0),
(614, 97, 0),
(614, 103, 0),
(614, 118, 0),
(628, 2, 0),
(629, 2, 0),
(650, 1, 0),
(650, 213, 0),
(663, 1, 0),
(688, 216, 0);

-- --------------------------------------------------------

--
-- Table structure for table `wp_term_taxonomy`
--

CREATE TABLE `wp_term_taxonomy` (
  `term_taxonomy_id` bigint(20) UNSIGNED NOT NULL,
  `term_id` bigint(20) UNSIGNED NOT NULL DEFAULT '0',
  `taxonomy` varchar(32) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `description` longtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `parent` bigint(20) UNSIGNED NOT NULL DEFAULT '0',
  `count` bigint(20) NOT NULL DEFAULT '0'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `wp_term_taxonomy`
--

INSERT INTO `wp_term_taxonomy` (`term_taxonomy_id`, `term_id`, `taxonomy`, `description`, `parent`, `count`) VALUES
(1, 1, 'category', '', 0, 4),
(2, 2, 'nav_menu', '', 0, 11),
(4, 4, 'Airline company', '', 0, 0),
(5, 5, 'Room Type', 'gfdgfd', 0, 0),
(6, 6, 'Room Type', 'hgfhgfh', 0, 0),
(7, 7, 'Category', '', 0, 1),
(8, 8, 'Package Class', '', 0, 0),
(9, 9, 'Package Class', '', 0, 0),
(10, 10, 'Package Class', '', 0, 1),
(11, 11, 'Package Class', '', 0, 0),
(12, 12, 'Package Class', '', 0, 0),
(13, 13, 'Expert Rating', '', 0, 0),
(14, 14, 'Expert Rating', '', 0, 0),
(15, 15, 'Expert Rating', '', 0, 1),
(16, 16, 'Expert Rating', '', 0, 0),
(17, 17, 'Expert Rating', '', 0, 0),
(18, 18, 'Room Facilities', '', 0, 0),
(19, 19, 'Room Facilities', '', 0, 0),
(20, 20, 'Room Facilities', '', 0, 1),
(21, 21, 'Room Facilities', '', 0, 0),
(22, 22, 'Promotions', '', 0, 1),
(23, 23, 'Promotions', '', 0, 0),
(24, 24, 'Promotions', '', 0, 0),
(25, 25, 'Promotions', '', 0, 0),
(26, 26, 'RoomType', '', 0, 0),
(27, 27, 'Category', '', 0, 1),
(28, 28, 'post_tag', 'vxcvxcvxcvcx', 0, 0),
(29, 29, 'post_tag', '', 0, 0),
(30, 30, 'Location', '', 0, 1),
(31, 31, 'Location', '', 0, 1),
(32, 32, 'Location', '', 0, 0),
(33, 33, 'Location', '', 0, 1),
(34, 34, 'Location', '', 0, 1),
(35, 35, 'Hotel Name', '', 0, 0),
(36, 36, 'Hotel Name', '', 0, 0),
(37, 37, 'Hotel Name', '', 0, 0),
(38, 38, 'Price Range', '', 0, 0),
(39, 39, 'Price Range', '', 0, 0),
(40, 40, 'Price Range', '', 0, 0),
(41, 41, 'No of Days', '', 0, 0),
(42, 42, 'No of Days', '', 0, 0),
(43, 43, 'No of Days', '', 0, 0),
(44, 44, 'No of Days', '', 0, 0),
(45, 45, 'HotelName', '', 0, 1),
(46, 46, 'HotelName', '', 0, 1),
(47, 47, 'PriceRange', '', 0, 3),
(48, 48, 'PriceRange', '', 0, 0),
(49, 49, 'PriceRange', '', 0, 0),
(50, 50, 'RoomFacilities', '', 0, 1),
(51, 51, 'NoofDays', '', 0, 3),
(52, 52, 'NoofDays', '', 0, 0),
(53, 53, 'NoofDays', '', 0, 0),
(54, 54, 'NoofDays', '', 0, 0),
(55, 55, 'PackageClass', '', 0, 0),
(56, 56, 'PackageClass', '', 0, 0),
(57, 57, 'PackageClass', '', 0, 1),
(58, 58, 'PackageClass', '', 0, 2),
(59, 59, 'PackageClass', '', 0, 0),
(60, 60, 'product_type', '', 0, 12),
(61, 61, 'product_type', '', 0, 0),
(62, 62, 'product_type', '', 0, 0),
(63, 63, 'product_type', '', 0, 0),
(64, 64, 'product_visibility', '', 0, 0),
(65, 65, 'product_visibility', '', 0, 0),
(66, 66, 'product_visibility', '', 0, 0),
(67, 67, 'product_visibility', '', 0, 0),
(68, 68, 'product_visibility', '', 0, 0),
(69, 69, 'product_visibility', '', 0, 0),
(70, 70, 'product_visibility', '', 0, 0),
(71, 71, 'product_visibility', '', 0, 1),
(72, 72, 'product_visibility', '', 0, 0),
(73, 73, 'product_cat', '', 0, 7),
(81, 81, 'product_tag', '', 0, 0),
(82, 82, 'product_tag', '', 0, 0),
(83, 83, 'product_tag', '', 0, 0),
(84, 84, 'product_tag', '', 0, 0),
(85, 85, 'product_cat', '', 0, 0),
(86, 86, 'product_cat', '', 0, 0),
(87, 87, 'product_cat', '', 0, 5),
(88, 88, 'product_cat', '', 0, 0),
(89, 89, 'package_city', '', 0, 1),
(90, 90, 'package_city', '', 0, 1),
(91, 91, 'package_city', '', 0, 1),
(92, 92, 'package_city', '', 0, 1),
(93, 93, 'package_city', '', 0, 0),
(94, 94, 'price_range', '', 0, 0),
(95, 95, 'price_range', '', 0, 2),
(96, 96, 'price_range', '', 0, 1),
(97, 97, 'package_class', '', 0, 2),
(98, 98, 'package_class', '', 0, 1),
(99, 99, 'package_class', '', 0, 1),
(100, 100, 'no_of_days', '', 0, 1),
(101, 101, 'no_of_days', '', 0, 1),
(102, 102, 'no_of_days', '', 0, 0),
(103, 103, 'no_of_days', '', 0, 2),
(104, 104, 'product_tag', '', 0, 0),
(105, 105, 'Car Category', '', 0, 0),
(106, 106, 'CarsName', '', 0, 3),
(107, 107, 'CarsFeatures', '', 0, 3),
(108, 108, 'CarsFeatures', '', 0, 0),
(109, 109, 'CarsLocation', '', 0, 2),
(110, 110, 'CarsLocation', '', 0, 1),
(111, 111, 'tour_categories', '', 0, 1),
(112, 112, 'tour_categories', '', 0, 0),
(113, 113, 'tour_categories', '', 0, 1),
(114, 114, 'tour_categories', '', 0, 1),
(115, 115, 'hotel_name', '', 0, 1),
(116, 116, 'hotel_name', '', 0, 1),
(117, 117, 'hotel_name', '', 0, 0),
(118, 118, 'hotel_name', '', 0, 2),
(119, 119, 'itinerary_types', 'dfdsfsdfdfds', 0, 1),
(120, 120, 'travel_locations', 'fdffsdf', 0, 1),
(121, 121, 'travel_keywords', 'dfdfdffd', 0, 0),
(122, 122, 'activity', 'dfdfdfds', 0, 1),
(123, 123, 'travel_locations', '', 120, 1),
(124, 124, 'travel_locations', '', 123, 1),
(125, 125, 'price', '', 0, 1),
(126, 126, 'price', '', 0, 1),
(127, 127, 'price', '', 0, 1),
(130, 130, 'tourhotelname', '', 0, 1),
(131, 131, 'tourhotelname', '', 0, 3),
(132, 132, 'tourhotelname', '', 0, 1),
(133, 133, 'facilities', '', 0, 1),
(134, 134, 'facilities', '', 0, 2),
(135, 135, 'facilities', '', 0, 2),
(136, 136, 'departuretime', '', 0, 1),
(137, 137, 'departuretime', '', 0, 1),
(138, 138, 'departuretime', '', 0, 1),
(139, 139, 'hotelfacilities', '', 0, 2),
(140, 140, 'hotelfacilities', '', 0, 3),
(141, 141, 'hotelfacilities', '', 0, 1),
(142, 142, 'hotelrating', '', 0, 1),
(143, 143, 'hotelrating', '', 0, 0),
(144, 144, 'hotelrating', '', 0, 2),
(145, 145, 'hotelrating', '', 0, 1),
(146, 146, 'hotelrating', '', 0, 2),
(147, 147, 'mphb_room_type_category', 'Easily realign text to components with text alignment classes. Ambitioni dedisse scripsisse iudicaretur. Cras mattis iudicium purus sit amet fermentum.', 0, 0),
(148, 148, 'mphb_room_type_tag', 'Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry\'s standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book. It has survived not only five centuries, but also the leap into electronic typesetting, remaining essentially unchanged. It was popularised in the 1960s with the release of Letraset sheets containing Lorem Ipsum passages, and more recently with desktop publishing software like Aldus PageMaker including versions of Lorem Ipsum.', 0, 0),
(149, 149, 'mphb_room_type_facility', '', 0, 1),
(150, 150, 'hb_room_capacity', '', 0, 0),
(151, 151, 'hb_room_capacity', '', 0, 0),
(152, 152, 'hb_room_type', '', 0, 1),
(153, 153, 'hb_room_type', '', 0, 0),
(154, 154, 'wb_tax_1_star', '', 0, 1),
(155, 155, 'wb_tax_1_star', '', 0, 0),
(156, 156, 'wb_hotel_room_type', '', 0, 0),
(157, 157, 'wb_hotel_room_facilities', '', 0, 0),
(158, 158, 'wb_tour_type', '', 0, 0),
(159, 159, 'wpbooking_amenity', '', 0, 1),
(160, 160, 'wpbooking_extra_service', '', 0, 0),
(161, 161, 'hotel_amenity', '', 0, 0),
(162, 162, 'locationto', '', 0, 1),
(163, 163, 'locationto', '', 0, 0),
(164, 164, 'locationto', '', 0, 0),
(165, 165, 'locationto', '', 0, 1),
(166, 166, 'locationto', '', 0, 1),
(167, 167, 'locationto', '', 0, 0),
(168, 168, 'locationform', '', 0, 0),
(169, 169, 'locationform', '', 0, 0),
(170, 170, 'locationform', '', 0, 0),
(171, 171, 'locationform', '', 0, 2),
(172, 172, 'locationform', '', 0, 1),
(173, 173, 'passenger', '', 0, 0),
(174, 174, 'passenger', '', 0, 3),
(175, 175, 'passenger', '', 0, 0),
(176, 176, 'passenger', '', 0, 0),
(177, 177, 'passenger', '', 0, 0),
(178, 178, 'passenger', '', 0, 0),
(179, 179, 'passenger', '', 0, 0),
(180, 180, 'passenger', '', 0, 0),
(181, 181, 'passenger', '', 0, 0),
(182, 182, 'passenger', '', 0, 0),
(183, 183, 'roundtrip', '', 0, 1),
(184, 184, 'departuredate', '', 0, 0),
(185, 185, 'departuredate', '', 0, 1),
(186, 186, 'departuredate', '', 0, 0),
(187, 187, 'departuredate', '', 0, 0),
(188, 188, 'departuredate', '', 0, 1),
(190, 190, 'departuredate', '', 0, 1),
(191, 191, 'stops', '', 0, 2),
(192, 192, 'airlines', '', 0, 2),
(193, 193, 'airlines', '', 0, 1),
(194, 194, 'stops', '', 0, 1),
(195, 195, 'roundtrip', '', 0, 2),
(196, 196, 'hotelprice', '', 0, 2),
(197, 197, 'hotelprice', '', 0, 0),
(198, 198, 'hotelprice', '', 0, 0),
(199, 199, 'hotellocation', '', 0, 0),
(200, 200, 'hotellocation', '', 0, 0),
(201, 201, 'hotellocation', '', 0, 1),
(202, 202, 'hotellocation', '', 0, 0),
(203, 203, 'hotellocation', '', 0, 1),
(204, 204, 'nav_menu', '', 0, 6),
(205, 205, 'Tourlocation', '', 0, 1),
(206, 206, 'Tourprice', '', 0, 1),
(207, 207, 'Tourlocation', '', 0, 1),
(208, 208, 'Tourlocation', '', 0, 1),
(209, 209, 'Tourprice', '', 0, 1),
(210, 210, 'Tourlocation', '', 0, 1),
(211, 211, 'Tourprice', '', 0, 1),
(212, 212, 'category', 'aaaa', 0, 0),
(213, 213, 'hotels', 'robii ', 0, 1),
(214, 214, 'hotels', '', 0, 0),
(215, 215, 'destino', '', 0, 0),
(216, 216, 'main_hotel_informations', 'Assign a parent term to create a hierarchy. The term Jazz, for example, would be the parent of Bebop and Big Band.Assign a parent term to create a hierarchy. The term Jazz, for example, would be the parent of Bebop and Big Band.Assign a parent term to create a hierarchy. The term Jazz, for example, would be the parent of Bebop and Big Band.Assign a parent term to create a hierarchy. The term Jazz, for example, would be the parent of Bebop and Big Band.', 0, 1);

-- --------------------------------------------------------

--
-- Table structure for table `wp_toolset_post_guid_id`
--

CREATE TABLE `wp_toolset_post_guid_id` (
  `guid` varchar(190) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `post_id` bigint(20) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `wp_usermeta`
--

CREATE TABLE `wp_usermeta` (
  `umeta_id` bigint(20) UNSIGNED NOT NULL,
  `user_id` bigint(20) UNSIGNED NOT NULL DEFAULT '0',
  `meta_key` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `meta_value` longtext COLLATE utf8mb4_unicode_ci
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `wp_usermeta`
--

INSERT INTO `wp_usermeta` (`umeta_id`, `user_id`, `meta_key`, `meta_value`) VALUES
(1, 1, 'nickname', 'admin'),
(2, 1, 'first_name', 'Lipan'),
(3, 1, 'last_name', 'Dutta'),
(4, 1, 'description', ''),
(5, 1, 'rich_editing', 'true'),
(6, 1, 'syntax_highlighting', 'true'),
(7, 1, 'comment_shortcuts', 'false'),
(8, 1, 'admin_color', 'fresh'),
(9, 1, 'use_ssl', '0'),
(10, 1, 'show_admin_bar_front', 'true'),
(11, 1, 'locale', ''),
(12, 1, 'wp_capabilities', 'a:14:{s:13:\"administrator\";b:1;s:13:\"bbp_keymaster\";b:1;s:26:\"wpcf_custom_post_type_view\";b:1;s:26:\"wpcf_custom_post_type_edit\";b:1;s:33:\"wpcf_custom_post_type_edit_others\";b:1;s:25:\"wpcf_custom_taxonomy_view\";b:1;s:25:\"wpcf_custom_taxonomy_edit\";b:1;s:32:\"wpcf_custom_taxonomy_edit_others\";b:1;s:22:\"wpcf_custom_field_view\";b:1;s:22:\"wpcf_custom_field_edit\";b:1;s:29:\"wpcf_custom_field_edit_others\";b:1;s:25:\"wpcf_user_meta_field_view\";b:1;s:25:\"wpcf_user_meta_field_edit\";b:1;s:32:\"wpcf_user_meta_field_edit_others\";b:1;}'),
(13, 1, 'wp_user_level', '10'),
(14, 1, 'dismissed_wp_pointers', 'wp496_privacy,wp_travel_menu_order_changes,wp_travel_new_trips_menu,theme_editor_notice'),
(15, 1, 'show_welcome_panel', '0'),
(17, 1, 'wp_dashboard_quick_press_last_post_id', '1059'),
(18, 1, 'community-events-location', 'a:1:{s:2:\"ip\";s:11:\"103.195.1.0\";}'),
(19, 1, 'managenav-menuscolumnshidden', 'a:5:{i:0;s:11:\"link-target\";i:1;s:11:\"css-classes\";i:2;s:3:\"xfn\";i:3;s:11:\"description\";i:4;s:15:\"title-attribute\";}'),
(20, 1, 'metaboxhidden_nav-menus', 'a:3:{i:0;s:23:\"add-post-type-portfolio\";i:1;s:19:\"add-post-type-offer\";i:2;s:12:\"add-post_tag\";}'),
(21, 1, 'nav_menu_recently_edited', '2'),
(22, 1, 'wp_r_tru_u_x', 'a:2:{s:2:\"id\";s:0:\"\";s:7:\"expires\";i:86400;}'),
(23, 1, 'wp_user-settings', 'libraryContent=browse&editor=html'),
(24, 1, 'wp_user-settings-time', '1558757203'),
(25, 1, 'ignore_redux_blast_1550567399', '1'),
(26, 1, 'closedpostboxes_umrah', 'a:0:{}'),
(27, 1, 'metaboxhidden_umrah', 'a:1:{i:0;s:7:\"slugdiv\";}'),
(28, 1, 'meta-box-order_umrah', 'a:3:{s:4:\"side\";s:107:\"submitdiv,Locationdiv,PackageClassdiv,HotelNamediv,PriceRangediv,NoofDaysdiv,RoomFacilitiesdiv,postimagediv\";s:6:\"normal\";s:52:\"umrah,postexcerpt,slugdiv,commentstatusdiv,authordiv\";s:8:\"advanced\";s:0:\"\";}'),
(29, 1, 'screen_layout_umrah', '2'),
(30, 1, '_woocommerce_persistent_cart_1', 'a:1:{s:4:\"cart\";a:2:{s:32:\"d6baf65e0b240ce177cf70da146c8dc8\";a:11:{s:3:\"key\";s:32:\"d6baf65e0b240ce177cf70da146c8dc8\";s:10:\"product_id\";i:264;s:12:\"variation_id\";i:0;s:9:\"variation\";a:0:{}s:8:\"quantity\";i:1;s:9:\"data_hash\";s:32:\"b5c1d5ca8bae6d4896cf1807cdf763f0\";s:13:\"line_tax_data\";a:2:{s:8:\"subtotal\";a:0:{}s:5:\"total\";a:0:{}}s:13:\"line_subtotal\";d:5;s:17:\"line_subtotal_tax\";i:0;s:10:\"line_total\";d:5;s:8:\"line_tax\";i:0;}s:32:\"eda80a3d5b344bc40f3bc04f65b7a357\";a:11:{s:3:\"key\";s:32:\"eda80a3d5b344bc40f3bc04f65b7a357\";s:10:\"product_id\";i:267;s:12:\"variation_id\";i:0;s:9:\"variation\";a:0:{}s:8:\"quantity\";i:1;s:9:\"data_hash\";s:32:\"b5c1d5ca8bae6d4896cf1807cdf763f0\";s:13:\"line_tax_data\";a:2:{s:8:\"subtotal\";a:0:{}s:5:\"total\";a:0:{}}s:13:\"line_subtotal\";d:5;s:17:\"line_subtotal_tax\";i:0;s:10:\"line_total\";d:5;s:8:\"line_tax\";i:0;}}}'),
(31, 1, 'closedpostboxes_product', 'a:0:{}'),
(32, 1, 'metaboxhidden_product', 'a:0:{}'),
(33, 1, 'wplc_ma_agent', '1'),
(34, 1, 'wplc_chat_agent_online', '1551523967'),
(35, 1, 'wc_last_active', '1558396800'),
(37, 1, 'meta-box-order_product', 'a:3:{s:4:\"side\";s:131:\"submitdiv,no_of_daysdiv,package_classdiv,package_citydiv,price_rangediv,tagsdiv-product_tag,postimagediv,woocommerce-product-images\";s:6:\"normal\";s:63:\"product,postexcerpt,woocommerce-product-data,postcustom,slugdiv\";s:8:\"advanced\";s:0:\"\";}'),
(38, 1, 'screen_layout_product', '2'),
(40, 1, 'meta-box-order_hotelhajj', 'a:4:{s:15:\"acf_after_title\";s:0:\"\";s:4:\"side\";s:87:\"submitdiv,hotelfacilitiesdiv,postimagediv,Hotellocationdiv,Hotelratingdiv,Hotelpricediv\";s:6:\"normal\";s:68:\"hotelhajj,postexcerpt,commentstatusdiv,commentsdiv,slugdiv,authordiv\";s:8:\"advanced\";s:0:\"\";}'),
(41, 1, 'screen_layout_hotelhajj', '2'),
(44, 1, 'closedpostboxes_mphb_room_type', 'a:1:{i:0;s:10:\"attributes\";}'),
(45, 1, 'metaboxhidden_mphb_room_type', 'a:0:{}'),
(46, 1, 'dismissed_update_notice', '1'),
(47, 1, 'dismissed_no_secure_connection_notice', '1'),
(49, 2, 'nickname', 'taibur'),
(50, 2, 'first_name', 'taibur'),
(51, 2, 'last_name', 'milon'),
(52, 2, 'description', ''),
(53, 2, 'rich_editing', 'true'),
(54, 2, 'syntax_highlighting', 'true'),
(55, 2, 'comment_shortcuts', 'false'),
(56, 2, 'admin_color', 'fresh'),
(57, 2, 'use_ssl', '0'),
(58, 2, 'show_admin_bar_front', 'true'),
(59, 2, 'locale', ''),
(60, 2, 'wp_capabilities', 'a:1:{s:6:\"taibur\";b:1;}'),
(61, 2, 'wp_user_level', '0'),
(62, 2, 'dismissed_wp_pointers', 'wp496_privacy,wp_travel_menu_order_changes,wp_travel_new_trips_menu'),
(64, 2, 'wc_last_active', '1557878400'),
(66, 2, 'wp_dashboard_quick_press_last_post_id', '634'),
(67, 2, '_woocommerce_persistent_cart_1', 'a:1:{s:4:\"cart\";a:0:{}}'),
(71, 2, 'closedpostboxes_dashboard', 'a:0:{}'),
(72, 2, 'metaboxhidden_dashboard', 'a:2:{i:0;s:18:\"dashboard_activity\";i:1;s:17:\"dashboard_primary\";}'),
(73, 2, 'ignore_redux_blast_1550567399', '1'),
(74, 1, 'wppb_pms_cross_promo_dismiss_notification', 'true'),
(79, 2, 'wppb_pms_cross_promo_dismiss_notification', 'true'),
(82, 2, 'session_tokens', 'a:2:{s:64:\"93469374b955f3b2aed8af75e1ab04df7b02c3e9ea591b10f64b98d627d62b97\";a:4:{s:10:\"expiration\";i:1559564322;s:2:\"ip\";s:14:\"45.251.228.217\";s:2:\"ua\";s:114:\"Mozilla/5.0 (Windows NT 6.1; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/74.0.3729.169 Safari/537.36\";s:5:\"login\";i:1559391522;}s:64:\"f9b9d7b20970cc23b40dfd6ccd98c27e0f382315043f0e673d4ef223c74e7ac8\";a:4:{s:10:\"expiration\";i:1559672106;s:2:\"ip\";s:3:\"::1\";s:2:\"ua\";s:69:\"Mozilla/5.0 (Windows NT 10.0; WOW64; Trident/7.0; rv:11.0) like Gecko\";s:5:\"login\";i:1559499306;}}'),
(83, 2, 'community-events-location', 'a:1:{s:2:\"ip\";s:12:\"45.251.228.0\";}'),
(84, 1, 'closedpostboxes_post', 'a:1:{i:0;s:23:\"acf-group_5d03ba6ce761f\";}'),
(85, 1, 'metaboxhidden_post', 'a:0:{}'),
(86, 1, 'meta-box-order_post', 'a:4:{s:6:\"normal\";s:23:\"acf-group_5d03ba6ce761f\";s:15:\"acf_after_title\";s:0:\"\";s:4:\"side\";s:0:\"\";s:8:\"advanced\";s:0:\"\";}'),
(87, 1, 'closedpostboxes_hotelhajj', 'a:0:{}'),
(88, 1, 'metaboxhidden_hotelhajj', 'a:1:{i:0;s:7:\"slugdiv\";}'),
(89, 1, 'closedpostboxes_toolset_page_wpcf-edit-type', 'a:2:{i:0;s:12:\"types_labels\";i:1;s:13:\"custom_fields\";}'),
(90, 1, 'closedpostboxes_toolset_page_wpcf-edit-tax', 'a:1:{i:0;s:12:\"types_labels\";}'),
(91, 1, 'metaboxhidden_toolset_page_wpcf-edit-tax', 'a:0:{}'),
(92, 1, 'closedpostboxes_toolset_page_wpcf-termmeta-edit', 'a:11:{i:0;s:35:\"types-custom-field-main_hotel_image\";i:1;s:27:\"types-custom-field-check_in\";i:2;s:28:\"types-custom-field-check_out\";i:3;s:33:\"types-custom-field-hotel_location\";i:4;s:30:\"types-custom-field-hotel_email\";i:5;s:33:\"types-custom-field-hotel_phone_no\";i:6;s:30:\"types-custom-field-hotel_price\";i:7;s:32:\"types-custom-field-hotel_website\";i:8;s:39:\"types-custom-field-cancelled_prepayment\";i:9;s:40:\"types-custom-field-children_and_extrabed\";i:10;s:29:\"types-custom-field-hotel_pets\";}'),
(93, 1, 'metaboxhidden_toolset_page_wpcf-termmeta-edit', 'a:0:{}'),
(94, 1, 'meta-box-order_toolset_page_wpcf-termmeta-edit', 'a:4:{i:0;s:366:\"types-custom-field-main_hotel_image,types-custom-field-check_in,types-custom-field-check_out,types-custom-field-hotel_location,types-custom-field-hotel_email,types-custom-field-hotel_phone_no,types-custom-field-hotel_price,types-custom-field-hotel_website,types-custom-field-cancelled_prepayment,types-custom-field-children_and_extrabed,types-custom-field-hotel_pets\";s:4:\"side\";s:9:\"submitdiv\";s:6:\"normal\";s:0:\"\";s:8:\"advanced\";s:0:\"\";}'),
(95, 1, 'screen_layout_toolset_page_wpcf-termmeta-edit', '2'),
(97, 1, 'closedpostboxes_available-rooms', 'a:0:{}'),
(98, 1, 'metaboxhidden_available-rooms', 'a:1:{i:0;s:7:\"slugdiv\";}'),
(99, 1, 'closedpostboxes_dashboard', 'a:1:{i:0;s:17:\"dashboard_primary\";}'),
(100, 1, 'metaboxhidden_dashboard', 'a:0:{}'),
(101, 1, 'metaboxhidden_toolset_page_wpcf-edit-type', 'a:1:{i:0;s:12:\"field_groups\";}'),
(102, 1, 'session_tokens', 'a:3:{s:64:\"2015d62ab6a87a03838c7ad333b5276807455ef25fb75beb08ccaa633db39b7e\";a:4:{s:10:\"expiration\";i:1570297207;s:2:\"ip\";s:3:\"::1\";s:2:\"ua\";s:114:\"Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/77.0.3865.90 Safari/537.36\";s:5:\"login\";i:1570124407;}s:64:\"bb4cf3306ebc14887fb6c03f153ee62ecec6945221db85988c00dcbd7491a997\";a:4:{s:10:\"expiration\";i:1570354911;s:2:\"ip\";s:3:\"::1\";s:2:\"ua\";s:114:\"Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/77.0.3865.90 Safari/537.36\";s:5:\"login\";i:1570182111;}s:64:\"3db6281e4e7a8a2b116d087c7a088ab4470be88e33a1d3976873cce859f7bdfd\";a:4:{s:10:\"expiration\";i:1570371748;s:2:\"ip\";s:3:\"::1\";s:2:\"ua\";s:114:\"Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/77.0.3865.90 Safari/537.36\";s:5:\"login\";i:1570198948;}}');

-- --------------------------------------------------------

--
-- Table structure for table `wp_users`
--

CREATE TABLE `wp_users` (
  `ID` bigint(20) UNSIGNED NOT NULL,
  `user_login` varchar(60) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `user_pass` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `user_nicename` varchar(50) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `user_email` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `user_url` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `user_registered` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `user_activation_key` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `user_status` int(11) NOT NULL DEFAULT '0',
  `display_name` varchar(250) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT ''
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `wp_users`
--

INSERT INTO `wp_users` (`ID`, `user_login`, `user_pass`, `user_nicename`, `user_email`, `user_url`, `user_registered`, `user_activation_key`, `user_status`, `display_name`) VALUES
(1, 'admin', '$P$BRMXr8ZbqrwBSLko/UTecJlyhucNPP0', 'admin', 'admin@gmail.com', '', '2019-02-19 05:37:26', '', 0, 'admin'),
(2, 'taibur', '$P$B.0RtrYnxr5dANRvyUvQJ9SfAVCLmp.', 'taibur', 'taibur@gmail.com', 'http://kmbikroy.com', '2019-05-15 04:38:19', '1557895115:$P$BTjRDDWJSA9aY8Lqix1K8FTyynMCaV.', 0, 'taibur milon');

-- --------------------------------------------------------

--
-- Table structure for table `wp_wc_download_log`
--

CREATE TABLE `wp_wc_download_log` (
  `download_log_id` bigint(20) UNSIGNED NOT NULL,
  `timestamp` datetime NOT NULL,
  `permission_id` bigint(20) UNSIGNED NOT NULL,
  `user_id` bigint(20) UNSIGNED DEFAULT NULL,
  `user_ip_address` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT ''
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `wp_wc_webhooks`
--

CREATE TABLE `wp_wc_webhooks` (
  `webhook_id` bigint(20) UNSIGNED NOT NULL,
  `status` varchar(200) COLLATE utf8mb4_unicode_ci NOT NULL,
  `name` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `user_id` bigint(20) UNSIGNED NOT NULL,
  `delivery_url` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `secret` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `topic` varchar(200) COLLATE utf8mb4_unicode_ci NOT NULL,
  `date_created` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `date_created_gmt` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `date_modified` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `date_modified_gmt` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `api_version` smallint(4) NOT NULL,
  `failure_count` smallint(10) NOT NULL DEFAULT '0',
  `pending_delivery` tinyint(1) NOT NULL DEFAULT '0'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `wp_weforms_entries`
--

CREATE TABLE `wp_weforms_entries` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `form_id` bigint(20) UNSIGNED DEFAULT NULL,
  `user_id` bigint(20) UNSIGNED DEFAULT NULL,
  `user_ip` int(11) UNSIGNED DEFAULT NULL,
  `user_device` varchar(50) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `referer` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `status` varchar(10) COLLATE utf8mb4_unicode_ci DEFAULT 'publish',
  `created_at` datetime DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `wp_weforms_entrymeta`
--

CREATE TABLE `wp_weforms_entrymeta` (
  `meta_id` bigint(20) UNSIGNED NOT NULL,
  `weforms_entry_id` bigint(20) UNSIGNED DEFAULT NULL,
  `meta_key` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `meta_value` longtext COLLATE utf8mb4_unicode_ci
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `wp_woocommerce_api_keys`
--

CREATE TABLE `wp_woocommerce_api_keys` (
  `key_id` bigint(20) UNSIGNED NOT NULL,
  `user_id` bigint(20) UNSIGNED NOT NULL,
  `description` varchar(200) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `permissions` varchar(10) COLLATE utf8mb4_unicode_ci NOT NULL,
  `consumer_key` char(64) COLLATE utf8mb4_unicode_ci NOT NULL,
  `consumer_secret` char(43) COLLATE utf8mb4_unicode_ci NOT NULL,
  `nonces` longtext COLLATE utf8mb4_unicode_ci,
  `truncated_key` char(7) COLLATE utf8mb4_unicode_ci NOT NULL,
  `last_access` datetime DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `wp_woocommerce_attribute_taxonomies`
--

CREATE TABLE `wp_woocommerce_attribute_taxonomies` (
  `attribute_id` bigint(20) UNSIGNED NOT NULL,
  `attribute_name` varchar(200) COLLATE utf8mb4_unicode_ci NOT NULL,
  `attribute_label` varchar(200) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `attribute_type` varchar(20) COLLATE utf8mb4_unicode_ci NOT NULL,
  `attribute_orderby` varchar(20) COLLATE utf8mb4_unicode_ci NOT NULL,
  `attribute_public` int(1) NOT NULL DEFAULT '1'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `wp_woocommerce_attribute_taxonomies`
--

INSERT INTO `wp_woocommerce_attribute_taxonomies` (`attribute_id`, `attribute_name`, `attribute_label`, `attribute_type`, `attribute_orderby`, `attribute_public`) VALUES
(1, 'gfdgfd', 'gdfgfd', 'select', 'menu_order', 0);

-- --------------------------------------------------------

--
-- Table structure for table `wp_woocommerce_downloadable_product_permissions`
--

CREATE TABLE `wp_woocommerce_downloadable_product_permissions` (
  `permission_id` bigint(20) UNSIGNED NOT NULL,
  `download_id` varchar(36) COLLATE utf8mb4_unicode_ci NOT NULL,
  `product_id` bigint(20) UNSIGNED NOT NULL,
  `order_id` bigint(20) UNSIGNED NOT NULL DEFAULT '0',
  `order_key` varchar(200) COLLATE utf8mb4_unicode_ci NOT NULL,
  `user_email` varchar(200) COLLATE utf8mb4_unicode_ci NOT NULL,
  `user_id` bigint(20) UNSIGNED DEFAULT NULL,
  `downloads_remaining` varchar(9) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `access_granted` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `access_expires` datetime DEFAULT NULL,
  `download_count` bigint(20) UNSIGNED NOT NULL DEFAULT '0'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `wp_woocommerce_log`
--

CREATE TABLE `wp_woocommerce_log` (
  `log_id` bigint(20) UNSIGNED NOT NULL,
  `timestamp` datetime NOT NULL,
  `level` smallint(4) NOT NULL,
  `source` varchar(200) COLLATE utf8mb4_unicode_ci NOT NULL,
  `message` longtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `context` longtext COLLATE utf8mb4_unicode_ci
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `wp_woocommerce_order_itemmeta`
--

CREATE TABLE `wp_woocommerce_order_itemmeta` (
  `meta_id` bigint(20) UNSIGNED NOT NULL,
  `order_item_id` bigint(20) UNSIGNED NOT NULL,
  `meta_key` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `meta_value` longtext COLLATE utf8mb4_unicode_ci
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `wp_woocommerce_order_items`
--

CREATE TABLE `wp_woocommerce_order_items` (
  `order_item_id` bigint(20) UNSIGNED NOT NULL,
  `order_item_name` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `order_item_type` varchar(200) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `order_id` bigint(20) UNSIGNED NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `wp_woocommerce_payment_tokenmeta`
--

CREATE TABLE `wp_woocommerce_payment_tokenmeta` (
  `meta_id` bigint(20) UNSIGNED NOT NULL,
  `payment_token_id` bigint(20) UNSIGNED NOT NULL,
  `meta_key` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `meta_value` longtext COLLATE utf8mb4_unicode_ci
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `wp_woocommerce_payment_tokens`
--

CREATE TABLE `wp_woocommerce_payment_tokens` (
  `token_id` bigint(20) UNSIGNED NOT NULL,
  `gateway_id` varchar(200) COLLATE utf8mb4_unicode_ci NOT NULL,
  `token` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `user_id` bigint(20) UNSIGNED NOT NULL DEFAULT '0',
  `type` varchar(200) COLLATE utf8mb4_unicode_ci NOT NULL,
  `is_default` tinyint(1) NOT NULL DEFAULT '0'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `wp_woocommerce_sessions`
--

CREATE TABLE `wp_woocommerce_sessions` (
  `session_id` bigint(20) UNSIGNED NOT NULL,
  `session_key` char(32) COLLATE utf8mb4_unicode_ci NOT NULL,
  `session_value` longtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `session_expiry` bigint(20) UNSIGNED NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `wp_woocommerce_sessions`
--

INSERT INTO `wp_woocommerce_sessions` (`session_id`, `session_key`, `session_value`, `session_expiry`) VALUES
(8, '1', 'a:11:{s:8:\"customer\";s:703:\"a:26:{s:2:\"id\";s:1:\"1\";s:13:\"date_modified\";s:0:\"\";s:8:\"postcode\";s:0:\"\";s:4:\"city\";s:0:\"\";s:9:\"address_1\";s:0:\"\";s:7:\"address\";s:0:\"\";s:9:\"address_2\";s:0:\"\";s:5:\"state\";s:0:\"\";s:7:\"country\";s:2:\"BD\";s:17:\"shipping_postcode\";s:0:\"\";s:13:\"shipping_city\";s:0:\"\";s:18:\"shipping_address_1\";s:0:\"\";s:16:\"shipping_address\";s:0:\"\";s:18:\"shipping_address_2\";s:0:\"\";s:14:\"shipping_state\";s:0:\"\";s:16:\"shipping_country\";s:2:\"BD\";s:13:\"is_vat_exempt\";s:0:\"\";s:19:\"calculated_shipping\";s:0:\"\";s:10:\"first_name\";s:0:\"\";s:9:\"last_name\";s:0:\"\";s:7:\"company\";s:0:\"\";s:5:\"phone\";s:0:\"\";s:5:\"email\";s:15:\"admin@gmail.com\";s:19:\"shipping_first_name\";s:0:\"\";s:18:\"shipping_last_name\";s:0:\"\";s:16:\"shipping_company\";s:0:\"\";}\";s:4:\"cart\";s:812:\"a:2:{s:32:\"d6baf65e0b240ce177cf70da146c8dc8\";a:11:{s:3:\"key\";s:32:\"d6baf65e0b240ce177cf70da146c8dc8\";s:10:\"product_id\";i:264;s:12:\"variation_id\";i:0;s:9:\"variation\";a:0:{}s:8:\"quantity\";i:1;s:9:\"data_hash\";s:32:\"b5c1d5ca8bae6d4896cf1807cdf763f0\";s:13:\"line_tax_data\";a:2:{s:8:\"subtotal\";a:0:{}s:5:\"total\";a:0:{}}s:13:\"line_subtotal\";d:5;s:17:\"line_subtotal_tax\";i:0;s:10:\"line_total\";d:5;s:8:\"line_tax\";i:0;}s:32:\"eda80a3d5b344bc40f3bc04f65b7a357\";a:11:{s:3:\"key\";s:32:\"eda80a3d5b344bc40f3bc04f65b7a357\";s:10:\"product_id\";i:267;s:12:\"variation_id\";i:0;s:9:\"variation\";a:0:{}s:8:\"quantity\";i:1;s:9:\"data_hash\";s:32:\"b5c1d5ca8bae6d4896cf1807cdf763f0\";s:13:\"line_tax_data\";a:2:{s:8:\"subtotal\";a:0:{}s:5:\"total\";a:0:{}}s:13:\"line_subtotal\";d:5;s:17:\"line_subtotal_tax\";i:0;s:10:\"line_total\";d:5;s:8:\"line_tax\";i:0;}}\";s:11:\"cart_totals\";s:408:\"a:15:{s:8:\"subtotal\";s:5:\"10.00\";s:12:\"subtotal_tax\";d:0;s:14:\"shipping_total\";s:6:\"100.00\";s:12:\"shipping_tax\";d:0;s:14:\"shipping_taxes\";a:0:{}s:14:\"discount_total\";d:0;s:12:\"discount_tax\";d:0;s:19:\"cart_contents_total\";s:5:\"10.00\";s:17:\"cart_contents_tax\";d:0;s:19:\"cart_contents_taxes\";a:0:{}s:9:\"fee_total\";s:4:\"0.00\";s:7:\"fee_tax\";d:0;s:9:\"fee_taxes\";a:0:{}s:5:\"total\";s:6:\"110.00\";s:9:\"total_tax\";d:0;}\";s:15:\"applied_coupons\";s:6:\"a:0:{}\";s:22:\"coupon_discount_totals\";s:6:\"a:0:{}\";s:26:\"coupon_discount_tax_totals\";s:6:\"a:0:{}\";s:21:\"removed_cart_contents\";s:6:\"a:0:{}\";s:22:\"shipping_for_package_0\";s:419:\"a:2:{s:12:\"package_hash\";s:40:\"wc_ship_3326ca7a0a7f9f64a493a6485187bc78\";s:5:\"rates\";a:1:{s:11:\"flat_rate:2\";O:16:\"WC_Shipping_Rate\":2:{s:7:\"\0*\0data\";a:6:{s:2:\"id\";s:11:\"flat_rate:2\";s:9:\"method_id\";s:9:\"flat_rate\";s:11:\"instance_id\";i:2;s:5:\"label\";s:9:\"Flat rate\";s:4:\"cost\";s:6:\"100.00\";s:5:\"taxes\";a:0:{}}s:12:\"\0*\0meta_data\";a:1:{s:5:\"Items\";s:61:\"global test &times; 1, 7 Days Star Umrah Package-03 &times; 1\";}}}}\";s:25:\"previous_shipping_methods\";s:39:\"a:1:{i:0;a:1:{i:0;s:11:\"flat_rate:2\";}}\";s:23:\"chosen_shipping_methods\";s:29:\"a:1:{i:0;s:11:\"flat_rate:2\";}\";s:22:\"shipping_method_counts\";s:14:\"a:1:{i:0;i:1;}\";}', 1558427715);

-- --------------------------------------------------------

--
-- Table structure for table `wp_woocommerce_shipping_zones`
--

CREATE TABLE `wp_woocommerce_shipping_zones` (
  `zone_id` bigint(20) UNSIGNED NOT NULL,
  `zone_name` varchar(200) COLLATE utf8mb4_unicode_ci NOT NULL,
  `zone_order` bigint(20) UNSIGNED NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `wp_woocommerce_shipping_zones`
--

INSERT INTO `wp_woocommerce_shipping_zones` (`zone_id`, `zone_name`, `zone_order`) VALUES
(1, 'Bangladesh', 0);

-- --------------------------------------------------------

--
-- Table structure for table `wp_woocommerce_shipping_zone_locations`
--

CREATE TABLE `wp_woocommerce_shipping_zone_locations` (
  `location_id` bigint(20) UNSIGNED NOT NULL,
  `zone_id` bigint(20) UNSIGNED NOT NULL,
  `location_code` varchar(200) COLLATE utf8mb4_unicode_ci NOT NULL,
  `location_type` varchar(40) COLLATE utf8mb4_unicode_ci NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `wp_woocommerce_shipping_zone_locations`
--

INSERT INTO `wp_woocommerce_shipping_zone_locations` (`location_id`, `zone_id`, `location_code`, `location_type`) VALUES
(1, 1, 'BD', 'country');

-- --------------------------------------------------------

--
-- Table structure for table `wp_woocommerce_shipping_zone_methods`
--

CREATE TABLE `wp_woocommerce_shipping_zone_methods` (
  `zone_id` bigint(20) UNSIGNED NOT NULL,
  `instance_id` bigint(20) UNSIGNED NOT NULL,
  `method_id` varchar(200) COLLATE utf8mb4_unicode_ci NOT NULL,
  `method_order` bigint(20) UNSIGNED NOT NULL,
  `is_enabled` tinyint(1) NOT NULL DEFAULT '1'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `wp_woocommerce_shipping_zone_methods`
--

INSERT INTO `wp_woocommerce_shipping_zone_methods` (`zone_id`, `instance_id`, `method_id`, `method_order`, `is_enabled`) VALUES
(1, 1, 'free_shipping', 1, 1),
(1, 2, 'flat_rate', 2, 1);

-- --------------------------------------------------------

--
-- Table structure for table `wp_woocommerce_tax_rates`
--

CREATE TABLE `wp_woocommerce_tax_rates` (
  `tax_rate_id` bigint(20) UNSIGNED NOT NULL,
  `tax_rate_country` varchar(2) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `tax_rate_state` varchar(200) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `tax_rate` varchar(8) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `tax_rate_name` varchar(200) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `tax_rate_priority` bigint(20) UNSIGNED NOT NULL,
  `tax_rate_compound` int(1) NOT NULL DEFAULT '0',
  `tax_rate_shipping` int(1) NOT NULL DEFAULT '1',
  `tax_rate_order` bigint(20) UNSIGNED NOT NULL,
  `tax_rate_class` varchar(200) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT ''
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `wp_woocommerce_tax_rate_locations`
--

CREATE TABLE `wp_woocommerce_tax_rate_locations` (
  `location_id` bigint(20) UNSIGNED NOT NULL,
  `location_code` varchar(200) COLLATE utf8mb4_unicode_ci NOT NULL,
  `tax_rate_id` bigint(20) UNSIGNED NOT NULL,
  `location_type` varchar(40) COLLATE utf8mb4_unicode_ci NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `wp_wpbooking_availability`
--

CREATE TABLE `wp_wpbooking_availability` (
  `id` int(11) NOT NULL,
  `post_id` int(11) DEFAULT NULL,
  `start` int(11) DEFAULT NULL,
  `end` int(11) DEFAULT NULL,
  `price` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `calendar_minimum` int(11) DEFAULT NULL,
  `calendar_maximum` int(11) DEFAULT NULL,
  `calendar_price` float DEFAULT NULL,
  `adult_minimum` int(11) DEFAULT NULL,
  `adult_price` float DEFAULT NULL,
  `child_minimum` int(11) DEFAULT NULL,
  `child_price` float DEFAULT NULL,
  `infant_minimum` int(11) DEFAULT NULL,
  `infant_price` float DEFAULT NULL,
  `weekly` float DEFAULT NULL,
  `monthly` float DEFAULT NULL,
  `status` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `base_id` int(11) DEFAULT NULL,
  `can_check_in` int(11) DEFAULT NULL,
  `can_check_out` int(11) DEFAULT NULL,
  `group_day` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `max_people` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `wp_wpbooking_availability`
--

INSERT INTO `wp_wpbooking_availability` (`id`, `post_id`, `start`, `end`, `price`, `calendar_minimum`, `calendar_maximum`, `calendar_price`, `adult_minimum`, `adult_price`, `child_minimum`, `child_price`, `infant_minimum`, `infant_price`, `weekly`, `monthly`, `status`, `base_id`, `can_check_in`, `can_check_out`, `group_day`, `max_people`) VALUES
(1, 440, 1554422400, 1554422400, '152000', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 'available', 440, 0, 0, '', 2);

-- --------------------------------------------------------

--
-- Table structure for table `wp_wpbooking_availability_tour`
--

CREATE TABLE `wp_wpbooking_availability_tour` (
  `id` int(11) NOT NULL,
  `post_id` int(11) DEFAULT NULL,
  `start` int(11) DEFAULT NULL,
  `end` int(11) DEFAULT NULL,
  `price` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `calendar_minimum` int(11) DEFAULT NULL,
  `calendar_maximum` int(11) DEFAULT NULL,
  `calendar_price` float DEFAULT NULL,
  `adult_minimum` int(11) DEFAULT NULL,
  `adult_price` float DEFAULT NULL,
  `child_minimum` int(11) DEFAULT NULL,
  `child_price` float DEFAULT NULL,
  `infant_minimum` int(11) DEFAULT NULL,
  `infant_price` float DEFAULT NULL,
  `weekly` float DEFAULT NULL,
  `monthly` float DEFAULT NULL,
  `status` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `base_id` int(11) DEFAULT NULL,
  `can_check_in` int(11) DEFAULT NULL,
  `can_check_out` int(11) DEFAULT NULL,
  `group_day` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `max_people` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `wp_wpbooking_favorite`
--

CREATE TABLE `wp_wpbooking_favorite` (
  `id` int(11) NOT NULL,
  `post_id` int(11) DEFAULT NULL,
  `user_id` int(11) DEFAULT NULL,
  `created_at` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `wp_wpbooking_order`
--

CREATE TABLE `wp_wpbooking_order` (
  `id` int(11) NOT NULL,
  `order_id` int(11) DEFAULT NULL,
  `post_id` int(11) DEFAULT NULL,
  `service_type` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `price` float DEFAULT NULL,
  `discount` int(11) DEFAULT NULL,
  `extra_fees` text COLLATE utf8mb4_unicode_ci,
  `tax` text COLLATE utf8mb4_unicode_ci,
  `tax_total` float DEFAULT NULL,
  `currency` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `raw_data` text COLLATE utf8mb4_unicode_ci,
  `check_in_timestamp` int(11) DEFAULT NULL,
  `check_out_timestamp` int(11) DEFAULT NULL,
  `user_id` int(11) DEFAULT NULL,
  `author_id` int(11) DEFAULT NULL,
  `deposit` text COLLATE utf8mb4_unicode_ci,
  `deposit_price` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `payment_method` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `status` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `adult_number` int(11) DEFAULT NULL,
  `children_number` int(11) DEFAULT NULL,
  `infant_number` int(11) DEFAULT NULL,
  `post_origin` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `wp_wpbooking_order_hotel_room`
--

CREATE TABLE `wp_wpbooking_order_hotel_room` (
  `id` int(11) NOT NULL,
  `order_id` int(11) DEFAULT NULL,
  `hotel_id` int(11) DEFAULT NULL,
  `hotel_id_origin` int(11) DEFAULT NULL,
  `room_id` int(11) DEFAULT NULL,
  `room_id_origin` int(11) DEFAULT NULL,
  `price` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `price_total` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `number` int(11) DEFAULT NULL,
  `extra_fees` text COLLATE utf8mb4_unicode_ci,
  `check_in_timestamp` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `check_out_timestamp` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `raw_data` text COLLATE utf8mb4_unicode_ci,
  `status` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `num_room` int(11) DEFAULT NULL,
  `total_room` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `wp_wpbooking_payment`
--

CREATE TABLE `wp_wpbooking_payment` (
  `id` int(11) NOT NULL,
  `order_id` int(11) DEFAULT NULL,
  `created_on` int(11) DEFAULT NULL,
  `amount` float DEFAULT NULL,
  `currency` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `gateway` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `payment_status` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `wp_wpbooking_review_helpful`
--

CREATE TABLE `wp_wpbooking_review_helpful` (
  `id` int(11) NOT NULL,
  `review_id` bigint(20) DEFAULT NULL,
  `user_id` bigint(20) DEFAULT NULL,
  `created_at` int(11) DEFAULT NULL,
  `ip_address` varchar(50) COLLATE utf8mb4_unicode_ci DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `wp_wpbooking_service`
--

CREATE TABLE `wp_wpbooking_service` (
  `id` int(11) NOT NULL,
  `post_id` int(11) DEFAULT NULL,
  `enable_property` varchar(10) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `price` float DEFAULT NULL,
  `number` int(11) DEFAULT NULL,
  `children_price` float DEFAULT NULL,
  `infant_price` float DEFAULT NULL,
  `map_lat` float DEFAULT NULL,
  `map_long` float DEFAULT NULL,
  `service_type` varchar(50) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `property_available_for` varchar(50) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `max_guests` int(11) DEFAULT NULL,
  `location_id` int(11) DEFAULT NULL,
  `pricing_type` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `base_price` float DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `wp_wpbooking_service`
--

INSERT INTO `wp_wpbooking_service` (`id`, `post_id`, `enable_property`, `price`, `number`, `children_price`, `infant_price`, `map_lat`, `map_long`, `service_type`, `property_available_for`, `max_guests`, `location_id`, `pricing_type`, `base_price`) VALUES
(1, 439, 'on', 0, 1, 0, 0, 0, 0, 'accommodation', 'forever', 0, 0, '', 0);

-- --------------------------------------------------------

--
-- Table structure for table `wp_wplc_chat_msgs`
--

CREATE TABLE `wp_wplc_chat_msgs` (
  `id` int(11) NOT NULL,
  `chat_sess_id` int(11) NOT NULL,
  `msgfrom` varchar(150) NOT NULL,
  `msg` longtext NOT NULL,
  `timestamp` datetime NOT NULL,
  `status` int(3) NOT NULL,
  `originates` int(3) NOT NULL,
  `other` longtext NOT NULL,
  `rel` varchar(40) NOT NULL,
  `afrom` int(10) NOT NULL,
  `ato` int(10) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Table structure for table `wp_wplc_chat_sessions`
--

CREATE TABLE `wp_wplc_chat_sessions` (
  `id` int(11) NOT NULL,
  `timestamp` datetime NOT NULL,
  `name` varchar(700) NOT NULL,
  `email` varchar(700) NOT NULL,
  `ip` varchar(700) NOT NULL,
  `status` int(11) NOT NULL,
  `session` varchar(100) NOT NULL,
  `url` varchar(700) NOT NULL,
  `last_active_timestamp` datetime NOT NULL,
  `agent_id` int(11) NOT NULL,
  `other` longtext NOT NULL,
  `rel` varchar(40) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Table structure for table `wp_wplc_offline_messages`
--

CREATE TABLE `wp_wplc_offline_messages` (
  `id` int(11) NOT NULL,
  `timestamp` datetime NOT NULL,
  `name` varchar(700) NOT NULL,
  `email` varchar(700) NOT NULL,
  `message` varchar(700) NOT NULL,
  `ip` varchar(700) NOT NULL,
  `user_agent` varchar(700) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Table structure for table `wp_wplc_webhooks`
--

CREATE TABLE `wp_wplc_webhooks` (
  `id` int(11) NOT NULL,
  `url` varchar(700) DEFAULT NULL,
  `push_to_devices` tinyint(1) DEFAULT NULL,
  `action` int(11) DEFAULT NULL,
  `method` varchar(70) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Table structure for table `wp_wpuf_subscribers`
--

CREATE TABLE `wp_wpuf_subscribers` (
  `id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `name` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `subscribtion_id` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `subscribtion_status` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `gateway` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `transaction_id` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `starts_from` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `expire` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `wp_wpuf_transaction`
--

CREATE TABLE `wp_wpuf_transaction` (
  `id` int(11) NOT NULL,
  `user_id` bigint(20) DEFAULT NULL,
  `status` varchar(60) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'pending_payment',
  `subtotal` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT '',
  `tax` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT '',
  `cost` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT '',
  `post_id` varchar(20) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `pack_id` bigint(20) DEFAULT NULL,
  `payer_first_name` varchar(60) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `payer_last_name` varchar(60) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `payer_email` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `payment_type` varchar(20) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `payer_address` longtext COLLATE utf8mb4_unicode_ci,
  `transaction_id` varchar(60) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created` datetime NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `wp_wpuser_groups`
--

CREATE TABLE `wp_wpuser_groups` (
  `id` int(11) NOT NULL,
  `title` varchar(250) DEFAULT NULL,
  `description` varchar(1000) DEFAULT NULL,
  `category` varchar(50) DEFAULT NULL,
  `tags` varchar(150) DEFAULT NULL,
  `area` varchar(240) DEFAULT NULL,
  `visibility` varchar(50) DEFAULT NULL,
  `icon` varchar(100) DEFAULT NULL,
  `created_by` int(11) NOT NULL,
  `created_time` timestamp NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `wp_wpuser_group_meta`
--

CREATE TABLE `wp_wpuser_group_meta` (
  `id` int(11) NOT NULL,
  `group_id` bigint(20) UNSIGNED NOT NULL DEFAULT '0',
  `meta_key` varchar(255) DEFAULT NULL,
  `meta_value` longtext
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `wp_wpuser_loginattempts`
--

CREATE TABLE `wp_wpuser_loginattempts` (
  `id` int(11) NOT NULL,
  `IP` varchar(20) NOT NULL,
  `Attempts` int(11) NOT NULL,
  `LastLogin` datetime NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `wp_wpuser_loginattempts`
--

INSERT INTO `wp_wpuser_loginattempts` (`id`, `IP`, `Attempts`, `LastLogin`) VALUES
(1, '::1', 1, '2019-05-22 04:31:05');

-- --------------------------------------------------------

--
-- Table structure for table `wp_wpuser_login_log`
--

CREATE TABLE `wp_wpuser_login_log` (
  `id` int(11) NOT NULL,
  `user` varchar(100) DEFAULT NULL,
  `ip` varchar(25) DEFAULT NULL,
  `status` varchar(15) DEFAULT NULL,
  `message` varchar(150) DEFAULT NULL,
  `user_agent` varchar(200) DEFAULT NULL,
  `created_date` timestamp NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `wp_wpuser_notification`
--

CREATE TABLE `wp_wpuser_notification` (
  `id` int(11) NOT NULL,
  `sender_id` int(11) DEFAULT NULL,
  `recipient_id` int(11) NOT NULL,
  `type_of_notification` varchar(20) DEFAULT NULL,
  `title_html` varchar(50) DEFAULT NULL,
  `body_html` varchar(240) DEFAULT NULL,
  `href` varchar(50) DEFAULT NULL,
  `is_unread` tinyint(1) DEFAULT '1',
  `created_time` timestamp NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `wp_wpuser_views`
--

CREATE TABLE `wp_wpuser_views` (
  `id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `view_by` int(11) DEFAULT NULL,
  `created_date` timestamp NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `wp_wsluserscontacts`
--

CREATE TABLE `wp_wsluserscontacts` (
  `id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `provider` varchar(50) NOT NULL,
  `identifier` varchar(255) NOT NULL,
  `full_name` varchar(150) NOT NULL,
  `email` varchar(255) NOT NULL,
  `profile_url` varchar(255) NOT NULL,
  `photo_url` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `wp_wslusersprofiles`
--

CREATE TABLE `wp_wslusersprofiles` (
  `id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `provider` varchar(50) NOT NULL,
  `object_sha` varchar(45) NOT NULL,
  `identifier` varchar(255) NOT NULL,
  `profileurl` varchar(255) NOT NULL,
  `websiteurl` varchar(255) NOT NULL,
  `photourl` varchar(255) NOT NULL,
  `displayname` varchar(150) NOT NULL,
  `description` varchar(255) NOT NULL,
  `firstname` varchar(150) NOT NULL,
  `lastname` varchar(150) NOT NULL,
  `gender` varchar(10) NOT NULL,
  `language` varchar(20) NOT NULL,
  `age` varchar(10) NOT NULL,
  `birthday` int(11) NOT NULL,
  `birthmonth` int(11) NOT NULL,
  `birthyear` int(11) NOT NULL,
  `email` varchar(255) NOT NULL,
  `emailverified` varchar(255) NOT NULL,
  `phone` varchar(75) NOT NULL,
  `address` varchar(255) NOT NULL,
  `country` varchar(75) NOT NULL,
  `region` varchar(50) NOT NULL,
  `city` varchar(50) NOT NULL,
  `zip` varchar(25) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Indexes for dumped tables
--

--
-- Indexes for table `activity_activities`
--
ALTER TABLE `activity_activities`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `activity_categories`
--
ALTER TABLE `activity_categories`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `activity_details`
--
ALTER TABLE `activity_details`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `available_rooms`
--
ALTER TABLE `available_rooms`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `booking_info`
--
ALTER TABLE `booking_info`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `car_details`
--
ALTER TABLE `car_details`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `car_packages`
--
ALTER TABLE `car_packages`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `city_list`
--
ALTER TABLE `city_list`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `guide_categories`
--
ALTER TABLE `guide_categories`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `guide_details`
--
ALTER TABLE `guide_details`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `guide_packages`
--
ALTER TABLE `guide_packages`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `hotel_details`
--
ALTER TABLE `hotel_details`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `hotel_offers`
--
ALTER TABLE `hotel_offers`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `hotel_offers_relation`
--
ALTER TABLE `hotel_offers_relation`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `main_booking_details`
--
ALTER TABLE `main_booking_details`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `newpluginform`
--
ALTER TABLE `newpluginform`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `new_order_img`
--
ALTER TABLE `new_order_img`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `ratings`
--
ALTER TABLE `ratings`
  ADD PRIMARY KEY (`id`),
  ADD KEY `post_id` (`service_id`),
  ADD KEY `meta_key` (`ratings_val`);

--
-- Indexes for table `restaurant_details`
--
ALTER TABLE `restaurant_details`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `star`
--
ALTER TABLE `star`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `tour_activities`
--
ALTER TABLE `tour_activities`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `tour_details`
--
ALTER TABLE `tour_details`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `transport_details`
--
ALTER TABLE `transport_details`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `transport_packages`
--
ALTER TABLE `transport_packages`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `transport_stopage`
--
ALTER TABLE `transport_stopage`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `transport_stopage_relations`
--
ALTER TABLE `transport_stopage_relations`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `umratinguser`
--
ALTER TABLE `umratinguser`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `wp_awebooking_availability`
--
ALTER TABLE `wp_awebooking_availability`
  ADD PRIMARY KEY (`room_id`,`year`,`month`);

--
-- Indexes for table `wp_awebooking_booking`
--
ALTER TABLE `wp_awebooking_booking`
  ADD PRIMARY KEY (`room_id`,`year`,`month`);

--
-- Indexes for table `wp_awebooking_booking_itemmeta`
--
ALTER TABLE `wp_awebooking_booking_itemmeta`
  ADD PRIMARY KEY (`meta_id`),
  ADD KEY `booking_item_id` (`booking_item_id`),
  ADD KEY `meta_key` (`meta_key`(32));

--
-- Indexes for table `wp_awebooking_booking_items`
--
ALTER TABLE `wp_awebooking_booking_items`
  ADD PRIMARY KEY (`booking_item_id`),
  ADD KEY `booking_item_parent` (`booking_item_parent`),
  ADD KEY `object_id` (`object_id`),
  ADD KEY `booking_id` (`booking_id`);

--
-- Indexes for table `wp_awebooking_pricing`
--
ALTER TABLE `wp_awebooking_pricing`
  ADD PRIMARY KEY (`rate_id`,`year`,`month`);

--
-- Indexes for table `wp_awebooking_rooms`
--
ALTER TABLE `wp_awebooking_rooms`
  ADD PRIMARY KEY (`id`),
  ADD KEY `name` (`name`),
  ADD KEY `room_type` (`room_type`);

--
-- Indexes for table `wp_awebooking_tax_rates`
--
ALTER TABLE `wp_awebooking_tax_rates`
  ADD PRIMARY KEY (`id`),
  ADD KEY `name` (`name`);

--
-- Indexes for table `wp_booking`
--
ALTER TABLE `wp_booking`
  ADD PRIMARY KEY (`booking_id`);

--
-- Indexes for table `wp_bookingdates`
--
ALTER TABLE `wp_bookingdates`
  ADD UNIQUE KEY `booking_id_dates` (`booking_id`,`booking_date`);

--
-- Indexes for table `wp_booking_package_calendaraccount`
--
ALTER TABLE `wp_booking_package_calendaraccount`
  ADD PRIMARY KEY (`key`);

--
-- Indexes for table `wp_booking_package_coursedata`
--
ALTER TABLE `wp_booking_package_coursedata`
  ADD PRIMARY KEY (`key`);

--
-- Indexes for table `wp_booking_package_emailsetting`
--
ALTER TABLE `wp_booking_package_emailsetting`
  ADD PRIMARY KEY (`key`);

--
-- Indexes for table `wp_booking_package_form`
--
ALTER TABLE `wp_booking_package_form`
  ADD PRIMARY KEY (`key`);

--
-- Indexes for table `wp_booking_package_guests`
--
ALTER TABLE `wp_booking_package_guests`
  ADD PRIMARY KEY (`key`);

--
-- Indexes for table `wp_booking_package_regular_holidays`
--
ALTER TABLE `wp_booking_package_regular_holidays`
  ADD PRIMARY KEY (`key`);

--
-- Indexes for table `wp_booking_package_schedule`
--
ALTER TABLE `wp_booking_package_schedule`
  ADD PRIMARY KEY (`key`);

--
-- Indexes for table `wp_booking_package_subscriptions`
--
ALTER TABLE `wp_booking_package_subscriptions`
  ADD PRIMARY KEY (`key`);

--
-- Indexes for table `wp_booking_package_taxes`
--
ALTER TABLE `wp_booking_package_taxes`
  ADD PRIMARY KEY (`key`);

--
-- Indexes for table `wp_booking_package_templateschedule`
--
ALTER TABLE `wp_booking_package_templateschedule`
  ADD PRIMARY KEY (`key`);

--
-- Indexes for table `wp_booking_package_userpraivatedata`
--
ALTER TABLE `wp_booking_package_userpraivatedata`
  ADD PRIMARY KEY (`key`);

--
-- Indexes for table `wp_booking_package_users`
--
ALTER TABLE `wp_booking_package_users`
  ADD PRIMARY KEY (`key`);

--
-- Indexes for table `wp_booking_package_webhook`
--
ALTER TABLE `wp_booking_package_webhook`
  ADD PRIMARY KEY (`key`);

--
-- Indexes for table `wp_bs_bookings`
--
ALTER TABLE `wp_bs_bookings`
  ADD PRIMARY KEY (`bookingID`);

--
-- Indexes for table `wp_bs_calendars`
--
ALTER TABLE `wp_bs_calendars`
  ADD PRIMARY KEY (`calendarID`);

--
-- Indexes for table `wp_bs_forms`
--
ALTER TABLE `wp_bs_forms`
  ADD PRIMARY KEY (`formID`);

--
-- Indexes for table `wp_commentmeta`
--
ALTER TABLE `wp_commentmeta`
  ADD PRIMARY KEY (`meta_id`),
  ADD KEY `comment_id` (`comment_id`),
  ADD KEY `meta_key` (`meta_key`(191));

--
-- Indexes for table `wp_comments`
--
ALTER TABLE `wp_comments`
  ADD PRIMARY KEY (`comment_ID`),
  ADD KEY `comment_post_ID` (`comment_post_ID`),
  ADD KEY `comment_approved_date_gmt` (`comment_approved`,`comment_date_gmt`),
  ADD KEY `comment_date_gmt` (`comment_date_gmt`),
  ADD KEY `comment_parent` (`comment_parent`),
  ADD KEY `comment_author_email` (`comment_author_email`(10)),
  ADD KEY `woo_idx_comment_type` (`comment_type`);

--
-- Indexes for table `wp_galcategory`
--
ALTER TABLE `wp_galcategory`
  ADD PRIMARY KEY (`catid`);

--
-- Indexes for table `wp_galimage`
--
ALTER TABLE `wp_galimage`
  ADD PRIMARY KEY (`imgid`);

--
-- Indexes for table `wp_gdgallerygalleries`
--
ALTER TABLE `wp_gdgallerygalleries`
  ADD PRIMARY KEY (`id_gallery`);

--
-- Indexes for table `wp_gdgalleryimages`
--
ALTER TABLE `wp_gdgalleryimages`
  ADD PRIMARY KEY (`id_image`),
  ADD KEY `id_gallery` (`id_gallery`);

--
-- Indexes for table `wp_gdgallerysettings`
--
ALTER TABLE `wp_gdgallerysettings`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `option_key` (`option_key`);

--
-- Indexes for table `wp_hotel_booking_order_itemmeta`
--
ALTER TABLE `wp_hotel_booking_order_itemmeta`
  ADD PRIMARY KEY (`meta_id`),
  ADD UNIQUE KEY `meta_id` (`meta_id`),
  ADD KEY `hotel_booking_order_item_id` (`hotel_booking_order_item_id`);

--
-- Indexes for table `wp_hotel_booking_order_items`
--
ALTER TABLE `wp_hotel_booking_order_items`
  ADD PRIMARY KEY (`order_item_id`),
  ADD UNIQUE KEY `order_item_id` (`order_item_id`);

--
-- Indexes for table `wp_hotel_booking_plans`
--
ALTER TABLE `wp_hotel_booking_plans`
  ADD PRIMARY KEY (`plan_id`),
  ADD UNIQUE KEY `plan_id` (`plan_id`);

--
-- Indexes for table `wp_links`
--
ALTER TABLE `wp_links`
  ADD PRIMARY KEY (`link_id`),
  ADD KEY `link_visible` (`link_visible`);

--
-- Indexes for table `wp_mphb_sync_logs`
--
ALTER TABLE `wp_mphb_sync_logs`
  ADD PRIMARY KEY (`log_id`);

--
-- Indexes for table `wp_mphb_sync_queue`
--
ALTER TABLE `wp_mphb_sync_queue`
  ADD PRIMARY KEY (`queue_id`);

--
-- Indexes for table `wp_mphb_sync_stats`
--
ALTER TABLE `wp_mphb_sync_stats`
  ADD PRIMARY KEY (`stat_id`);

--
-- Indexes for table `wp_options`
--
ALTER TABLE `wp_options`
  ADD PRIMARY KEY (`option_id`),
  ADD UNIQUE KEY `option_name` (`option_name`);

--
-- Indexes for table `wp_p2p_relationshipmeta`
--
ALTER TABLE `wp_p2p_relationshipmeta`
  ADD PRIMARY KEY (`meta_id`),
  ADD KEY `p2p_relationship_id` (`p2p_relationship_id`),
  ADD KEY `meta_key` (`meta_key`(32));

--
-- Indexes for table `wp_p2p_relationships`
--
ALTER TABLE `wp_p2p_relationships`
  ADD PRIMARY KEY (`id`),
  ADD KEY `type` (`type`),
  ADD KEY `rel_from` (`rel_from`),
  ADD KEY `rel_to` (`rel_to`);

--
-- Indexes for table `wp_postmeta`
--
ALTER TABLE `wp_postmeta`
  ADD PRIMARY KEY (`meta_id`),
  ADD KEY `post_id` (`post_id`),
  ADD KEY `meta_key` (`meta_key`(191));

--
-- Indexes for table `wp_posts`
--
ALTER TABLE `wp_posts`
  ADD PRIMARY KEY (`ID`),
  ADD KEY `post_name` (`post_name`(191)),
  ADD KEY `type_status_date` (`post_type`,`post_status`,`post_date`,`ID`),
  ADD KEY `post_parent` (`post_parent`),
  ADD KEY `post_author` (`post_author`);

--
-- Indexes for table `wp_termmeta`
--
ALTER TABLE `wp_termmeta`
  ADD PRIMARY KEY (`meta_id`),
  ADD KEY `term_id` (`term_id`),
  ADD KEY `meta_key` (`meta_key`(191));

--
-- Indexes for table `wp_terms`
--
ALTER TABLE `wp_terms`
  ADD PRIMARY KEY (`term_id`),
  ADD KEY `slug` (`slug`(191)),
  ADD KEY `name` (`name`(191));

--
-- Indexes for table `wp_termsmeta`
--
ALTER TABLE `wp_termsmeta`
  ADD PRIMARY KEY (`meta_id`),
  ADD KEY `terms_id` (`terms_id`),
  ADD KEY `meta_key` (`meta_key`);

--
-- Indexes for table `wp_term_relationships`
--
ALTER TABLE `wp_term_relationships`
  ADD PRIMARY KEY (`object_id`,`term_taxonomy_id`),
  ADD KEY `term_taxonomy_id` (`term_taxonomy_id`);

--
-- Indexes for table `wp_term_taxonomy`
--
ALTER TABLE `wp_term_taxonomy`
  ADD PRIMARY KEY (`term_taxonomy_id`),
  ADD UNIQUE KEY `term_id_taxonomy` (`term_id`,`taxonomy`),
  ADD KEY `taxonomy` (`taxonomy`);

--
-- Indexes for table `wp_toolset_post_guid_id`
--
ALTER TABLE `wp_toolset_post_guid_id`
  ADD UNIQUE KEY `post_id` (`post_id`),
  ADD KEY `guid` (`guid`);

--
-- Indexes for table `wp_usermeta`
--
ALTER TABLE `wp_usermeta`
  ADD PRIMARY KEY (`umeta_id`),
  ADD KEY `user_id` (`user_id`),
  ADD KEY `meta_key` (`meta_key`(191));

--
-- Indexes for table `wp_users`
--
ALTER TABLE `wp_users`
  ADD PRIMARY KEY (`ID`),
  ADD KEY `user_login_key` (`user_login`),
  ADD KEY `user_nicename` (`user_nicename`),
  ADD KEY `user_email` (`user_email`);

--
-- Indexes for table `wp_wc_download_log`
--
ALTER TABLE `wp_wc_download_log`
  ADD PRIMARY KEY (`download_log_id`),
  ADD KEY `permission_id` (`permission_id`),
  ADD KEY `timestamp` (`timestamp`);

--
-- Indexes for table `wp_wc_webhooks`
--
ALTER TABLE `wp_wc_webhooks`
  ADD PRIMARY KEY (`webhook_id`),
  ADD KEY `user_id` (`user_id`);

--
-- Indexes for table `wp_weforms_entries`
--
ALTER TABLE `wp_weforms_entries`
  ADD PRIMARY KEY (`id`),
  ADD KEY `form_id` (`form_id`);

--
-- Indexes for table `wp_weforms_entrymeta`
--
ALTER TABLE `wp_weforms_entrymeta`
  ADD PRIMARY KEY (`meta_id`),
  ADD KEY `meta_key` (`meta_key`(191)),
  ADD KEY `entry_id` (`weforms_entry_id`);

--
-- Indexes for table `wp_woocommerce_api_keys`
--
ALTER TABLE `wp_woocommerce_api_keys`
  ADD PRIMARY KEY (`key_id`),
  ADD KEY `consumer_key` (`consumer_key`),
  ADD KEY `consumer_secret` (`consumer_secret`);

--
-- Indexes for table `wp_woocommerce_attribute_taxonomies`
--
ALTER TABLE `wp_woocommerce_attribute_taxonomies`
  ADD PRIMARY KEY (`attribute_id`),
  ADD KEY `attribute_name` (`attribute_name`(20));

--
-- Indexes for table `wp_woocommerce_downloadable_product_permissions`
--
ALTER TABLE `wp_woocommerce_downloadable_product_permissions`
  ADD PRIMARY KEY (`permission_id`),
  ADD KEY `download_order_key_product` (`product_id`,`order_id`,`order_key`(16),`download_id`),
  ADD KEY `download_order_product` (`download_id`,`order_id`,`product_id`),
  ADD KEY `order_id` (`order_id`);

--
-- Indexes for table `wp_woocommerce_log`
--
ALTER TABLE `wp_woocommerce_log`
  ADD PRIMARY KEY (`log_id`),
  ADD KEY `level` (`level`);

--
-- Indexes for table `wp_woocommerce_order_itemmeta`
--
ALTER TABLE `wp_woocommerce_order_itemmeta`
  ADD PRIMARY KEY (`meta_id`),
  ADD KEY `order_item_id` (`order_item_id`),
  ADD KEY `meta_key` (`meta_key`(32));

--
-- Indexes for table `wp_woocommerce_order_items`
--
ALTER TABLE `wp_woocommerce_order_items`
  ADD PRIMARY KEY (`order_item_id`),
  ADD KEY `order_id` (`order_id`);

--
-- Indexes for table `wp_woocommerce_payment_tokenmeta`
--
ALTER TABLE `wp_woocommerce_payment_tokenmeta`
  ADD PRIMARY KEY (`meta_id`),
  ADD KEY `payment_token_id` (`payment_token_id`),
  ADD KEY `meta_key` (`meta_key`(32));

--
-- Indexes for table `wp_woocommerce_payment_tokens`
--
ALTER TABLE `wp_woocommerce_payment_tokens`
  ADD PRIMARY KEY (`token_id`),
  ADD KEY `user_id` (`user_id`);

--
-- Indexes for table `wp_woocommerce_sessions`
--
ALTER TABLE `wp_woocommerce_sessions`
  ADD PRIMARY KEY (`session_id`),
  ADD UNIQUE KEY `session_key` (`session_key`);

--
-- Indexes for table `wp_woocommerce_shipping_zones`
--
ALTER TABLE `wp_woocommerce_shipping_zones`
  ADD PRIMARY KEY (`zone_id`);

--
-- Indexes for table `wp_woocommerce_shipping_zone_locations`
--
ALTER TABLE `wp_woocommerce_shipping_zone_locations`
  ADD PRIMARY KEY (`location_id`),
  ADD KEY `location_id` (`location_id`),
  ADD KEY `location_type_code` (`location_type`(10),`location_code`(20));

--
-- Indexes for table `wp_woocommerce_shipping_zone_methods`
--
ALTER TABLE `wp_woocommerce_shipping_zone_methods`
  ADD PRIMARY KEY (`instance_id`);

--
-- Indexes for table `wp_woocommerce_tax_rates`
--
ALTER TABLE `wp_woocommerce_tax_rates`
  ADD PRIMARY KEY (`tax_rate_id`),
  ADD KEY `tax_rate_country` (`tax_rate_country`),
  ADD KEY `tax_rate_state` (`tax_rate_state`(2)),
  ADD KEY `tax_rate_class` (`tax_rate_class`(10)),
  ADD KEY `tax_rate_priority` (`tax_rate_priority`);

--
-- Indexes for table `wp_woocommerce_tax_rate_locations`
--
ALTER TABLE `wp_woocommerce_tax_rate_locations`
  ADD PRIMARY KEY (`location_id`),
  ADD KEY `tax_rate_id` (`tax_rate_id`),
  ADD KEY `location_type_code` (`location_type`(10),`location_code`(20));

--
-- Indexes for table `wp_wpbooking_availability`
--
ALTER TABLE `wp_wpbooking_availability`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `wp_wpbooking_availability_tour`
--
ALTER TABLE `wp_wpbooking_availability_tour`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `wp_wpbooking_favorite`
--
ALTER TABLE `wp_wpbooking_favorite`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `wp_wpbooking_order`
--
ALTER TABLE `wp_wpbooking_order`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `wp_wpbooking_order_hotel_room`
--
ALTER TABLE `wp_wpbooking_order_hotel_room`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `wp_wpbooking_payment`
--
ALTER TABLE `wp_wpbooking_payment`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `wp_wpbooking_review_helpful`
--
ALTER TABLE `wp_wpbooking_review_helpful`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `wp_wpbooking_service`
--
ALTER TABLE `wp_wpbooking_service`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `wp_wplc_chat_msgs`
--
ALTER TABLE `wp_wplc_chat_msgs`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `wp_wplc_chat_sessions`
--
ALTER TABLE `wp_wplc_chat_sessions`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `wp_wplc_offline_messages`
--
ALTER TABLE `wp_wplc_offline_messages`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `wp_wplc_webhooks`
--
ALTER TABLE `wp_wplc_webhooks`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `wp_wpuf_subscribers`
--
ALTER TABLE `wp_wpuf_subscribers`
  ADD PRIMARY KEY (`id`),
  ADD KEY `user_id` (`user_id`);

--
-- Indexes for table `wp_wpuf_transaction`
--
ALTER TABLE `wp_wpuf_transaction`
  ADD PRIMARY KEY (`id`),
  ADD KEY `user_id` (`user_id`),
  ADD KEY `post_id` (`post_id`),
  ADD KEY `pack_id` (`pack_id`),
  ADD KEY `payer_email` (`payer_email`);

--
-- Indexes for table `wp_wpuser_groups`
--
ALTER TABLE `wp_wpuser_groups`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `wp_wpuser_group_meta`
--
ALTER TABLE `wp_wpuser_group_meta`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `wp_wpuser_loginattempts`
--
ALTER TABLE `wp_wpuser_loginattempts`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `wp_wpuser_login_log`
--
ALTER TABLE `wp_wpuser_login_log`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `wp_wpuser_notification`
--
ALTER TABLE `wp_wpuser_notification`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `wp_wpuser_views`
--
ALTER TABLE `wp_wpuser_views`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `wp_wsluserscontacts`
--
ALTER TABLE `wp_wsluserscontacts`
  ADD UNIQUE KEY `id` (`id`),
  ADD KEY `user_id` (`user_id`);

--
-- Indexes for table `wp_wslusersprofiles`
--
ALTER TABLE `wp_wslusersprofiles`
  ADD UNIQUE KEY `id` (`id`),
  ADD KEY `user_id` (`user_id`),
  ADD KEY `provider` (`provider`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `activity_activities`
--
ALTER TABLE `activity_activities`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `activity_categories`
--
ALTER TABLE `activity_categories`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `activity_details`
--
ALTER TABLE `activity_details`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `available_rooms`
--
ALTER TABLE `available_rooms`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;

--
-- AUTO_INCREMENT for table `booking_info`
--
ALTER TABLE `booking_info`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `car_details`
--
ALTER TABLE `car_details`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=12;

--
-- AUTO_INCREMENT for table `car_packages`
--
ALTER TABLE `car_packages`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=8;

--
-- AUTO_INCREMENT for table `city_list`
--
ALTER TABLE `city_list`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `guide_categories`
--
ALTER TABLE `guide_categories`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT for table `guide_details`
--
ALTER TABLE `guide_details`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `guide_packages`
--
ALTER TABLE `guide_packages`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `hotel_details`
--
ALTER TABLE `hotel_details`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=57;

--
-- AUTO_INCREMENT for table `hotel_offers`
--
ALTER TABLE `hotel_offers`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=10;

--
-- AUTO_INCREMENT for table `hotel_offers_relation`
--
ALTER TABLE `hotel_offers_relation`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=150;

--
-- AUTO_INCREMENT for table `main_booking_details`
--
ALTER TABLE `main_booking_details`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=28;

--
-- AUTO_INCREMENT for table `newpluginform`
--
ALTER TABLE `newpluginform`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `new_order_img`
--
ALTER TABLE `new_order_img`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=232;

--
-- AUTO_INCREMENT for table `ratings`
--
ALTER TABLE `ratings`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT for table `restaurant_details`
--
ALTER TABLE `restaurant_details`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `star`
--
ALTER TABLE `star`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `tour_activities`
--
ALTER TABLE `tour_activities`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=11;

--
-- AUTO_INCREMENT for table `tour_details`
--
ALTER TABLE `tour_details`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=18;

--
-- AUTO_INCREMENT for table `transport_details`
--
ALTER TABLE `transport_details`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `transport_packages`
--
ALTER TABLE `transport_packages`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `transport_stopage`
--
ALTER TABLE `transport_stopage`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT for table `transport_stopage_relations`
--
ALTER TABLE `transport_stopage_relations`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `umratinguser`
--
ALTER TABLE `umratinguser`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT for table `wp_awebooking_booking_itemmeta`
--
ALTER TABLE `wp_awebooking_booking_itemmeta`
  MODIFY `meta_id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `wp_awebooking_booking_items`
--
ALTER TABLE `wp_awebooking_booking_items`
  MODIFY `booking_item_id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `wp_awebooking_rooms`
--
ALTER TABLE `wp_awebooking_rooms`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `wp_awebooking_tax_rates`
--
ALTER TABLE `wp_awebooking_tax_rates`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `wp_booking`
--
ALTER TABLE `wp_booking`
  MODIFY `booking_id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `wp_booking_package_calendaraccount`
--
ALTER TABLE `wp_booking_package_calendaraccount`
  MODIFY `key` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- AUTO_INCREMENT for table `wp_booking_package_coursedata`
--
ALTER TABLE `wp_booking_package_coursedata`
  MODIFY `key` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `wp_booking_package_emailsetting`
--
ALTER TABLE `wp_booking_package_emailsetting`
  MODIFY `key` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=26;

--
-- AUTO_INCREMENT for table `wp_booking_package_form`
--
ALTER TABLE `wp_booking_package_form`
  MODIFY `key` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- AUTO_INCREMENT for table `wp_booking_package_guests`
--
ALTER TABLE `wp_booking_package_guests`
  MODIFY `key` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=9;

--
-- AUTO_INCREMENT for table `wp_booking_package_regular_holidays`
--
ALTER TABLE `wp_booking_package_regular_holidays`
  MODIFY `key` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `wp_booking_package_schedule`
--
ALTER TABLE `wp_booking_package_schedule`
  MODIFY `key` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=235;

--
-- AUTO_INCREMENT for table `wp_booking_package_subscriptions`
--
ALTER TABLE `wp_booking_package_subscriptions`
  MODIFY `key` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `wp_booking_package_taxes`
--
ALTER TABLE `wp_booking_package_taxes`
  MODIFY `key` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `wp_booking_package_templateschedule`
--
ALTER TABLE `wp_booking_package_templateschedule`
  MODIFY `key` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `wp_booking_package_userpraivatedata`
--
ALTER TABLE `wp_booking_package_userpraivatedata`
  MODIFY `key` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `wp_booking_package_webhook`
--
ALTER TABLE `wp_booking_package_webhook`
  MODIFY `key` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `wp_bs_bookings`
--
ALTER TABLE `wp_bs_bookings`
  MODIFY `bookingID` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT for table `wp_bs_calendars`
--
ALTER TABLE `wp_bs_calendars`
  MODIFY `calendarID` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `wp_bs_forms`
--
ALTER TABLE `wp_bs_forms`
  MODIFY `formID` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `wp_commentmeta`
--
ALTER TABLE `wp_commentmeta`
  MODIFY `meta_id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=8;

--
-- AUTO_INCREMENT for table `wp_comments`
--
ALTER TABLE `wp_comments`
  MODIFY `comment_ID` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=12;

--
-- AUTO_INCREMENT for table `wp_galcategory`
--
ALTER TABLE `wp_galcategory`
  MODIFY `catid` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `wp_galimage`
--
ALTER TABLE `wp_galimage`
  MODIFY `imgid` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `wp_gdgallerygalleries`
--
ALTER TABLE `wp_gdgallerygalleries`
  MODIFY `id_gallery` int(11) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `wp_gdgalleryimages`
--
ALTER TABLE `wp_gdgalleryimages`
  MODIFY `id_image` int(11) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=11;

--
-- AUTO_INCREMENT for table `wp_gdgallerysettings`
--
ALTER TABLE `wp_gdgallerysettings`
  MODIFY `id` int(11) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=277;

--
-- AUTO_INCREMENT for table `wp_hotel_booking_order_itemmeta`
--
ALTER TABLE `wp_hotel_booking_order_itemmeta`
  MODIFY `meta_id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `wp_hotel_booking_order_items`
--
ALTER TABLE `wp_hotel_booking_order_items`
  MODIFY `order_item_id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `wp_hotel_booking_plans`
--
ALTER TABLE `wp_hotel_booking_plans`
  MODIFY `plan_id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `wp_links`
--
ALTER TABLE `wp_links`
  MODIFY `link_id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `wp_mphb_sync_logs`
--
ALTER TABLE `wp_mphb_sync_logs`
  MODIFY `log_id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `wp_mphb_sync_queue`
--
ALTER TABLE `wp_mphb_sync_queue`
  MODIFY `queue_id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `wp_mphb_sync_stats`
--
ALTER TABLE `wp_mphb_sync_stats`
  MODIFY `stat_id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `wp_options`
--
ALTER TABLE `wp_options`
  MODIFY `option_id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=28995;

--
-- AUTO_INCREMENT for table `wp_p2p_relationshipmeta`
--
ALTER TABLE `wp_p2p_relationshipmeta`
  MODIFY `meta_id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `wp_p2p_relationships`
--
ALTER TABLE `wp_p2p_relationships`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `wp_postmeta`
--
ALTER TABLE `wp_postmeta`
  MODIFY `meta_id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3513;

--
-- AUTO_INCREMENT for table `wp_posts`
--
ALTER TABLE `wp_posts`
  MODIFY `ID` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=1060;

--
-- AUTO_INCREMENT for table `wp_termmeta`
--
ALTER TABLE `wp_termmeta`
  MODIFY `meta_id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=140;

--
-- AUTO_INCREMENT for table `wp_terms`
--
ALTER TABLE `wp_terms`
  MODIFY `term_id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=217;

--
-- AUTO_INCREMENT for table `wp_termsmeta`
--
ALTER TABLE `wp_termsmeta`
  MODIFY `meta_id` bigint(20) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `wp_term_taxonomy`
--
ALTER TABLE `wp_term_taxonomy`
  MODIFY `term_taxonomy_id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=217;

--
-- AUTO_INCREMENT for table `wp_usermeta`
--
ALTER TABLE `wp_usermeta`
  MODIFY `umeta_id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=103;

--
-- AUTO_INCREMENT for table `wp_users`
--
ALTER TABLE `wp_users`
  MODIFY `ID` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `wp_wc_download_log`
--
ALTER TABLE `wp_wc_download_log`
  MODIFY `download_log_id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `wp_wc_webhooks`
--
ALTER TABLE `wp_wc_webhooks`
  MODIFY `webhook_id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `wp_weforms_entries`
--
ALTER TABLE `wp_weforms_entries`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `wp_weforms_entrymeta`
--
ALTER TABLE `wp_weforms_entrymeta`
  MODIFY `meta_id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `wp_woocommerce_api_keys`
--
ALTER TABLE `wp_woocommerce_api_keys`
  MODIFY `key_id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `wp_woocommerce_attribute_taxonomies`
--
ALTER TABLE `wp_woocommerce_attribute_taxonomies`
  MODIFY `attribute_id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `wp_woocommerce_downloadable_product_permissions`
--
ALTER TABLE `wp_woocommerce_downloadable_product_permissions`
  MODIFY `permission_id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `wp_woocommerce_log`
--
ALTER TABLE `wp_woocommerce_log`
  MODIFY `log_id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `wp_woocommerce_order_itemmeta`
--
ALTER TABLE `wp_woocommerce_order_itemmeta`
  MODIFY `meta_id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `wp_woocommerce_order_items`
--
ALTER TABLE `wp_woocommerce_order_items`
  MODIFY `order_item_id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `wp_woocommerce_payment_tokenmeta`
--
ALTER TABLE `wp_woocommerce_payment_tokenmeta`
  MODIFY `meta_id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `wp_woocommerce_payment_tokens`
--
ALTER TABLE `wp_woocommerce_payment_tokens`
  MODIFY `token_id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `wp_woocommerce_sessions`
--
ALTER TABLE `wp_woocommerce_sessions`
  MODIFY `session_id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=9;

--
-- AUTO_INCREMENT for table `wp_woocommerce_shipping_zones`
--
ALTER TABLE `wp_woocommerce_shipping_zones`
  MODIFY `zone_id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `wp_woocommerce_shipping_zone_locations`
--
ALTER TABLE `wp_woocommerce_shipping_zone_locations`
  MODIFY `location_id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `wp_woocommerce_shipping_zone_methods`
--
ALTER TABLE `wp_woocommerce_shipping_zone_methods`
  MODIFY `instance_id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `wp_woocommerce_tax_rates`
--
ALTER TABLE `wp_woocommerce_tax_rates`
  MODIFY `tax_rate_id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `wp_woocommerce_tax_rate_locations`
--
ALTER TABLE `wp_woocommerce_tax_rate_locations`
  MODIFY `location_id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `wp_wpbooking_availability`
--
ALTER TABLE `wp_wpbooking_availability`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `wp_wpbooking_availability_tour`
--
ALTER TABLE `wp_wpbooking_availability_tour`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `wp_wpbooking_favorite`
--
ALTER TABLE `wp_wpbooking_favorite`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `wp_wpbooking_order`
--
ALTER TABLE `wp_wpbooking_order`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `wp_wpbooking_order_hotel_room`
--
ALTER TABLE `wp_wpbooking_order_hotel_room`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `wp_wpbooking_payment`
--
ALTER TABLE `wp_wpbooking_payment`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `wp_wpbooking_review_helpful`
--
ALTER TABLE `wp_wpbooking_review_helpful`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `wp_wpbooking_service`
--
ALTER TABLE `wp_wpbooking_service`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `wp_wplc_chat_msgs`
--
ALTER TABLE `wp_wplc_chat_msgs`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `wp_wplc_chat_sessions`
--
ALTER TABLE `wp_wplc_chat_sessions`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `wp_wplc_offline_messages`
--
ALTER TABLE `wp_wplc_offline_messages`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `wp_wplc_webhooks`
--
ALTER TABLE `wp_wplc_webhooks`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `wp_wpuf_subscribers`
--
ALTER TABLE `wp_wpuf_subscribers`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `wp_wpuf_transaction`
--
ALTER TABLE `wp_wpuf_transaction`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `wp_wpuser_groups`
--
ALTER TABLE `wp_wpuser_groups`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `wp_wpuser_group_meta`
--
ALTER TABLE `wp_wpuser_group_meta`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `wp_wpuser_loginattempts`
--
ALTER TABLE `wp_wpuser_loginattempts`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `wp_wpuser_login_log`
--
ALTER TABLE `wp_wpuser_login_log`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `wp_wpuser_notification`
--
ALTER TABLE `wp_wpuser_notification`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `wp_wpuser_views`
--
ALTER TABLE `wp_wpuser_views`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `wp_wsluserscontacts`
--
ALTER TABLE `wp_wsluserscontacts`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `wp_wslusersprofiles`
--
ALTER TABLE `wp_wslusersprofiles`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- Constraints for dumped tables
--

--
-- Constraints for table `wp_gdgalleryimages`
--
ALTER TABLE `wp_gdgalleryimages`
  ADD CONSTRAINT `wp_gdgalleryimages_ibfk_1` FOREIGN KEY (`id_gallery`) REFERENCES `wp_gdgallerygalleries` (`id_gallery`) ON DELETE CASCADE;

--
-- Constraints for table `wp_wc_download_log`
--
ALTER TABLE `wp_wc_download_log`
  ADD CONSTRAINT `fk_wp_wc_download_log_permission_id` FOREIGN KEY (`permission_id`) REFERENCES `wp_woocommerce_downloadable_product_permissions` (`permission_id`) ON DELETE CASCADE;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
