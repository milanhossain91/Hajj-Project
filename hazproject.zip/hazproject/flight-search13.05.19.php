
<?php
/**
 * The flight search template file
 *
 * This is the most generic template file in a WordPress theme
 * and one of the two required files for a theme (the other being style.css).
 * It is used to display a page when nothing more specific matches a query.
 * E.g., it puts together the home page when no home.php file exists.
 *
 * @link https://developer.wordpress.org/themes/basics/template-hierarchy/
 *
 * @package aynix
 */
 /*
  Template Name: flight-search
*/
get_header(); ?>

    <!-- mobile-menu-area start -->
        <div class="mobile-menu-area">
          <div class="container">
            <div class="row">
              <div class="col-md-12">
                <div class="mobile-menu">
                  <nav id="dropdown">
                    <ul>
                        <li class="active"><a href="#">Home</a>
                            <ul>
                                <li><a href="#">Sub Item</a></li>
                                <li><a href="#">Sub Item</a></li>
                                <li><a href="#">Sub Item</a></li>
                                <li><a href="#">Sub Item</a></li>
                                <li><a href="#">Sub Item</a></li>
                                <li><a href="#">Sub Item</a></li>
                                <li><a href="#">Sub Item</a></li>
                            </ul>
                        </li>
                        <li><a href="#">Projects</a></li>
                        <li><a href="#">Activities</a></li>
                        <li><a href="#">Total Jobs</a></li>
                        <li><a href="#">Flights</a></li>
                        <li><a href="#">Hotels</a></li>
                    </ul>
                  </nav>
                </div>
              </div>
            </div>
          </div>
        </div>
        <!-- mobile-menu-area end -->



    <div class="search-area has-border u-padding-t-60">
        <div class="container">


              <?php 

                          

                                    $args = array(
                                       
                                        'depth'               => 0,
                                        'echo'                => 1,
                                        'exclude'             => '',
                                        'exclude_tree'        => '',
                                        'feed'                => '',
                                        'feed_image'          => '',
                                        'feed_type'           => '',
                                        'hide_empty'          => 0,
                                        'hide_title_if_empty' => false,
                                        'hierarchical'        => true,
                                        'order'               => 'ASC',
                                        'orderby'             => 'name',
                                        'separator'           => '',
                                        'show_count'          => 1,
                                        'show_option_all'     => '',
                                        'show_option_none'    => __( 'No categories' ),
                                        'style'               => 'list',
                                        'taxonomy'            => 'locationform',
                                        'title_li'            => __( $current_category_name ),
                                        'use_desc_for_title'  => 0,
                                    );

                                      $categories = get_categories($args);  
                                        $locationform = array();  
                                        foreach ($categories as $category_list ) 
                                        {  
                                              $locationform[$category_list->cat_ID] = $category_list->cat_name;  
                                        } 

                                   

                                    $args = array(
                                        
                                        'depth'               => 0,
                                        'echo'                => 1,
                                        'exclude'             => '',
                                        'exclude_tree'        => '',
                                        'feed'                => '',
                                        'feed_image'          => '',
                                        'feed_type'           => '',
                                        'hide_empty'          => 0,
                                        'hide_title_if_empty' => false,
                                        'hierarchical'        => true,
                                        'order'               => 'ASC',
                                        'orderby'             => 'name',
                                        'separator'           => '',
                                        'show_count'          => 1,
                                        'show_option_all'     => '',
                                        'show_option_none'    => __( 'No categories' ),
                                        'style'               => 'list',
                                        'taxonomy'            => 'locationto',
                                        'title_li'            => __( $current_category_name ),
                                        'use_desc_for_title'  => 0,
                                    );

                                      $categories = get_categories($args);  
                                        $locationto = array();  
                                        foreach ($categories as $category_list ) 
                                        {  
                                              $locationto[$category_list->cat_ID] = $category_list->cat_name;  
                                        } 

                                      $args = array(
                                        
                                        'depth'               => 0,
                                        'echo'                => 1,
                                        'exclude'             => '',
                                        'exclude_tree'        => '',
                                        'feed'                => '',
                                        'feed_image'          => '',
                                        'feed_type'           => '',
                                        'hide_empty'          => 0,
                                        'hide_title_if_empty' => false,
                                        'hierarchical'        => true,
                                        'order'               => 'ASC',
                                        'orderby'             => 'name',
                                        'separator'           => '',
                                        'show_count'          => 1,
                                        'show_option_all'     => '',
                                        'show_option_none'    => __( 'No categories' ),
                                        'style'               => 'list',
                                        'taxonomy'            => 'departuredate',
                                        'title_li'            => __( $current_category_name ),
                                        'use_desc_for_title'  => 0,
                                    );

                                      $categories = get_categories($args);  
                                        $departuredate = array();  
                                        foreach ($categories as $category_list ) 
                                        {  
                                              $departuredate[$category_list->cat_ID] = $category_list->cat_name;  
                                        } 


                                         $args = array(
                                        
                                        'depth'               => 0,
                                        'echo'                => 1,
                                        'exclude'             => '',
                                        'exclude_tree'        => '',
                                        'feed'                => '',
                                        'feed_image'          => '',
                                        'feed_type'           => '',
                                        'hide_empty'          => 0,
                                        'hide_title_if_empty' => false,
                                        'hierarchical'        => true,
                                        'order'               => 'ASC',
                                        'orderby'             => 'name',
                                        'separator'           => '',
                                        'show_count'          => 1,
                                        'show_option_all'     => '',
                                        'show_option_none'    => __( 'No categories' ),
                                        'style'               => 'list',
                                        'taxonomy'            => 'roundtrip',
                                        'title_li'            => __( $current_category_name ),
                                        'use_desc_for_title'  => 0,
                                    );

                                      $categories = get_categories($args);  
                                        $roundtrip = array();  
                                        foreach ($categories as $category_list ) 
                                        {  
                                              $roundtrip[$category_list->cat_ID] = $category_list->cat_name;  
                                        } 


                                    $args = array(
                                        
                                        'depth'               => 0,
                                        'echo'                => 1,
                                        'exclude'             => '',
                                        'exclude_tree'        => '',
                                        'feed'                => '',
                                        'feed_image'          => '',
                                        'feed_type'           => '',
                                        'hide_empty'          => 0,
                                        'hide_title_if_empty' => false,
                                        'hierarchical'        => true,
                                        'order'               => 'ASC',
                                        'orderby'             => 'name',
                                        'separator'           => '',
                                        'show_count'          => 1,
                                        'show_option_all'     => '',
                                        'show_option_none'    => __( 'No categories' ),
                                        'style'               => 'list',
                                        'taxonomy'            => 'passenger',
                                        'title_li'            => __( $current_category_name ),
                                        'use_desc_for_title'  => 0,
                                    );

                                      $categories = get_categories($args);  
                                        $passenger = array();  
                                        foreach ($categories as $category_list ) 
                                        {  
                                              $passenger[$category_list->cat_ID] = $category_list->cat_name;  
                                        } 



                                    if($_POST['locationform'] && !empty($_POST['locationform']))
                                    {
                                        $locationform = $_POST['locationform'];
                                    }

                                    if($_POST['locationto'] && !empty($_POST['locationto']))
                                    {
                                        $locationto = $_POST['locationto'];
                                    }
                                    if($_POST['departuredate'] && !empty($_POST['departuredate']))
                                    {
                                        $departuredate = $_POST['departuredate'];
                                    }

                                    if($_POST['roundtrip'] && !empty($_POST['roundtrip']))
                                    {
                                        $roundtrip = $_POST['roundtrip'];
                                    }
                                    if($_POST['passenger'] && !empty($_POST['passenger']))
                                    {
                                        $passenger = $_POST['passenger'];
                                    }


                                
                                 


                                ?>





            <form action="<?php the_permalink(); ?>" method="post">
                <h1 class="title">Search for Flights</h1>
                <div class="flight-tab">
                      
                                <!-- Tab panes -->
                                <div class="tab-content">
                                  <div role="tabpanel" class="tab-pane fade in active show" id="flight-tab1">
                                      
                            <div class="tf-row row">

                                
                                <div class="tf-col col-lg-3">
                                 <label for="desti">From</label>
                                   <select class="form-control" name="locationform">

                                    <option>Select Location</option>
                                    <?php foreach ($locationform as $v) { ;?>
                                     <option value="<?php echo $v;?>"><?php echo $v;?></option>
                                    <?php } ; ?>
                                  </select>
                                </div>


                                <div class="tf-col col-lg-3">
                                    <label for="desti">To</label>
                                    <select class="form-control" name="locationto">
                                    <option>Select Location</option>
                                    <?php foreach ($locationto as $v) { ;?>
                                     <option value="<?php echo $v;?>"><?php echo $v;?></option>
                                    <?php } ; ?>
                                  </select>
                                </div>



                                <div class="tf-col col-lg-2">

                                 <label for="desti">Departing Date</label>

                                 <select class="form-control" name="departuredate">
                                    <option>Passenger</option>
                                    <?php foreach ($departuredate as $v) { ;?>
                                     <option value="<?php echo $v;?>"><?php echo $v;?></option>
                                    <?php } ; ?>
                                  </select>

                                    
                                </div>
                                <div class="tf-col col-lg-2">

                                <label class="container" for="desti">Round Trip</label>
                                 <?php

                                 if (is_array($roundtrip) || is_object($roundtrip))
                                  {

                                  foreach ($roundtrip as $v) { ;?>
                                  
                                <input type="checkbox" name="roundtrip" value="<?php echo $v;?>">
                                 <?php 
                                   }
                                }

                                  ; ?>
                                    
                                </div>

                                <div class="tf-col col-lg-2">

                            

                                <label for="desti">Passenger</label>

                                <select class="form-control" name="passenger">
                                    <option>Passenger</option>
                                    <?php foreach ($passenger as $v) { ;?>
                                     <option value="<?php echo $v;?>"><?php echo $v;?></option>
                                    <?php } ; ?>
                                  </select>
                                   
                              </div>
                                
                                <div class="col-lg-12">
                                    <div class="btn-area">
                                        <button class="btn btn-primary btn-md" type="submit">Search For Flight</button>
                                    </div>
                                </div>

                            </div>
                        
                                  </div>
                               
                                </div>
                            </div>
            </form>
        </div>
    </div>

    <div class="popural u-padding-t-50 u-padding-b-30">
        <div class="container">
            <div class="sec-ti">
                <h2 class="font-weight300">Popular Flight Destinations</h2>
            </div>
            <div class="row">

                <?php

                              $args = array(
                                      'order' => 'asc',
                                      'order_by' => 'title',
                                      'post_type' => 'flights', 
                                      'posts_per_page' => 0,
                                          'tax_query' => array(

                                            'relation' => 'AND',

                                            array(
                                                
                                                'taxonomy' => 'locationform', 
                                                'field' => 'slug',
                                                'terms' => $locationform,
                                                
                                                
                                            ),


                                            array(
                                                
                                                'taxonomy' => 'locationto', 
                                                'field' => 'slug',
                                                'terms' => $locationto,
                                                
                                                
                                            ),

                                             array(
                                                
                                                'taxonomy' => 'departuredate', 
                                                'field' => 'slug',
                                                'terms' => $departuredate,
                                                
                                                
                                            ),

                                            array(
                                                
                                                'taxonomy' => 'roundtrip', 
                                                'field' => 'slug',
                                                'terms' => $roundtrip,
                                                
                                                
                                            ),

                                            array(
                                                
                                                'taxonomy' => 'passenger', 
                                                'field' => 'slug',
                                                'terms' => $passenger,
                                                
                                                
                                           ),

                                      
                                        )
                                      );

          
                             

               $query = new WP_Query($args);
             
               if ($query -> have_posts()):
               while($query -> have_posts()) : $query -> the_post();?>
                      

                    <div class="col-sm-3">
                        <div class="pop-item">
                            <a href="<?php the_permalink(); ?>">
                                <?php the_post_thumbnail();?>
                                <div class="content">
                                    <h5><?php the_title();?></h5>                              
                                    <p class="mb0">Price : <?php echo get_post_meta( get_the_ID(), 'fprice', true );?></p>
                                </div>
                            </a>
                        </div>
                    </div>

                   <?php 

                   endwhile; 
                

                 else: 
               

                    $ourteams = new WP_Query(array(
                  'post_type' => 'flights', 
                  'posts_per_page' => 0 
                  ));

                    while ($ourteams->have_posts() ) : 
                 $ourteams->the_post();


                    ?>

                    <div class="col-sm-3">
                        <div class="pop-item">
                            <a href="<?php the_permalink(); ?>">
                                <?php the_post_thumbnail();?>
                                <div class="content">
                                    <h5><?php the_title();?></h5>                              
                                    <p class="mb0">Price : <?php echo get_post_meta( get_the_ID(), 'fprice', true );?></p>
                                </div>
                            </a>
                        </div>
                    </div>



                   <?php
                      endwhile; 
                         wp_reset_postdata();
                        endif;
                    ?>

               

            </div>
        </div>
    </div>

<?php get_footer();?>