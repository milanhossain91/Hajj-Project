<?php

global $wpdb;

if(isset($_GET['order_id'])){
   $order_id = $_GET['order_id'];   
 }
  if(isset($_GET['room_id'])){
       $room_id = $_GET['room_id'];   
     }
    
    if(isset($_GET['check_in'])){
     
      $check_in = date("Y-m-d", strtotime($_GET['check_in']));   
      
     }

    if(isset($_GET['check_out'])){ 
      $check_out = date("Y-m-d", strtotime($_GET['check_out']));   
     } 

     if(isset($_GET['u_rooms'])){
     $u_rooms = $_GET['u_rooms']; 
     }  

      if(isset($_GET['u_adults'])){
     $u_adults = $_GET['u_adults']; 
     } 
 
     if(isset($_GET['u_children'])){
     $u_children = $_GET['u_children']; 
     } 
    

      $extra_price = 0; 
      $Tax = 0; 
      $Total_price = $room_price+$extra_price+$Tax;  

 
       

 
                 
                             
$wp_post_db = "available_rooms"; 
$show_vendor_posts = $wpdb->get_results("SELECT * FROM $wp_post_db WHERE hotel_id='$room_id' ORDER BY id DESC"); 
$i=0;
foreach( $show_vendor_posts as $show_vendor_post) 
{  

   //print_r($show_vendor_post);
   $rid =  $show_vendor_post->id;   
   $room_id =  $show_vendor_post->hotel_id;   
   $room_title =  $show_vendor_post->room_title;  
   $room_description =  $show_vendor_post->room_description;    
   $room_price =  $show_vendor_post->room_price;    
   $date_added =  $show_vendor_post->date_added;     
   }                                                          
                      



//booking form room-details-template.php



if($_POST['hotel_booking']){

  if(isset($_POST['room_id'])){
     $room_id = $_POST['room_id'];   
     }
  
    if(isset($_POST['check_in'])){
     $check_in = $_POST['check_in'];   
     }

    if(isset($_POST['check_out'])){
     $check_out = $_POST['check_out']; 
     } 


    if(isset($_POST['u_rooms'])){
     $u_rooms = $_POST['u_rooms']; 
     }  

      if(isset($_POST['u_adults'])){
     $u_adults = $_POST['u_adults']; 
     } 
 
     if(isset($_POST['u_children'])){
     $u_children = $_POST['u_children']; 
     } 


    $location =  site_url().'/hotel-booking/?room_id='.$room_id.'&check_in='.$check_in.'&check_out='.$check_out.'&u_rooms='.$u_rooms.'&u_adults='.$u_adults.'&u_children='.$u_children;  
    echo '<script type="text/javascript">window.location.href = "'.$location.'"</script>';


}


///===========================hotel booking================================

function getHotelIdByRoomId($roomID){ 
global $wpdb;
$wp_post_db = "available_rooms"; 
$show_vendor_posts = $wpdb->get_results("SELECT hotel_id FROM $wp_post_db WHERE id='$roomID'");  
foreach( $show_vendor_posts as $show_vendor_posts) 
{   
   return  $show_vendor_posts->hotel_id;   
    
}
}
 
  
 




if(isset($_POST['hotel_booking_submit'])){ 

// Create rooms object
$bookingData = array(   

  'user_id'           => get_current_user_id(),   
  'post_parent_id'           => getHotelIdByRoomId($room_id),
  'post_id'       => $room_id, //available room
  'check_in'    => $check_in,
  'check_out'       => $check_out, 

  'booking_total'       => $_POST['booking_total'],
  'u_name' => $_POST['u_name'], 
  'u_cell'       => $_POST['u_cell'], 

  'u_email'       => $_POST['u_email'], 
  'u_address'       => $_POST['u_address'], 
  'u_city'       => $_POST['u_city'],  
    
  'u_rooms'    => $u_rooms,
  'u_children'       => $u_children,  
  'u_adults'       => $u_adults,  
  'service_type'       => 'hotels',  
  
  
);  
//print_r($bookingData);

$order_id =  $wpdb->insert('main_booking_details', $bookingData );    
if($order_id){
 $location =  site_url().'/hotel-booking/?order_id='.$order_id.'&room_id='.$room_id.'&check_in='.$check_in.'&check_out='.$check_out.'&u_rooms='.$u_rooms.'&u_adults='.$u_adults.'&u_children='.$u_children;  
    echo '<script type="text/javascript">window.location.href = "'.$location.'"</script>';
}

}
?>

 