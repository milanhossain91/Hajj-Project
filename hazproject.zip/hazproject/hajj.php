<?php
/**
 * The template for displaying all single posts
 *
 * @link https://developer.wordpress.org/themes/basics/template-hierarchy/#single-post
 *
 * @package venox
 */
 /*
  Template Name: Hajj
*/

get_header();
?>


        <div class="hajj-pack has-border has-border">
            <div class="container">
                <div class="row">
                    <div class="col-lg-10">
                        <div class="pk-title">
                            <h1>Hajj Packages</h1>
                        </div>

                        <ul class="hajj-pk-item">

                        <?php	  
                   $ourhajj = new WP_Query(array(
                  'post_type' => 'hajj', 
                  'posts_per_page' => 0 
                  ));

                  
                    while ($ourhajj->have_posts() ) : 
                 $ourhajj->the_post();
                 ?>

                            <li>
                                <h3><?php the_title(); ?></h3>
                                <p><?php the_content(); ?></p>
                                <figure>
                                    <a href="<?php the_permalink(); ?>">
                                       <?php 
                                                 $title=get_the_title();
                                                 the_post_thumbnail( array(1051, 888),array( 'alt' =>$title) );

                                                 ?>
                                    </a>
                                </figure>
                            </li>

                        <?php endwhile;   ?>  

                        </ul> 

                    </div>
                </div>
            </div>
        </div>


<?php get_footer();?>